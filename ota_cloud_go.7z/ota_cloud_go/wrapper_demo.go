package main

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/proto"
	"fmt"
	"go-micro.dev/v4/server"
	"reflect"
	"time"
)

func ServiceName(name string) Option {
	return func(opts *Options) {
		opts.Name = name
	}
}

func ServiceVersion(version string) Option {
	return func(opts *Options) {
		opts.Version = version
	}
}

func ServiceID(id string) Option {
	return func(opts *Options) {
		opts.ID = id
	}
}

type Options struct {
	Name    string
	Version string
	ID      string
}
type Option func(*Options)

func NewHandlerWrapper(opts ...Option) server.HandlerWrapper {
	options := Options{}
	for _, opt := range opts {
		opt(&options)
	}

	handler := &wrapper{
		options: options,
	}

	return handler.HandlerFunc
}

type wrapper struct {
	options Options
}

func (w *wrapper) HandlerFunc(fn server.HandlerFunc) server.HandlerFunc {
	return func(ctx context.Context, req server.Request, rsp interface{}) error {
		endpoint := req.Endpoint()
		beginTime := time.Now()
		logger.Infof("--------> cost begin-------> 1, %v, endpoint: %v", w.options.Name, endpoint)

		logger.Infof("service: %v, method: %v, req type: %v, req: %v", req.Service(), req.Method(), reflect.TypeOf(req.Body()), req.Body())
		reqBody := reflect.ValueOf(req.Body())
		var bussiReq *proto.ExecuteBussinessRequest = nil
		var ok bool

		if reqBody.Kind() == reflect.Ptr {
			bussiReq, ok = reqBody.Interface().(*proto.ExecuteBussinessRequest)
			if !ok {
				return fmt.Errorf("request body is not proto.ExecuteBussinessRequest pointer")
			}
		} else {
			return fmt.Errorf("request body is not ptr")
		}

		url := bussiReq.GetUrl()
		//
		//data := bussiReq.GetData()
		// 解析body. 根据 url 解析得到具体的结构。
		//gpb.Unmarshal(data, v)

		ctx = context.WithValue(ctx, "x1", "v1")
		err := fn(ctx, req, rsp)
		endTime := time.Now()
		diff := endTime.Sub(beginTime)

		//respValue := reflect.ValueOf(rsp)
		logger.Infof("response type: %v", reflect.TypeOf(rsp))
		logger.Infof("-----------> url: %v, cost end -------> 2, cost time: %+v, w.name: %v, w.ID: %v", url, diff, w.options.Name, w.options.ID)
		logger.Infof("resp: %+v", rsp)
		return err
	}
}
