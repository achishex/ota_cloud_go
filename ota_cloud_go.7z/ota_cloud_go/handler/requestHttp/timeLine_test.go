package requestHttp

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/evidence_report"
	pb "cuav-cloud-go-service/proto"
	"testing"
)

func TestCheckInvalidTrackId(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	evidence_report.MockTargetEventDbHandle(dbHandler)

	var testInParam = map[int64]*pb.TimelineListResItem{}
	testInParam[1306186197254406156] = &pb.TimelineListResItem{
		TrackId: "1303495108966875136",
		Id:      1306186197254406156,
	}
	//testInParam[1306186029750681606] = &pb.TimelineListResItem{
	//	TrackId: "1303483357936353280",
	//	Id:      1306186029750681606,
	//}
	testInParam[1306185716218068998] = &pb.TimelineListResItem{
		TrackId: "1303483357936353280", //1303483357936353280
		Id:      1306185716218068998,
	}
	testInParam[1306187988255768578] = &pb.TimelineListResItem{
		TrackId: "1306187988633780226",
		Id:      1306187988255768578,
	}

	for k, v := range testInParam {
		t.Logf("id: %v, item: %v", k, *v)
	}

	//
	retItems := CheckInvalidTrackId(testInParam)
	t.Logf("------------------")
	for id, item := range retItems {
		t.Logf("id: %v, item: %v", id, *item)
	}
}
