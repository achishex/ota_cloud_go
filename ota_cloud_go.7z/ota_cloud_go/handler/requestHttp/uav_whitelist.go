package requestHttp

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/errorcode"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	tmodel "cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/handler/response"
	"cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"
)

const (
	UavWhiteListNumLimit = 500
)

type uavWhitelistHandler struct {
	acc db.UavWhitelistAccess
	rds redis.SkyFendRedisOps
}

func NewUavWhitelistHandler(gdb *gorm.DB) *uavWhitelistHandler {
	return &uavWhitelistHandler{
		acc: db.NewBaseAccessImpl(gdb),
		rds: config.GlobalRedis,
	}
}

// UavWhitelistAdd 无人机白名单添加
func (u *uavWhitelistHandler) UavWhitelistAdd(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UavWhitelistAdd.")
	req := &pb.UavWhitelistAddReq{}
	if err := json.NewDecoder(r.Body).Decode(req); err != nil {
		common.DefaultResponse(w, nil, errors.New("UavWhitelistAdd decode request body error: "+err.Error()), common.HTTPFailed)
		return
	}
	if req.SerialNum == "" {
		logger.Error("SerialNum empty")
		common.CommonResponse(w, *r, nil, errorcode.ParameterInvalid)
		return
	}
	uwl := &model.TUavWhite{Model: req.Model, SerialNum: req.SerialNum}
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		common.CommonResponse(w, *r, nil, errorcode.ParseTokenPayloadError)
		return
	}
	uw := &model.TUavWhite{}
	if err := u.acc.First(nil, uw, "tb_code = ? and serial_num = ? and status = ?",
		token.Payload.TbCode, req.SerialNum, constant.EffectStatus); err != nil {
		logger.Errorf("First TUavWhite error: %s", err.Error())
	}
	if uw.Id != 0 && uw.Role == constant.FriendlyArmy {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		common.CommonResponse(w, *r, nil, errorcode.RecordDuplication)
		return
	}
	uws := make([]*model.TUavWhite, 0, 4)
	if err := u.acc.Find(nil, &uws, "tb_code = ? and status = ?", token.Payload.TbCode, constant.EffectStatus); err != nil {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		logger.Errorf("Find TUavWhite error: %s", err.Error())
		common.CommonResponse(w, *r, nil, errorcode.NotFoundError)
		return
	}
	if len(uws) >= UavWhiteListNumLimit {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		logger.Warnf("Failed to add UavWhitelist: more than %d", UavWhiteListNumLimit)
		common.CommonResponse(w, *r, nil, errorcode.UavWhiteAddOutLimit, UavWhiteListNumLimit, len(uws))
		return
	}
	id, err := snowflake.GetUniqueID()
	if err != nil {
		logger.Errorf("Failed to get snowflake id: %v", err)
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	now := time.Now().UTC()
	uavWhiteLsit := &model.TUavWhite{
		Id:         id,
		SerialNum:  req.SerialNum,
		TbCode:     token.Payload.TbCode,
		Vendor:     req.Vendor,
		Model:      req.Model,
		Usage:      int(req.Usage),
		Role:       constant.FriendlyArmy,
		UsageDesc:  req.UsageDesc,
		Remark:     req.Remark,
		Status:     constant.EffectStatus,
		CreateTime: now,
		UpdateTime: now,
	}
	tx := u.acc.DB().Begin()
	if uw.Id != 0 && uw.Role != constant.FriendlyArmy {
		uavWhiteLsit.Id = uw.Id
		if _, err := u.acc.Updates(tx, uavWhiteLsit); err != nil {
			tx.Rollback()
			logger.Errorf("db Update error: %s", err.Error())
			common.DefaultResponse(w, nil, errors.New("db Update error"), common.HTTPFailed)
			return
		}
	} else {
		if err := u.acc.Insert(tx, uavWhiteLsit); err != nil {
			tx.Rollback()
			logger.Errorf("db create error: %s", err.Error())
			common.DefaultResponse(w, nil, errors.New("db create error"), common.HTTPFailed)
			return
		}
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}
	if err := u.rds.SetEx(model.GetUavWhitelistKey(*uavWhiteLsit), uavWhiteLsit.SerialNum, time.Hour*24); err != nil {
		logger.Errorf("Failed to SetEx redis key %s : %s", model.GetUavWhitelistKey(*uw), err.Error())
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)

	go addUwOperationLog(uavWhiteLsit, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)

	common.DefaultResponse(w, pb.UavWhitelistAddRes{}, nil, common.HTTPSucceed)
}

// UavWhitelistAdd 无人机白名单添加
func (u *uavWhitelistHandler) UavWhitelistAdd2(ctx context.Context, req *pb.UavWhitelistAddReq) (*pb.UavWhitelistAddRes, error) {
	logger.Info("-----------------Receive UavWhitelistAdd.")
	if req.SerialNum == "" {
		logger.Error("SerialNum empty")
		return nil, error_collect.GetError(errorcode.ParameterInvalid)
	}
	uwl := &model.TUavWhite{Model: req.Model, SerialNum: req.SerialNum}
	token := protocals.GetToken(ctx)
	uw := &model.TUavWhite{}
	if err := u.acc.First(nil, uw, "tb_code = ? and serial_num = ? and status = ?",
		token.Payload.TbCode, req.SerialNum, constant.EffectStatus); err != nil {
		logger.Errorf("First TUavWhite error: %s", err.Error())
	}
	if uw.Id != 0 && uw.Role == constant.FriendlyArmy {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		return nil, error_collect.GetError(errorcode.RecordDuplication)
	}
	uws := make([]*model.TUavWhite, 0, 4)
	if err := u.acc.Find(nil, &uws, "tb_code = ? and status = ?", token.Payload.TbCode, constant.EffectStatus); err != nil {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		logger.Errorf("Find TUavWhite error: %s", err.Error())
		return nil, error_collect.GetError(errorcode.NotFoundError)
	}
	if len(uws) >= UavWhiteListNumLimit {
		go addUwOperationLog(uwl, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)
		logger.Warnf("Failed to add UavWhitelist: more than %d", UavWhiteListNumLimit)
		return nil, error_collect.GetErrorWithArgs(errorcode.UavWhiteAddOutLimit, UavWhiteListNumLimit, len(uws))
	}
	id, err := snowflake.GetUniqueID()
	if err != nil {
		logger.Errorf("Failed to get snowflake id: %v", err)
		return nil, error_collect.GetError(errorcode.UavWhiteAddError)
	}
	now := time.Now().UTC()
	uavWhiteLsit := &model.TUavWhite{
		Id:         id,
		SerialNum:  req.SerialNum,
		TbCode:     token.Payload.TbCode,
		Vendor:     req.Vendor,
		Model:      req.Model,
		Usage:      int(req.Usage),
		Role:       constant.FriendlyArmy,
		UsageDesc:  req.UsageDesc,
		Remark:     req.Remark,
		Status:     constant.EffectStatus,
		CreateTime: now,
		UpdateTime: now,
	}
	tx := u.acc.DB().Begin()
	if uw.Id != 0 && uw.Role != constant.FriendlyArmy {
		uavWhiteLsit.Id = uw.Id
		if _, err := u.acc.Updates(tx, uavWhiteLsit); err != nil {
			tx.Rollback()
			logger.Errorf("db Update error: %s", err.Error())
			return nil, error_collect.GetError(errorcode.UavWhiteAddError)
		}
	} else {
		if err := u.acc.Insert(tx, uavWhiteLsit); err != nil {
			tx.Rollback()
			logger.Errorf("db create error: %s", err.Error())
			return nil, error_collect.GetError(errorcode.UavWhiteAddError)
		}
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}
	if err := u.rds.SetEx(model.GetUavWhitelistKey(*uavWhiteLsit), uavWhiteLsit.SerialNum, time.Hour*24); err != nil {
		logger.Errorf("Failed to SetEx redis key %s : %s", model.GetUavWhitelistKey(*uw), err.Error())
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)

	go addUwOperationLog(uavWhiteLsit, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil)

	return &pb.UavWhitelistAddRes{}, nil
}

// UavWhitelistUpdate 无人机名单更新
func (u *uavWhitelistHandler) UavWhitelistUpdate(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UavWhitelistUpdate.")
	req := &pb.UavWhitelistUpdateReq{}
	if err := json.NewDecoder(r.Body).Decode(req); err != nil {
		common.DefaultResponse(w, nil, errors.New("UavWhitelistUpdate decode request body error: "+err.Error()), common.HTTPFailed)
		return
	}
	uwId, err := strconv.ParseInt(req.Id, 10, 64)
	if err != nil {
		common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete params error: "+err.Error()), common.HTTPFailed)
		return
	}
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	uw := &model.TUavWhite{}
	if err := u.acc.First(nil, uw, "id = ?", uwId); err != nil {
		logger.Errorf("First TUavWhite error: %s", err.Error())
		common.DefaultResponse(w, nil, errors.New("UavWhitelistUpdate error, record not exist"), common.HTTPFailed)
		return
	}
	if token.Payload.TbCode != uw.TbCode {
		logger.Errorf("Payload error: not match")
		common.DefaultResponse(w, nil, errors.New("payload error: not match"), common.HTTPFailed)
		return
	}
	updateMap := make(map[string]any)
	if compareAndGetDiff(req, *uw, updateMap) {
		logger.Warn("whitelist same, not update")
		common.DefaultResponse(w, struct{}{}, nil, common.HTTPSucceed)
		return
	}
	tx := u.acc.DB().Begin()
	effectCount, err := u.acc.Update(tx, uw, updateMap, "id = ?", uwId)
	if err != nil {
		tx.Rollback()
		logger.Errorf("Update TUavWhite error: %s", err.Error())
		common.DefaultResponse(w, nil, errors.New("UavWhitelist Update error"), common.HTTPFailed)
		return
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)
	// 添加操作日志
	go addUwOperationLog(uw, token, constant.OperationLogOperationTypeUpdate, constant.OperationLogBusinessTypeWhitelistUpdate, updateMap)

	common.DefaultResponse(w, pb.UavWhitelistUpdateRes{EffectCount: int32(effectCount)}, nil, common.HTTPSucceed)
}

// UavWhitelistUpdate 无人机名单更新
func (u *uavWhitelistHandler) UavWhitelistUpdate2(ctx context.Context, req *pb.UavWhitelistUpdateReq) (*pb.UavWhitelistUpdateRes, error) {
	logger.Info("-----------------Receive UavWhitelistUpdate.")

	uwId, err := strconv.ParseInt(req.Id, 10, 64)
	if err != nil {
		return nil, error_collect.GetError(errorcode.ParameterInvalid)
	}
	token := protocals.GetToken(ctx)

	uw := &model.TUavWhite{}
	if err := u.acc.First(nil, uw, "id = ?", uwId); err != nil {
		logger.Errorf("First TUavWhite error: %s", err.Error())
		return nil, error_collect.GetError(errorcode.NotFoundError)
	}
	if token.Payload.TbCode != uw.TbCode {
		logger.Errorf("Payload error: not match")
		return nil, error_collect.GetError(errorcode.ParameterInvalid)
	}
	updateMap := make(map[string]any)
	if compareAndGetDiff(req, *uw, updateMap) {
		logger.Warn("whitelist same, not update")
		return &pb.UavWhitelistUpdateRes{}, nil
	}
	tx := u.acc.DB().Begin()
	effectCount, err := u.acc.Update(tx, uw, updateMap, "id = ?", uwId)
	if err != nil {
		tx.Rollback()
		logger.Errorf("Update TUavWhite error: %s", err.Error())
		return nil, error_collect.GetError(errorcode.UavWhitelistUpdateError)
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)
	// 添加操作日志
	go addUwOperationLog(uw, token, constant.OperationLogOperationTypeUpdate, constant.OperationLogBusinessTypeWhitelistUpdate, updateMap)

	return &pb.UavWhitelistUpdateRes{EffectCount: int32(effectCount)}, nil
}

func compareAndGetDiff(a *pb.UavWhitelistUpdateReq, b model.TUavWhite, update map[string]any) bool {
	flag := true
	if a.Model != b.Model {
		flag = false
		update["model"] = a.Model
	}
	if a.Usage != 0 && a.Usage != int32(b.Usage) {
		flag = false
		update["usage"] = a.Usage
	}
	if a.Vendor != b.Vendor {
		flag = false
		update["vendor"] = a.Vendor
	}
	if a.Remark != b.Remark {
		flag = false
		update["remark"] = a.Remark
	}
	if a.UsageDesc != b.UsageDesc {
		flag = false
		update["usage_desc"] = a.UsageDesc
	}
	if !flag {
		update["update_at"] = time.Now().UTC()
	}

	return flag
}

// UavWhitelistAdd 无人机白名单删除
func (u *uavWhitelistHandler) UavWhitelistDelete(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UavWhitelistDelete.")
	req := &pb.UavWhitelistUpdateReq{}
	if err := json.NewDecoder(r.Body).Decode(req); err != nil {
		common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete decode request body error: "+err.Error()), common.HTTPFailed)
		return
	}
	var uwId int64
	if req.Id != "" {
		var err error
		uwId, err = strconv.ParseInt(req.Id, 10, 64)
		if err != nil {
			common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete params error: "+err.Error()), common.HTTPFailed)
			return
		}
	}

	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	uw := &model.TUavWhite{}
	if uwId != 0 {
		if err := u.acc.First(nil, uw, "id = ?", uwId); err != nil {
			logger.Errorf("First TUavWhite error: %s", err.Error())
			common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete error, record not exist"), common.HTTPFailed)
			return
		}
	} else if req.SerialNum != "" {
		if err := u.acc.First(nil, uw, "serial_num = ? and status = ?", req.SerialNum, constant.EffectStatus); err != nil {
			logger.Errorf("First TUavWhite error: %s", err.Error())
			common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete error, record not exist"), common.HTTPFailed)
			return
		}
	} else {
		logger.Error("Params error, request is empty")
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}

	if token.Payload.TbCode != uw.TbCode {
		logger.Errorf("Payload error: not match")
		common.DefaultResponse(w, nil, errors.New("payload error: not match"), common.HTTPFailed)
		return
	}

	tx := u.acc.DB().Begin()
	if _, err := u.acc.Update(tx, &model.TUavWhite{}, map[string]any{"status": constant.DeleteStatus, "update_at": time.Now().UTC()}, "id = ?", uw.Id); err != nil {
		tx.Rollback()
		logger.Errorf("Delete TUavWhite error: %s", err.Error())
		common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete error"), common.HTTPFailed)
		return
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}
	if err := u.rds.DeleteKey(model.GetUavWhitelistKey(*uw)); err != nil {
		logger.Errorf("Failed to get redis key %s : %v", model.GetUavWhitelistKey(*uw), err)
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)

	go addUwOperationLog(uw, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeWhitelistDelete, nil)

	common.DefaultResponse(w, struct{}{}, nil, common.HTTPSucceed)
}

// UavWhitelistAdd 无人机白名单删除
func (u *uavWhitelistHandler) UavWhitelistDelete2(ctx context.Context, req *pb.UavWhitelistUpdateReq) error {
	logger.Info("-----------------Receive UavWhitelistDelete.")
	var uwId int64
	if req.Id != "" {
		var err error
		uwId, err = strconv.ParseInt(req.Id, 10, 64)
		if err != nil {
			return error_collect.GetError(errorcode.ParameterInvalid)
		}
	}

	token := protocals.GetToken(ctx)
	uw := &model.TUavWhite{}
	if uwId != 0 {
		if err := u.acc.First(nil, uw, "id = ?", uwId); err != nil {
			logger.Errorf("First TUavWhite error: %s", err.Error())
			return error_collect.GetError(errorcode.NotFoundError)
		}
	} else if req.SerialNum != "" {
		if err := u.acc.First(nil, uw, "serial_num = ? and status = ?", req.SerialNum, constant.EffectStatus); err != nil {
			logger.Errorf("First TUavWhite error: %s", err.Error())
			return error_collect.GetError(errorcode.NotFoundError)
		}
	} else {
		logger.Error("Params error, request is empty")
		return error_collect.GetError(errorcode.ParameterInvalid)
	}

	if token.Payload.TbCode != uw.TbCode {
		logger.Errorf("Payload error: not match")
		return error_collect.GetError(errorcode.ParameterInvalid)
	}

	tx := u.acc.DB().Begin()
	if _, err := u.acc.Update(tx, &model.TUavWhite{}, map[string]any{"status": constant.DeleteStatus, "update_at": time.Now().UTC()}, "id = ?", uw.Id); err != nil {
		tx.Rollback()
		logger.Errorf("Delete TUavWhite error: %s", err.Error())
		return error_collect.GetError(errorcode.UavWhitelistDeleteError)
	}
	tx.Commit()

	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + token.Payload.TbCode); err != nil {
		logger.Errorf("DeleteKey error: %s", err.Error())
	}
	if err := u.rds.DeleteKey(model.GetUavWhitelistKey(*uw)); err != nil {
		logger.Errorf("Failed to get redis key %s : %v", model.GetUavWhitelistKey(*uw), err)
	}

	// 异步通知C2
	go SyncWhitelistToC2Dev(token.Payload.TbCode)

	go addUwOperationLog(uw, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeWhitelistDelete, nil)

	return nil
}

// UavWhitelistList 无人机白名单列表
func (u *uavWhitelistHandler) UavWhitelistList(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UavWhitelistList.")
	req := &pb.UavWhitelistListReq{}
	if err := json.NewDecoder(r.Body).Decode(req); err != nil {
		common.DefaultResponse(w, nil, errors.New("UavWhitelistDelete decode request body error: "+err.Error()), common.HTTPFailed)
		return
	}
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	where := make([]string, 0, 2)
	args := make([]interface{}, 0, 2)
	where = append(where, "tb_code = ? ")
	args = append(args, token.Payload.TbCode)
	where = append(where, "status = ?")
	args = append(args, constant.EffectStatus)
	where = append(where, "role = ?")
	args = append(args, constant.FriendlyArmy)
	if req.SerialNum != "" {
		where = append(where, "serial_num like ? ")
		args = append(args, "%"+req.SerialNum+"%")
	}
	if req.Vendor != "" {
		where = append(where, "vendor like ? ")
		args = append(args, "%"+req.Vendor+"%")
	}
	countQuery := u.acc.DB().Model(&model.TUavWhite{})
	total := new(int64)
	if err := countQuery.Where(strings.Join(where, " AND "), args...).Count(total).Error; err != nil {
		logger.Errorf("Failed to count TUavWhite: %s", err.Error())
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	query := u.acc.DB().Model(&model.TUavWhite{})
	list := make([]*model.TUavWhite, 0, 4)
	if err := query.Where(strings.Join(where, " AND "), args...).Limit(int(req.PageSize)).Offset(int((req.PageNo - 1) * req.PageSize)).Order("id desc").Find(&list).Error; err != nil {
		logger.Errorf("Find TUavWhite error: %s", err.Error())
		common.DefaultResponse(w, nil, err, common.HTTPFailed)
		return
	}
	data := make([]*response.UavWhitelistItem, 0, len(list))
	for _, item := range list {
		data = append(data, &response.UavWhitelistItem{
			Id:         item.Id,
			TbCode:     item.TbCode,
			SerialNum:  item.SerialNum,
			Vendor:     item.Vendor,
			Model:      item.Model,
			Role:       item.Role,
			Usage:      item.Usage,
			UsageDesc:  item.UsageDesc,
			Remark:     item.Remark,
			CreateTime: item.CreateTime.UTC().UnixMilli(),
			UpdateTime: item.UpdateTime.UTC().UnixMilli(),
		})
	}
	common.DefaultResponse(w, response.UavWhitelistRes{
		List:     data,
		PageNo:   int(req.PageNo),
		PageSize: int(req.PageSize),
		Total:    *total,
	}, nil, common.HTTPSucceed)
}

func addUwOperationLog(uw *model.TUavWhite, token *common.TokenContext, optType, optObject int, updateMap map[string]any) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("addUwOperationLog panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	optUavWhiteName := uw.SerialNum
	if uw.Model != "" {
		optUavWhiteName = uw.Model + "-" + uw.SerialNum
	}
	content := map[string]any{constant.OptlogWhitelistI18NPrefix + constant.ContentFieldNameUavWhiteName: optUavWhiteName}
	if optObject == constant.OperationLogBusinessTypeWhitelistUpdate {
		fields := tmodel.GetUpdateFields(optObject, updateMap)
		if len(fields) == 0 {
			return
		}
		content[constant.OptlogWhitelistI18NPrefix+constant.ContentFieldNameUpdateFields] = fields
	}
	optLog := &tmodel.OperationLogAddIn{
		LogType:         constant.OperationLogTypeUser,
		BusinessType:    constant.OperationLogBusinessTypeWhitelist,
		OperationType:   optType,
		OperationObject: optObject,
		TbCode:          token.Payload.TbCode,
		OperatorId:      token.Payload.AccountId,
		OperatorName:    token.Payload.Account,
		Content:         content,
		Status:          constant.OperationLogStatusSuccess,
		Source:          constant.OperationLogSourceWeb,
		ToInfoWindow:    constant.OperationLogToInfoWindow,
	}
	if uw.Id == 0 {
		optLog.Status = constant.OperationLogStatusFail
		optLog.ToInfoWindow = constant.OperationLogNotToInfoWindow
	}
	if err := thirdpartapi.NewCloudDataService().OperationLogAdd(optLog); err != nil {
		logger.Errorf("OperationLogAdd error: %s", err.Error())
	}
}
