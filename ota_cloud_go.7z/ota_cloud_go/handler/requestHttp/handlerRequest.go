package requestHttp

import (
	"bytes"
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/errorcode"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	tmodel "cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	"cuav-cloud-go-service/domain/service/counter_recommend"
	"cuav-cloud-go-service/domain/service/uavwhitelist"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/handler/request"
	"cuav-cloud-go-service/infra/docsGen"
	"cuav-cloud-go-service/infra/protocals"
	ps "cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"
	"time"

	"google.golang.org/protobuf/proto"

	"cuav-cloud-go-service/domain/repository/error_collect"
	ec "cuav-cloud-go-service/domain/repository/error_collect"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/Shopify/sarama"
)

func InitRoute() {
	mux := http.DefaultServeMux
	docsGen.InitDocsGenServerOnGinRouter(mux)
	//接口-mock测试
	ps.Register("/inner/test_mock_test", InnerMockDemoTestCall)
	ps.RegisterNoOut("/inner/test_mock_test_no_out", InnerMockWithNOOut)
	//推荐反制打击设备
	ps.Register("/rest/v1/business/handle-device/recommend", CounterMeasureRecommend)

	// 添加反制区
	ps.RegisterNoOut("/rest/v1/business/counter-area/create", CounterAreaCreate)
	//查询反制区
	ps.Register("/rest/v1/business/counter-area/query", CounterAreaQuery)
	//删除反制区
	ps.RegisterNoOut("/rest/v1/business/counter-area/delete", CounterAreaDelete)

	//自动反制规则添加
	ps.Register("/rest/v1/business/auto-counter-rule/create", AutoCounterRuleCreate)
	//自动反制规则更改
	ps.RegisterNoOut("/rest/v1/business/auto-counter-rule/modify", AutoCounterRuleStatusModify)
	//自动反制规则查询
	ps.Register("/rest/v1/business/auto-counter-rule/query", AutoCounterRuleQuery)
	//自动反制规则删除
	ps.RegisterNoOut("/rest/v1/business/auto-counter-rule/delete", AutoCounterRuleDeleteRequest)

	// 手动反制任务开始通知(内部)
	ps.RegisterNoOut("/inner/rest/v1/business/counter-task-manual/start", CounterTaskManualStart)
	// 反制状态变更通知(内部)
	ps.RegisterNoOut("/inner/rest/v1/business/counter-task-status/feedback", CounterStatusFeedBack)
	//手动取消进行中任务
	ps.RegisterNoOut("/rest/v1/business/counter-task/cancel", CancelCounterTask)
	//查询任务列表
	ps.Register("/rest/v1/business/counter-task/query", QueryCounterTask)
	ps.Register("/inner/rest/v1/business/counter-task/progress-count", CounterTaskProgressCount)

	// 目标事件查询
	ps.Register("/rest/v1/business/evidence/target-event/query", TargetEventQuery)
	// 下载取证报告, 返回下载链接是否有效
	ps.Register("/rest/v1/business/evidence/report/download", EvidenceReportDownload)
	// 直接使用 trackId 下载
	http.HandleFunc("/rest/v1/business/evidence/report/download/direct", EvidenceReportDownloadDirect)
	// 查看-预览报告， 获取预览报告依赖的数据
	ps.Register("/rest/v1/business/evidence/report/preview", PreviewEvidenceReport)
	// 上传pdf请求-form表单提供
	ps.RegisterForm("/rest/v1/business/evidence/report/upload-pdf", EvidenceReportPdfUpload)
	// 自定义报告名称
	ps.RegisterNoOut("/rest/v1/business/evidence/report/rename", RenameReportName)
	// 黑飞文件上传
	http.HandleFunc("/rest/v1/business/evidence/report/capture-flying-document/upload", CaptureFlyingDocumentUpload)
	// 文件下载
	http.HandleFunc("/rest/v1/business/evidence/report/document/download", CaptureFlyingDownload)

	ps.Register("/rest/v1/business/query/address", QueryAddress)

	//健康检查
	http.HandleFunc("/actuator/shutdown", ActuatorRequests)
	http.HandleFunc("/actuator/health/liveness", ActuatorRequests)
	http.HandleFunc("/actuator/health/readiness", ActuatorRequests)

	//围栏区
	ps.RegisterNoOut("/rest/v1/business/fence/add", AddFence2)       //添加围栏区
	ps.RegisterNoOut("/rest/v1/business/fence/update", UpdateFence2) //修改围栏区
	http.HandleFunc("/rest/v1/business/fence/list", ListFence)       //获取围栏区列表
	ps.RegisterNoOut("/rest/v1/business/fence/delete", DelFence2)    //删除围栏区

	http.HandleFunc("/inner/rest/v1/business/fence/list", InnerListFence) //获取围栏区列表
	//围栏区告警
	http.HandleFunc("/rest/v1/business/alarm/unRead-list", ListUnReadAlarm)     //获取未读告警列表
	http.HandleFunc("/rest/v1/business/alarm/update-status", UpdateAlarmStatus) //更新告警处理状态
	//http.HandleFunc("/inner/rest/v1/alarm/get-latest-record", FetchUnprocAlarmLatestRecord) // 获取未处理的最新告警记录

	// 无人机白名单
	uh := NewUavWhitelistHandler(config.GetDB())
	ps.Register("/rest/v1/business/whitelist/add", uh.UavWhitelistAdd2)            // 添加白名单
	ps.Register("/rest/v1/business/whitelist/update", uh.UavWhitelistUpdate2)      // 更新白名单
	ps.RegisterNoOut("/rest/v1/business/whitelist/delete", uh.UavWhitelistDelete2) // 删除白名单
	http.HandleFunc("/rest/v1/business/whitelist/list", uh.UavWhitelistList)       // 获取白名单列表

	http.HandleFunc("/rest/v1/business/query/eventDuration", TimelineList) // 获取时间线信息

	go func() {
		server := &http.Server{
			Addr:           "0.0.0.0:" + strconv.Itoa(config.GetConfig().ConnectPort.NacosPort),
			Handler:        mux,
			ReadTimeout:    5 * time.Second,
			WriteTimeout:   5 * time.Second,
			MaxHeaderBytes: 50 * 1024 * 1024,
		}
		server.ListenAndServe()
	}()
}

func ActuatorRequests(w http.ResponseWriter, r *http.Request) {
	jsonResponse(w, nil, http.StatusOK)
}

// InnerMockDemoTestCall 接口模拟测试
func InnerMockDemoTestCall(ctx context.Context, listFenceArea *pb.FenceListRequest) ([]*pb.FenceResList, error) {
	ret := []*pb.FenceResList{
		&pb.FenceResList{
			Id: 100,
		},
		&pb.FenceResList{
			Id: 200,
		},
	}
	//return nil, errors.New("test is not ok")
	return ret, nil
}

func InnerMockWithNOOut(ctx context.Context, listFenceArea *pb.FenceListRequest) error {
	return ec.GetError(ec.SF_ErrorAutoCounterRuleDelete)
}

func delCacheFendArea(tbCode string, areaName string, id int64) {
	areaHandle := alarm_service.NewFendAreaOpsService(alarm_service.ResFendAreaRedis, alarm_service.ResFendAreaDB)
	areaHandle.DeleteAllFendAreaOnTbCode(tbCode)
}
func AddFence(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive AddFence.")
	var requestBody pb.FenceAddRequest
	var responseBody common.Response
	responseBody.ErrorCode = common.HTTPFailed
	err := json.NewDecoder(r.Body).Decode(&requestBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}
	logger.Infof("-----------------AddFence req:%v", requestBody)
	//todo
	id, err := snowflake.GetUniqueID()
	logger.Info("GetUniqueID success:", id)
	if err != nil {
		logger.Errorf("Failed to get snowflake id: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	var count int64
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).Where("tb_code = ? AND area_name = ? AND id != ?", token.Payload.TbCode, requestBody.AreaName, id).Count(&count).Error; err != nil {
		logger.Errorf("Failed to check for duplicate AreaName: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	if count > 0 {
		logger.Errorf("Duplicate AreaName under the same TbCode")
		responseBody.ErrorMessage = "已存在相同名称的围栏区，请重新命名！"
		jsonResponse(w, responseBody, http.StatusConflict)
		return
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, requestBody.AreaName, id)

		logger.Infof("after add, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, requestBody.AreaName, id)
	}()

	fence := &bean.FencedAreaConfig{
		ID:                id,
		TbCode:            token.Payload.TbCode,
		AreaName:          requestBody.AreaName,
		AreaType:          int(requestBody.AreaType),
		AreaPerimeter:     requestBody.AreaPerimeter,
		AreaSquare:        requestBody.AreaSquare,
		CentroidLongitude: requestBody.CentroidLongitude,
		CentroidLatitude:  requestBody.CentroidLatitude,
		Geometry:          requestBody.Geometry,
		CreateTime:        time.Now().UTC().UnixMilli(),
		UpdateTime:        time.Now().UTC().UnixMilli(),
	}
	if err := config.GetDB().Create(fence).Error; err != nil {
		logger.Errorf("FencedAreaConfig create   error:%v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	responseBody.ErrorCode = common.HTTPSucceed
	// 将响应数据发送回客户端
	jsonResponse(w, responseBody, http.StatusOK)
	logger.Info("-----------------End AddFence res:", responseBody.ErrorCode)
	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(fence, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeFenceAdd, nil)
	return
}

func AddFence2(ctx context.Context, requestBody *pb.FenceAddRequest) error {
	logger.Info("-----------------Receive AddFence.")
	//todo
	id, err := snowflake.GetUniqueID()
	logger.Info("GetUniqueID success:", id)
	if err != nil {
		logger.Errorf("Failed to get snowflake id: %v", err)
		return error_collect.GetError(errorcode.GetUniqueIDError)
	}
	token := protocals.GetToken(ctx)

	var count int64
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).Where("tb_code = ? AND area_name = ? AND id != ?", token.Payload.TbCode, requestBody.AreaName, id).Count(&count).Error; err != nil {
		logger.Errorf("Failed to check for duplicate AreaName: %v", err)
		return error_collect.GetError(errorcode.NotFoundError)
	}
	if count > 0 {
		logger.Errorf("Duplicate AreaName under the same TbCode")
		return error_collect.GetError(errorcode.FenceExsit)
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, requestBody.AreaName, id)

		logger.Infof("after add, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, requestBody.AreaName, id)
	}()

	fence := &bean.FencedAreaConfig{
		ID:                id,
		TbCode:            token.Payload.TbCode,
		AreaName:          requestBody.AreaName,
		AreaType:          int(requestBody.AreaType),
		AreaPerimeter:     requestBody.AreaPerimeter,
		AreaSquare:        requestBody.AreaSquare,
		CentroidLongitude: requestBody.CentroidLongitude,
		CentroidLatitude:  requestBody.CentroidLatitude,
		Geometry:          requestBody.Geometry,
		CreateTime:        time.Now().UTC().UnixMilli(),
		UpdateTime:        time.Now().UTC().UnixMilli(),
	}
	if err := config.GetDB().Create(fence).Error; err != nil {
		logger.Errorf("FencedAreaConfig create   error:%v", err)
		return error_collect.GetError(errorcode.FenceAddError)
	}

	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(fence, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeFenceAdd, nil)
	return nil
}

func SendKafkaMsg(tbcode string) {
	con := sarama.NewConfig()
	con.Producer.RequiredAcks = sarama.WaitForAll
	con.Producer.Partitioner = sarama.NewRandomPartitioner
	con.Producer.Return.Successes = true
	// 假设 Kafka 集群地址为 "localhost:9092"
	logger.Info("Kafka ip addr:", config.GetConfig().Kafka.BootStrapServers)
	bootstrapServers := strings.Split(config.GetConfig().Kafka.BootStrapServers, ",")
	producer, err := sarama.NewSyncProducer(bootstrapServers, con)
	if err != nil {
		logger.Errorf("Failed to create producer: %s", err)
	}
	defer producer.Close()
	noticeItem := &NoticeItem{
		Key: "/notice/v1/fence",
		Data: TbCode{
			TbCode: tbcode,
		},
	}
	noticeItemJson, err := json.Marshal(noticeItem)
	if err != nil {
		logger.Errorf("Failed to serialize NoticeItem: %s\n", err)
		return
	}

	// 创建一个消息，指定主题为 "my-topic"
	msg := &sarama.ProducerMessage{
		Topic: config.GetConfig().Kafka.EventNoticeTopic, // 指定主题
		Value: sarama.StringEncoder(noticeItemJson),
	}

	// 发送消息
	partition, offset, err := producer.SendMessage(msg)
	if err != nil {
		logger.Errorf("Failed to send message: %s", err)
	}

	logger.Info("Partition: %d, Offset: %d", partition, offset)
}

type NoticeItem struct {
	Key  string `json:"key"`
	Data TbCode `json:"data"`
}

type TbCode struct {
	TbCode string `json:"tbCode"`
}

func UpdateFence(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UpdateFence.")
	var requestBody pb.FenceUpdateRequest
	var responseBody common.Response
	responseBody.ErrorCode = common.HTTPFailed
	err := json.NewDecoder(r.Body).Decode(&requestBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}
	logger.Infof("-----------------UpdateFence req:%v", requestBody)
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	id, err := strconv.ParseInt(requestBody.Id, 10, 64)
	if err != nil {
		logger.Errorf("Failed to parse ID: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	var count int64
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).Where("tb_code = ? AND area_name = ? AND id != ?", token.Payload.TbCode, requestBody.AreaName, id).Count(&count).Error; err != nil {
		logger.Errorf("Failed to check for duplicate AreaName: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	if count > 0 {
		logger.Errorf("Duplicate AreaName under the same TbCode")
		responseBody.ErrorMessage = "已存在相同名称的围栏区，请重新命名！"
		jsonResponse(w, responseBody, http.StatusConflict)
		return
	}
	oldFence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).First(oldFence, "id = ?", id).Error; err != nil {
		logger.Errorf("Fence id %d not Found", id)
		responseBody.ErrorMessage = "围栏区不存在"
		jsonResponse(w, responseBody, http.StatusBadRequest)
		return
	}
	updateMap := make(map[string]any)
	if oldFence.AreaName != requestBody.AreaName {
		updateMap["area_name"] = struct{}{}
	}
	if oldFence.AreaType != int(requestBody.AreaType) {
		updateMap["area_type"] = struct{}{}
	}
	if oldFence.AreaPerimeter != requestBody.AreaPerimeter || oldFence.AreaSquare != requestBody.AreaSquare {
		updateMap["area_range"] = struct{}{}
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, requestBody.AreaName, id)

		logger.Infof("after update area, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, requestBody.AreaName, id)
	}()

	newFence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Model(newFence).Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).Updates(bean.FencedAreaConfig{
		AreaName:          requestBody.AreaName,
		AreaType:          int(requestBody.AreaType),
		AreaPerimeter:     requestBody.AreaPerimeter,
		AreaSquare:        requestBody.AreaSquare,
		CentroidLongitude: requestBody.CentroidLongitude,
		CentroidLatitude:  requestBody.CentroidLatitude,
		Geometry:          requestBody.Geometry,
		UpdateTime:        time.Now().UTC().UnixMilli(),
	}).Error; err != nil {
		logger.Errorf("FencedAreaConfig update error:%v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	// 将响应数据发送回客户端
	responseBody.ErrorCode = common.HTTPSucceed
	jsonResponse(w, responseBody, http.StatusOK)
	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(newFence, token, constant.OperationLogOperationTypeUpdate, constant.OperationLogBusinessTypeFenceUpdate, updateMap)
	logger.Info("-----------------End UpdateFence res:", responseBody.ErrorCode)
}

func UpdateFence2(ctx context.Context, requestBody *pb.FenceUpdateRequest) error {
	logger.Info("-----------------Receive UpdateFence.")
	token := protocals.GetToken(ctx)

	id, err := strconv.ParseInt(requestBody.Id, 10, 64)
	if err != nil {
		logger.Errorf("Failed to parse ID: %v", err)
		return error_collect.GetError(errorcode.GetUniqueIDError)
	}
	var count int64
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).Where("tb_code = ? AND area_name = ? AND id != ?", token.Payload.TbCode, requestBody.AreaName, id).Count(&count).Error; err != nil {
		logger.Errorf("Failed to check for duplicate AreaName: %v", err)
		return error_collect.GetError(errorcode.NotFoundError)
	}
	if count > 0 {
		logger.Errorf("Duplicate AreaName under the same TbCode")
		return error_collect.GetError(errorcode.FenceExsit)
	}
	oldFence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Model(&bean.FencedAreaConfig{}).First(oldFence, "id = ?", id).Error; err != nil {
		logger.Errorf("Fence id %d not Found", id)
		return error_collect.GetError(errorcode.NotFoundError)
	}
	updateMap := make(map[string]any)
	if oldFence.AreaName != requestBody.AreaName {
		updateMap["area_name"] = struct{}{}
	}
	if oldFence.AreaType != int(requestBody.AreaType) {
		updateMap["area_type"] = struct{}{}
	}
	if oldFence.AreaPerimeter != requestBody.AreaPerimeter || oldFence.AreaSquare != requestBody.AreaSquare {
		updateMap["area_range"] = struct{}{}
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, requestBody.AreaName, id)

		logger.Infof("after update area, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, requestBody.AreaName, id)
	}()

	newFence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Model(newFence).Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).Updates(bean.FencedAreaConfig{
		AreaName:          requestBody.AreaName,
		AreaType:          int(requestBody.AreaType),
		AreaPerimeter:     requestBody.AreaPerimeter,
		AreaSquare:        requestBody.AreaSquare,
		CentroidLongitude: requestBody.CentroidLongitude,
		CentroidLatitude:  requestBody.CentroidLatitude,
		Geometry:          requestBody.Geometry,
		UpdateTime:        time.Now().UTC().UnixMilli(),
	}).Error; err != nil {
		logger.Errorf("FencedAreaConfig update error:%v", err)
		return error_collect.GetError(errorcode.FenceUpdateError)
	}
	// 将响应数据发送回客户端
	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(newFence, token, constant.OperationLogOperationTypeUpdate, constant.OperationLogBusinessTypeFenceUpdate, updateMap)

	return nil
}

func ListFence(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive ListFence.")
	var requestBody pb.FenceListRequest
	var responseBody common.ResponseFenceResList
	responseBody.ErrorCode = common.HTTPFailed
	err := json.NewDecoder(r.Body).Decode(&requestBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}
	logger.Infof("-----------------ListFence req:%v", requestBody)
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	var fencedAreaConfigs []bean.FencedAreaConfig
	if err := config.GetDB().Where("tb_code = ?", token.Payload.TbCode).Find(&fencedAreaConfigs).Error; err != nil {
		logger.Errorf("Failed to get fenced area configs: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	for _, config := range fencedAreaConfigs {
		var ruleItem *pb.RuleDetailInFenceArea = nil
		item, err := auto_counter_service.NewAutoCounterRuleOps(nil).QueryRuleByFenceId(token.Payload.TbCode, config.ID)

		if err == nil && item != nil {
			validTime := &pb.RuleInvalidTime{
				WholeDay: proto.Int32(item.WholeDay),
			}
			if item.WholeDay != auto_counter_service.Rule_Whole_Day { //不是全天
				sH, sM, sS := utils.GetTimeByDB(item.BeginTime)
				eH, eM, eS := utils.GetTimeByDB(item.EndTime)
				validTime.StartHour, validTime.StartMinute, validTime.StartSecond = proto.Int32(sH), proto.Int32(sM), proto.Int32(sS)
				validTime.EndHour, validTime.EndMinute, validTime.EndSecond = proto.Int32(eH), proto.Int32(eM), proto.Int32(eS)
				validTime.CrossDay = proto.Int32(item.CrossDay)
			}

			var updaeTime int64 = 0
			if item.UpdateTime != nil {
				updaeTime = item.UpdateTime.UTC().UnixMilli()
			}
			ruleItem = &pb.RuleDetailInFenceArea{
				// required: true
				// example: 自动反制规则1
				// 自动反制名字
				RuleName: item.RuleName,

				RuleTimeDay: validTime,
				// required: true
				// example: 0 不禁用任何模式, 1 禁用无线电打击, 2 禁用诱骗, 3 禁用诱打联动
				// 规则警用模式
				ForbiddenMode: item.ForbiddenMode,
				// required: true
				// example: 0 或者没有字段，1 标识开启， 2 关闭该规则
				// 关闭该规则
				RuleEnable: item.RuleEnable,
				// required: true
				// example: 12312312313
				// 规则唯一id
				RuleId: item.ID,
				// required: false
				// example: 172125451613 毫秒时间戳
				// 更新时间戳
				UpdateTime: updaeTime,
			}
		}

		responseBody.Data = append(responseBody.Data, &pb.FenceResList{
			Id:                config.ID,
			AreaName:          config.AreaName,
			AreaType:          int32(config.AreaType),
			AreaPerimeter:     config.AreaPerimeter,
			AreaSquare:        config.AreaSquare,
			CentroidLongitude: config.CentroidLongitude,
			CentroidLatitude:  config.CentroidLatitude,
			Geometry:          config.Geometry,
			CreateTime:        time.Unix(0, config.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			UpdateTime:        time.Unix(0, config.UpdateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			RuleItem:          ruleItem,
		})
	}

	responseBody.ErrorCode = common.HTTPSucceed
	// 将响应数据发送回客户端
	jsonResponse(w, responseBody, http.StatusOK)
	logger.Info("-----------------End ListFence res:", responseBody.ErrorCode)

}

func InnerListFence(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive ListFence.")
	var requestBody request.InnerListFenceRequest
	var responseBody common.ResponseFenceResList
	responseBody.ErrorCode = common.HTTPFailed
	err := json.NewDecoder(r.Body).Decode(&requestBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}

	var fencedAreaConfigs []bean.FencedAreaConfig
	if err := config.GetDB().Where("tb_code = ?", requestBody.TbCode).Find(&fencedAreaConfigs).Error; err != nil {
		logger.Errorf("Failed to get fenced area configs: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	for _, config := range fencedAreaConfigs {
		responseBody.Data = append(responseBody.Data, &pb.FenceResList{
			Id:                config.ID,
			AreaName:          config.AreaName,
			AreaType:          int32(config.AreaType),
			AreaPerimeter:     config.AreaPerimeter,
			AreaSquare:        config.AreaSquare,
			CentroidLongitude: config.CentroidLongitude,
			CentroidLatitude:  config.CentroidLatitude,
			Geometry:          config.Geometry,
			CreateTime:        time.Unix(0, config.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			UpdateTime:        time.Unix(0, config.UpdateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
		})
	}

	responseBody.ErrorCode = common.HTTPSucceed
	// 将响应数据发送回客户端
	jsonResponse(w, responseBody, http.StatusOK)
}

// DelFence godoc
// @Summary 删除围栏区
// @Description 删除围栏区
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.FenceDeleteRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/fence/delete [POST]
func DelFence2(ctx context.Context, requestBody *pb.FenceDeleteRequest) error {
	logger.Info("-----------------Receive DelFence")
	token := protocals.GetToken(ctx)

	id, err := strconv.ParseInt(requestBody.Id, 10, 64)
	if err != nil {
		logger.Errorf("Failed to parse ID: %v", err)
		return error_collect.GetError(errorcode.ParameterInvalid)
	}

	// add filter to process fence area exist in counter rule.
	_, ruleList := auto_counter_service.NewAutoCounterRuleOps(nil).QueryFenceAreaBindIds(token.Payload.TbCode, id)
	if len(ruleList) > 0 {
		if requestBody.GetDeleteRule() <= 0 { // 存在规则内，但是没有设置删除规则。
			logger.Errorf("fence area id: %v exist in auto counter rule table", id)
			return error_collect.GetError(ec.SF_ErrorFenceInCounterRule)

		} else { //强制删除规则内的围栏区； 从规则记录中解绑该围栏区，将围栏区id设置为0
			for _, ruleItem := range ruleList {
				if ruleItem == nil {
					continue
				}
				//
				logger.Infof("to update fenceId from %v to 0 for rule id: %v", id, ruleItem.ID)
				if err := DelRuleOnFenceAreaDeleted(token.Payload.TbCode, ruleItem.ID, id); err != nil {
					continue
				}
				addCrOperationLog(*ruleItem, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeCounterRuleDelete)
			}
		}
	}

	fence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).First(fence).Error; err != nil {
		logger.Errorf("Failed to find fenced area config: %v", err)
		return error_collect.GetError(errorcode.NotFoundError)
	}
	if err := config.GetDB().Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).Delete(&bean.FencedAreaConfig{}).Error; err != nil {
		logger.Errorf("Failed to delete fenced area config: %v", err)
		return error_collect.GetError(errorcode.FenceDeleteError)
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, "", id)

		logger.Infof("after delete, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, "", id)
	}()

	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(fence, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeFenceDelete, nil)

	return nil
}

// DelFence godoc
// @Summary 删除围栏区
// @Description 删除围栏区
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.FenceDeleteRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/fence/delete [POST]
func DelFence(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive DelFence,", r.Body)
	var requestBody pb.FenceDeleteRequest
	var responseBody common.Response
	responseBody.ErrorCode = common.HTTPFailed
	err := json.NewDecoder(r.Body).Decode(&requestBody)
	if err != nil {
		jsonResponse(w, responseBody, http.StatusBadRequest)
		logger.Error("Failed to decode request body: %v", err)
		return
	}
	logger.Infof("-----------------DelFence req:%v", requestBody)
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	id, err := strconv.ParseInt(requestBody.Id, 10, 64)
	if err != nil {
		logger.Errorf("Failed to parse ID: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	// add filter to process fence area exist in counter rule.
	_, ruleList := auto_counter_service.NewAutoCounterRuleOps(nil).QueryFenceAreaBindIds(token.Payload.TbCode, id)
	if len(ruleList) > 0 {
		if requestBody.GetDeleteRule() <= 0 { // 存在规则内，但是没有设置删除规则。
			logger.Errorf("fence area id: %v exist in auto counter rule table", id)
			responseBody.ErrorCode = ec.SF_ErrorFenceInCounterRule
			responseBody.ErrorMessage = ec.GetError(responseBody.ErrorCode).GetCodeMsg()
			jsonResponse(w, responseBody, http.StatusOK)
			return

		} else { //强制删除规则内的围栏区； 从规则记录中解绑该围栏区，将围栏区id设置为0
			for _, ruleItem := range ruleList {
				if ruleItem == nil {
					continue
				}
				//
				logger.Infof("to update fenceId from %v to 0 for rule id: %v", id, ruleItem.ID)
				if err := DelRuleOnFenceAreaDeleted(token.Payload.TbCode, ruleItem.ID, id); err != nil {
					continue
				}
				addCrOperationLog(*ruleItem, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeCounterRuleDelete)
			}
		}
	}

	fence := &bean.FencedAreaConfig{}
	if err := config.GetDB().Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).First(fence).Error; err != nil {
		logger.Errorf("Failed to find fenced area config: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	if err := config.GetDB().Where("tb_code = ? AND id = ?", token.Payload.TbCode, id).Delete(&bean.FencedAreaConfig{}).Error; err != nil {
		logger.Errorf("Failed to delete fenced area config: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	defer func() {
		delCacheFendArea(token.Payload.TbCode, "", id)

		logger.Infof("after delete, del cache for tbCode: %v, areaName: %v, id: %v",
			token.Payload.TbCode, "", id)
	}()

	responseBody.ErrorCode = common.HTTPSucceed
	// 将响应数据发送回客户端
	jsonResponse(w, responseBody, http.StatusOK)
	SendKafkaMsg(token.Payload.TbCode)
	go SyncFenceToC2Dev(token.Payload.TbCode)
	go addFaOperationLog(fence, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeFenceDelete, nil)
	logger.Info("-----------------End DelFence res:", responseBody.ErrorCode)
}

func addFaOperationLog(fa *bean.FencedAreaConfig, token *common.TokenContext, optType, optObject int, updateMap map[string]any) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("addFaOperationLog error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	content := map[string]any{constant.OptlogFenceI18NPrefix + constant.ContentFieldNameFenceAreaName: fa.AreaName}
	if optObject == constant.OperationLogBusinessTypeFenceUpdate {
		fields := tmodel.GetUpdateFields(optObject, updateMap)
		if len(fields) == 0 {
			return
		}
		content[constant.OptlogFenceI18NPrefix+constant.ContentFieldNameUpdateFields] = fields
	}
	optLog := &tmodel.OperationLogAddIn{
		LogType:         constant.OperationLogTypeUser,
		BusinessType:    constant.OperationLogBusinessTypeFence,
		OperationType:   optType,
		OperationObject: optObject,
		TbCode:          token.Payload.TbCode,
		OperatorId:      token.Payload.AccountId,
		OperatorName:    token.Payload.Account,
		Content:         content,
		Status:          constant.OperationLogStatusSuccess,
		Source:          constant.OperationLogSourceWeb,
		ToInfoWindow:    constant.OperationLogToInfoWindow,
	}
	if err := thirdpartapi.NewCloudDataService().OperationLogAdd(optLog); err != nil {
		logger.Errorf("OperationLogAdd error: %s", err.Error())
	}
}

// jsonResponse 将给定的数据封装为JSON格式，并写入HTTP响应
func jsonResponse(w http.ResponseWriter, data interface{}, statusCode int) {
	response, err := json.Marshal(data)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	w.Write(response)
}

func SyncFenceToC2Dev(code string) {
	logger.Info("SyncFenceToC2Dev")
	list, err := RequestC2List(code)
	if err != nil {
		logger.Errorf("Failed to get c2 list: %v", err)
		return
	}
	for _, c2 := range list.Data.Items {
		if c2 == nil {
			continue
		}
		req := &pb.C2OnlineRequest{
			TbCode: code,
			C2Sn:   c2.SN,
		}
		logger.Info("C2online req:", req)
		go common.CallRpcFenceSync(req)
	}
}

func SyncWhitelistToC2Dev(code string) {
	func() {
		if err := recover(); err != nil {
			logger.Errorf("SyncWhitelistToC2Dev error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	list, err := RequestC2List(code)
	if err != nil {
		logger.Errorf("Failed to get c2 list: %v", err)
		return
	}
	uwList, err := uavwhitelist.NewUavWhitelistService().UavWhitelist(code, false)
	if err != nil {
		logger.Errorf("Failed to UavWhitelist: %s", err.Error())
		return
	}
	uavInfolist := make([]*pb.UavInfo, 0, len(uwList))
	uwlistM := make(map[string]*model.TUavWhite)
	// 根据最新的去重
	for _, uw := range uwList {
		if val, ok := uwlistM[uw.SerialNum]; ok && val.UpdateTime.UTC().UnixMilli() > uw.UpdateTime.UTC().UnixMilli() {
			continue
		} else {
			uwlistM[uw.SerialNum] = uw
		}
	}
	for _, uw := range uwlistM {
		item := &pb.UavInfo{
			SerialNum:  uw.SerialNum,
			Vendor:     uw.Vendor,
			Model:      uw.Model,
			Role:       int32(uw.Role),
			Usage:      int32(uw.Usage),
			UsageDesc:  uw.UsageDesc,
			Remark:     uw.Remark,
			Status:     int32(uw.Status),
			CreateTime: uw.CreateTime.UTC().UnixMilli(),
			UpdateTime: uw.UpdateTime.UTC().UnixMilli(),
		}
		uavInfolist = append(uavInfolist, item)
	}
	for _, c2 := range list.Data.Items {
		if c2 == nil {
			continue
		}
		req := &pb.C2OnlineRequest{
			TbCode: code,
			C2Sn:   c2.SN,
		}
		logger.Info("SyncWhitelistToC2Dev req:", req)
		common.CallRpcUavWhitelistSync(req, uavInfolist)
	}
}

type QueryGatewayDeviceCond struct {
	Domains []int64 `json:"domains"`
	TbCode  string  `json:"tbCode"`
}
type GetC2Request struct {
	Item      *QueryGatewayDeviceCond `json:"data"`
	PageIndex int32                   `json:"pageIndex"`
	PageSize  int32                   `json:"pageSize"`
}

func RequestC2List(tbCode string) (*common.ReqC2ListResponse, error) {
	url := "http://cuav-cloud-access-service:8883/inner/rest/v1/device/gateway/list"
	params := &GetC2Request{
		PageIndex: 1,
		PageSize:  100,
		Item: &QueryGatewayDeviceCond{
			Domains: []int64{4},
			TbCode:  tbCode,
		},
	}

	jsonParams, err := json.Marshal(params)
	if err != nil {
		logger.Errorf("Failed to marshal params: %v", err)
		return nil, err
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonParams))
	if err != nil {
		logger.Errorf("Failed to create request: %v", err)
		return nil, err
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer feign_token")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		logger.Errorf("Failed to send request: %v", err)
		return nil, err
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Errorf("Failed to read response body: %v", err)
		return nil, err
	}

	var response common.ReqC2ListResponse
	err = json.Unmarshal(body, &response)
	if err != nil {
		logger.Errorf("Failed to unmarshal response body: %v", err)
		return nil, err
	}

	logger.Info("Response body:", response)
	return &response, nil
}

// ListUnReadAlarm 未读告警列表处理(历史记录)
func ListUnReadAlarm(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UnReadAlarmList.")
	var reqBody pb.AlarmUnReadListRequest
	var respBody common.ResponseAlarmUnReadList
	if err := json.NewDecoder(r.Body).Decode(&reqBody); err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}

	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	ret, err := alarm_service.NewAlarmOps(alarm_service.ResAlarmDB).QueryUnReadLatestList(token.Payload.TbCode, reqBody.GetBeginTime(), reqBody.GetEndTime())
	if err != nil {
		logger.Errorf("Failed to ListUnReadAlarm: %v, tbcode: %v", err, token.Payload.TbCode)
		jsonResponse(w, err, http.StatusBadGateway)
	}
	respBody.ErrorCode = common.HTTPSucceed
	respBody.Data = ret

	// 将响应数据发送回客户端
	jsonResponse(w, respBody, http.StatusOK)
	logger.Info("-----------------End ListUnReadAlarm res:", respBody.ErrorCode)
}

// UpdateAlarmStatus 更新告警状态
func UpdateAlarmStatus(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------Receive UpdateAlarmStatus.")
	var reqBody pb.AlarmStatusUpdateRequest
	var respBody common.ResponseAlarmUpdate

	err := json.NewDecoder(r.Body).Decode(&reqBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}

	logger.Infof("-----------------UpdateAlarmStatus req:%v", reqBody)
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}

	updateRet, err := alarm_service.NewAlarmOps(alarm_service.ResAlarmDB).UpdateStatusToDealed(reqBody.GetUpdateItems())
	if err != nil {
		logger.Errorf("Failed to UpdateAlarmStatus : %v, tbcode: %v", err, token.Payload.TbCode)
		jsonResponse(w, err, http.StatusBadGateway)
	}
	respBody.ErrorCode = common.HTTPSucceed
	respBody.Data = updateRet
	// 调用其他服务来通知 其他端。
	var toNotice = make(map[int64]*pb.AlarmStatusUpdateItem)
	for _, procItem := range updateRet {
		if procItem == nil {
			continue
		}
		// 更新失败，不向其他节点发通知
		if procItem.UpdateRet != 0 {
			continue
		}
		// 反查更新的原始数据
		for index, _ := range reqBody.GetUpdateItems() {
			if reqBody.GetUpdateItems()[index] == nil {
				continue
			}
			//处理成功的数据
			if procItem.GetId() == reqBody.GetUpdateItems()[index].GetId() {
				tmpVal := reqBody.GetUpdateItems()[index]
				id, _ := strconv.ParseInt(procItem.GetId(), 10, 64)
				toNotice[id] = tmpVal //key is alarm id
			}
		}
	}
	notifyHandle := alarm_service.NewAlarmStatusUpdateNotify()
	//通知 其他端来拉取最新的数据，同步作用
	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("painc, FlagNonAlarmReport, e: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
			}
		}()
		notifyHandle.FlagNonAlarmReport(toNotice, true)
	}()
	//go func() {
	//	defer func() {
	//		if e := recover(); e != nil {
	//			logger.Errorf("painc, Notify, e: %v", e)
	//		}
	//	}()
	//
	//	notifyHandle.Notify(toNotice, token.Payload.TbCode)
	//}()
	// 将响应数据发送回客户端
	jsonResponse(w, respBody, http.StatusOK)
	logger.Info("-----------------End UpdateAlarmStatus res:", respBody.ErrorCode)

}

// FetchUnprocAlarmLatestRecord 获取 未处理的最新告警记录
func FetchUnprocAlarmLatestRecord(w http.ResponseWriter, r *http.Request) {
	logger.Infof("call FetchUnprocAlarmLatestRecord:")
	var reqBody pb.AlarmUnProcLatestRequest
	var respBody common.ResponseFetchUnProcAlarmLatest
	respBody.ErrorCode = common.HTTPFailed

	err := json.NewDecoder(r.Body).Decode(&reqBody)
	if err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}

	logger.Infof("do logic on record, req: %+v", reqBody)
	items := reqBody.GetItems()
	for k, _ := range items {
		if items[k] == nil {
			continue
		}
		if items[k].GetNums() > 100 {
			logger.Errorf("req get nums : %v more than 100, tbcode: %v", items[k].GetNums(), items[k].GetTbCode())
			continue
		}
		//批量获取元素， 对每个tbCode.
		retItems, err := alarm_service.NewLatestCacheAlarmRecord().FetchItems(items[k].GetTbCode(), items[k].GetNums())
		if err != nil {
			logger.Errorf("fetch latest alarm record from cache fail, err: %v, tbcode: %v", err, items[k].GetTbCode())
			continue
		}
		if len(retItems) == 0 {
			logger.Infof("fetch latest alarm record from cache is empty, tbcode: %v", items[k].GetTbCode())
			continue
		}
		respBody.Data = append(respBody.Data, retItems...)
	}

	respBody.ErrorCode = common.HTTPSucceed
	jsonResponse(w, respBody, http.StatusOK)
	logger.Info("-----------------End FetchUnprocAlarmLatestRecord res:", respBody.ErrorCode)
}

// CounterMeasureRecommend 无人机反制设备推荐接口
// CounterMeasureRecommend godoc
// @Summary 推荐打击无人机的设备列表
// @Description  给无人机推荐打击的设备列表
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.CounterMeasureRecommendRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=[]proto.CounterMeasureRecommendResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/handle-device/recommend [POST]
func CounterMeasureRecommend(ctx context.Context, requestBody *pb.CounterMeasureRecommendRequest) ([]*pb.CounterMeasureRecommendResponse, error) {
	logger.Infof("----------- call CounterMeasureRecommend, request: %+v", requestBody)
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	return counter_recommend.GetCounterDeviceListOnUav(ctx, tbCode, requestBody)
}
