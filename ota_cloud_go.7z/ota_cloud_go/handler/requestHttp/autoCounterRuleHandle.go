package requestHttp

import (
	"context"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	tmodel "cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	"cuav-cloud-go-service/handler/common"
	ps "cuav-cloud-go-service/infra/protocals"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// checkIsFenceArea 是否使用围栏区
func checkIsFenceArea(req *pb.AutoCounterRuleCreateRequest) bool {
	if req == nil {
		return false
	}
	if len(req.GetFenceAreaId()) > 0 {
		logger.Infof("fence area is used.")
		return true
	}
	return false
}

// checkIsCounterArea 检查是否有反制区
func checkIsCounterArea(req *pb.AutoCounterRuleCreateRequest) bool {
	if req == nil {
		return false
	}

	if req.GetCounterArea() != nil &&
		req.GetCounterArea().GetAreaName() != "" &&
		req.GetCounterArea().GetGeometry() != "" {
		logger.Infof("counter area is used.")
		return true
	}
	return false
}

// checkFenceAreaBind 判断规则表中是否绑定该围栏区
func checkFenceAreaBind(tbCode string, ruleDbHande *auto_counter_service.AutoCounterRuleOps, req *pb.AutoCounterRuleCreateRequest) bool {
	if req == nil || ruleDbHande == nil || tbCode == "" {
		return false
	}
	//
	fenceAreaId, _ := strconv.ParseInt(req.GetFenceAreaId(), 10, 64)
	err, exist := ruleDbHande.QueryFenceAreaBind(tbCode, fenceAreaId)
	if err != nil {
		return false
	}
	return exist
}

// AutoCounterRuleCreate godoc
// @Summary 自动反制规则创建
// @Description  自动反制规则创建
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.AutoCounterRuleCreateRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=pb.AutoCounterRuleCreateResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/auto-counter-rule/create [POST]
func AutoCounterRuleCreate(ctx context.Context, requestBody *pb.AutoCounterRuleCreateRequest) (*pb.AutoCounterRuleCreateResponse, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	ruleNameLen := len([]rune(requestBody.GetRuleName()))
	if ruleNameLen > 64 || ruleNameLen <= 0 {
		logger.Infof("rule name too long or empty, rule name: %v", requestBody.GetRuleName())
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleParamInvalid)
	}

	ruleId, _ := snowflake.GetUniqueID()
	ruleOps := auto_counter_service.NewAutoCounterRuleOps(nil)

	err, exist := ruleOps.CheckRuleExist(tbCode, requestBody.GetRuleName(), ruleId) //规则名存在
	if err != nil {
		logger.Infof("check rule exist fail, err: %v", err)
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
	}

	if exist {
		logger.Errorf("rule name exist")
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
	}
	isFenceArea := checkIsFenceArea(requestBody)
	isCounterArea := checkIsCounterArea(requestBody)
	if isFenceArea == true && isCounterArea == true {
		logger.Errorf("counter area and fence area all have values, not know how to use")
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
	}

	if isFenceArea == false && isCounterArea == false {
		logger.Errorf("not set counter or  fence area")
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
	}

	var crossRuleList []*pb.CrossRule
	if isFenceArea { // 使用围栏区来设置
		fenceAreaId, err := strconv.ParseInt(requestBody.GetFenceAreaId(), 10, 64)
		if err != nil {
			logger.Errorf("parse fenceAreaId fail, fenceAreaId:%v", requestBody.GetFenceAreaId())
			return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
		}

		if checkFenceAreaBind(tbCode, ruleOps, requestBody) == true {
			logger.Errorf("fence area has bind")
			return nil, ec.GetError(ec.SF_ErrorAutoCounterFenceBound)
		}
		logger.Infof("with fence area, create auto counter rule.")

		if err := ruleOps.InsertRuleItem(tbCode, ruleId, 0, fenceAreaId, requestBody); err != nil {
			logger.Errorf("insert new rule to db fail, err: %v, tbCode: %v, ruleId: %v", err, tbCode, ruleId)
			return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
		}

		items, _ := auto_counter_service.NewFenceAreaOpsHandler(nil).QueryFenceAreaByTbCodeAndId(tbCode, fenceAreaId)
		if len(items) > 0 {
			// 检查规则的适用范围是否和其他规则的适用范围 存在重叠
			if items[0] != nil {
				cruleId, _ := ruleOps.QueryAreaCross(ctx, tbCode, ruleId, nil, items[0])
				for _, ids := range cruleId {
					crossRuleList = append(crossRuleList, &pb.CrossRule{
						RuleId:   strconv.FormatInt(ids.RuleId, 10),
						RuleName: ids.RuleName,
					})
				}

			}
		}
	}

	if isCounterArea { // 使用反制区来设置
		logger.Infof("with counter area, create auto counter rule.")

		counterAreaId, _ := snowflake.GetUniqueID()
		if err := CreateNewCounterItemInDB(tbCode, counterAreaId, requestBody.GetCounterArea()); err != nil {
			logger.Errorf("insert counter area fail, err: %v", err)
			return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
		}

		if err := ruleOps.InsertRuleItem(tbCode, ruleId, counterAreaId, 0, requestBody); err != nil {
			logger.Errorf("insert new rule to db fail, err: %v, tbCode: %v, ruleId: %v", err, tbCode, ruleId)
			return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleCreated)
		}

		cruleId, _ := ruleOps.QueryAreaCross(ctx, tbCode, ruleId, requestBody.CounterArea, nil)
		for _, ids := range cruleId {
			crossRuleList = append(crossRuleList, &pb.CrossRule{
				RuleId:   strconv.FormatInt(ids.RuleId, 10),
				RuleName: ids.RuleName,
			})
		}
		// 检查
	}
	addCrOperationLog(model.AutoCounterRuleConfig{RuleName: requestBody.RuleName}, token, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeCounterRuleAdd)

	routinues.GoSafe(
		func() {
			if err := auto_counter_service.NewRuleNotifyImpl().Notify(tbCode); err != nil {
				logger.Errorf("notify to rule add fail, err: %v", err)
			}
		})

	return &pb.AutoCounterRuleCreateResponse{
		RuleId:   strconv.FormatInt(ruleId, 10),
		RuleList: crossRuleList,
	}, nil
}

// AutoCounterRuleQuery godoc
// @Summary 自动反制规则分页查询
// @Description 自动反制规则分页查询
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.AutoCounterRuleQueryRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=pb.AutoCounterRulePagingQueryResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/auto-counter-rule/query [POST]
func AutoCounterRuleQuery(ctx context.Context, requestBody *pb.AutoCounterRuleQueryRequest) (*pb.AutoCounterRulePagingQueryResponse, error) {
	//直接全量将规则信息返回
	//把规则中围栏区信息或反制区信息返回
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	if requestBody.GetPageIndex() <= 0 {
		requestBody.PageIndex = 1
		logger.Infof("get latest counter rule.")
	}

	if requestBody.GetPageSize() <= 0 {
		requestBody.PageSize = 20
	}

	return auto_counter_service.QueryRules(tbCode, requestBody, false)
}

// DelRuleOnFenceAreaDeleted 删除 规则记录
func DelRuleOnFenceAreaDeleted(tbCode string, ruleId, fenceAreaId int64) error {
	ruleOps := auto_counter_service.NewAutoCounterRuleOps(nil)

	if err := ruleOps.DeleteRuleById(tbCode, ruleId); err != nil {
		logger.Errorf("delete rule by id: %v fail, err: %v", ruleId, err)
		return ec.GetError(ec.SF_ErrorAutoCounterRuleDelete)
	}
	routinues.GoSafe(
		func() {
			if err := auto_counter_service.NewRuleNotifyImpl().Notify(tbCode); err != nil {
				logger.Errorf("notify to rule add fail, err: %v", err)
			}
		})
	return nil
}

func addCrOperationLog(cr model.AutoCounterRuleConfig, token *common.TokenContext, optType, optObject int) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("addCrOperationLog panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	content := map[string]any{constant.OptlogCounterRuleI18NPrefix + constant.ContentFieldNameRuleName: cr.RuleName}
	optLog := &tmodel.OperationLogAddIn{
		LogType:         constant.OperationLogTypeUser,
		BusinessType:    constant.OperationLogBusinessTypeCounterRule,
		OperationType:   optType,
		OperationObject: optObject,
		TbCode:          token.Payload.TbCode,
		OperatorId:      token.Payload.AccountId,
		OperatorName:    token.Payload.Account,
		Content:         content,
		Status:          constant.OperationLogStatusSuccess,
		Source:          constant.OperationLogSourceWeb,
		ToInfoWindow:    constant.OperationLogToInfoWindow,
	}
	if err := thirdpartapi.NewCloudDataService().OperationLogAdd(optLog); err != nil {
		logger.Errorf("OperationLogAdd error: %s", err.Error())
	}
}

// ModifyRule 更新规则中的字段
func ModifyRule(tbCode string, requestBody *pb.AutoCounterRuleModifyRequest) error {
	ruleId, err := strconv.ParseInt(requestBody.GetRuleId(), 10, 64)
	if err != nil {
		logger.Errorf("parse rule id fail, err: %v", err)
		return err
	}

	ruleOps := auto_counter_service.NewAutoCounterRuleOps(nil)
	item, err := ruleOps.QueryRuleByRuleId(tbCode, ruleId)
	if err != nil || item == nil {
		logger.Errorf("query rule items fail, err: %v, req item: %+v", err, requestBody.String())
		return ec.GetError(ec.SF_ErrorAutoCounterRuleModify)
	}

	if (requestBody.GetRuleEnable() == 0 || item.RuleEnable == requestBody.GetRuleEnable()) && (requestBody.GetDelFenceId() == 0 || item.FenceAreaId == 0) {
		logger.Infof("need not update status.")
		return nil
	}

	var ruleEnable int32 = 0 // set invalid value
	if item.RuleEnable != requestBody.GetRuleEnable() {
		logger.Infof("rule enable status from: %v to %v", item.RuleEnable, requestBody.GetRuleEnable())
		ruleEnable = requestBody.GetRuleEnable()
	}

	var delFenceId bool = false
	if requestBody.GetDelFenceId() > 0 && requestBody.GetDelFenceId() == item.FenceAreaId {
		logger.Infof("delete fence area id: %v, need to update rule table to 0", requestBody.GetDelFenceId())
		delFenceId = true
	}
	err = ruleOps.UpdateItems(tbCode, ruleId, ruleEnable, delFenceId)
	if err != nil {
		return err
	}

	routinues.GoSafe(
		func() {
			if err := auto_counter_service.NewRuleNotifyImpl().Notify(tbCode); err != nil {
				logger.Errorf("notify to rule add fail, err: %v", err)
			}
		})
	return nil
}

// AutoCounterRuleStatusModify godoc
// @Summary 自动规则更改
// @Description 自动规则更改
// 1. 更新状态: 规则关闭和开启。
// 2. 当围栏区删除时, 需要将围栏区的id置为0, 比如：删除其中id.
// 3. 发通知获取规则的变更
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.AutoCounterRuleModifyRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/auto-counter-rule/modify [POST]
func AutoCounterRuleStatusModify(ctx context.Context, requestBody *pb.AutoCounterRuleModifyRequest) error {

	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	return ModifyRule(tbCode, requestBody)
}

// AutoCounterRuleDeleteRequest godoc
// @Summary 自动规则删除
// @Description 自动规则删除
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.AutoCounterRuleDeleteRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/auto-counter-rule/delete [POST]
func AutoCounterRuleDeleteRequest(ctx context.Context, requestBody *pb.AutoCounterRuleDeleteRequest) error {
	//1.删除该自动反制规则
	//2. 调用通知

	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}
	if requestBody.GetRuleId() == "" {
		logger.Errorf("rule id is empty")
		return ec.GetError(ec.SF_ErrorAutoCounterRuleDelete)
	}
	ruleId, err := strconv.ParseInt(requestBody.GetRuleId(), 10, 64)
	if err != nil {
		logger.Errorf("rule id parse fail, err: %v", err)
		return ec.GetError(ec.SF_ErrorAutoCounterRuleDelete)
	}

	ruleOps := auto_counter_service.NewAutoCounterRuleOps(nil)

	if err := ruleOps.DeleteRuleById(tbCode, ruleId); err != nil {
		logger.Errorf("delete rule by id: %v fail, err: %v", requestBody.GetRuleId(), err)
		return ec.GetError(ec.SF_ErrorAutoCounterRuleDelete)
	}
	addCrOperationLog(model.AutoCounterRuleConfig{RuleName: requestBody.RuleName}, token, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeCounterRuleDelete)

	routinues.GoSafe(
		func() {
			if err := auto_counter_service.NewRuleNotifyImpl().Notify(tbCode); err != nil {
				logger.Errorf("notify to rule add fail, err: %v", err)
			}
		})
	return nil
}
