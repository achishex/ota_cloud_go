package requestHttp

import (
	"context"
	"cuav-cloud-go-service/deploy/apimap"
	"cuav-cloud-go-service/handler/request"
	"cuav-cloud-go-service/handler/response"
	"sync"
)

// QueryAddress godoc
// @Summary 根据经纬度获取地理信息
// @Description  根据经纬度获取地理信息
// @Accept   json
// @Produce  json
// @Param  request body request.QueryAddress true "request body"
// @success 200 {object} response.AddressRes{} "success response body"
// @Failure 400 {object} response.AddressRes{} "fail response body"
// @Router /rest/v1/business/query/address [POST]
func QueryAddress(ctx context.Context, req *request.QueryAddress) (*response.AddressRes, error) {
	res := &response.AddressRes{}
	var group sync.WaitGroup
	group.Add(len(req.List))
	for _, item := range req.List {
		go func(longitude, latitude float64) {
			defer group.Done()
			address := apimap.GetSite(longitude, latitude)
			res.List = append(res.List, response.AddressResItem{Longitude: longitude, Latitude: latitude, Address: address})
		}(item.Longitude, item.Latitude)
	}
	group.Wait()

	return res, nil
}
