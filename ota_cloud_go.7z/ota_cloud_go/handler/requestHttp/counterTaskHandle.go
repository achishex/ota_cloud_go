package requestHttp

import (
	"context"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/common/response"
	"cuav-cloud-go-service/domain/service/countertask"
)

// CounterTaskManualStart godoc
// @Summary 手动反制开始通知
// @Description  手动反制开始通知
// @Accept   json
// @Produce  json
// @Param  request body request.CounterTaskManualStartRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /inner/rest/v1/business/counter-task-manual/start [POST]
func CounterTaskManualStart(ctx context.Context, req *request.CounterTaskManualStartRequest) error {
	ops := countertask.NewCounterTaskOps(nil)
	return ops.CounterTaskManualStart(ctx, req)
}

// CounterStatusFeedBack godoc
// @Summary 反制状态反馈
// @Description  反制状态反馈
// @Accept   json
// @Produce  json
// @Param  request body request.CounterStatusFeedBackRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /inner/rest/v1/business/counter-task-status/feedback [POST]
func CounterStatusFeedBack(ctx context.Context, req *request.CounterStatusFeedBackRequest) error {
	return countertask.NewCounterTaskOps(nil).CounterStatusFeedBack(ctx, req)
}

// CancelCounterTask godoc
// @Summary 取消反制任务
// @Description  取消反制任务
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body request.CounterStatusFeedBackRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/counter-task/cancel [POST]
func CancelCounterTask(ctx context.Context, req *request.CounterStatusFeedBackRequest) error {
	return countertask.NewCounterTaskOps(nil).CancelTaskOnManual(ctx, req)
}

// QueryCounterTask godoc
// @Summary 查询反制任务
// @Description  查询反制任务
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body request.CounterTaskQueryRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=[]response.CounterTaskQueryResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/counter-task/query [POST]
func QueryCounterTask(ctx context.Context, reqBody *request.CounterTaskQueryRequest) (*response.CounterTaskQueryRes, error) {
	return countertask.NewCounterTaskOps(nil).QueryCounterTask(ctx, reqBody)
}

// CounterTaskProgressCount godoc
// @Summary 查询反制任务进行中个数
// @Description  查询反制任务
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body request.TaskProgressCountRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=[]response.TaskProgressCount} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /inner/rest/v1/business/counter-task/progress-count [POST]
func CounterTaskProgressCount(ctx context.Context, req *request.TaskProgressCountRequest) (*response.TaskProgressCount, error) {
	return countertask.NewCounterTaskOps(nil).CounterTaskProgressCount(ctx, req)
}
