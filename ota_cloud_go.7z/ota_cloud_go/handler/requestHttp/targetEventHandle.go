package requestHttp

import (
	"bytes"
	"context"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/errorcode"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/common/response"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/service/evidence_report"
	"cuav-cloud-go-service/handler/common"
	reqModel "cuav-cloud-go-service/handler/request"
	ps "cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"net/url"
	"path/filepath"
	"strings"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	fileTypeVideo   = ".webm"
	fileTypePicture = ".png"
	sevenDays       = 7 * 24 * 3600
)

// TargetEventQuery godoc
// @Summary 目标事件列表查询
// @Description  目标事件列表查询
// @Accept   json
// @Produce  json
// @Param  request body pb.TargetEventListRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=pb.TargetEventListResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/target-event/query [POST]
func TargetEventQuery(ctx context.Context, req *pb.TargetEventListRequest) (*pb.TargetEventListResponse, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}
	return evidence_report.NewEvidenceReportService().QueryTargetList(ctx, tbCode, req)
}

//
//// ReportFileDownload godoc
//// @Summary 报告下载
//// @Description  报告下载
//// @Accept   json
//// @Produce  json
//// @Param  request body pb.EvidenceReportDownloadReq true "request body"
//// @success 200 {array} byte "success response body"
//// @Failure 400 {array} byte "fail response body"
//// @Router /rest/v1/business/report-download [POST]
//func ReportFileDownload(w http.ResponseWriter, r *http.Request) {
//	body, err := ioutil.ReadAll(r.Body)
//	if err != nil {
//		logger.Errorf("read body fail, err: %v", err)
//		http.Error(w, fmt.Sprintf("read body fail: %s", err), http.StatusInternalServerError)
//		return
//	}
//
//	token, err := common.GetTokenPayload(r)
//	if err != nil {
//		logger.Errorf("get token fail: %v", err)
//		http.Error(w, fmt.Sprintf("get token fail: %s", err), http.StatusInternalServerError)
//		return
//	}
//
//	tbCode := token.Payload.TbCode
//	_ = tbCode
//
//	var req pb.EvidenceReportDownloadReq
//	if err := json.Unmarshal(body, &req); err != nil {
//		logger.Errorf("unmarshal body to EvidenceReportDownloadReq fail, err: %v", err)
//		http.Error(w, fmt.Sprintf("unmarshal body fail: %s", err), http.StatusInternalServerError)
//		return
//	}
//
//	safeFileName := filepath.Base(req.GetFileName())
//	filePath := filepath.Join("./res", safeFileName)
//
//	file, err := os.Open(filePath)
//	if err != nil {
//		logger.Errorf("open file fail, err: %v", err)
//		http.Error(w, fmt.Sprintf("open file fail: %s", err), http.StatusInternalServerError)
//	}
//	defer file.Close()
//
//	fileInfo, err := file.Stat()
//	if err != nil {
//		logger.Errorf("get file status fail, err: %v", err)
//		http.Error(w, fmt.Sprintf("get file status fail: %s", err), http.StatusInternalServerError)
//	}
//
//	// 设置响应头
//	w.Header().Set("Content-Disposition", "attachment; filename="+fileInfo.Name())
//	w.Header().Set("Content-Type", getMimeType(fileInfo.Name()))
//	w.Header().Set("Content-Length", fmt.Sprintf("%d", fileInfo.Size()))
//
//	if _, err := io.Copy(w, file); err != nil {
//		http.Error(w, fmt.Sprintf("read file fail: %s", err), http.StatusInternalServerError)
//	}
//	return
//}

func getMimeType(fileName string) string {
	ext := strings.ToLower(filepath.Ext(fileName))
	switch ext {
	case ".txt":
		return "text/plain"
	case ".pdf":
		return "application/pdf"
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".png":
		return "image/png"
	case ".zip":
		return "application/zip"
	default:
		return "application/octet-stream"
	}
}

// EvidenceReportDownloadDirect godoc
// @Summary 使用trackId 进行下载， 而非使用url下载
// @Description 使用trackId 进行下载， 而非 url下载
// @Accept   json
// @Produce  json
// @Param  request body proto.EvidenceReportDownloadRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/download/direct [POST]
func EvidenceReportDownloadDirect(w http.ResponseWriter, r *http.Request) {
	var (
		err error
		ctx = context.Background()
	)

	ctx = context.WithValue(ctx, constant.XLanguageHeaderKey, r.Header.Get(constant.XLanguageHeaderKey))
	ctx, err = ps.FilterLogin(ctx, r)
	if err != nil {
		logger.Errorf("parse token fail, err: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		logger.Errorf("read request body fail, err: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	var req pb.EvidenceReportDownloadRequest
	if err := json.Unmarshal(body, &req); err != nil {
		logger.Errorf("unmarshal body to EvidenceReportDownloadReq fail, err: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	if req.GetTrackId() == "" {
		logger.Errorf("track id is empty")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var fileName string
	var buf []byte
	if fileName, buf, err = EvidenceReportDownloadDirectImpl(ctx, tbCode, &req); err != nil {
		logger.Errorf("fail, err: %v, trackId: %v", err, req.GetTrackId())
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// 如果文件名包含特殊字符，需要对其进行 URL 编码
	encodedFileName := url.PathEscape(fileName)
	// 设置响应头以指示浏览器下载文件，并指定 UTF-8 编码的文件名
	contentDisposition := fmt.Sprintf("attachment; filename*=UTF-8''%s", encodedFileName)

	w.Header().Set("Content-Disposition", contentDisposition)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(buf)))

	var zeroTime time.Time
	reader := bytes.NewReader(buf)
	http.ServeContent(w, r, fileName, zeroTime, reader)
}

// EvidenceReportDownloadDirectImpl 下载报告文件并返回报告文件名, ret => filename, pathDir, error
func EvidenceReportDownloadDirectImpl(ctx context.Context, tbCode string, req *pb.EvidenceReportDownloadRequest) (string, []byte, error) {
	return evidence_report.NewEvidenceReportService().DownloadReportWithCache(ctx, tbCode, req.GetTrackId())
}

// EvidenceReportDownload godoc
// @Summary 获取 取证报告下载 url (判断下载是否有效)
// @Description  获取 取证报告下载url(判断下载是否有效), 最后下载使用 trackId 下载
// @Accept   json
// @Produce  json
// @Param  request body proto.EvidenceReportDownloadRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=proto.EvidenceReportDownloadResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/download [POST]
func EvidenceReportDownload(ctx context.Context, req *pb.EvidenceReportDownloadRequest) (*pb.EvidenceReportDownloadResponse, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}
	return evidence_report.NewEvidenceReportService().GetReportDownloadUrl(ctx, tbCode, req.GetTrackId())
}

// PreviewEvidenceReport godoc
// @Summary 查看-预览取证报告
// @Description  查看-预览取证报告, errorCode: 13310
// @Accept   json
// @Produce  json
// @Param  request body proto.EvidenceReportPreviewRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=proto.EvidenceReportPreviewResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/preview [POST]
func PreviewEvidenceReport(ctx context.Context, req *pb.EvidenceReportPreviewRequest) (*pb.EvidenceReportPreviewResponse, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	if req == nil || req.GetTrackId() == "" {
		logger.Errorf("input param is nil")
		return nil, ec.GetError(ec.SF_InValidParam)
	}

	return evidence_report.NewEvidenceReportService().PreviewEvidenceReport(ctx, tbCode, req.GetTrackId())
}

// EvidenceReportPdfUpload godoc
// @Summary 上传-取证报告pdf
// @Description  上传-取证报告pdf
// @Accept   json
// @Produce  json
// @Param  request body request.EvidenceReportPdfUploadRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=response.EvidenceReportPdfUploadResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/upload-pdf [POST]
func EvidenceReportPdfUpload(ctx context.Context, req *request.EvidenceReportPdfUploadRequest) (*response.EvidenceReportPdfUploadResponse, error) {
	if req.TrackId == "" {
		logger.Errorf("upload pdf track_id is empty")
		return nil, ec.GetError(ec.SF_InValidParam)
	}

	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	if len(req.File) <= 0 {
		logger.Errorf("upload pdf file is empty")
		return nil, ec.GetError(ec.SF_InValidParam)
	}

	err, urlRet, expirePoint := evidence_report.NewEvidenceReportService().UploadPdfFile(ctx, tbCode, req.TrackId, req.File, req.FileName)
	if err != nil {
		logger.Errorf("receive pdf upload fail, err: %v, trackId: %v", err, req.TrackId)
		return nil, err
	}

	return &response.EvidenceReportPdfUploadResponse{
		Url:             urlRet,
		ExpireTimePoint: expirePoint,
	}, err
}

// RenameReportName godoc
// @Summary 重命名报告名
// @Description   重命名报告名
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.EvidenceReportRenameRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/rename [POST]
func RenameReportName(ctx context.Context, req *pb.EvidenceReportRenameRequest) error {
	if req.GetTrackId() == "" {
		logger.Errorf("upload pdf track_id is empty")
		return ec.GetError(ec.SF_InValidParam)
	}

	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	if req.GetName() == "" {
		logger.Infof("req rename name is empty, trackId: %v", req.GetTrackId())
	}

	if err := evidence_report.NewEvidenceReportService().UpdateReportName(req.GetTrackId(), req.GetName()); err != nil {
		logger.Errorf("update report name to: %v fail: %", req.GetName(), err)
		return ec.GetError(ec.SF_ErrorRenameFail)
	}
	return nil

}

func CaptureFlyingDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	escapepath := r.URL.Query().Get("s3Path")
	if escapepath == "" {
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	path, err := url.PathUnescape(escapepath)
	if err != nil {
		logger.Errorf("CaptureFlyingDownload path %s error: %s", escapepath, err.Error())
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	buf, err := evidence_report.NewEvidenceReportService().DownloadFile(path)
	if err != nil {
		logger.Errorf("download file %s error: %v", path, err.Error())
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	pathParts := strings.Split(path, "/")
	fileName := ""
	if len(pathParts) != 0 {
		fileName = pathParts[len(pathParts)-1]
	}
	contentDisposition := fmt.Sprintf("attachment; filename*=UTF-8''%s", fileName)
	w.Header().Set("Content-Disposition", contentDisposition)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(buf)))

	var zeroTime time.Time
	reader := bytes.NewReader(buf)
	http.ServeContent(w, r, fileName, zeroTime, reader)
}

// CaptureFlyingDocumentUpload godoc
// @Summary 上传-黑飞资料
// @Description  上传-黑飞资料
// @Accept   json
// @Produce  json
// @Param  request body request.CaptureFlyingInfoUploadRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=response.CaptureFlyingDocumentUploadResponse} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/evidence/report/capture-flying-document/upload [POST]
func CaptureFlyingDocumentUpload(w http.ResponseWriter, r *http.Request) {
	reqStart := time.Now().UnixMilli()
	trackId := r.FormValue("trackId")
	if trackId == "" {
		logger.Errorf("CaptureFlyingDocumentUpload track_id is empty")
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("CaptureFlyingDocumentUpload GetTokenPayload error", err.Error())
		common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
		return
	}
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		common.CommonResponse(w, *r, nil, int(ec.SF_ErrorTokenInvalid))
		return
	}
	tbCode := token.Payload.TbCode

	extraInfoStr := r.FormValue("info")
	extraInfos := make([]reqModel.CaptureFlyingDocumentExtra, 0, 4)
	if extraInfoStr != "" {
		if err := json.Unmarshal([]byte(extraInfoStr), &extraInfos); err != nil {
			logger.Errorf("CaptureFlyingDocumentUpload extraInfos Unmarshal error: %s", err.Error())
			common.CommonResponse(w, *r, nil, int(ec.SF_InValidParam))
			return
		}
	}
	extraInfoMap := make(map[string]reqModel.CaptureFlyingDocumentExtra)
	for _, item := range extraInfos {
		extraInfoMap[item.ImgName] = item
	}

	r.ParseForm()
	if err := r.ParseMultipartForm(512 << 20); err != nil {
		logger.Errorf("CaptureFlyingDocumentUpload ParseMultipartForm error: %s", err.Error())
		common.CommonResponse(w, *r, nil, int(ec.SF_ErrorTokenInvalid))
		return
	}

	evidenceService := evidence_report.NewEvidenceReportService()
	captureFlying, err := evidenceService.GetCaptureFlyingInfoByTrackId(tbCode, trackId)
	if err != nil && err.Error() != "record not found" {
		logger.Errorf("CaptureFlyingDocumentUpload query db error: %s", err.Error())
		common.CommonResponse(w, *r, nil, int(errorcode.NotFoundError))
		return
	}
	updateFlag := false
	if captureFlying == nil {
		id, err := snowflake.GetUniqueID()
		if err != nil {
			logger.Errorf("CaptureFlyingDocumentUpload GetUniqueID error: %s", err.Error())
			common.CommonResponse(w, *r, nil, int(ec.SF_ErrorUploadCaptureFlying))
			return
		}
		captureFlying = &model.CaptureFlyingInfo{
			Id:        id,
			TbCode:    tbCode,
			TrackId:   trackId,
			CreatedAt: time.Now().UTC(),
		}
	} else {
		updateFlag = true
		logger.Infof("CaptureFlyingDocumentUpload update captureFlying {%s}.", captureFlying.TrackId)
	}
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Errorf("CaptureFlyingDocumentUpload panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
			}
		}()
		// 处理上传的文件
		files := r.MultipartForm.File["files"]
		handleChan := make(chan model.DocumentItem, len(files))
		var countDown sync.WaitGroup
		countDown.Add(len(files))
		for _, fileHeader := range files {
			// 多线程处理
			go func(header *multipart.FileHeader) {
				defer countDown.Done()
				defer func() {
					if r := recover(); r != nil {
						logger.Errorf("CaptureFlyingDocumentUpload panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
					}
				}()
				start := time.Now().UnixMilli()
				fileName := header.Filename
				fileType := parseFileType(fileName)
				if fileType != fileTypePicture && fileType != fileTypeVideo {
					logger.Errorf("CaptureFlyingDocumentUpload file type invalid: %s", fileName)
					return
				}
				file, err := header.Open()
				if err != nil {
					logger.Errorf("CaptureFlyingDocumentUpload open file error: %s", err.Error())
					return
				}
				defer file.Close()
				fileBuf := &bytes.Buffer{}
				if _, err := io.Copy(fileBuf, file); err != nil {
					logger.Errorf("CaptureFlyingDocumentUpload read file error: %s", err.Error())
					return
				}
				s3Path, _, err := evidenceService.UploadCaptureFlyingFile(context.Background(), tbCode, trackId, fileName, fileBuf.Bytes())
				if err != nil {
					logger.Errorf("receive pdf upload fail, err: %v, trackId: %v", err, trackId)
					return
				}
				url, err := evidenceService.GetDownloadUrl(s3Path, constant.PdfTrajZipFileUrlExpireSecond)
				if err != nil {
					logger.Errorf("CaptureFlyingDocumentUpload GetDownloadUrl fail, err: %v, trackId: %v", err, trackId)
				}

				logger.Infof("fileName: %s fileType: %s cost: %d", fileName, fileType, time.Now().UnixMilli()-start)
				msg := model.DocumentItem{
					Url:      url,
					S3Path:   s3Path,
					Name:     fileName,
					Type:     fileType,
					ExpireAt: time.Now().Add(constant.PdfTrajZipFileUrlExpireSecond * time.Second),
				}
				if info, ok := extraInfoMap[fileName]; ok {
					msg.PilotLatitude = info.PilotLatitude
					msg.PilotLongitude = info.PilotLongitude
					msg.ShootingAt = info.Time
				}
				sendMsg(handleChan, captureFlying.DocumentInfo, msg)
			}(fileHeader)
		}

		doneChan := make(chan struct{})
		go func() {
			defer func() {
				if r := recover(); r != nil {
					logger.Errorf("CaptureFlyingDocumentUpload consumer panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
				}
			}()
			for {
				select {
				case doc := <-handleChan:
					switch doc.Type {
					case fileTypePicture:
						if len(captureFlying.DocumentInfo.ScreenshotDocuments) >= 3 {
							break
						}
						captureFlying.DocumentInfo.ScreenshotDocuments = append(captureFlying.DocumentInfo.ScreenshotDocuments, doc)
					case fileTypeVideo:
						if len(captureFlying.DocumentInfo.VideoDocuments) != 0 {
							break
						}
						captureFlying.DocumentInfo.VideoDocuments = append(captureFlying.DocumentInfo.VideoDocuments, doc)
					default:
					}
				case <-doneChan:
					return
				}
			}
		}()
		countDown.Wait()
		doneChan <- struct{}{}

		if err := evidenceService.SaveCaptureFlyingInfo(captureFlying, updateFlag); err != nil {
			logger.Errorf("CaptureFlyingDocumentUpload update evidence error: %s", err.Error())
		}
		logger.Infof("upload cost: %d", time.Now().UnixMilli()-reqStart)
	}()

	common.CommonResponse(w, *r, &response.CaptureFlyingDocumentUploadResponse{}, common.HTTPSucceed)
}

func sendMsg(c chan model.DocumentItem, info model.DocumentInfo, doc model.DocumentItem) {
	switch doc.Type {
	case fileTypePicture:
		if len(info.VideoDocuments) >= 2 {
			break
		}
		c <- doc
	case fileTypeVideo:
		if len(info.VideoDocuments) != 0 {
			break
		}
		c <- doc
	default:
	}
}

func parseFileType(fileName string) string {
	return filepath.Ext(fileName)
}
