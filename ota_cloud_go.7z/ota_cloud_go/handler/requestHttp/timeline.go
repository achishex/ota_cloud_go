package requestHttp

import (
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/evidence_report"
	"cuav-cloud-go-service/handler/common"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	MinDuration = 10
)

// TimelineList 查询时间线
// @Summary 查询时间线
// @Description 查询时间线
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.TimelineListRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=common.TimelineListRes} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/query/eventDuration [POST]
func TimelineList(w http.ResponseWriter, r *http.Request) {
	logger.Info("-----------------TimelineList.")
	var reqBody pb.TimelineListRequest
	var respBody common.ResponseTimelineList
	if err := json.NewDecoder(r.Body).Decode(&reqBody); err != nil {
		jsonResponse(w, errors.New("bad requestHttp"), http.StatusBadRequest)
		return
	}

	token, err := common.GetTokenPayload(r)
	if err != nil {
		logger.Errorf("Failed to get token payload: %v", err)
		jsonResponse(w, err, http.StatusBadGateway)
		return
	}
	TbCode := token.Payload.TbCode

	ret, total, err := alarm_service.UavRecordDBHandler.GetFencedUAVRecords(TbCode,
		reqBody.Data.StartTime, reqBody.Data.EndTime, reqBody.Data.C2Sn, int(reqBody.PageIndex), int(reqBody.PageSize))

	if err != nil {
		logger.Errorf("Failed to ListUnReadAlarm: %v, tbcode: %v", err, token.Payload.TbCode)
		jsonResponse(w, err, http.StatusBadGateway)
	}

	// timeLineItemsCollect key 是 id; value 是事件线上记录
	var timeLineItemsCollect = make(map[int64]*pb.TimelineListResItem)
	var timeLine []*pb.TimelineListResItem

	for _, v := range ret {
		if v.RiskLevel == 0 {
			logger.Errorf("riskLevel is 0,ignore.")
			continue
		}
		var Snindex []*pb.Snindex
		err := json.Unmarshal(v.Devrelations, &Snindex)
		if err != nil {
			logger.Error("err = ", err)
		}

		var data pb.TimelineListResItem
		if len(v.Eventid) != 0 {
			var videotime []*pb.VideoTime
			err = json.Unmarshal(v.Videotime, &videotime)
			if err != nil {
				logger.Error("err = ", err)
			}
			data.VideoTime = videotime
		}

		data.EventId = v.Eventid
		data.StartTime = v.StartTime.Format(time.RFC3339Nano)
		data.EndTime = v.EndTime.Format(time.RFC3339Nano)
		if !v.StartTime.IsZero() {
			if !v.EndTime.IsZero() {
				data.Duration = int32(v.EndTime.Unix()) - int32(v.StartTime.Unix())
			} else {
				data.Duration = int32(time.Now().Unix()) - int32(v.StartTime.Unix())
			}
		}
		if data.Duration <= MinDuration {
			continue
		}
		data.Snindex = Snindex
		data.SerialNum = v.SerialNum
		data.ObjId = v.ObjID
		data.Freq = float32(v.Freq)
		data.RiskLevel = v.RiskLevel
		data.StartLongitude = v.StartLongitude
		data.StartLatitude = v.StartLatitude
		data.EndLongitude = v.Longitude
		data.EndLatitude = v.Latitude
		data.EndSite = v.EndSite
		data.StartSite = v.StartSite
		data.DroneName = v.DroneName
		data.PilotLatitude = v.PilotLatitude
		data.PilotLongitude = v.PilotLongitude
		data.HomeLatitude = v.HomeLatitude
		data.HomeLongitude = v.HomeLongitude
		data.DroneEventId = strconv.FormatInt(v.ID, 10)
		data.TrackId = v.TrackId
		data.Id = v.ID
		timeLine = append(timeLine, &data)
		//
		timeLineItemsCollect[v.ID] = &data
		logger.Debugf("qurey data = %+v", v)
	}

	validTimeLineItems := CheckInvalidTrackId(timeLineItemsCollect)
	for index, _ := range timeLine {
		item := timeLine[index]

		if item == nil {
			continue
		}
		if item.GetId() <= 0 {
			continue
		}

		// 不存在则表示 目标事件还没结束
		if _, ok := validTimeLineItems[item.GetId()]; !ok {
			logger.Errorf("track id: %v not exist in t_uav_target_event", item.GetTrackId())
			timeLine[index].TrackId = ""
		}
	}

	respBody.ErrorCode = common.HTTPSucceed
	pageIndex := reqBody.PageIndex
	pageSize := reqBody.PageSize
	pageTotal := (int32(total) / reqBody.PageSize) + 1

	respBody.Data = common.TimelineListRes{
		Data:      timeLine,
		PageIndex: pageIndex,
		PageSize:  pageSize,
		PageTotal: pageTotal,
	}

	// 将响应数据发送回客户端
	jsonResponse(w, respBody, http.StatusOK)

}

// CheckInvalidTrackId; srcTimeLineItems 的 key: timeline id
func CheckInvalidTrackId(srcTimeLineItems map[int64]*pb.TimelineListResItem) map[int64]*pb.TimelineListResItem {
	var trackIdIDRel = map[string][]int64{} // track_id => id list
	for id, _ := range srcTimeLineItems {
		timeLineItem := srcTimeLineItems[id]
		if timeLineItem == nil {
			continue
		}
		if timeLineItem.GetTrackId() == "" {
			continue
		}

		idList := trackIdIDRel[timeLineItem.GetTrackId()]
		idList = append(idList, id)
		trackIdIDRel[timeLineItem.GetTrackId()] = idList
	}

	var trackIdList []string
	for trackId, _ := range trackIdIDRel {
		if trackId == "" {
			continue
		}

		trackIdList = append(trackIdList, trackId)
	}

	retTrackList := new(evidence_report.EvidenceReportService).CheckEventTargetExist(trackIdList)
	if len(retTrackList) <= 0 {
		logger.Debugf("track list query is empty by track list: %v", trackIdList)
		return nil
	}

	var retTrackInfo = make(map[int64]*pb.TimelineListResItem)
	for _, trackId := range retTrackList {
		if len(trackId) <= 0 {
			continue
		}

		if idList, ok := trackIdIDRel[trackId]; ok {
			//logger.Debugf("trackId: %v, id list: %v", trackId, idList)

			for _, id := range idList {
				if id <= 0 {
					continue
				}

				if timeLineItem, ok := srcTimeLineItems[id]; ok {
					//logger.Debugf("add new item, id: %v, item: %v", id, *timeLineItem)
					retTrackInfo[id] = timeLineItem
				}

			}
		}
	}
	return retTrackInfo
}
