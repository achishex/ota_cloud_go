package requestHttp

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"google.golang.org/protobuf/proto"
	"testing"
	"time"
)

func TestWithFenceArea_AutoCounterRuleCreate(t *testing.T) {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	auto_counter_service.AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	auto_counter_service.FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ctx := context.WithValue(context.Background(), protocals.CtxTokenKey, &common.TokenContext{
		Payload: common.TokenPayload{
			TbCode: "000001",
		},
	})

	reqBody := &pb.AutoCounterRuleCreateRequest{
		RuleName:      "规则3",
		FenceAreaId:   "1294351668279377920",
		RuleEnable:    1,
		ForbiddenMode: 1,
		RuleTimeDay: &pb.RuleInvalidTime{
			WholeDay:    proto.Int32(0),
			StartHour:   proto.Int32(int32(9)),
			StartMinute: proto.Int32(int32(8)),
			StartSecond: proto.Int32(int32(7)),
			EndHour:     proto.Int32(int32(10)),
			EndMinute:   proto.Int32(int32(11)),
			EndSecond:   proto.Int32(int32(12)),
			CrossDay:    proto.Int32(int32(0)),
		},
	}

	response, err := AutoCounterRuleCreate(ctx, reqBody)
	if err != nil || response == nil {
		t.Logf("call AutoCounterRuleCreate fail, err: %v", err)
	} else {
		t.Logf("AutoCounterRuleCreate response: %v", response)
	}
}

func TestWithCounterArea_AutoCounterRuleCreate(t *testing.T) {

	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	auto_counter_service.AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	auto_counter_service.FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	auto_counter_service.CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](dbHandler).SetTabName(model.CounterAreaConfig{}.TableName())

	ctx := context.WithValue(context.Background(), protocals.CtxTokenKey, &common.TokenContext{
		Payload: common.TokenPayload{
			TbCode: "000001",
		},
	})

	//counterAreaReqBody := &pb.CounterAreaCreateRequest{
	//	// required: true
	//	// example: 反制区1
	//	// 反制区名字
	//	AreaName: "反制区1",
	//	// required: true
	//	// example: 12.12
	//	// 围栏区周长
	//	AreaPerimeter: 16.7900000,
	//	// required: true
	//	// example: 12.12
	//	// 围栏区面积
	//	AreaSquare: 9151732.8000000,
	//	// required: true
	//	// example: 114.4692414
	//	// 围栏区中心点经度
	//	CentroidLongitude: 114.0919889,
	//	// required: true
	//	// example:22.562659
	//	// 围栏区中心点纬度
	//	CentroidLatitude: 22.6271349,
	//	// required: true
	//	// example: {}
	//	// 围栏区几何信息
	//	Geometry: `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[114.08500798614935,22.611183496839246],[114.12792333038756,22.644140611451334],[114.06303532989939,22.626078556067373],[114.08500798614935,22.611183496839246]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
	//}
	//err := CounterAreaCreate(ctx, counterAreaReqBody)
	//if err != nil {
	//	t.Logf("create counter area fail, err: %v", err)
	//} else {
	//	t.Logf("create counter area succ.")
	//}

	//
	reqBody := &pb.AutoCounterRuleCreateRequest{
		RuleName: "规则-反制区",
		CounterArea: &pb.CounterAreaCreateRequest{
			// required: true
			// example: 反制区1
			// 反制区名字
			AreaName: "反制区1",
			// required: true
			// example: 12.12
			// 围栏区周长
			AreaPerimeter: 16.79,
			// required: true
			// example: 12.12
			// 围栏区面积
			AreaSquare: 9151732.8,
			// required: true
			// example: 114.4692414
			// 围栏区中心点经度
			CentroidLongitude: 114.0919889,
			// required: true
			// example:22.562659
			// 围栏区中心点纬度
			CentroidLatitude: 22.6271349,
			// required: true
			// example: {}
			// 围栏区几何信息
			Geometry: `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[114.08500798614935,22.611183496839246],[114.12792333038756,22.644140611451334],[114.06303532989939,22.626078556067373],[114.08500798614935,22.611183496839246]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
		},
		RuleEnable:    1,
		ForbiddenMode: 1,
		RuleTimeDay: &pb.RuleInvalidTime{
			WholeDay:    proto.Int32(0),
			StartHour:   proto.Int32(int32(9)),
			StartMinute: proto.Int32(int32(8)),
			StartSecond: proto.Int32(int32(7)),
			EndHour:     proto.Int32(int32(10)),
			EndMinute:   proto.Int32(int32(11)),
			EndSecond:   proto.Int32(int32(12)),
			CrossDay:    proto.Int32(int32(0)),
		},
	}

	response, err := AutoCounterRuleCreate(ctx, reqBody)
	if err != nil || response == nil {
		t.Logf("call AutoCounterRuleCreate fail, err: %v", err)
	} else {
		t.Logf("AutoCounterRuleCreate response: %v", response)
	}
}

func TestAutoCounterRuleQuery(t *testing.T) {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	auto_counter_service.AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	auto_counter_service.FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ctx := context.WithValue(context.Background(), protocals.CtxTokenKey, &common.TokenContext{
		Payload: common.TokenPayload{
			TbCode: "000001",
		},
	})

	req := &pb.AutoCounterRuleQueryRequest{
		PageIndex: 1,
		PageSize:  10,
	}
	response, err := AutoCounterRuleQuery(ctx, req)
	if err != nil {
		t.Logf("AutoCounterRuleQuery fail, err: %v", err)
	} else if response == nil {
		t.Logf("AutoCounterRuleQuery ret is nil")
	} else {
		t.Logf("pageSize: %v, pageIndex: %v, totalNums: %v", response.PageSize, response.PageIndex, response.TotalNums)
		for i := 0; i < len(response.Data); i++ {
			t.Logf("AutoCounterRuleQuery ret: %+v", response.Data[i])
		}
	}
}

func TestTimeStampUTC(t *testing.T) {
	nowTm := time.Now().Local()
	utcTm := nowTm.UTC()
	t.Logf("nowTm: %v, utcTm: %v", nowTm, utcTm)

	t.Logf("nowTm: %v", nowTm.UnixMilli())
	t.Logf("utcTm: %v", utcTm.UnixMilli())
}

func TestAutoCounterRuleStatusModify(t *testing.T) {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	auto_counter_service.AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	auto_counter_service.FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ctx := context.WithValue(context.Background(), protocals.CtxTokenKey, &common.TokenContext{
		Payload: common.TokenPayload{
			TbCode: "000001",
		},
	})

	req := &pb.AutoCounterRuleModifyRequest{
		RuleId:     "1294604594611617792",
		RuleEnable: 2, //关闭
	}

	err := AutoCounterRuleStatusModify(ctx, req)
	if err != nil {
		t.Logf("modify rule to close, err: %v", err)
	} else {
		t.Logf("modify rule to close succ")
	}
}

func TestAutoCounterRuleDeleteRequest(t *testing.T) {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	auto_counter_service.AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	auto_counter_service.FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ctx := context.WithValue(context.Background(), protocals.CtxTokenKey, &common.TokenContext{
		Payload: common.TokenPayload{
			TbCode: "000001",
		},
	})

	req := &pb.AutoCounterRuleDeleteRequest{
		RuleId: "1294604594611617792",
	}

	if err := AutoCounterRuleDeleteRequest(ctx, req); err != nil {
		t.Logf("delete rule from table, err: %v", err)
	} else {
		t.Logf("delete rule from table succ.")
	}

}
