package requestHttp

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/deploy/snowflake"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	ps "cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"strconv"
)

func CreateNewCounterItemInDB(tbCode string, counterAreaId int64, requestBody *pb.CounterAreaCreateRequest) error {
	counterOps := auto_counter_service.NewCounterAreaOpsHandler(nil)
	if err := counterOps.InsertCounterAreaItem(requestBody, tbCode, counterAreaId); err != nil {
		logger.Errorf("insert counter area fail, err: %v", err)
		return errors.New("create counter area fail")
	}
	return nil
}

// CounterAreaCreate godoc
// @Summary 反制区创建
// @Description  反制区创建
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.CounterAreaCreateRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/counter-area/create [POST]
func CounterAreaCreate(ctx context.Context, requestBody *pb.CounterAreaCreateRequest) error {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}
	//1. 根据tb_code, area_name and id 查询记录是否存在； 错误或者存在则返回错误。
	//2. 插入表中，
	//3. 暂时由规则的创建来触发，发送kafka通知。

	id, _ := snowflake.GetUniqueID()
	return CreateNewCounterItemInDB(tbCode, id, requestBody)
}

// CounterAreaQuery godoc
// @Summary 反制区查询
// @Description   反制区查询
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.CounterAreaQueryRequest true "request body"
// @success 200 {object} protocals.HttpResponse{data=[]pb.CounterAreaList} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/counter-area/query [POST]
func CounterAreaQuery(ctx context.Context, requestBody *pb.CounterAreaQueryRequest) ([]*pb.CounterAreaList, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}
	counterOps := auto_counter_service.NewCounterAreaOpsHandler(nil)
	data, err := counterOps.QueryCounterAreasByTbCode(tbCode)
	if err != nil {
		return nil, errors.New("is error query")
	}

	ret := []*pb.CounterAreaList{}
	for _, v := range data {
		ret = append(ret, &pb.CounterAreaList{
			// required: true
			// id: 1231313123131
			// 围栏区几何信息
			Id: v.ID,
			// required: true
			// areaName: 反制区1
			// 围栏区几何信息
			AreaName: v.AreaName,
			// required: true
			// example: 123.123213
			// 围栏区周长
			AreaPerimeter: v.AreaPerimeter,
			// required: true
			// example: {}
			// 围栏区面积
			AreaSquare: v.AreaSquare,
			// required: true
			// example: 145.1212
			// 围栏区中心点经度
			CentroidLongitude: v.CentroidLongitude,
			// required: true
			// example:22.452262
			// 围栏区中心点纬度
			CentroidLatitude: v.CentroidLatitude,
			// required: true
			// example: {}
			// 围栏区几何信息
			Geometry: v.Geometry,
			// required: true
			// example: {}
			// 创建时间
			CreateTime: strconv.FormatInt(v.CreateTime.UTC().UnixMilli(), 10),
			// required: false
			// example: {}
			// 更新时间
			UpdateTime: strconv.FormatInt(v.UpdateTime.UTC().UnixMilli(), 10),
			// required: false
			// example: 7422123123123
			// 围栏区id(使用围栏区指定反制区)
			FenceAreaId: v.FenceAreaId,
		})
	}
	return ret, nil
}

// CounterAreaDelete godoc
// @Summary 反制区删除
// @Description  反制区删除
// @Accept   json
// @Produce  json
// @Param Authorization header string true "token"
// @Param  request body proto.CounterAreaDeleteRequest true "request body"
// @success 200 {object} protocals.HttpResponse{} "success response body"
// @Failure 400 {object} protocals.HttpResponse{} "fail response body"
// @Router /rest/v1/business/counter-area/delete [POST]
func CounterAreaDelete(ctx context.Context, requestBody *pb.CounterAreaDeleteRequest) error {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}

	tbCode := token.Payload.TbCode
	if token.IsDebug != "" {
		tbCode = token.IsDebug
		logger.Infof("use isDebug value as tbCode: %v", tbCode)
	}

	counterAreaId, err := strconv.ParseInt(requestBody.GetId(), 10, 64)
	if requestBody.GetId() == "" || err != nil {
		logger.Errorf("counter area id is empty")
		return ec.GetError(ec.SF_ErrorTokenInvalid)
	}
	counterOps := auto_counter_service.NewCounterAreaOpsHandler(nil)

	if err := counterOps.DeleteCounterAreaItem(counterAreaId); err != nil {
		logger.Errorf("delete counter area fail, tbCode: %v, err: %v", tbCode, err)
		return err
	}
	return nil
}
