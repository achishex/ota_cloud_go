package response

type UavWhitelistItem struct {
	Id         int64  `json:"id"`         // id
	SerialNum  string `json:"serialNum"`  // 无人机编号
	TbCode     string `json:"tbCode"`     // 企业编号
	Vendor     string `json:"vendor"`     // 供应商
	Model      string `json:"model"`      // 无人机型号
	Role       int    `json:"role"`       // 角色
	Usage      int    `json:"usage"`      // 用途
	UsageDesc  string `json:"usageDesc"`  // 用途描述
	Remark     string `json:"remark"`     // 备注
	CreateTime int64  `json:"createTime"` // 创建时间
	UpdateTime int64  `json:"updateTime"` // 更新时间
}

type UavWhitelistRes struct {
	List     []*UavWhitelistItem `json:"list"`
	PageNo   int                 `json:"pageNo"`
	PageSize int                 `json:"pageSize"`
	Total    int64               `json:"total"`
}
