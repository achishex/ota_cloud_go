package response

type AddressResItem struct {
	Longitude float64 `json:"longitude"`
	Latitude  float64 `json:"latitude"`
	Address   string  `json:"address"`
}

type AddressRes struct {
	List []AddressResItem `json:"list"`
}
