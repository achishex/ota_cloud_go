package request

type QueryAddressItem struct {
	Longitude float64 `json:"longitude"`
	Latitude  float64 `json:"latitude"`
}

type QueryAddress struct {
	List []QueryAddressItem `json:"list"`
}
