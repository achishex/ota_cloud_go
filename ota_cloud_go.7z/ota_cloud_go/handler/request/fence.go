package request

type InnerListFenceRequest struct {
	TbCode string `json:"tbCode"`
}
