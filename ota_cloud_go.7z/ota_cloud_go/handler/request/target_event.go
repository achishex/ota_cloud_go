package request

type CaptureFlyingDocumentExtra struct {
	ImgName        string  `json:"imgName"`
	Time           string  `json:"time"`
	PilotLongitude float64 `json:"pilotLongitude"`
	PilotLatitude  float64 `json:"pilotLatitude"`
}
