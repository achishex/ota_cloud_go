package common

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/service/uavwhitelist"
	"cuav-cloud-go-service/handler/callrpc"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
)

func CallRpcFenceSync(req *pb.C2OnlineRequest) {
	syncReq := &pb.SyncFenceRequest{
		TbCode: req.TbCode,
		C2Sn:   req.C2Sn,
	}
	//查数据库
	syncReq.FenceList = make([]*pb.FenceList, 0)
	var fencedAreaConfigs []bean.FencedAreaConfig
	if err := config.GetDB().Where("tb_code = ?", req.TbCode).Find(&fencedAreaConfigs).Error; err != nil {
		logger.Errorf("Failed to get fenced area configs: %v", err)
		return
	}
	for _, areaConfig := range fencedAreaConfigs {
		syncReq.FenceList = append(syncReq.FenceList, &pb.FenceList{
			FenceName:         areaConfig.AreaName,
			FenceType:         int32(areaConfig.AreaType),
			FencePerimeter:    areaConfig.AreaPerimeter,
			FenceSquare:       areaConfig.AreaSquare,
			CentroidLongitude: areaConfig.CentroidLongitude,
			CentroidLatitude:  areaConfig.CentroidLatitude,
			Geometry:          areaConfig.Geometry,
			UpdateTime:        areaConfig.UpdateTime,
			DeleteTime:        areaConfig.DeleteTime,
		})
	}
	rpcReq, err := proto.Marshal(syncReq)
	if err != nil {
		logger.Errorf("Failed to parse GrpcFenceSyncRequest: %v", err)
		return
	}
	logger.Info("rpcReq:", rpcReq)
	rpcRsp := callrpc.CallExecuteMethod(SendGrpcFenceSyncRequest, rpcReq)
	logger.Info("GrpcFenceSyncRequest rsp:%v", rpcRsp)
}

func CallRpcUavWhitelistSync(req *pb.C2OnlineRequest, list []*pb.UavInfo) {
	func() {
		if err := recover(); err != nil {
			logger.Errorf("CallRpcUavWhitelistSync panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	time.Sleep(1 * time.Second)
	syncReq := &pb.UavWhitelistSyncRequest{
		TbCode: req.TbCode,
		C2Sn:   req.C2Sn,
	}
	// 获取白名单列表
	if len(list) == 0 {
		uwList, err := uavwhitelist.NewUavWhitelistService().UavWhitelist(req.TbCode, false)
		if err != nil {
			logger.Errorf("CallRpcUavWhitelistSync UavWhitelist error: %s", err.Error())
			return
		}
		uavInfolist := make([]*pb.UavInfo, 0, len(uwList))
		uwlistM := make(map[string]*model.TUavWhite)
		// 根据最新的去重
		for _, uw := range uwList {
			if val, ok := uwlistM[uw.SerialNum]; ok && val.UpdateTime.UTC().UnixMilli() > uw.UpdateTime.UTC().UnixMilli() {
				continue
			} else {
				uwlistM[uw.SerialNum] = uw
			}
		}
		for _, uw := range uwlistM {
			item := &pb.UavInfo{
				SerialNum:  uw.SerialNum,
				Vendor:     uw.Vendor,
				Model:      uw.Model,
				Role:       int32(uw.Role),
				Usage:      int32(uw.Usage),
				UsageDesc:  uw.UsageDesc,
				Remark:     uw.Remark,
				Status:     int32(uw.Status),
				CreateTime: uw.CreateTime.UTC().UnixMilli(),
				UpdateTime: uw.UpdateTime.UTC().UnixMilli(),
			}
			uavInfolist = append(uavInfolist, item)
		}
		list = uavInfolist
	}
	syncReq.UavBlackWhiteRuleList = list
	logger.Debugf("c2Sn: %s \n result: %+v \n len: %d", syncReq.C2Sn, syncReq.UavBlackWhiteRuleList, len(syncReq.UavBlackWhiteRuleList))
	rpcReq, err := proto.Marshal(syncReq)
	if err != nil {
		logger.Errorf("Failed to parse GrpcUavWhiteSyncRequest: %v", err)
		return
	}
	rpcRsp := callrpc.CallExecuteMethod(SendGrpcUavWhiteSyncRequest, rpcReq)
	logger.Debugf("GrpcUavWhiteSyncRequest rsp:%v", rpcRsp)
}
