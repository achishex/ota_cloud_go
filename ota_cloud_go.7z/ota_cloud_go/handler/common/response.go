package common

import (
	"cuav-cloud-go-service/deploy/i18nlib"
	"cuav-cloud-go-service/domain/common/constant"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type Response struct {
	ErrorCode    int32  `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         string `json:"data"`
}
type ResponseFenceResList struct {
	ErrorCode    int32              `json:"errorCode"`
	ErrorMessage string             `json:"errorMessage"`
	Data         []*pb.FenceResList `json:"data"`
}

type GatewayDeviceResult struct {
	SN string `json:"sn"`
}
type ReqC2ListResponse struct {
	ErrorCode    int32  `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         struct {
		Items []*GatewayDeviceResult `json:"data"`
	} `json:"data"`
}

type ResponseAlarmUnReadList struct {
	ErrorCode    int32                   `json:"errorCode"`
	ErrorMessage string                  `json:"errorMessage"`
	Data         []*pb.AlarmCheckRspItem `json:"data"`
}

// ResponseAlarmUpdate 手动请求更新告警记录返回值
type ResponseAlarmUpdate struct {
	ErrorCode    int32                      `json:"errorCode"`
	ErrorMessage string                     `json:"errorMessage"`
	Data         []*pb.AlarmStatusUpdateRet `json:"data"`
}

type ResponseFetchUnProcAlarmLatest struct {
	ErrorCode    int32                   `json:"errorCode"`
	ErrorMessage string                  `json:"errorMessage"`
	Data         []*pb.AlarmCheckRspItem `json:"data"`
}

type httpResponse struct {
	ErrorCode    int32  `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         any    `json:"data"`
}

type TimelineListRes struct {
	Data      []*pb.TimelineListResItem `json:"data"`
	PageTotal int32                     `json:"pageTotal"`
	PageIndex int32                     `json:"pageIndex"`
	PageSize  int32                     `json:"pageSize"`
}

type ResponseTimelineList struct {
	ErrorCode    int32           `json:"errorCode"`
	ErrorMessage string          `json:"errorMessage"`
	Data         TimelineListRes `json:"data"`
}

func DefaultResponse(w http.ResponseWriter, data interface{}, err error, errCode int) {
	result := httpResponse{}
	if err != nil {
		result.ErrorCode = int32(errCode)
		result.ErrorMessage = err.Error()
	} else {
		result.Data = data
	}
	response, err := json.Marshal(result)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(response)
}

func CommonResponse(w http.ResponseWriter, r http.Request, data interface{}, errCode int, args ...any) {
	result := httpResponse{}
	language := r.Header.Get(constant.XLanguageHeaderKey)
	if errCode != 0 {
		result.ErrorCode = int32(errCode)
		msg, err := i18nlib.GetValue(strconv.Itoa(errCode), language)
		if err != nil {
			logger.Errorf("I18n GetValue error: %s", err.Error())
			result.ErrorMessage = err.Error()
		} else {
			result.ErrorMessage = fmt.Sprintf(msg, args...)
		}
	} else {
		result.Data = data
	}
	response, err := json.Marshal(result)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	w.Header().Set(constant.ContentTypeHeaderKey, constant.ContentTypeJson)
	w.WriteHeader(http.StatusOK)
	w.Write(response)
}
