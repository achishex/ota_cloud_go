package common

import (
	"cuav-cloud-go-service/config"
	pb "cuav-cloud-go-service/proto"
	"testing"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func initResource() {
	if err := logger.Init("./application-dev.yml",
		"/logs/ms_log/cuav-cloud-go-service"); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return
	}
	config.InitConfig("./application-dev.yml")
	// 初始化数据库
	_, err := config.InitDB()
	if err != nil {
		// logger.Fatalf("InitSqlite err %v", err)
		return
	}
	config.InitRedis()
}

func TestCallRpcUavWhitelistSync(t *testing.T) {
	initResource()
	type args struct {
		req *pb.C2OnlineRequest
	}
	tests := []struct {
		name string
		args args
	}{
		{name: "ppb1", args: args{req: &pb.C2OnlineRequest{TbCode: "000001", C2Sn: "00000000001"}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			CallRpcUavWhitelistSync(tt.args.req, nil)
		})
	}
}
