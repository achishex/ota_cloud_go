package common

const (
	GRPCSucceed = 0
	GRPCFailed  = 1
)

const (
	HTTPSucceed = 0
	HTTPFailed  = -1
)

const (
	GrpcC2OnLineRequest     = "/inner/grpc/v1/c2/online"
	GrpcAlarmFenceRequest   = "/inner/grpc/v1/alarm-fence/get"
	GrpcAlarmFenceCheck     = "/inner/grpc/v1/alarm-fence/alarm_check"
	GrpcUavWhiteSync        = "/inner/grpc/v1/whitelist/sync"
	GrpcUavWhitelist        = "/inner/grpc/v1/whitelist/list"
	GrpcDeviceStatusSync    = "/inner/grpc/v1/heartbeat/dispatch"
	GrpcEvidenceStatsNotify = "/inner/grpc/v1/evidence/status/notify" // 取证报告-目标事件状态变更通知
)

const (
	SendGrpcFenceSyncRequest    = "/inner/grpc/v1/fence/sync"
	SendGrpcUavWhiteSyncRequest = "/inner/grpc/v1/black-white-rule/sync"
)
