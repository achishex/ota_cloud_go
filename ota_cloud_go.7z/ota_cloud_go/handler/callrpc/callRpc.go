package callrpc

import (
	"context"
	pb "cuav-cloud-go-service/proto"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/grpc"
)

func CallExecuteMethod(url string, data []byte) *pb.GrpcResult {
	logger.Info("Start call url: ", url)

	//
	conn, err := grpc.Dial("cuav-cloud-access-service:18883", grpc.WithInsecure())
	if err != nil {
		logger.Errorf("did not connect: %v", err)
		return nil
	}
	defer conn.Close()

	grpcPortalService := pb.NewCuavCloudAccessServiceClient(conn)

	req := &pb.GrpcRequest{
		Header: nil,
		Url:    url,
		Data:   data,
	}

	rsp, err := grpcPortalService.Execute(context.Background(), req)
	if err != nil {
		logger.Errorf("Error calling Execute: ", err)
		return rsp
	}
	logger.Info("Response url:", rsp)
	return rsp
}
