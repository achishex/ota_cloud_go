package requestRpc

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"fmt"
)

// InitGrpcRouter 所有grpc 对外接口的 url 和 process handle 注册入口
func InitGrpcRouter() {
	protocals.RegisterGrpcProcessNoOut(common.GrpcC2OnLineRequest, C2OnlineSync)
	protocals.RegisterGrpcProcess(common.GrpcAlarmFenceCheck, AlarmFenceCheckLogicProcess)
	protocals.RegisterGrpcProcessNoOut(common.GrpcUavWhiteSync, NewUavWhitelistHandler().DealUavWhitelistSyncV2)
	protocals.RegisterGrpcProcess(common.GrpcUavWhitelist, NewUavWhitelistHandler().DealGetUavWhitelistV2)
	protocals.RegisterGrpcProcessNoOut(common.GrpcDeviceStatusSync, NewDeviceInfoSyncHandler().ReceiveSyncDevHeartBeatInfoV2)
	// 目标事件状态变更通知
	protocals.RegisterGrpcProcessNoOut(common.GrpcEvidenceStatsNotify, NewEvidenceReportHandlerImpl().StatusNotifyProcess)
	//Add other process.
}

type CuavCloudGoService struct {
}

func NewCuavCloudGoService() *CuavCloudGoService {
	return &CuavCloudGoService{}
}

func (s *CuavCloudGoService) Execute(ctx context.Context, in *pb.ExecuteBussinessRequest, out *pb.ExecuteBussinessResponse) error {
	callFn := protocals.CallGrpcByUrl(in.GetUrl())
	if callFn == nil {
		logger.Errorf("not get process func for url: %v", in.GetUrl())
		return fmt.Errorf("not support url process")
	}

	callFn(ctx, in, out)
	return nil
}
