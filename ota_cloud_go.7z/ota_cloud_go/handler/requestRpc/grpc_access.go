package requestRpc

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"go-micro.dev/v4/server"
	gpb "google.golang.org/protobuf/proto"
	"reflect"
	"time"
)

const (
	GrpcBodyKey = "body"
)

func GetBody[T any](ctx context.Context) (*T, error) {
	v := ctx.Value(GrpcBodyKey)
	data, ok := v.(*T)
	if !ok {
		return nil, fmt.Errorf("parse grpc body fail")
	}
	if data == nil {
		return nil, fmt.Errorf("not get data, is nil")
	}
	return data, nil
}

func GrpcBodyParser[T gpb.Message](ctx context.Context, data []byte) (context.Context, error) {
	if len(data) == 0 {
		logger.Errorf("body data is nil")
		return ctx, fmt.Errorf("body data is nil")
	}

	var m1 T
	if reflect.TypeOf(m1).Kind() == reflect.Ptr {
		msg := reflect.New(reflect.TypeOf(m1).Elem())
		err := gpb.Unmarshal(data, msg.Interface().(gpb.Message))
		if err != nil {
			return ctx, err
		}
		retCtx := context.WithValue(ctx, GrpcBodyKey, msg.Interface())
		return retCtx, nil
	}
	return ctx, nil
}

type GrpcMsgProcessInterface struct {
	parseBody func(ctx context.Context, data []byte) (context.Context, error)
}

var UrlRelation map[string]*GrpcMsgProcessInterface = make(map[string]*GrpcMsgProcessInterface) //包括body 解析

type GrpcAccessWrapper struct {
}

// RegisterGrpcBodyProcess 定义消息处理函数的统一入口，各个消息需要手动调用
func RegisterGrpcBodyProcess[T gpb.Message](url string) {
	UrlRelation[url] = &GrpcMsgProcessInterface{
		parseBody: GrpcBodyParser[T],
	}
}
func (w *GrpcAccessWrapper) HandlerFunc(fn server.HandlerFunc) server.HandlerFunc {
	return func(ctx context.Context, req server.Request, rsp interface{}) error {
		processBegin := time.Now()
		reqBody := reflect.ValueOf(req.Body())

		if reqBody.Kind() != reflect.Ptr {
			logger.Errorf("receive data is not ptr")
			return errors.New("request body is is not ptr")
		}
		body, ok := reqBody.Interface().(*proto.ExecuteBussinessRequest)
		if !ok {
			logger.Errorf("request body is not proto.ExecuteBussinessRequest pointer.")
			return fmt.Errorf("request body is not *proto.ExecuteBussinessRequest.")
		}
		if body == nil {
			logger.Errorf("request body is nil")
			return fmt.Errorf("request body is nil")
		}

		url := body.GetUrl()

		err := fn(ctx, req, rsp)

		endTime := time.Now()
		diff := endTime.Sub(processBegin)
		logger.Infof("grpc url: [%v], cost: %d ms", url, diff/time.Millisecond)
		return err
	}
}
func NewGrpcAccessWrapper() server.HandlerWrapper {
	grpcAccess := &GrpcAccessWrapper{}

	return grpcAccess.HandlerFunc
}
