package requestRpc

import (
	pb "cuav-cloud-go-service/proto"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func checkInParam(r *pb.AlarmCheckRequest) int {
	if r == nil {
		return -1
	}
	if len(r.GetItems()) == 0 {
		logger.Errorf("alarm check tbCode is empty")
		return -2
	}
	return 1
}
