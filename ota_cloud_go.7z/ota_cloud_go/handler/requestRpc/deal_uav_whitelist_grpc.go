package requestRpc

import (
	"context"
	"cuav-cloud-go-service/domain/service/uavwhitelist"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/handler/requestHttp"
	pb "cuav-cloud-go-service/proto"
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
)

type uavWhitelistHandler struct {
	srv *uavwhitelist.UavWhitelistService
}

func NewUavWhitelistHandler() *uavWhitelistHandler {
	return &uavWhitelistHandler{
		srv: uavwhitelist.NewUavWhitelistService(),
	}
}

func (u *uavWhitelistHandler) DealUavWhitelistSync(in *pb.ExecuteBussinessRequest) *pb.ExecuteBussinessResponse {
	logger.Infof("---------------> call DealUavWhitelistSync")
	rsp := &pb.ExecuteBussinessResponse{
		ErrorCode: common.GRPCSucceed,
		ErrorMsg:  "success",
	}

	req := &pb.UavWhitelistSyncRequest{}
	if err := proto.Unmarshal(in.Data, req); err != nil {
		logger.Errorf("Failed to parse DealUavWhitelistSync, err: %v", err)
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "unmarshal fail"
		return rsp
	}
	if err := u.srv.UavWhitelistSync(req); err != nil {
		logger.Errorf("Failed to parse DealUavWhitelistSync, err: %v", err)
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "DealUavWhitelistSync fail"
		return rsp
	}

	// 异步通知C2
	go requestHttp.SyncWhitelistToC2Dev(req.TbCode)

	return rsp
}

// DealUavWhitelistSyncV2  ExecuteBussinessResponse is client response,
func (u *uavWhitelistHandler) DealUavWhitelistSyncV2(ctx context.Context, req *pb.UavWhitelistSyncRequest) error {
	if err := u.srv.UavWhitelistSync(req); err != nil {
		logger.Errorf("Failed to parse DealUavWhitelistSync, err: %v", err)
		return errors.New("DealUavWhitelistSync fail")
	}

	// 异步通知C2
	go requestHttp.SyncWhitelistToC2Dev(req.TbCode)
	return nil
}
func (u *uavWhitelistHandler) DealGetUavWhitelist(in *pb.ExecuteBussinessRequest) *pb.ExecuteBussinessResponse {
	logger.Infof("---------------> call DealGetUavWhitelist")
	rsp := &pb.ExecuteBussinessResponse{
		ErrorCode: common.GRPCSucceed,
		ErrorMsg:  "success",
	}

	req := &pb.UavWhitelistListReq{}
	if err := proto.Unmarshal(in.Data, req); err != nil {
		logger.Errorf("Failed to parse AlarmCheckRequest, err: %s", err.Error())
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "unmarshal fail"
		return rsp
	}

	result, err := u.srv.GetUavWhitelist(req, true)
	if err != nil {
		logger.Errorf("Failed to GetUavWhitelist, err: %s", err.Error())
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "Failed to GetUavWhitelist"
		return rsp
	}
	retBuf, err := proto.Marshal(result)
	if err != nil {
		logger.Errorf("marsh pb to bin fail, err: %v", err)
		rsp.ErrorMsg = "marshal response to pb fail"
		rsp.ErrorCode = common.GRPCFailed
		return rsp
	}
	rsp.Data = retBuf
	return rsp
}

func (u *uavWhitelistHandler) DealGetUavWhitelistV2(ctx context.Context, req *pb.UavWhitelistListReq) (*pb.UavWhitelistRes, error) {
	result, err := u.srv.GetUavWhitelist(req, true)
	if err != nil {
		logger.Errorf("Failed to GetUavWhitelist, err: %s", err.Error())
		return nil, errors.New("Failed to GetUavWhitelist")
	}
	return result, nil
}
