package requestRpc

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/handler/common"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"google.golang.org/protobuf/proto"
)

// deviceInfoSyncHandler 设备同步信息处理逻辑
type deviceInfoSyncHandler struct {
	deviceMngHandle *device_manager.DeviceManager
}

// NewDeviceInfoSyncHandler 创建设备同步信息对象
func NewDeviceInfoSyncHandler() *deviceInfoSyncHandler {
	return &deviceInfoSyncHandler{
		deviceMngHandle: device_manager.NewDeviceManager(),
	}
}

func printSyncPreview(data *pb.DevStatusSyncRequest) string {
	if data == nil {
		return ""
	}
	//
	var printBuf string
	for tbCode, item := range data.Items {
		devTypeSn := ""
		for _, v := range item.DevInfo {
			if v == nil {
				continue
			}
			devTypeSn = fmt.Sprintf("%s, devType: %s , c2Sn: %s,", devTypeSn, v.DevType, v.C2Sn)
		}
		printBuf = fmt.Sprintf("%s; tbCode: %v, %s", printBuf, tbCode, devTypeSn)

	}
	return printBuf
}

// ReceiveSyncDevHeartBeatInfo  接收数据同步
func (d *deviceInfoSyncHandler) ReceiveSyncDevHeartBeatInfo(in *pb.ExecuteBussinessRequest) *pb.ExecuteBussinessResponse {
	//logger.Infof("---------------> call ReceiveSyncInfo")
	rsp := &pb.ExecuteBussinessResponse{
		ErrorCode: common.GRPCSucceed,
		ErrorMsg:  "success",
	}

	req := &pb.DevStatusSyncRequest{}
	if err := proto.Unmarshal(in.Data, req); err != nil {
		logger.Errorf("Failed to parse DevStatusSyncRequest, err: %v", err)
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "unmarshal fail"
		return rsp
	}
	//logger.Infof("req: %+v", printSyncPreview(req))
	if err := d.deviceMngHandle.WriteToCache(req); err != nil {
		logger.Errorf("Failed to write device to cache fail, err: %v", err)
		rsp.ErrorCode = common.GRPCFailed
		rsp.ErrorMsg = "device info sync fail"
		return rsp
	}

	return rsp
}

func (d *deviceInfoSyncHandler) ReceiveSyncDevHeartBeatInfoV2(ctx context.Context, req *pb.DevStatusSyncRequest) error {
	if err := d.deviceMngHandle.WriteToCache(req); err != nil {
		logger.Errorf("Failed to write device to cache fail, err: %v", err)
		return errors.New("device info sync fail")
	}
	return nil
}
