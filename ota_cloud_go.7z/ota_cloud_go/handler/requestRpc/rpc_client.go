package requestRpc

import (
	"context"
	"cuav-cloud-go-service/handler/common"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	grpcc "github.com/go-micro/plugins/v4/client/grpc"
	"go-micro.dev/v4"
	"google.golang.org/protobuf/proto"
)

func buildCheckAlarmReqDemo() *pb.AlarmCheckRequest {
	item := &pb.AlarmCheckRequest{}
	item.Items = make(map[string]*pb.AlarmCheckReqItem)

	item.Items["000001"] = &pb.AlarmCheckReqItem{
		TbCode:     "0000001",
		C2Location: make(map[string]*pb.C2LocationInfo),
		UavItems: []*pb.DevLocationInfo{
			&pb.DevLocationInfo{
				Sn: "device_11111",
			},
		},
	}
	return item
}
func buildC2Online() *pb.C2OnlineRequest {
	item := &pb.C2OnlineRequest{
		TbCode: "000001",
		C2Sn:   "1231313",
		Online: 1,
	}
	return item
}

func buildUavWhiteListSyncRequest() *pb.UavWhitelistSyncRequest {
	item := &pb.UavWhitelistSyncRequest{
		TbCode: "000001",
		C2Sn:   "12312313",
		UavBlackWhiteRuleList: []*pb.UavInfo{
			&pb.UavInfo{
				SerialNum: "11111",
			},
		},
	}
	return item

}

func buildGetUavWhiteListReq() *pb.UavWhitelistListReq {
	item := &pb.UavWhitelistListReq{
		TbCode:    "000001",
		SerialNum: "11111",
		Vendor:    "dj-11111",
		PageNo:    1,
		PageSize:  10,
	}
	return item
}
func buildDevSyncHeartBeatReq() *pb.DevStatusSyncRequest {
	item := &pb.DevStatusSyncRequest{
		Items: map[string]*pb.DevStatusSyncMsg{},
	}
	item.Items["aaaa"] = &pb.DevStatusSyncMsg{
		TbCode: "000001",
		DevInfo: []*pb.DevStatusInfo{
			&pb.DevStatusInfo{
				DevType: "1231231",
			},
		},
	}
	return item
}
func RunClient() {

	// 创建 gRPC 客户端
	svr := micro.NewService(
		micro.Client(grpcc.NewClient()),
		micro.Name("cuav-cloud-go-service"),
		micro.Address(":18901"),
	)

	svr.Init()

	{
		item := buildCheckAlarmReqDemo()
		data, _ := proto.Marshal(item)
		// 创建 greeter 客户端 NewCuavCloudGoService
		cli := pb.NewCuavCloudGoService("cuav-cloud-go-service", svr.Client())
		rsp, err := cli.Execute(context.Background(), &pb.ExecuteBussinessRequest{
			Header: map[string]string{"Language": "en"},
			Url:    common.GrpcAlarmFenceCheck,
			Data:   data,
		})
		if err != nil || rsp == nil {
			fmt.Println("client response is nil, err: ", err)
			return
		}
		fmt.Printf("resp: %v\n", rsp)
	}

	{

		c2OnlineReq := buildC2Online()
		data, _ := proto.Marshal(c2OnlineReq)
		// 创建 greeter 客户端 NewCuavCloudGoService
		cli := pb.NewCuavCloudGoService("cuav-cloud-go-service", svr.Client())
		rsp, err := cli.Execute(context.Background(), &pb.ExecuteBussinessRequest{
			Header: map[string]string{"Language": "en"},
			Url:    common.GrpcC2OnLineRequest,
			Data:   data,
		})
		if err != nil || rsp == nil {
			fmt.Println(" online client response is nil, err: ", err)
			return
		}
		fmt.Printf("resp: %v\n", rsp)
	}

	{
		whiteListSyncReq := buildUavWhiteListSyncRequest()
		data, _ := proto.Marshal(whiteListSyncReq)
		// 创建 greeter 客户端 NewCuavCloudGoService
		cli := pb.NewCuavCloudGoService("cuav-cloud-go-service", svr.Client())
		rsp, err := cli.Execute(context.Background(), &pb.ExecuteBussinessRequest{
			Header: map[string]string{"Language": "en"},
			Url:    common.GrpcUavWhiteSync,
			Data:   data,
		})
		if err != nil || rsp == nil {
			fmt.Println(" whitelist sync is nil, err: ", err)
			return
		}
		fmt.Printf(" whitelist sync  resp: %v\n", rsp)
	}

	{
		whitelistGetReq := buildGetUavWhiteListReq()
		data, _ := proto.Marshal(whitelistGetReq)
		// 创建 greeter 客户端 NewCuavCloudGoService
		cli := pb.NewCuavCloudGoService("cuav-cloud-go-service", svr.Client())
		rsp, err := cli.Execute(context.Background(), &pb.ExecuteBussinessRequest{
			Header: map[string]string{"Language": "en"},
			Url:    common.GrpcUavWhitelist,
			Data:   data,
		})
		if err != nil || rsp == nil {
			fmt.Println(" whitelist get is nil, err: ", err)
			return
		}
		fmt.Printf(" whitelist get  resp: %v\n", rsp)
	}

	{
		devInfoSyncReq := buildDevSyncHeartBeatReq()
		data, _ := proto.Marshal(devInfoSyncReq)
		// 创建 greeter 客户端 NewCuavCloudGoService
		cli := pb.NewCuavCloudGoService("cuav-cloud-go-service", svr.Client())
		rsp, err := cli.Execute(context.Background(), &pb.ExecuteBussinessRequest{
			Header: map[string]string{"Language": "en"},
			Url:    common.GrpcDeviceStatusSync,
			Data:   data,
		})
		if err != nil || rsp == nil {
			fmt.Println(" dev sync  is nil, err: ", err)
			return
		}
		fmt.Printf(" dev sync   resp: %v\n", rsp)
	}
}
