package requestRpc

import (
	"context"
	"cuav-cloud-go-service/handler/common"
	pb "cuav-cloud-go-service/proto"
	"errors"
)

func C2OnlineSync(ctx context.Context, req *pb.C2OnlineRequest) error {
	if ctx == nil || req == nil {
		return errors.New("grpc fail")
	}

	//调用下发围栏区数据RPC接口
	go common.CallRpcFenceSync(req)
	// 调用下发白名单列表
	go common.CallRpcUavWhitelistSync(req, []*pb.UavInfo{})
	return nil
}
