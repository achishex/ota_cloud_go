package requestRpc

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/service/evidence_report"
	pb "cuav-cloud-go-service/proto"
)

// EvidenceReportHandler 取证报告服务 grpc handler
type EvidenceReportHandler struct {
	srv *evidence_report.EvidenceReportService
}

// NewEvidenceReportHandlerImpl 创建取证报告服务 handler
func NewEvidenceReportHandlerImpl() *EvidenceReportHandler {
	return &EvidenceReportHandler{
		srv: evidence_report.NewEvidenceReportService(),
	}
}

// StatusNotifyProcess 取证报告轨迹消失事件处理
func (ev *EvidenceReportHandler) StatusNotifyProcess(ctx context.Context, req *pb.TargetEventStatusNotifyRequest) error {
	if len(req.GetNotifyItems()) <= 0 {
		logger.Errorf("trajectory disappear notify request body is nil")
		return nil
	}

	return ev.srv.TargetEventStatusChangeModify(req)
}
