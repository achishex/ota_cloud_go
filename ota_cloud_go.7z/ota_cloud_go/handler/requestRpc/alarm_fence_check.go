package requestRpc

import (
	"context"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	"cuav-cloud-go-service/domain/service/uav_record"
	"cuav-cloud-go-service/domain/service/uavwhitelist"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	timeoutCheck = 200000
)

func init() {

}

func AlarmFenceCheckLogicProcess(ctx context.Context, req *pb.AlarmCheckRequest) (*pb.AlarmCheckResponse, error) {
	return NewAlarmFenceCheckSimple().Handle(ctx, req)
}

type alarmFenceCheckSimple struct {
	fendAreaService *alarm_service.FendAreaOPService
}

func NewAlarmFenceCheckSimple() *alarmFenceCheckSimple {
	return &alarmFenceCheckSimple{
		fendAreaService: alarm_service.NewFendAreaOpsService(alarm_service.ResFendAreaRedis, alarm_service.ResFendAreaDB),
	}
}
func (a *alarmFenceCheckSimple) asyncCacheUavDetect(inputParam *alarm_service.AlarmCheckInParam, strategyHandle alarm_service.AlarmStrategyInterface) {
	// 异步缓存侦测数据
	routinues.AsyncRun(true, func() {
		if err := strategyHandle.CacheUavDetectData(inputParam); err != nil {
			logger.Errorf("cache uav detect data fail, err: %v", err)
		}
	})
}

func (a *alarmFenceCheckSimple) Handle(ctx context.Context, req *pb.AlarmCheckRequest) (*pb.AlarmCheckResponse, error) {

	checkStart := time.Now().UnixMicro()
	if v := checkInParam(req); v <= 0 {
		if v < 0 {
			return nil, fmt.Errorf("req param is invali")
		}
	}

	var respInner = &pb.AlarmCheckResponse{}

	var validUavInTbCode = make(map[string]*pb.AlarmCheckReqItem) //key: tbCode
	for tbCode, _ := range req.GetItems() {
		alarmCheckItem := req.GetItems()[tbCode]

		if tbCode == "" || alarmCheckItem == nil {
			logger.Errorf("get fend area tb code is nil")
			continue
		}
		// 获取白名单列表
		srv := uavwhitelist.NewUavWhitelistService()
		result, err := srv.GetUavWhitelist(&pb.UavWhitelistListReq{TbCode: tbCode}, true)
		if err != nil {
			logger.Errorf("GetUavWhitelist error: %s", err.Error())
			continue
		}
		uavWhitelistMap := make(map[string]*pb.UavWhitelistItem)
		for _, item := range result.List {
			uavWhitelistMap[item.SerialNum] = item
		}
		// 过滤掉白名单的无人机
		afterFilterUavs := make([]*pb.DevLocationInfo, 0)
		for _, uavItem := range alarmCheckItem.UavItems {
			// 不在白名单列表且不为友军
			if val, ok := uavWhitelistMap[uavItem.Sn]; !ok || val.GetRole() != constant.FriendlyArmy {
				afterFilterUavs = append(afterFilterUavs, uavItem)
			}
		}
		beforeFilterUavs := alarmCheckItem.UavItems
		alarmCheckItem.UavItems = afterFilterUavs

		// 记录有效无人机列表
		validUavInTbCode[tbCode] = alarmCheckItem

		// 进行自动反制逻辑
		routinues.GoSafe(func() {
			if len(validUavInTbCode) <= 0 {
				return
			}

			for tbCode, _ := range validUavInTbCode { //对每个tbCode的下的无人机列表推荐反制设备
				alarmUavList := validUavInTbCode[tbCode]
				if alarmUavList == nil {
					continue
				}
				auto_counter_service.NewAutoCounterService().AutoCounter(tbCode, alarmUavList.GetUavItems())
			}
		})

		fendAreasList, err := a.fendAreaService.GetFendAreaByTbCode(tbCode)
		if err != nil {
			logger.Errorf("get fend area list failed, err: %v, tbCode: %v", err, tbCode)
			return nil, fmt.Errorf("get fence area list fail")
		}

		if len(fendAreasList) == 0 {
			logger.Infof("get fend area list empty, tbCode: %v", tbCode)
		}

		// 异步处理
		uav_record.SendUavFlyMessage(tbCode, alarmCheckItem, fendAreasList)

		inputParam := alarm_service.NewAlarmCheckInParam(tbCode, alarmCheckItem.GetC2Location(), alarmCheckItem.GetUavItems(), fendAreasList)
		strategyHandle := alarm_service.NewAlarmStrategy(alarm_service.ResFendAreaRedis, alarm_service.ResFendAreaDB, alarm_service.AlarmRecordMQPubHandler)

		check2Start := time.Now().UnixMicro()
		respItem, err := strategyHandle.Check(inputParam)
		if err != nil {
			logger.Errorf("get alarm check fail, tbCode: %v, err: %v", tbCode, err)
			continue
		}
		if time.Now().UnixMicro()-check2Start > timeoutCheck {
			logger.Infof("Alarm handle cost: %d", time.Now().UnixMicro()-check2Start)
		}

		if respItem != nil {
			respInner.UavAlarmRiskLevelScores = append(respInner.UavAlarmRiskLevelScores, respItem.GetUavAlarmRiskLevelScores()...)
		}
		// 检查无人机白名单, 并组装数据
		m := make(map[int64]*pb.AlarmCheckRspItem)
		for _, item := range respInner.UavAlarmRiskLevelScores {
			if val, ok := uavWhitelistMap[item.Sn]; ok {
				item.UavWhiteRole = val.Role
			}
			m[item.UniqueId] = item
		}
		for _, item := range beforeFilterUavs {
			if _, ok := m[item.UniqueId]; !ok {
				var uavWhiteRole int32
				if val, ok := uavWhitelistMap[item.Sn]; ok {
					uavWhiteRole = val.Role
				}
				respInner.UavAlarmRiskLevelScores = append(respInner.UavAlarmRiskLevelScores, &pb.AlarmCheckRspItem{
					UniqueId:     item.UniqueId,
					Sn:           item.Sn,
					ObjId:        item.ObjID,
					UavWhiteRole: uavWhiteRole,
				})
			}
		}
		alarmListKey := alarm_service.NewLatestAlarmCache(alarm_service.ResFendAreaRedis).GetTbCodeEventIdKey(tbCode)
		activeAlarms, err := alarm_service.ResFendAreaRedis.SMembers(alarmListKey)
		if err != nil {
			logger.Errorf("get alarm list fail, e: %v", err)
		} else {
			if respInner.TbAlarmStatistics == nil {
				respInner.TbAlarmStatistics = make(map[string]*pb.AlarmStatistics)
			}
			respInner.TbAlarmStatistics[tbCode] = &pb.AlarmStatistics{Count: int32(len(activeAlarms))}
		}
	}
	if time.Now().UnixMicro()-checkStart > timeoutCheck {
		logger.Infof("Alarm check cost: %d", time.Now().UnixMicro()-checkStart)
	}
	return respInner, nil
}
