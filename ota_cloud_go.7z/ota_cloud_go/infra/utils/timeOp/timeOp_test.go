package timeOp

import "testing"

func TestStringToTime(t *testing.T) {
	srcTimeStr := "2023-02-14 13:40:12"
	tm := StringToTime(srcTimeStr)
	t.Logf("tm ms: %v, %v", tm.UnixMilli(), tm.String())

	t.Logf("%v", ParseTime(tm, "2006-01-02 15:04:05"))
}
