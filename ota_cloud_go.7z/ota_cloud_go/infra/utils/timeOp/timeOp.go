package timeOp

import "time"

func ParseTimeToString(t time.Time) string {
	layout := "2006-01-02 15:04:05.0000000"
	return t.Format(layout)
}

func ParseTime(t time.Time, layout string) string {
	return t.Format(layout)
}

// StringToTime 将字符串 "2023-02-14 13:40:12"
func StringToTime(str string) time.Time {
	strTime, _ := time.ParseInLocation("2006-01-02 15:04:05", str, time.Local)
	return strTime
}

func TimeUnixStampMsToStr(tmMs int64) string {
	return ParseTime(time.UnixMilli(tmMs), "2006-01-02 15:04:05")
}
