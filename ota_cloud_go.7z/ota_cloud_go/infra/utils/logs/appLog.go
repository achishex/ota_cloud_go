package logs

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"github.com/google/uuid"
	"strings"
)

const (
	CtxRequestID = "X-Nonce"
)

// SetRequestId 无
func SetRequestId(ctx context.Context, requestId string) context.Context {
	if requestId == "" {
		return ctx
	}
	return context.WithValue(ctx, CtxRequestID, requestId)
}

func GetRequestId(ctx context.Context) string {
	if requestId, ok := ctx.Value(CtxRequestID).(string); ok {
		return requestId
	}
	return ""
}

func UUID() string {
	uid, _ := uuid.NewRandom()
	return strings.ReplaceAll(uid.String(), "-", "")
}

// WithRequestID 从ctx 获取一个 id，不存在则创建一个uuid.
func WithRequestID(ctx context.Context) context.Context {
	if v, ok := ctx.Value(CtxRequestID).(string); ok && v != "" {
		return ctx
	}
	return context.WithValue(ctx, CtxRequestID, UUID())
}

func Accessf(ctx context.Context, format string, v ...interface{}) {
	reqId := GetRequestId(WithRequestID(ctx))
	args := []any{}
	for _, vv := range v {
		args = append(args, vv)
	}
	logger.Accessf(reqId+" "+format, args[:]...)
}
