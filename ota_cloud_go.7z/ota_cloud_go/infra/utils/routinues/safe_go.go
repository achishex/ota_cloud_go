package routinues

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"fmt"
	"runtime/debug"
)

func Recover(cleanup ...func()) {
	for _, cl := range cleanup {
		cl()
	}
	if p := recover(); p != nil {
		logger.Errorf(fmt.Sprintf("%s\n%s", fmt.Sprint(p), string(debug.Stack())))
	}
}

func RunSafe(fn func()) {
	defer Recover()
	fn()
}

// GoSafe 对外使用，可以捕获异常并打印异常的栈信息
func GoSafe(fn func()) {
	go RunSafe(fn)
}

// AsyncRun 异步运行任务
func AsyncRun(async bool, fn func()) {
	if async == true {
		go RunSafe(fn)
	} else {
		RunSafe(fn)
	}
}
