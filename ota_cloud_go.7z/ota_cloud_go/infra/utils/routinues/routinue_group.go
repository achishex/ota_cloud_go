package routinues

import "sync"

type RoutineGroupWrap struct {
	wg sync.WaitGroup
}

func NewRoutineGroupWrap() *RoutineGroupWrap {
	return new(RoutineGroupWrap)
}

func (g *RoutineGroupWrap) Run(fn func()) {
	g.wg.Add(1)
	GoSafe(func() {
		defer g.wg.Done()
		fn()
	})
}
func (g *RoutineGroupWrap) AsyncRun(async bool, fn func()) {
	g.wg.Add(1)
	AsyncRun(async, func() {
		defer g.wg.Done()
		fn()
	})
}

func (g *RoutineGroupWrap) Wait() {
	g.wg.Wait()
}
