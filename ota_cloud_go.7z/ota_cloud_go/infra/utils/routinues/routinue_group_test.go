package routinues

import (
	"testing"
	"time"
	"unsafe"
)

func TestParallelRun(t *testing.T) {
	tasksManger := NewRoutineGroupWrap()
	var tasks map[string]int = make(map[string]int)

	tasks["t1"] = 1
	tasks["t2"] = 1
	tasks["t3"] = 1
	for task, _ := range tasks {
		t.Logf("out t: %v", task)
		tt := task
		tasksManger.AsyncRun(true, func() {
			time.Sleep(100 * time.Millisecond)
			t.Logf("task: %v", tt)
		})
	}
	tasksManger.Wait()
}

type DemoAsyncData struct {
	x int
}

func TestAsyncFunc(t *testing.T) {

	var dataList []*DemoAsyncData = []*DemoAsyncData{
		&DemoAsyncData{1},
		&DemoAsyncData{2},
		&DemoAsyncData{3},
		&DemoAsyncData{4},
	}

	var addrList map[int64]bool = make(map[int64]bool)
	for i := 0; i < len(dataList); i++ {
		t.Logf("data addr: %p", dataList[i])
		addrList[int64(uintptr(unsafe.Pointer(dataList[i])))] = true
	}

	for l := 0; l < len(dataList); l++ {
		if dataList[l] == nil {
			continue
		}

		func(data *DemoAsyncData) {
			AsyncRun(true, func() {
				if data == nil {
					t.Logf("is nil for data")
				} else {
					t.Logf("data: %v, %p", data.x, data)
				}
				if _, ok := addrList[int64(uintptr(unsafe.Pointer(data)))]; ok {
					t.Logf("exist addr: 0x%v", int64(uintptr(unsafe.Pointer(data))))
				} else {
					t.Logf("not exist addr: 0x%x", int64(uintptr(unsafe.Pointer(data))))
				}
				time.Sleep(1 * time.Second)
			})
		}(dataList[l])
	}

	select {}
}
