package s3Client

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/files_op"
	"cuav-cloud-go-service/domain/repository/mock"
	"strings"
	"testing"
)

func TestS3clientUploadPreSign(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.EvidenceReportS3.Ak = "AKIAVVMOXO7XHGUU5W62"
		config.ServiceCfg.EvidenceReportS3.Sk = "j/cRcFcTqKSlo8A4RtoHe/H4+uUZ4qxz4r1kRIE6"
		config.ServiceCfg.EvidenceReportS3.Bucket = "c2-eventvideo"
		config.ServiceCfg.EvidenceReportS3.FilePrefix = "TO_30_2_"
		config.ServiceCfg.EvidenceReportS3.Region = "cn-northwest-1"
		config.ServiceCfg.EvidenceReportS3.UploadTimeoutSecond = 60
	}

	cli := NewS3ClientS3(&S3ClientConfig{
		Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
		Region:              config.GetConfig().EvidenceReportS3.Region,
		Ak:                  config.GetConfig().EvidenceReportS3.Ak,
		Sk:                  config.GetConfig().EvidenceReportS3.Sk,
		FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
		StoreType:           AwsS3,
		CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
	})

	//demoData := "this is 000000"
	//demoIo := strings.NewReader(demoData)
	//cli.Upload(demoIo, BuildS3ObjectFile("cloud/track/", cli.BuildBaseObjFileName("demo-test_1.txt")))
	//cli.Upload(demoIo, "eventImage/55779ac3-6d39-428e-8fd0-64da5e11b5e2/sfagx-1422323044680/1826436289759997952@1724134752782_2.jpg")

	downloadUrl, err := cli.GetDownloadUrl("cloud/track/TO_30_2_1326793820892037123_666.jpg", 8*24*3600)
	t.Logf("url: %v, err: %v", downloadUrl, err)

}
func TestS3ClientUpload(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.EvidenceReportS3.Ak = "AKIAVVMOXO7XHGUU5W62"
		config.ServiceCfg.EvidenceReportS3.Sk = "j/cRcFcTqKSlo8A4RtoHe/H4+uUZ4qxz4r1kRIE6"
		config.ServiceCfg.EvidenceReportS3.Bucket = "c2-eventvideo"
		config.ServiceCfg.EvidenceReportS3.FilePrefix = "TO_30_2_"
		config.ServiceCfg.EvidenceReportS3.Region = "cn-northwest-1"
		config.ServiceCfg.EvidenceReportS3.UploadTimeoutSecond = 60
	}

	cli := NewS3ClientS3(&S3ClientConfig{
		Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
		Region:              config.GetConfig().EvidenceReportS3.Region,
		Ak:                  config.GetConfig().EvidenceReportS3.Ak,
		Sk:                  config.GetConfig().EvidenceReportS3.Sk,
		FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
		StoreType:           AwsS3,
		CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
	})

	demoData := "this is 000000"
	demoIo := strings.NewReader(demoData)
	cli.Upload(demoIo, BuildS3ObjectFile("cloud/track/", cli.BuildBaseObjFileName("demo-test_1.txt")))
	//cli.Upload(demoIo, "eventImage/55779ac3-6d39-428e-8fd0-64da5e11b5e2/sfagx-1422323044680/1826436289759997952@1724134752782_2.jpg")

	cli.Download(BuildS3ObjectFile("cloud/track/", cli.BuildBaseObjFileName("demo-test_1.txt")))
	err := cli.DownloadToLocal(BuildS3ObjectFile("cloud/track/", cli.BuildBaseObjFileName("demo-test_1.txt")), "demo-test_2.txt")
	if err != nil {
		t.Logf("download file fail, err； %v", err)
	}
	files_op.DeleteFile("demo-test_2.txt")
	downloadUrl, err := cli.GetDownloadUrl(BuildS3ObjectFile("cloud/track/", cli.BuildBaseObjFileName("demo-test_1.txt")), 3600)
	t.Logf("url: %v, err: %v", downloadUrl, err)

	if err := DownloadByPreUrl(downloadUrl, "./data.txt"); err != nil {
		t.Logf("download file %v fail, err: %v", downloadUrl, err)
		return
	}
	if err := files_op.DeleteFile("./data.txt"); err != nil {
		t.Logf("delete file fail, err: %v", err)
	} else {
		t.Logf("delete file: %v succ", "data.txt")
	}
	dUrl := `https://cloud-evidence-report.s3.cn-northwest-1.amazonaws.com.cn/cloud/track/12312313.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256\u0026X-Amz-Credential=AKIAVVMOXO7XHGUU5W62%2F20240813%2Fcn-northwest-1%2Fs3%2Faws4_request\u0026X-Amz-Date=20240813T121318Z\u0026X-Amz-Expires=2592000\u0026X-Amz-SignedHeaders=host\u0026response-expires=Thu%2C%2012%20Sep%202024%2012%3A13%3A18%20GMT\u0026X-Amz-Signature=14b1b46ba4ca6aaeca5a9a06dadb97c9f9fc6605808161a2eda456f78c9c63ce`
	DownloadByPreUrl(dUrl, "./xyz.zip")
}

func TestS3ClientPreSign(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.EvidenceReportS3.Ak = "AKIAVVMOXO7XAWRYBSOU"
		config.ServiceCfg.EvidenceReportS3.Sk = "7s4mvN+6qctFQ8cGOrbXgkS9sXhHEbGUGAmFnLfq"
		config.ServiceCfg.EvidenceReportS3.Bucket = "c2-eventvideo"
		config.ServiceCfg.EvidenceReportS3.FilePrefix = ""
		config.ServiceCfg.EvidenceReportS3.Region = "cn-northwest-1"
		config.ServiceCfg.EvidenceReportS3.UploadTimeoutSecond = 60
	}

	cli := NewS3ClientS3(&S3ClientConfig{
		Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
		Region:              config.GetConfig().EvidenceReportS3.Region,
		Ak:                  config.GetConfig().EvidenceReportS3.Ak,
		Sk:                  config.GetConfig().EvidenceReportS3.Sk,
		FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
		StoreType:           AwsS3,
		CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
	})

	url, err := cli.GetDownloadUrl("eventImage/55779ac3-6d39-428e-8fd0-64da5e11b5e2/sfagx-1422323044680/1826401780205285376@1724134752735_1.jpg", 3600*2)
	if err != nil {
		t.Logf("is err: %v", err)
		return
	}
	t.Logf("url: %v", url)
}

func TestS3ClientPreSignTwo(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.EvidenceReportS3.Ak = "AKIAVVMOXO7XAWRYBSOU"
		config.ServiceCfg.EvidenceReportS3.Sk = "7s4mvN+6qctFQ8cGOrbXgkS9sXhHEbGUGAmFnLfq"
		config.ServiceCfg.EvidenceReportS3.Bucket = "c2-eventvideo"
		config.ServiceCfg.EvidenceReportS3.FilePrefix = "TO_30_2_"
		config.ServiceCfg.EvidenceReportS3.Region = "cn-northwest-1"
		config.ServiceCfg.EvidenceReportS3.UploadTimeoutSecond = 60
	}

	cli := NewS3ClientS3(&S3ClientConfig{
		Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
		Region:              config.GetConfig().EvidenceReportS3.Region,
		Ak:                  config.GetConfig().EvidenceReportS3.Ak,
		Sk:                  config.GetConfig().EvidenceReportS3.Sk,
		FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
		StoreType:           AwsS3,
		CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
	})

	url, err := cli.GetDownloadUrl("cloud/track/TO_30_2_1312070561061797907.zip", 3600*2)
	if err != nil {
		t.Logf("is err: %v", err)
		return
	}
	t.Logf("url: %v", url)

	cli.DownloadToLocal("cloud/track/TO_30_2_1312070561061797907.zip", "TO_30_2_1312070561061797907.zip")
}
