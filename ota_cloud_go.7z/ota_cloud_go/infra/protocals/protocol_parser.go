package protocals

import (
	"bytes"
	"context"
	"cuav-cloud-go-service/deploy/i18nlib"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/handler/common"
	"cuav-cloud-go-service/infra/utils/logs"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"reflect"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	CtxTokenKey = "token"
)

// HttpResponse represents response item.
// swagger:model HttpResponse
type HttpResponse struct {
	// Custom error code
	// required: true
	// example:  succ is 0, fail are -10001, less than 0
	ErrorCode int32 `json:"errorCode"`
	// Custom error message description
	// required: true
	// example: "fail"
	ErrorMessage string `json:"errorMessage"`
	// Custom request tracerId.
	// required: true
	// example: abc123iefdfa
	SeqId string `json:"seqId"`
	// Custom request cost time in millisecond.
	// required: true
	// example: 12
	CostTimeMs int64 `json:"costTimeMs"`
	// Custom request response context.
	// required: false
	// example: null
	Data any `json:"data"`
}

func (hr *HttpResponse) buildErrResponse(code int32, msg string) {
	hr.ErrorCode = code
	hr.ErrorMessage = msg
}

// CliError 定义错误码信息接口
type CliError interface {
	GetCode() int32
	GetCodeMsg() string
	Error() string
	GetCodeArgs() []any
}

// GetToken 获取token
func GetToken(ctx context.Context) *common.TokenContext {
	tokenValueAny := ctx.Value(CtxTokenKey)
	tokenValue, ok := tokenValueAny.(*common.TokenContext)
	if !ok || tokenValue == nil {
		logger.Errorf("not get token from ctx, token key: %v", CtxTokenKey)
		return nil
	} else {
		return tokenValue
	}
}
func FilterLogin(ctx context.Context, r *http.Request) (context.Context, error) {
	if n := strings.Index(r.URL.Path, "/inner/rest/"); n == 0 {
		return context.Background(), nil
	}

	var tokenContext *common.TokenContext = &common.TokenContext{}
	value := r.Header.Get("x-token-payload")
	if value == "" {
		isDebug := r.Header.Get("mock-debug")
		if isDebug != "" {
			tokenContext.IsDebug = isDebug
			ctx = context.WithValue(ctx, CtxTokenKey, tokenContext)
			return ctx, nil
		}

		logger.Error("token payload is empty")
		return ctx, errors.New("token payload is empty")
	}

	err := json.Unmarshal([]byte(value), &tokenContext)
	if err != nil {
		return ctx, err
	}
	ctx = context.WithValue(ctx, CtxTokenKey, tokenContext)
	return ctx, nil
}

// AccessDecorator 统一接收数据包和组装回包
func AccessDecorator(handler any) func(http.ResponseWriter, *http.Request) {
	handlerType := reflect.TypeOf(handler)
	handlerValue := reflect.ValueOf(handler)

	lastCallFnType := func(http.ResponseWriter, *http.Request) {}
	//
	oneCallFn := func(args []reflect.Value) (result []reflect.Value) {
		responseData := HttpResponse{
			ErrorMessage: "",
			ErrorCode:    0,
		}

		beginTime := time.Now().UnixMilli()
		w := args[0].Interface().(http.ResponseWriter)
		r := args[1].Interface().(*http.Request)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		ctx := logs.SetRequestId(context.Background(), r.Header.Get(logs.CtxRequestID))
		ctx = context.WithValue(ctx, constant.XLanguageHeaderKey, r.Header.Get(constant.XLanguageHeaderKey))
		ctx = logs.WithRequestID(ctx)

		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("[panic], stack: %v", string(debug.Stack()))
				responseData.SeqId = logs.GetRequestId(ctx)
				responseData.buildErrResponse(http.StatusBadGateway, fmt.Sprintf("inner panic, e: %v", e))
				response, err := json.Marshal(responseData)
				if err != nil {
					logger.Errorf("marshal response fail, err: %v", err)
					return
				}
				w.Write(response)
				return
			}
		}()

		var realIn []reflect.Value

		if handlerType.NumIn() == 2 {
			paramIn := handlerType.In(1)
			if paramIn.Kind() == reflect.Ptr {
				paramIn = paramIn.Elem()
			}

			val := reflect.New(paramIn)
			if r.Method == http.MethodPost {
				var e error
				ctx, e = FilterLogin(ctx, r)
				if e != nil {
					logger.Errorf("Failed to get token payload, err: %v", e)
					responseData.buildErrResponse(http.StatusBadGateway, fmt.Sprintf("Failed to get token payload, e: %v", e))
					responseData.SeqId = logs.GetRequestId(ctx)
					response, err := json.Marshal(responseData)
					if err != nil {
						logger.Errorf("marshal response fail, err: %v", err)
						return nil
					}
					w.Write(response)
					return nil
				}

				body, err := ioutil.ReadAll(r.Body)
				if err != nil {
					logger.Errorf("read request body fail, err: %v", err)
					responseData.buildErrResponse(http.StatusInternalServerError, fmt.Sprintf("read body fail, e: %v", e))
					responseData.SeqId = logs.GetRequestId(ctx)
					response, err := json.Marshal(responseData)
					if err != nil {
						logger.Errorf("marshal response fail, err: %v", err)
						return nil
					}
					w.Write(response)
					return nil
				}
				defer r.Body.Close()

				if e := json.Unmarshal(body, val.Interface()); e != nil {
					logger.Errorf("json unmarshal to struct fail, r.Body: %+v, err: %v", string(body), e)
					responseData.buildErrResponse(http.StatusBadRequest, fmt.Sprintf("parse body fail, e: %v", e))
					responseData.SeqId = logs.GetRequestId(ctx)

					response, err := json.Marshal(responseData)
					if err != nil {
						logger.Errorf("marshal response fail, err: %v", err)
						return nil
					}
					w.Write(response)
					return nil
				}
			}
			realIn = append(realIn, reflect.ValueOf(ctx), val)
		}

		callFuncName := ""
		if len(realIn) >= 2 {
			lastFuncNames := strings.Split(runtime.FuncForPC(reflect.ValueOf(handler).Pointer()).Name(), ".")
			if len(lastFuncNames) > 0 {
				callFuncName = lastFuncNames[len(lastFuncNames)-1]
			}
			logger.Infof("--------> %v, http body: %+v", callFuncName, realIn[1].Interface())

		}

		retValues := handlerValue.Call(realIn)

		if n := strings.Index(r.URL.Path, "/inner/rest/"); n == 0 {
			//内部接口调用:
			r.Header.Set(constant.XLanguageHeaderKey, "en")
		}

		retItemNums := handlerType.NumOut()

		if retItemNums == 2 {
			if retValues[retItemNums-1].Interface() != nil { // error is not nil
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					responseData.ErrorCode = errImpl.GetCode()
					responseData.ErrorMessage = errImpl.GetCodeMsg()
					// 错误码国际化
					language := r.Header.Get(constant.XLanguageHeaderKey)
					msg, err := i18nlib.GetValue(strconv.Itoa(int(responseData.ErrorCode)), language)
					if err != nil {
						logger.Warnf("I18n GetValue error: %s", err.Error())
						responseData.ErrorMessage = errImpl.GetCodeMsg()
					} else {
						responseData.ErrorMessage = fmt.Sprintf(msg, errImpl.GetCodeArgs()...)
					}

				} else {
					responseData.ErrorMessage = "not defined err code"
					responseData.ErrorCode = -100
				}

			} else if handlerType.NumOut() != 1 {
				responseData.ErrorCode = 0
				responseData.Data = retValues[0].Interface()
			}
		} else if retItemNums == 1 { //only error
			if retValues[retItemNums-1].Interface() != nil {
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					responseData.ErrorCode = errImpl.GetCode()
					responseData.ErrorMessage = errImpl.GetCodeMsg()
					// 错误码国际化
					language := r.Header.Get(constant.XLanguageHeaderKey)
					msg, err := i18nlib.GetValue(strconv.Itoa(int(responseData.ErrorCode)), language)
					if err != nil {
						logger.Warnf("I18n GetValue error: %s", err.Error())
						responseData.ErrorMessage = errImpl.GetCodeMsg()
					} else {
						responseData.ErrorMessage = fmt.Sprintf(msg, errImpl.GetCodeArgs()...)
					}
				} else {
					responseData.ErrorMessage = "not defined err code"
					responseData.ErrorCode = -100
				}
			} else {
				responseData.ErrorCode = 0
			}
		} else {
			responseData.Data = retValues[0].Interface()
			responseData.ErrorCode = 0
		}
		endTime := time.Now().UnixMilli()
		responseData.CostTimeMs = endTime - beginTime
		responseData.SeqId = logs.GetRequestId(ctx)

		var response bytes.Buffer
		encoder := json.NewEncoder(&response)
		encoder.SetEscapeHTML(false) // 禁用 HTML 转义
		err := encoder.Encode(responseData)

		//response, err := json.Marshal(responseData)
		if err != nil {
			logger.Errorf("marshal response fail, err: %v", err)
			return nil
		}

		logger.Infof("<-------- %v, http response: %+v", callFuncName, (response).String())
		w.Write(response.Bytes())
		return nil
	}

	h := reflect.MakeFunc(reflect.TypeOf(lastCallFnType), oneCallFn)
	return h.Interface().(func(http.ResponseWriter, *http.Request))
}

// AccessFormDecorator 统一接收 form 表单处理
func AccessFormDecorator(handler any) func(http.ResponseWriter, *http.Request) {
	handlerType := reflect.TypeOf(handler)
	handlerValue := reflect.ValueOf(handler)

	lastCallFnType := func(http.ResponseWriter, *http.Request) {}
	//
	oneCallFn := func(args []reflect.Value) (result []reflect.Value) {
		responseData := HttpResponse{
			ErrorMessage: "",
			ErrorCode:    0,
		}

		beginTime := time.Now().UnixMilli()
		w := args[0].Interface().(http.ResponseWriter)
		r := args[1].Interface().(*http.Request)

		w.WriteHeader(http.StatusOK)

		ct := r.Header.Get("Content-Type")
		if index := strings.Index(ct, "multipart/form-data"); index > 0 {
			logger.Infof("is form data op.")
			w.Header().Set("Content-Type", ct)
		}

		if err := r.ParseMultipartForm(10 << 20); err != nil { // limit 10MB
			logger.Errorf("file more than 10MB")
			w.WriteHeader(http.StatusBadRequest)
			return
		}

		ctx := logs.SetRequestId(context.Background(), r.Header.Get(logs.CtxRequestID))
		ctx = i18nlib.SetLangStrToCtx(ctx, r)
		ctx = logs.WithRequestID(ctx)

		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("[panic], stack: %v", string(debug.Stack()))
				responseData.SeqId = logs.GetRequestId(ctx)
				responseData.buildErrResponse(http.StatusBadGateway, fmt.Sprintf("inner panic, e: %v", e))
				response, err := json.Marshal(responseData)
				if err != nil {
					logger.Errorf("marshal response fail, err: %v", err)
					return
				}
				w.Write(response)
				return
			}
		}()

		var realIn []reflect.Value

		if handlerType.NumIn() == 2 {
			paramIn := handlerType.In(1)
			if paramIn.Kind() == reflect.Ptr {
				paramIn = paramIn.Elem()
			}

			var fileFieldNames = make(map[string]string)
			mform := r.MultipartForm
			if mform != nil {
				for fileField, fileFieldValue := range mform.File {
					if fileField != "" {
						if len(fileFieldValue) > 0 {
							if fileFieldValue[0] != nil {
								fileFieldNames[fileField] = fileFieldValue[0].Filename
							}
						}
					}
				}
			}

			var fileFieldValue = make(map[string]*bytes.Buffer)
			for fileFieldName, _ := range fileFieldNames {
				file, _, err := r.FormFile(fileFieldName)
				if err != nil {
					continue
				}
				defer file.Close()

				var buf *bytes.Buffer = new(bytes.Buffer)
				_, err = io.Copy(buf, file)
				if err != nil {
					logger.Errorf("read from file form fail, err: %v")
					continue
				}
				fileFieldValue[fileFieldName] = buf
			}

			val := reflect.New(paramIn)
			if r.Method == http.MethodPost {
				var e error
				ctx, e = FilterLogin(ctx, r)
				if e != nil {
					logger.Errorf("Failed to get token payload, err: %v", e)
					responseData.buildErrResponse(http.StatusBadGateway, fmt.Sprintf("Failed to get token payload, e: %v", e))
					responseData.SeqId = logs.GetRequestId(ctx)
					response, err := json.Marshal(responseData)
					if err != nil {
						logger.Errorf("marshal response fail, err: %v", err)
						return nil
					}
					w.Write(response)
					return nil
				}

				v2 := val.Elem()
				t2 := v2.Type()

				var fileName string = ""
				for i := 0; i < t2.NumField(); i++ {
					field := t2.Field(i)
					tag := field.Tag.Get("form")
					if tag == "" {
						tag = field.Name
					}
					fieldValue := v2.Field(i)
					if !fieldValue.CanSet() {
						continue
					}

					_, ok := fileFieldNames[tag]
					if ok {
						logger.Infof("file field name: %v", tag)
						fieldValue.SetBytes(fileFieldValue[tag].Bytes())
						fileName = fileFieldNames[tag]
						continue
					}

					formValue := r.FormValue(tag)
					if formValue == "" {
						//内部参数，硬编码
						if tag == "FileName" {
							fieldValue.SetString(fileName)
						}
						continue
					}

					switch field.Type.Kind() {
					case reflect.String:
						logger.Infof("parse form key: %v, value: %v", tag, formValue)
						fieldValue.SetString(formValue)

					case reflect.Int:
						intVal, err := strconv.Atoi(formValue)
						if err != nil {
							return
						}
						fieldValue.SetInt(int64(intVal))

					default:
						logger.Errorf("unhandled default case")
					}
				}
			}
			realIn = append(realIn, reflect.ValueOf(ctx), val)
		}

		callFuncName := ""
		if len(realIn) >= 2 {
			lastFuncNames := strings.Split(runtime.FuncForPC(reflect.ValueOf(handler).Pointer()).Name(), ".")
			if len(lastFuncNames) > 0 {
				callFuncName = lastFuncNames[len(lastFuncNames)-1]
			}
		}

		retValues := handlerValue.Call(realIn)

		if n := strings.Index(r.URL.Path, "/inner/rest/"); n == 0 {
			//内部接口调用:
			r.Header.Set(constant.XLanguageHeaderKey, "en")
		}

		retItemNums := handlerType.NumOut()

		if retItemNums == 2 {
			if retValues[retItemNums-1].Interface() != nil { // error is not nil
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					responseData.ErrorCode = errImpl.GetCode()
					responseData.ErrorMessage = errImpl.GetCodeMsg()
					// 错误码国际化
					language := r.Header.Get(constant.XLanguageHeaderKey)
					msg, err := i18nlib.GetValue(strconv.Itoa(int(responseData.ErrorCode)), language)
					if err != nil {
						logger.Warnf("I18n GetValue error: %s", err.Error())
						responseData.ErrorMessage = errImpl.GetCodeMsg()
					} else {
						responseData.ErrorMessage = fmt.Sprintf(msg, errImpl.GetCodeArgs()...)
					}

				} else {
					responseData.ErrorMessage = "not defined err code"
					responseData.ErrorCode = -100
				}

			} else if handlerType.NumOut() != 1 {
				responseData.ErrorCode = 0
				responseData.Data = retValues[0].Interface()
			}
		} else if retItemNums == 1 { //only error
			if retValues[retItemNums-1].Interface() != nil {
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					responseData.ErrorCode = errImpl.GetCode()
					responseData.ErrorMessage = errImpl.GetCodeMsg()
					// 错误码国际化
					language := r.Header.Get(constant.XLanguageHeaderKey)
					msg, err := i18nlib.GetValue(strconv.Itoa(int(responseData.ErrorCode)), language)
					if err != nil {
						logger.Warnf("I18n GetValue error: %s", err.Error())
						responseData.ErrorMessage = errImpl.GetCodeMsg()
					} else {
						responseData.ErrorMessage = fmt.Sprintf(msg, errImpl.GetCodeArgs()...)
					}
				} else {
					responseData.ErrorMessage = "not defined err code"
					responseData.ErrorCode = -100
				}
			} else {
				responseData.ErrorCode = 0
			}
		} else {
			responseData.Data = retValues[0].Interface()
			responseData.ErrorCode = 0
		}
		endTime := time.Now().UnixMilli()
		responseData.CostTimeMs = endTime - beginTime
		responseData.SeqId = logs.GetRequestId(ctx)

		var response bytes.Buffer
		encoder := json.NewEncoder(&response)
		encoder.SetEscapeHTML(false) // 禁用 HTML 转义
		err := encoder.Encode(responseData)
		if err != nil {
			logger.Errorf("marshal response fail, err: %v", err)
			return nil
		}

		logger.Infof("<-------- %v, http response: %+v", callFuncName, response.String())
		w.Write(response.Bytes())
		return nil
	}

	h := reflect.MakeFunc(reflect.TypeOf(lastCallFnType), oneCallFn)
	return h.Interface().(func(http.ResponseWriter, *http.Request))
}
