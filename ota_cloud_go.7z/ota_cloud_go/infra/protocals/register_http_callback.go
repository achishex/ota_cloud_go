package protocals

import (
	"context"
	"net/http"
)

func Register[In any, Out any](url string, call func(ctx context.Context, inParam In) (Out, error)) {
	http.HandleFunc(url, AccessDecorator(call))
}

func RegisterNoOut[In any](url string, call func(ctx context.Context, inParam In) error) {
	http.HandleFunc(url, AccessDecorator(call))
}

func RegisterNoOutForm[In any](url string, call func(ctx context.Context, inParam In) error) {
	http.HandleFunc(url, AccessFormDecorator(call))
}

func RegisterForm[In any, Out any](url string, call func(ctx context.Context, inParam In) (Out, error)) {
	http.HandleFunc(url, AccessFormDecorator(call))
}
