package protocals

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/handler/common"
	pb "cuav-cloud-go-service/proto"
	"google.golang.org/protobuf/proto"
	"reflect"
	"runtime"
	"strings"
)

type ProcessGrpc func(ctx context.Context, in *pb.ExecuteBussinessRequest, out *pb.ExecuteBussinessResponse)

var GrpProcessCollect = make(map[string]ProcessGrpc)

func RegisterGrpcProcess[In any, Out any](url string, call func(ctx context.Context, inParam In) (Out, error)) {
	GrpProcessCollect[url] = GrpcProcessWrapper(call)
}
func RegisterGrpcProcessNoOut[In any](url string, call func(ctx context.Context, inParam In) error) {
	GrpProcessCollect[url] = GrpcProcessWrapper(call)
}

func CallGrpcByUrl(url string) ProcessGrpc {
	fn, ok := GrpProcessCollect[url]
	if !ok || fn == nil {
		return nil
	}

	return fn
}

// GrpcProcessWrapper 统一接收数据包和组装回包
func GrpcProcessWrapper(handler any) ProcessGrpc {
	handlerType := reflect.TypeOf(handler)
	handlerValue := reflect.ValueOf(handler)

	lastCallFnType := func(ctx context.Context, in *pb.ExecuteBussinessRequest, out *pb.ExecuteBussinessResponse) {
	}

	oneCallFn := func(args []reflect.Value) (result []reflect.Value) {

		ctx := args[0].Interface().(context.Context)
		reqParam := args[1].Interface().(*pb.ExecuteBussinessRequest)
		rspParam := args[2].Interface().(*pb.ExecuteBussinessResponse)

		rspParam.ErrorCode = common.GRPCSucceed
		rspParam.ErrorMsg = "succ"

		var realIn []reflect.Value

		if handlerType.NumIn() == 2 {
			paramIn := handlerType.In(1)
			if paramIn.Kind() == reflect.Ptr {
				paramIn = paramIn.Elem()
			}

			val := reflect.New(paramIn)
			if e := proto.Unmarshal(reqParam.GetData(), val.Interface().(proto.Message)); e != nil {
				rspParam.ErrorCode = common.GRPCFailed
				rspParam.ErrorMsg = "parse pb body fail"
				logger.Errorf("parse pb body fail, url: %v, err: %v", reqParam.GetUrl(), e)
				return
			}

			realIn = append(realIn, reflect.ValueOf(ctx), val)
		}

		callFuncName := ""
		if len(realIn) >= 2 {
			lastFuncNames := strings.Split(runtime.FuncForPC(reflect.ValueOf(handler).Pointer()).Name(), ".")
			if len(lastFuncNames) > 0 {
				callFuncName = lastFuncNames[len(lastFuncNames)-1]
			}
			logger.Infof("--------> %v, grpc req body: %+v", callFuncName, realIn[1].Interface())

		}

		retValues := handlerValue.Call(realIn)

		retItemNums := handlerType.NumOut()

		if retItemNums == 2 {
			if retValues[retItemNums-1].Interface() != nil { // error is not nil
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					rspParam.ErrorCode = errImpl.GetCode()
					rspParam.ErrorMsg = errImpl.GetCodeMsg()

				} else {
					rspParam.ErrorMsg = "not defined err code"
					rspParam.ErrorCode = common.GRPCFailed
				}

			} else if handlerType.NumOut() != 1 {
				rspParam.ErrorCode = 0
				logger.Infof("[ %v ], grpc response body: %+v", callFuncName, retValues[0].Interface())

				rspData, err := proto.Marshal(retValues[0].Interface().(proto.Message))
				if err != nil {
					rspParam.ErrorCode = common.GRPCFailed
					logger.Errorf("marsh response to proto bin fail, err: %v", err)
				} else {
					rspParam.Data = rspData
				}
			}
		} else if retItemNums == 1 { //only error
			if retValues[retItemNums-1].Interface() != nil {
				errImpl, ok := retValues[retItemNums-1].Interface().(CliError)
				if ok {
					rspParam.ErrorCode = errImpl.GetCode()
					rspParam.ErrorMsg = errImpl.GetCodeMsg()

				} else {
					rspParam.ErrorMsg = "not defined err code"
					rspParam.ErrorCode = common.GRPCFailed
				}
			} else {
				rspParam.ErrorCode = common.GRPCSucceed
			}
		} else {
			logger.Infof("[ %v ], grpc response body: %+v", callFuncName, retValues[0].Interface())
			rspParam.Data, _ = proto.Marshal(retValues[0].Interface().(proto.Message))
			rspParam.ErrorCode = common.GRPCSucceed
		}
		logger.Infof("<-------- %v, grpc response: %+v", callFuncName, rspParam)
		return
	}

	h := reflect.MakeFunc(reflect.TypeOf(lastCallFnType), oneCallFn)
	return h.Interface().(func(ctx context.Context, in *pb.ExecuteBussinessRequest, out *pb.ExecuteBussinessResponse))
}
