package pdfOps

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"fmt"
	"github.com/signintech/gopdf"
	"os"
	"testing"
)

// TestPdfOpsOneText 单页，一行文字
func TestPdfOpsOneText(t *testing.T) {
	mock.LoggerMock()

	pdf := NewPdfHandler(FontCh, "./", 14)
	if pdf == nil {
		t.Logf("new pdf handler is nil")
		return
	}

	if err := pdf.LoadFont(); err != nil {
		t.Logf("load font fail, %v", err)
		return
	}

	pdf.NewPage()
	if err := pdf.SetFont(); err != nil {
		t.Logf("set font fail, %v", err)
		return
	}

	if err := pdf.CreateCell([]rune("sssssss 你好，我是谁?")); err != nil {
		t.Logf("cell create fail, %v", err)
		return
	}

	if err := pdf.WriteTxt("pdf_txt.pdf"); err != nil {
		t.Logf("write txt fail, err: %v", err)
		return
	}

}

// splitTextIntoLines 将文本分割成多行
func splitTextIntoLines(text string) []string {
	lines := []string{}
	line := ""
	for _, r := range text {
		if r == '\n' {
			lines = append(lines, line)
			line = ""
		} else {
			line += string(r)
		}
	}
	if line != "" {
		lines = append(lines, line)
	}
	return lines
}

// TestPdfOpsMultiText 多页，每页有多行文字
func TestPdfOpsMultiText(t *testing.T) {
	mock.LoggerMock()

	pdf := NewPdfHandler(FontCh, "./", 14)
	if pdf == nil {
		t.Logf("new pdf handler is nil")
		return
	}

	//...
	if err := pdf.LoadFont(); err != nil {
		t.Logf("load font fail, %v", err)
		return
	}

	pageTextsData := []string{
		"你好，世界！这是第一页。\n这个 PDF 文件包含多页中文文本。\n你可以添加更多的内容。",
		"这是第二页。\n你现在看到的是不同的页面内容。\n你可以把这些文本分布在不同的页面上。",
		"这是第三页。\n你可以继续添加更多的页面和文本。\n这样就可以生成一个多页的 PDF 文件。",
	}

	// 创建多个页面
	for _, text := range pageTextsData {
		pdf.NewPage()
		pdf.SetFont()

		lines := splitTextIntoLines(text)

		startY := 50.0
		lineHeight := float64(14) * 1.5

		for i, line := range lines {
			t.Logf("line: %v", line)
			pdf.SetXY(50.0, startY+float64(i)*lineHeight)
			pdf.CreateCell([]rune(line))
		}
	}

	pdf.WriteTxt("./multi_text.pdf")
}

// TestPdfOpsAddImage 单页： 文字和图片组合
func TestPdfOpsAddImage(t *testing.T) {
	mock.LoggerMock()

	pdf := NewPdfHandler(FontCh, "./", 14)
	if pdf == nil {
		t.Logf("new pdf handler is nil")
		return
	}

	//...
	if err := pdf.LoadFont(); err != nil {
		t.Logf("load font fail, %v", err)
		return
	}

	pdf.NewPage()
	pdf.SetFont()
	//
	pageTextData := "你好，世界！这是第一页。\n这个 PDF 文件包含中文文字和图片。\n你可以添加更多的内容。"
	lines := splitTextIntoLines(pageTextData)
	startY := 50.0
	lineHeight := float64(14) * 1.5
	for i, line := range lines {
		pdf.SetXY(50.0, startY+float64(i)*lineHeight)
		pdf.CreateCell([]rune(line))
	}

	pdf.SetXY(0, 0)
	// 添加图片, 设置图片宽高：
	imageWidth, imageHeight := 200.0, 150.0 // 设置图片的宽和高
	imagePath := "pada.png"
	if err := pdf.GoPdfItem.Image(imagePath, 0, 100, &gopdf.Rect{W: imageWidth, H: imageHeight}); err != nil {
		t.Logf("image add fail, err: %v", err)
		return
	}
	pdf.WriteTxt("./txt_image_one_page.pdf")
}

// TestPdfOpsAddTextImages 多页： 文字和图片组合
func TestPdfOpsAddTextImages(t *testing.T) {
	mock.LoggerMock()

	pdf := NewPdfHandler(FontCh, "./", 14)
	if pdf == nil {
		t.Logf("new pdf handler is nil")
		return
	}

	//...
	if err := pdf.LoadFont(); err != nil {
		t.Logf("load font fail, %v", err)
		return
	}

	pageTextData := []string{
		"你好，世界！这是第一页。\n这个 PDF 文件包含中文文字和图片。\n你可以添加更多的内容",
		"这是第二页。\n你现在看到的是不同的页面内容。\n这里也有中文文字和图片",
	}

	for _, text := range pageTextData {
		pdf.NewPage()
		pdf.SetFont()

		lines := splitTextIntoLines(text)
		startY := 50.0
		lineHeight := float64(14) * 1.5

		for i, line := range lines {
			pdf.SetXY(50, startY+float64(i)*lineHeight)
			pdf.CreateCell([]rune(line))
		}

		imagePath := "pada.png"
		imageErr := pdf.GoPdfItem.Image(imagePath, 100, 400, nil)
		if imageErr != nil {
			fmt.Printf("Error adding image: %v\n", imageErr)
			os.Exit(1)
		}
	}
	pdf.WriteTxt("./txt_image_multi.pdf")
}
