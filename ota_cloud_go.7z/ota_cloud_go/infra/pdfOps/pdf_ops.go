package pdfOps

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/signintech/gopdf"
	_ "github.com/signintech/gopdf"
	"path/filepath"

	"fmt"
)

type FontFamilyName struct {
	FamilyName   string
	FontTypeName string
}

var FontSet map[int32]FontFamilyName = map[int32]FontFamilyName{
	FontCh: FontFamilyName{
		FamilyName:   "NotoSansSC",
		FontTypeName: "NotoSansSC-Regular.ttf",
	},
}

const (
	FontCh = 1
)

type PdfParam struct {
	FontType int32
	FontPath string
	FontSize int32
}

// PdfHandler pdf 操作句柄
type PdfHandler struct {
	Conf      *PdfParam
	GoPdfItem *gopdf.GoPdf
}

// NewPdfHandler 创建 pdf 处理句柄, fontType: FontCh or others.
func NewPdfHandler(fontType int32, fontPath string, fontSize int32) *PdfHandler {
	ret := &PdfHandler{
		Conf: &PdfParam{
			FontType: fontType,
			FontPath: fontPath,
			FontSize: fontSize,
		},

		GoPdfItem: &gopdf.GoPdf{},
	}
	ret.GoPdfItem.Start(gopdf.Config{PageSize: *gopdf.PageSizeA4})
	return ret
}

// LoadFont 添加自定义中文字体； 加载配置的字体，设置字体和字号；
func (ph *PdfHandler) LoadFont() error {
	fontTypeName, ok := FontSet[ph.Conf.FontType]
	if !ok {
		logger.Infof("not find font type: %v", ph.Conf.FontType)
		return nil
	}
	fPath := filepath.Join(ph.Conf.FontPath, fontTypeName.FontTypeName)

	if err := ph.GoPdfItem.AddTTFFont(fontTypeName.FamilyName, fPath); err != nil {
		logger.Errorf("load font fail, err: %v, font path: %v, font family: %v", err, fPath, fontTypeName.FamilyName)
		return err
	}

	return nil
}

// SetFont 设置字体
func (ph *PdfHandler) SetFont() error {
	fontTypeName, ok := FontSet[ph.Conf.FontType]
	if !ok {
		logger.Infof("not find font type: %v", ph.Conf.FontType)
		return nil
	}
	if err := ph.GoPdfItem.SetFont(fontTypeName.FamilyName, "", ph.Conf.FontSize); err != nil {
		logger.Errorf("set font fail, err: %v, font size: %v, family type: %v", err, ph.Conf.FontSize, fontTypeName.FamilyName)
		return err
	}
	return nil
}

// NewPage 添加新页面
func (ph *PdfHandler) NewPage() {
	ph.GoPdfItem.AddPage()
}

func (ph *PdfHandler) SetXY(x, y float64) error {
	if ph == nil {
		return fmt.Errorf("pdf handler is nil")
	}
	ph.GoPdfItem.SetXY(x, y)
	return nil
}

// CreateCell create cell of text
func (ph *PdfHandler) CreateCell(data []rune) error {
	if ph == nil {
		return fmt.Errorf("pdf handler is nil")
	}
	if err := ph.GoPdfItem.Cell(nil, string(data)); err != nil {
		logger.Errorf(" create cell of text fail, err: %v", err)
		return err
	}
	return nil
}

// WriteTxt 将文字写入 pdf
func (ph *PdfHandler) WriteTxt(pdfFile string) error {
	if err := ph.GoPdfItem.WritePdf(pdfFile); err != nil {
		logger.Errorf("write txt  to pdf file: %v, fail: %v", pdfFile, err)
		return err
	}
	return nil
}
