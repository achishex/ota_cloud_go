package config

import (
	"fmt"
	"io/ioutil"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/pkg/errors"
	"go-micro.dev/v4/config"
	"go-micro.dev/v4/config/source/env"
	"gopkg.in/yaml.v2"
)

type Config struct {
	Port int
}

var cfg = &Config{
	Port: 18901,
}

func Address() string {
	cfg.Port = GetConfig().ConnectPort.NacosPort
	return fmt.Sprintf(":%d", GetConfig().ConnectPort.GrpcPort)
}

func Load() error {
	configor, err := config.NewConfig(config.WithSource(env.NewSource()))
	if err != nil {
		return errors.Wrap(err, "configor.New")
	}
	if err := configor.Load(); err != nil {
		return errors.Wrap(err, "configor.Load")
	}
	if err := configor.Scan(cfg); err != nil {
		return errors.Wrap(err, "configor.Scan")
	}
	return nil
}

var ServiceCfg *ServiceConfig

func GetConfig() *ServiceConfig {
	return ServiceCfg
}

type ServiceConfig struct {
	Db struct {
		Dbname string `yaml:"dbname"`
		Host   string `yaml:"host"`
		Port   int    `yaml:"port"`
		Pwd    string `yaml:"pwd"`
		User   string `yaml:"user"`
	} `yaml:"db"`
	Redis struct {
		Host     string `yaml:"host"`
		Port     int    `yaml:"port"`
		Password string `yaml:"password"`
		DataBase int    `yaml:"database"`
	} `yaml:"redis"`
	Nacos struct {
		ServerAddr string `yaml:"server-addr"`
		Port       int    `yaml:"port"`
	} `yaml:"nacos"`
	ConnectPort struct {
		NacosPort int `yaml:"nacos-port"`
		GrpcPort  int `yaml:"grpc-port"`
	} `yaml:"connect-port"`
	Logger struct {
		Encoding    string `yaml:"encoding"`
		FilterTopic string `yaml:"filterTopic"`
		Level       string `yaml:"level"`
		Rotate      struct {
			Compress   bool   `yaml:"compress"`
			Filename   string `yaml:"filename"`
			Localtime  bool   `yaml:"localtime"`
			Maxage     int    `yaml:"maxage"`
			Maxbackups int    `yaml:"maxbackups"`
			Maxsize    int    `yaml:"maxsize"`
		} `yaml:"rotate"`
	} `yaml:"logger"`
	Kafka struct {
		BootStrapServers string `yaml:"bootstrap-servers"`
		Consumer         struct {
			GroupID      string `yaml:"group-id"`
			AlarmGroupID string `yaml:"alarm-group-id"`
		} `yaml:"consumer"`
		EventNoticeTopic     string `yaml:"event-notice-topic"`
		AlarmAsyncWriteTopic string `yaml:"alarm-async-topic"`
	} `yaml:"kafka"`
	EvidenceReportS3 struct {
		Ak                  string `yaml:"ak"`
		Sk                  string `yaml:"sk"`
		Bucket              string `yaml:"bucket"`
		FilePrefix          string `yaml:"file-prefix"`
		Region              string `yaml:"region"`
		UploadTimeoutSecond int32  `yaml:"upload-timeout-second"`
	} `yaml:"evidence-report-s3"`
	I18nPath string `yaml:"i18npath"`
	Mqtt     struct {
		Username string `yaml:"username"`
		Password string `yaml:"password"`
		Url      string `yaml:"url"`
		ClientId string `yaml:"clientId"`
	} `yaml:"mqtt"`
}

func ParseYamlFile(filename string) (*ServiceConfig, error) {
	buf, err := ioutil.ReadFile(filename)
	if err != nil {
		logger.Errorf("ReadFile: %v", err)
		return nil, err
	}
	// 初始化 ServiceCfg
	ServiceCfg = &ServiceConfig{}
	err = yaml.Unmarshal(buf, ServiceCfg)
	if err != nil {
		logger.Errorf("Unmarshal: %v", err)
		return ServiceCfg, err
	}
	logger.Info("ServiceCfg: %+v", ServiceCfg)
	return ServiceCfg, nil
}

func InitConfig(filePath string) {
	ServiceCfg, err := ParseYamlFile(filePath)
	if err != nil {
		logger.Fatalf("parseYamlFile: %v", err)
		return
	}

	if ServiceCfg == nil {
		logger.Fatalf("ServiceCfg is nil after parsing YAML file")
		return
	}

	logger.Infof("Parsed YAML file: %+v\n", ServiceCfg)
}
