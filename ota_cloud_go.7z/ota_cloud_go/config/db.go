package config

import (
	"cuav-cloud-go-service/domain/repository/redis"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var (
	Db          *gorm.DB
	GlobalRedis redis.SkyFendRedisOps = nil
)

// GetDB 获取DB
func GetDB() *gorm.DB {
	if Db != nil {
		return Db
	}
	logger.Errorf("Db is nil")
	return nil
}

// initPostgresWithParams 使用 db配置信息初始化db handle.
func initPostgresWithParams(host string, port int, user string, passwd string, dbName string) (*gorm.DB, error) {
	dsn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable",
		host, port, user, passwd, dbName)

	dbHandle, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		logger.Errorf("open db : %v fail, err: %v", dbName, err)
		return nil, err
	}
	logger.Info("Successfully connected!")
	return dbHandle, nil
}

func initPostgres() (*gorm.DB, error) {
	return initPostgresWithParams(GetConfig().Db.Host, GetConfig().Db.Port, GetConfig().Db.User, GetConfig().Db.Pwd, GetConfig().Db.Dbname)
}

func InitDB() (*gorm.DB, error) {
	var err error
	Db, err = initPostgres()
	if err != nil {
		logger.Error("Failed to connect to database:", err)
		return nil, err
	}
	return Db, nil
}

func CloseDB(dbHandle *gorm.DB) error {
	sqlDB, err := dbHandle.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}

func InitRedis() {
	GlobalRedis = redis.NewSkyFendRedisClient(
		redis.WithRedisAddrOpt(fmt.Sprintf("%v:%d", GetConfig().Redis.Host, GetConfig().Redis.Port)),
		redis.WithRedisDB(GetConfig().Redis.DataBase),
		redis.WithRedisPasswd(GetConfig().Redis.Password),
	)
}
