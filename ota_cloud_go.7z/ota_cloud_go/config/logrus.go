package config

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func InitLog() {
	//初始化日志组件
	if err := logger.Init("/opt/cloud/service/cuav-cloud-go-service/config/application-dev.yml",
		"/logs/ms_log/cuav-cloud-go-service"); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return
	}
}
