package main

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/cmqtt"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/uav_record"
	"fmt"
)

const pingTopic = "/ping"

func initAdaptorWithAuth() *cmqtt.Adaptor {
	mock.LoggerMock()
	config.InitConfig("/opt/cloud/service/cuav-cloud-go-service/config/application-dev.yml")
	usename := config.GetConfig().Mqtt.Username
	password := config.GetConfig().Mqtt.Password
	url := "tcp://10.240.34.35:30010"
	clientid := config.GetConfig().Mqtt.ClientId
	return cmqtt.NewAdaptorWithAuth(url, clientid, usename, password)
}
func ping(m cmqtt.Message) ([]byte, int32) {

	p := m.Payload()
	fmt.Println("p = ", p)
	return m.Payload(), 1
}

var consumes = []cmqtt.DoRoute{
	{
		Topic:   pingTopic,
		Handler: ping,
	},
}

func main() {
	// s := initAdaptorWithAuth()
	// s.SetAutoReconnect(true)
	// s.SetCleanSession(true)
	// s.RegisterSubHandlers(consumes)
	// _ = s.Connect()
	// data := []byte("good morning")
	// time.Sleep(time.Second)
	// go s.Publish(pingTopic, data)
	// uav_record.DoRcvMqttMsg()
	eventID := "fakeEventID"
	eventRet := uav_record.GetEventImageDownloadURL(eventID)
	fmt.Println("\n-------------eventRet = ", eventRet)
	select {}
}
