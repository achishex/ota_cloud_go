package geo

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
)

func TestCalcSite(t *testing.T) {
	mock.LoggerMock()
	//
	srcNode := &LonLatLocation{
		Longitude: 114.45624,
		// 纬度
		Latitude: 22.45585,
		// 高度
		Altitude: 0,
	}
	dstNode := &LonLatLocation{
		Longitude: 113.12356,
		// 纬度
		Latitude: 22.12356,
		// 高度
		Altitude: 0,
	}

	//
	retData, err := CalcAngleByLocation(srcNode, dstNode)
	if err != nil {
		t.Logf("calc site fail, err: %v", err)
	} else {
		t.Logf("calc site succ, ret: %+v", retData)
	}

}
