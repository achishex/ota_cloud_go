package geo

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
)

func TestAA(t *testing.T) {}

func TestParseCrossArea(t *testing.T) {
	mock.LoggerMock()
	srcData := `{
		"type": "Feature",
		"geometry": {
			"type": "MultiPolygon",
			"coordinates": [
				[
					[
						[113.9110152268387, 22.639972391718725],
						[113.91260558906173, 22.640520235918228],
						[113.91157562080001, 22.640837101240088],
						[113.9110152268387, 22.639972391718725]
					]
				],
				[
					[
						[113.88960296455004, 22.606928368461467],
						[113.91535217109298, 22.632123038592216],
						[113.90592844279183, 22.632123038592216],
						[113.88960296455004, 22.606928368461467]
					]
				],
				[
					[
						[113.88822967353441, 22.632123038592216],
						[113.90592844279183, 22.632123038592216],
						[113.9110152268387, 22.639972391718725],
						[113.88822967353441, 22.632123038592216]
					]
				]
			]
		},
		"properties": {
			"type": "esriSFS",
			"color": [106, 0, 108, 13],
			"outline": {
				"type": "esriSLS",
				"color": [106, 0, 108, 153],
				"width": 2,
				"style": "esriSLSSolid"
			},
			"style": "esriSFSSolid"
		}
	}`

	dstPoly, e := ParseGeoJsonToPolygons(srcData)
	t.Logf("parse str 2 polygon e: %v, data: %v", e, dstPoly)
}

func TestParseGeoJsonToPolygons(t *testing.T) {
	mock.LoggerMock()
	srcData := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[113.93753227996856, 22.603279745271383],
				[113.93512902069122, 22.60121954496328],
				[113.94251045990019, 22.59995171406089],
				[113.94268212127714, 22.603121269419525],
				[113.93753227996856, 22.603279745271383]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [210, 210, 122, 13],
		"outline": {
			"type": "esriSLS",
			"color": [210, 210, 122, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`

	dstPoly, e := ParseGeoJsonToPolygons(srcData)
	t.Logf("parse str 2 polygon e: %v, data: %v", e, dstPoly)
}

func TestParseFromStr2Poly(t *testing.T) {
	mock.LoggerMock()

	srcData := `{
	"aggregateGeometries": null,
	"geometry": {
		"spatialReference": {
			"wkid": 4326
		},
		"rings": [
			[
				[114.00282797622694, 22.594840652313202],
				[114.00106844711313, 22.59674246489875],
				[113.9991801719666, 22.594642545324728],
				[113.99939474868778, 22.599951714060968],
				[114.00192675399792, 22.59983285431513],
				[114.00458750534077, 22.598168807096666],
				[114.00282797622694, 22.594840652313202]
			]
		]
	},
	"symbol": {
		"type": "esriSFS",
		"color": [16, 152, 212, 26],
		"outline": {
			"type": "esriSLS",
			"color": [16, 152, 212, 255],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	},
	"attributes": {},
	"popupTemplate": null
}`
	dstPoly, e := ParseGeoJsonToPolygons(srcData)
	t.Logf("parse str 2 polygon e: %v, data: %v", e, dstPoly)

	// 不在圈内
	u, l := 113.99109062957744, 22.60411174049991
	exist, e := GeoCheckPointInPolygons(u, l, dstPoly)
	t.Logf("not exist poly, e: %v, exist: %v", e, exist)
	//在圈内
	u, l = 114.0015405158997, 22.599020643304982
	exist, e = GeoCheckPointInPolygons(u, l, dstPoly)
	t.Logf(" exist poly, e: %v, exist: %v", e, exist)
	// 算距离：
	sLon, sLat := 113.95895541, 30.38129032
	dLon, dLat := 114.19017725, 30.38129032
	dist := GeoDistance(sLon, sLat, dLon, dLat)
	t.Logf("expect: 22166.14, dist: %v", dist)

	//
	//dist = distanceUsingH3(sLon, sLat, dLon, dLat, 5)
	//t.Logf("expect: 22166.14, dist: %v", dist)
}

func TestParseGeoJsonFromStrToPoly(t *testing.T) {
	mock.LoggerMock()
	//
	//	originStr := `
	//{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.98922837030003,22.602773547478524],[113.99313366662582,22.605705328604728],[113.9912453914793,22.608280490227262],[113.98227608453325,22.605982656018153],[113.98536598931848,22.60000018352454],[113.98922837030003,22.602773547478524]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,255],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}
	//`
	originStr := `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.95745358066846,22.629663433972063],[113.94372067051222,22.57514742754486],[114.01629909859243,22.573562337062523],[114.01726040858979,22.626748008145906],[113.95745358066846,22.629663433972063]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,255],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`

	_, err := ParseGeoJsonToPolygons(originStr)
	if err != nil {
		t.Logf("parase json fail, err: %v", err)
	}
	//} else {
	//	t.Logf("parse json data: %+v", data)
	//}
}

func TestCheckInPolygons2(t *testing.T) {
	mock.LoggerMock()
	srcData := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[113.97710022735622, 22.598921592853866],
				[113.97521195220975, 22.586242546765206],
				[113.98928818511986, 22.585450067623256],
				[113.98688492584253, 22.599872474241756],
				[113.97710022735622, 22.598921592853866]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [228, 101, 107, 13],
		"outline": {
			"type": "esriSLS",
			"color": [228, 101, 107, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`

	dstPoly, e := ParseGeoJsonToPolygons(srcData)
	t.Logf("parse str 2 polygon e: %v, data: %v", e, dstPoly)

	//113.97710022735622 22.598921592853866
	u, l := float64(113.93557990127117), float64(22.599099511394893)
	exist, e := GeoCheckPointInPolygons(u, l, dstPoly)
	if e != nil {
		t.Logf("check is fail, e: %v", e)
	} else if exist {
		t.Logf("check is exist")
	} else {
		t.Logf("not exist in area")
	}

}
