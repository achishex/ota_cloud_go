package geo

import (
	"cuav-cloud-go-service/deploy/bean"
	"encoding/json"
	"math"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	geo "github.com/kellydunn/golang-geo"
	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"
	"github.com/paulmach/orb/planar"
)

type PolygonList = []orb.Polygon

// PolygonPointList 一个围栏区的 point
type PolygonPointList = [][]Point

type PolygonUnionList struct {
	PolygonListItems      PolygonList //
	PolygonPointListItems PolygonPointList
	//
	AreaItemDetail *bean.FencedAreaConfig
}

type Coordinate struct {
	Latitude  float64
	Longitude float64
}

type Point struct {
	X float64
	Y float64
}

// ConvertToPlaneCoordinate 将经纬度转换为平面坐标
func ConvertToPlaneCoordinate(coordinate Coordinate) Point {
	radius := 6371000.0 // 地球半径（单位：米）
	latRad := coordinate.Latitude * (math.Pi / 180.0)
	lonRad := coordinate.Longitude * (math.Pi / 180.0)
	x := radius * lonRad * math.Cos(latRad)
	y := radius * latRad
	return Point{X: x, Y: y}
}

// CalculateDistance 计算两点（平面坐标）之间的距离
func CalculateDistance(p1 Point, p2 Point) float64 {
	return math.Sqrt(math.Pow(p1.X-p2.X, 2) + math.Pow(p1.Y-p2.Y, 2))
}

// DistanceToLine 计算点到线段的（平面坐标点）最短距离
func DistanceToLine(point Point, lineP1 Point, lineP2 Point) float64 {
	alpha := ((point.X-lineP1.X)*(lineP2.X-lineP1.X) + (point.Y-lineP1.Y)*(lineP2.Y-lineP1.Y)) / (math.Pow(lineP2.X-lineP1.X, 2) + math.Pow(lineP2.Y-lineP1.Y, 2))
	closestPoint := Point{
		X: lineP1.X + alpha*(lineP2.X-lineP1.X),
		Y: lineP1.Y + alpha*(lineP2.Y-lineP1.Y),
	}
	return CalculateDistance(point, closestPoint)
}

// CalculateDroneCircle 计算无人机形成的圆 (圆心+半径)
func CalculateDroneCircle(droneCoordinate Coordinate, radius float64) (Point, float64) {
	dronePoint := ConvertToPlaneCoordinate(droneCoordinate)
	return dronePoint, radius
}

// GeoDistance 计算两个坐标之间的距离, 单位是：米
func GeoDistance(droneLongitude, droneLatitude, C2Longitude, C2Latitude float64) float64 {
	point1 := geo.NewPoint(droneLatitude, droneLongitude)
	point2 := geo.NewPoint(C2Latitude, C2Longitude)
	return point1.GreatCircleDistance(point2) * 1000
}

// GeoCheckPointInPolygons 检查是否在围栏区内； 使用前需要调用 ParseGeoJsonToPolygons()
func GeoCheckPointInPolygons(uavLon, uavLat float64, fendArea PolygonList) (bool, error) {
	for _, fence := range fendArea {
		contains := planar.PolygonContains(fence, orb.Point{uavLon, uavLat})
		if contains {
			// logger.Debugf("inPolygon Point is in polygon: %v", contains)
			return true, nil
		}
	}
	return false, nil
}

// GeoCalcMiniDistanceToPolygonsByDistance 判断是否在围栏区内
//
//	func GeoCalcMiniDistanceToPolygonsByDistance(uavLon, uavLat float64, fendArea PolygonPointList, radius float64) (bool, float64) {
//		dronePoint, droneRadius := CalculateDroneCircle(Coordinate{
//			Latitude:  uavLat,
//			Longitude: uavLon,
//		}, radius)
//
//		retDistance := math.MaxFloat64
//		for _, fence := range fendArea {
//			intersect, distance := checkIntersection(dronePoint, droneRadius, fence)
//			if intersect {
//				return intersect, distance
//			}
//			if retDistance > distance {
//				retDistance = distance
//			}
//		}
//		return false, retDistance
//	}
func GeoCalcMiniDistanceToPolygonsByDistance(uavLon, uavLat float64, fendArea PolygonPointList, radius float64) bool {
	dronePoint, droneRadius := CalculateDroneCircle(Coordinate{
		Latitude:  uavLat,
		Longitude: uavLon,
	}, radius)

	for _, fence := range fendArea {
		intersect := CirclePolygonIntersect(dronePoint, droneRadius, fence)
		if intersect {
			return intersect
		}
	}
	return false
}

//
//// checkIntersection 检查圆与多边形是否有交集
//func checkIntersection(dronePoint Point, radius float64, polygon []Point) (bool, float64) {
//	distArr := make([]float64, 0)
//	for i := 0; i < len(polygon); i++ {
//		p1 := polygon[i]
//		p2 := polygon[(i+1)%len(polygon)]
//		dist := distanceToLine(dronePoint, p1, p2)
//		distArr = append(distArr, dist)
//	}
//	minDistance := func(data []float64) float64 {
//		if len(data) == 0 {
//			return -1000
//		}
//		var minVal float64
//		for i := 0; i < len(data); i++ {
//			if minVal < data[i] {
//				minVal = data[i]
//			}
//		}
//		return minVal
//	}(distArr)
//
//	if minDistance <= radius {
//		return true, minDistance
//	}
//	return false, minDistance
//}

// 计算点到线段的最短距离
func distanceToLine(point Point, lineP1 Point, lineP2 Point) float64 {
	alpha := ((point.X-lineP1.X)*(lineP2.X-lineP1.X) + (point.Y-lineP1.Y)*(lineP2.Y-lineP1.Y)) / (math.Pow(lineP2.X-lineP1.X, 2) + math.Pow(lineP2.Y-lineP1.Y, 2))
	closestPoint := Point{
		X: lineP1.X + alpha*(lineP2.X-lineP1.X),
		Y: lineP1.Y + alpha*(lineP2.Y-lineP1.Y),
	}
	return calculateDistance(point, closestPoint)
}

// / 计算两点之间的距离
func calculateDistance(p1 Point, p2 Point) float64 {
	return math.Sqrt(math.Pow(p1.X-p2.X, 2) + math.Pow(p1.Y-p2.Y, 2))
}

// unmarshalToOrbPolygon 将数据库geometry字段反序列化成orb.Polygon； 在入口的时候调用
func unmarshalToOrbPolygon(geometry orb.Geometry, geoJsonType string) (PolygonList, error) {
	polygons := make([]orb.Polygon, 0)
	if geoJsonType == "Polygon" {
		rings := make([]orb.Ring, 0)
		geometryByte, err := json.Marshal(geometry)
		if err != nil {
			logger.Errorf("inPolygon Marshal Geometry failed, err: %v", err)
			return nil, err
		}
		if err = json.Unmarshal(geometryByte, &rings); err != nil {
			logger.Errorf("inPolygon Unmarshal Ring failed, err: %v", err)
			return nil, err
		}
		for i := range rings {
			polygons = append(polygons, orb.Polygon{rings[i]})
		}
	} else if geoJsonType == "MultiPolygon" {
		rings := make([][]orb.Ring, 0)
		geometryByte, err := json.Marshal(geometry)
		if err != nil {
			logger.Errorf("inPolygon Marshal Geometry failed, err: %v", err)
			return nil, err
		}
		if err = json.Unmarshal(geometryByte, &rings); err != nil {
			logger.Errorf("inPolygon Unmarshal Ring failed, err: %v", err)
			return nil, err
		}
		for i := range rings {
			for j := range rings[i] {
				polygons = append(polygons, orb.Polygon{rings[i][j]})
			}
		}
	}
	return polygons, nil
}

// ParseGeoJsonToPolygons 解析数据
func ParseGeoJsonToPolygons(geoJsonStr string) (PolygonList, error) {
	feature, err := geojson.UnmarshalFeature([]byte(geoJsonStr))
	if err != nil {
		logger.Errorf("inPolygon UnmarshalFeature failed, err: %v, geoJson: %v", err, geoJsonStr)
		return nil, err
	}
	polygons, err := unmarshalToOrbPolygon(feature.Geometry, feature.Geometry.GeoJSONType())
	if err != nil {
		logger.Errorf("inPolygon unmarshalToOrbPolygon failed, err: %v", err)
		return nil, err
	}
	//logger.Debugf("inPolygon polygons: %+v", polygons)
	return polygons, nil
}

// UnmarshalToPoint 将数据库一个围栏区 geometry字段反序列化成Point; 在入口的时候调用
func UnmarshalToPoint(geoJsonStr string) (PolygonPointList, error) {
	var polygons = make([][]Point, 0)
	feature, err := geojson.UnmarshalFeature([]byte(geoJsonStr))
	if err != nil {
		logger.Errorf("unmarshalToPoint UnmarshalFeature err: %v", err)
		return nil, err
	}
	geometryByte, err := json.Marshal(feature.Geometry)
	if err != nil {
		logger.Errorf("unmarshalToPoint marshal GeoJSON err: %v", err)
		return nil, err
	}
	//logger.Debugf("unmarshalToPoint geometryByte: %v", string(geometryByte))
	if feature.Geometry.GeoJSONType() == "Polygon" {
		points := [][]orb.Point{}
		if err = json.Unmarshal(geometryByte, &points); err != nil {
			logger.Errorf("unmarshalToPoint unmarshal Point err: %v", err)
			return nil, err
		}
		for i := range points {
			polygon := make([]Point, len(points[i]))
			coordinateList := make([]Coordinate, len(points[i]))
			for j := range points[i] {
				coordinateList[j] = Coordinate{Latitude: points[i][j].Lat(), Longitude: points[i][j].Lon()}
				polygon[j] = ConvertToPlaneCoordinate(coordinateList[j])
			}
			polygons = append(polygons, polygon)
		}
	} else if feature.Geometry.GeoJSONType() == "MultiPolygon" {
		points := [][][]orb.Point{}
		if err = json.Unmarshal(geometryByte, &points); err != nil {
			logger.Errorf("unmarshalToPoint unmarshal Point err: %v", err)
			return nil, err
		}
		for i := range points {
			for j := range points[i] {
				polygon := make([]Point, len(points[i][j]))
				coordinateList := make([]Coordinate, len(points[i][j]))
				for k, tmp := range points[i][j] {
					coordinateList[k] = Coordinate{Latitude: tmp[1], Longitude: tmp[0]}
					polygon[k] = ConvertToPlaneCoordinate(coordinateList[k])
				}
				polygons = append(polygons, polygon)
			}
		}
	}
	return polygons, nil
}

func CirclePolygonIntersect(circleCenter Point, radius float64, polygon []Point) bool {
	// 判断圆心是否在多边形内部
	if isPointInPolygon(circleCenter, polygon) {
		return true
	}

	// 判断圆与多边形的边是否有交点
	for i := 0; i < len(polygon); i++ {
		p1 := polygon[i]
		p2 := polygon[(i+1)%len(polygon)]
		if isSegmentCircleIntersect(p1, p2, circleCenter, radius) {
			return true
		}
	}

	return false
}

// 判断点是否在多边形内部
func isPointInPolygon(point Point, polygon []Point) bool {
	crosses := 0
	for i := 0; i < len(polygon); i++ {
		p1 := polygon[i]
		p2 := polygon[(i+1)%len(polygon)]
		if (point.Y < p2.Y && point.Y >= p1.Y) || (point.Y < p1.Y && point.Y >= p2.Y) {
			x := (point.Y-p1.Y)*(p2.X-p1.X)/(p2.Y-p1.Y) + p1.X
			if x > point.X {
				crosses++
			}
		}
	}
	return crosses%2 != 0
}

// 判断线段和圆是否有交点
func isSegmentCircleIntersect(p1, p2, circleCenter Point, radius float64) bool {
	d := distanceToSegment(circleCenter, p1, p2)
	return d <= radius
}

// 计算点到线段的最近距离
func distanceToSegment(p, p1, p2 Point) float64 {
	if p1.X == p2.X && p1.Y == p2.Y {
		return math.Sqrt((p.X-p1.X)*(p.X-p1.X) + (p.Y-p1.Y)*(p.Y-p1.Y))
	}
	dot := (p.X-p1.X)*(p2.X-p1.X) + (p.Y-p1.Y)*(p2.Y-p1.Y)
	t1 := dot / ((p2.X-p1.X)*(p2.X-p1.X) + (p2.Y-p1.Y)*(p2.Y-p1.Y))
	if t1 < 0 {
		return math.Sqrt((p.X-p1.X)*(p.X-p1.X) + (p.Y-p1.Y)*(p.Y-p1.Y))
	}
	if t1 > 1 {
		return math.Sqrt((p.X-p2.X)*(p.X-p2.X) + (p.Y-p2.Y)*(p.Y-p2.Y))
	}
	x := p1.X + t1*(p2.X-p1.X)
	y := p1.Y + t1*(p2.Y-p1.Y)
	return math.Sqrt((p.X-x)*(p.X-x) + (p.Y-y)*(p.Y-y))
}
