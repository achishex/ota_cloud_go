package geo

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"fmt"
	"math"
	"runtime/debug"
)

const (
	PI          float64 = 3.14159265358979323846
	EarthRadius         = 6378137.0 // 单位为km

)

type AngleLocation struct {
	// RadialDistance 径向距离
	RadialDistance float64 `json:"radialDistance"`

	// PitchAngle 俯仰角
	PitchAngle float64 `json:"pitchAngle"`

	// AzimuthAngle 方位角
	AzimuthAngle float64 `json:"azimuthAngle"`
}

// LonLatLocation 经纬度位置
type LonLatLocation struct {
	// 经度
	Longitude float64
	// 纬度
	Latitude float64
	// 高度
	Altitude float64
}

// ECEFLocation 地心直角坐标系位置
type ECEFLocation struct {
	X float64
	Y float64
	Z float64
}

func (el *ECEFLocation) String() string {
	s := fmt.Sprintf("x: %f, y: %f, z: %f", el.X, el.Y, el.Z)
	return s
}

// ENLocation 东北天坐标系
type ENLocation struct {
	X float64
	Y float64
	Z float64
}

// LLAtoECEF 经纬度转化为地心直角坐标
func LLAtoECEF(locSrc *LonLatLocation, locDst *ECEFLocation) {
	if locSrc == nil || locDst == nil {
		return
	}

	lonRadius := locSrc.Longitude * PI / 180.0
	latRadius := locSrc.Latitude * PI / 180.0

	NFlag := EarthRadius / (math.Sqrt(1.0 - 0.00669437999014*math.Sin(latRadius)*math.Sin(latRadius)))
	locDst.X = (NFlag + locSrc.Altitude) * math.Cos(latRadius) * math.Cos(lonRadius)
	locDst.Y = (NFlag + locSrc.Altitude) * math.Cos(latRadius) * math.Sin(lonRadius)
	locDst.Z = (NFlag + (1.0 - 0.00669437999014) + locSrc.Altitude) * math.Sin(latRadius)

	logger.Infof("%s", locDst)
}

// ecefToEnu 将A、B从地心坐标系转换到以A为原点的东北天坐标系
func ecefToEnu(srcLoc *LonLatLocation, m1 *ECEFLocation, m2 *ECEFLocation, dstLoc *ENLocation) {
	if srcLoc == nil || m1 == nil || m2 == nil || dstLoc == nil {
		return
	}
	lonRadius := srcLoc.Longitude * PI / 180.0
	latRadius := srcLoc.Latitude * PI / 180.0

	var (
		detaX float64 = 0.0
		detaY float64 = 0.0
		detaZ float64 = 0.0
	)

	detaX = m2.X - m1.X
	detaY = m2.Y - m1.Y
	detaZ = m2.Z - m1.Z

	dstLoc.X = -math.Sin(lonRadius)*detaX + math.Cos(lonRadius)*detaY
	dstLoc.Y = -math.Sin(latRadius)*math.Cos(lonRadius)*detaX - math.Sin(latRadius)*math.Sin(lonRadius)*detaY + math.Cos(latRadius)*detaZ
	dstLoc.Z = math.Cos(latRadius)*math.Cos(lonRadius)*detaX + math.Cos(latRadius)*math.Sin(lonRadius)*detaY + math.Sin(latRadius)*detaZ
}

// CalcAngleByLocation 计算两个点之间的度量：径向距离，俯仰角和方位角 (其中srcNode 可以作为参考点，一般是公司的设备)
func CalcAngleByLocation(srcNode *LonLatLocation, dstNode *LonLatLocation) (*AngleLocation, error) {
	defer func() {
		if e := recover(); e != nil {
			logger.Errorf(fmt.Sprintf("%s\n%s", fmt.Sprint(e), string(debug.Stack())))
		}
	}()

	if srcNode == nil || dstNode == nil {
		return nil, fmt.Errorf("input angle location is nil")
	}
	var (
		retData *AngleLocation = new(AngleLocation)
	)
	var (
		srcEcff *ECEFLocation = new(ECEFLocation)
		dstEcff *ECEFLocation = new(ECEFLocation)

		srcEnu *ENLocation = new(ENLocation)
		dstEnu *ENLocation = new(ENLocation)
	)

	LLAtoECEF(srcNode, srcEcff)

	LLAtoECEF(dstNode, dstEcff)

	// 转化为 srcNode 为原点的东北坐标系
	ecefToEnu(srcNode, srcEcff, srcEcff, srcEnu)
	ecefToEnu(srcNode, srcEcff, dstEcff, dstEnu)

	var (
		detaX float64 = dstEnu.X - srcEnu.X
		detaY float64 = dstEnu.Y - srcEnu.Y
		detaZ float64 = dstEnu.Z - srcEnu.Z
	)
	retData.RadialDistance = math.Sqrt(detaX*detaX + detaY*detaY + detaZ*detaZ)
	var Rad_ele = math.Atan(detaZ / (math.Sqrt(detaX*detaX + detaY*detaY)))
	retData.PitchAngle = Rad_ele * (180.0 / PI)

	var Rad_azi float64 = 0.0

	if math.Sqrt(detaX*detaX+detaY*detaY) < 0.00000001 {
		Rad_azi = math.Acos(detaY / math.Sqrt(detaX*detaX+detaY*detaY))
		retData.AzimuthAngle = 0

	} else {
		Rad_azi = math.Acos(detaY / math.Sqrt(detaX*detaX+detaY*detaY))

		if dstEnu.X < 0 && dstEnu.Y > 0 {
			retData.AzimuthAngle = -Rad_azi*(180.0/PI) + 360

		} else if dstEnu.X < 0 && dstEnu.Y < 0 {
			retData.AzimuthAngle = -Rad_azi*(180.0/PI) + 360

		} else {

			retData.AzimuthAngle = Rad_azi * (180.0 / PI)
		}
	}

	retData.AzimuthAngle = math.Round(retData.AzimuthAngle)
	retData.PitchAngle = math.Round(retData.PitchAngle)

	return retData, nil
}
