package math_utils

import "math"

// TruncateToDecimals 切除小数点后面的位数，不进行四舍五入
func TruncateToDecimals(value float64, decimals int) float64 {
	// 计算乘数
	factor := math.Pow(10, float64(decimals))

	// 截断并返回结果
	return math.Trunc(value*factor) / factor
}

// RoundToDecimals 切除小数点后面的位数，进行四舍五入
func RoundToDecimals(value float64, decimals int) float64 {
	// 计算乘数
	factor := math.Pow(10, float64(decimals))

	// 舍入并返回结果
	return math.Round(value*factor) / factor
}
