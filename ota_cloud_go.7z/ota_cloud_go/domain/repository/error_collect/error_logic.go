package error_collect

import "fmt"

// SF_ErrorTokenInvalid 在此定义错误码
const (
	// SF_InValidParam 无效参数
	SF_InValidParam int32 = 50000
	// SF_ErrorTokenInvalid token 无效
	SF_ErrorTokenInvalid int32 = 53000
	// SF_ErrorCounterRecommendRecallFail counter device error code
	SF_ErrorCounterRecommendRecallFail = 53100
	// SF_ErrorRecallEmpty 召回为空
	SF_ErrorRecallEmpty = 53101
	// SF_ErrorCounterRecommendSortFail 排序失败
	SF_ErrorCounterRecommendSortFail = 53101
	// SF_ErrorCounterRecommendFilterFail 过滤失败
	SF_ErrorCounterRecommendFilterFail = 53102
	// SF_ErrorCounterRecommendDevFail 获取结果失败
	SF_ErrorCounterRecommendDevFail = 53103

	//SF_ErrorFenceInCounterRule 删除围栏区时在反制规则记录中
	SF_ErrorFenceInCounterRule = 53200

	//SF_ErrorAutoCounterFenceBound 反制规则中围栏区已被绑定
	SF_ErrorAutoCounterFenceBound = 53300
	// SF_ErrorAutoCounterRuleCreated 反制规则创建失败
	SF_ErrorAutoCounterRuleCreated = 53301
	//SF_ErrorAutoCounterRuleQuery 反制规则查询失败
	SF_ErrorAutoCounterRuleQuery = 53302
	//SF_ErrorAutoCounterRuleModify 反制规则更新失败
	SF_ErrorAutoCounterRuleModify = 53303
	//SF_ErrorAutoCounterRuleDelete 反制规则删除失败
	SF_ErrorAutoCounterRuleDelete = 53304
	//SF_ErrorAutoCounterRuleParamInvalid 反制规则创建参数非法
	SF_ErrorAutoCounterRuleParamInvalid = 53305

	// 取证报告 事件未结束
	SF_ErrorTargetNoStop = 53310
	// 取证报告 预览失败
	SF_ErrorPreviewReport = 53311
	// 取证报告 自定义报告名失败
	SF_ErrorRenameFail = 53312
	// 取证报告 自定义报告名失败
	SF_ErrorUploadCaptureFlying = 53313
)

// init 在此定义错误码信息和错误码的映射关系
func init() {
	buildErr(SF_ErrorTokenInvalid, fmt.Sprintf("token invalid"))
	buildErr(SF_ErrorCounterRecommendRecallFail, fmt.Sprintf("recall counter devices fail"))
	buildErr(SF_ErrorCounterRecommendSortFail, fmt.Sprintf("sort counter devices fail"))
	buildErr(SF_ErrorCounterRecommendFilterFail, fmt.Sprintf("filter counter devices fail"))
	buildErr(SF_ErrorCounterRecommendDevFail, fmt.Sprintf("counter devices get fail"))
	buildErr(SF_ErrorFenceInCounterRule, fmt.Sprintf("del fence in counter rule item."))
	//
	buildErr(SF_ErrorAutoCounterFenceBound, fmt.Sprintf("fence area have bound one auto counter rule"))
	buildErr(SF_ErrorAutoCounterRuleCreated, fmt.Sprintf("auto counter rule create fail"))
	buildErr(SF_ErrorAutoCounterRuleQuery, fmt.Sprintf("auto counter rule query fail"))
	buildErr(SF_ErrorAutoCounterRuleModify, fmt.Sprintf("auto counter rule modify fail"))
	buildErr(SF_ErrorAutoCounterRuleDelete, fmt.Sprintf("auto counter rule delete fail"))
	buildErr(SF_ErrorAutoCounterRuleParamInvalid, fmt.Sprintf("counter rule create param invalid"))
}
