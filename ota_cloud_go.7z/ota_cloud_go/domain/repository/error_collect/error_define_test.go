package error_collect

import (
	"fmt"
	"testing"
)

func TestErrorCollectOp(t *testing.T) {
	err := GetError(SF_ErrorTokenInvalid)
	t.Logf("1: %v", err)

	err = GetError(SF_ErrorTokenInvalid, fmt.Sprintf("forget input token"))
	t.Logf("2: %v", err)
	//

	err = GetError(1000)
	t.Logf("3: %v", err)
	//
	err = GetError(2000, "this busi_define errocde 2000")
	t.Logf("4: %v", err)

	//
	err = GetError(3000, "this is 3000 err code")
	err = GetError(err.GetCode(), err.GetCodeMsg(), ", xyz!!!")
	t.Logf("5: %v", err)

	noFormatStr := fmt.Sprintf("is ok test")
	t.Logf("%s", noFormatStr)
}
