package error_collect

import (
	ps "cuav-cloud-go-service/infra/protocals"
	"fmt"
)

type LogicError struct {
	ErrCode int32  `json:"err_code"`
	ErrMsg  string `json:"err_msg"`
	Args    []any
}

func (e *LogicError) Error() string {
	if e == nil {
		return "un_init error obj"
	}
	return fmt.Sprintf("err_code: %d, err_msg: %v", e.ErrCode, e.ErrMsg)
}
func (e *LogicError) GetCode() int32 {
	if e == nil {
		return int32(-1)
	}
	return e.ErrCode
}
func (e *LogicError) GetCodeMsg() string {
	if e == nil {
		return "un defined"
	}
	return e.ErrMsg
}
func (e *LogicError) GetCodeArgs() []any {
	if e == nil {
		return nil
	}
	return e.Args
}

func buildErr(code int32, msg string) {
	collectErrors.ErrorCollect[code] = &LogicError{
		ErrCode: code,
		ErrMsg:  msg,
	}
}

var collectErrors = LogicErrors{
	ErrorCollect: make(map[int32]ps.CliError),
}

type LogicErrors struct {
	ErrorCollect map[int32]ps.CliError
}

// GetError 根据错误和可能的错误参数返回一个错误对象
func GetError(code int32, errMsg ...any) ps.CliError {
	formatStr := ""
	for _ = range errMsg {
		formatStr += "%v"
	}
	errItem, ok := collectErrors.ErrorCollect[code]
	if ok {
		if len(errMsg) <= 0 {
			return errItem
		}
		return &LogicError{
			ErrCode: code,
			ErrMsg:  fmt.Sprintf(formatStr, errMsg...),
		}
	}
	if len(errMsg) <= 0 {
		return &LogicError{
			ErrCode: code,
			ErrMsg:  fmt.Sprintf("code err: %v", code),
		}
	}
	composeErrMsg := fmt.Sprintf(formatStr, errMsg...)
	return &LogicError{
		ErrCode: code,
		ErrMsg:  composeErrMsg,
	}
}

// GetError 根据错误和可能的错误参数返回一个错误对象
func GetErrorWithArgs(code int32, msgArgs ...any) ps.CliError {
	return &LogicError{
		ErrCode: code,
		Args:    msgArgs,
	}
}
