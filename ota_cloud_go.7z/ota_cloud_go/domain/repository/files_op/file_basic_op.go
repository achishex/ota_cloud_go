package files_op

import (
	"fmt"
	"os"
)

func DeleteFile(fileName string) error {
	if _, err := os.Stat(fileName); err == nil {
		err := os.Remove(fileName)
		if err != nil {
			return fmt.Errorf("delete file: %v, err: %v", fileName, err)
		} else {
			return nil
		}
	} else {
		return fmt.Errorf("get file status fail, err: %v, file: %v", err, fileName)
	}
}

func WriteFile(fileName string, data []byte) error {
	outputFile, err := os.Create(fileName)
	if err != nil {
		return fmt.Errorf("Error creating  file: %v, fileName: %v", err, fileName)
	}
	defer outputFile.Close()

	_, err = outputFile.Write(data)
	if err != nil {
		return fmt.Errorf("Error writing  file: %v, fileName: %v", err, fileName)
	}
	return nil
}
