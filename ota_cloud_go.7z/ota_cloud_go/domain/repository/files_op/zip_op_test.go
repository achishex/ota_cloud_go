package files_op

import "testing"

func TestAddNewFilesToZip(t *testing.T) {
	//srcZipFileName := "./demo12.zip"
	//toAddFileName1 := "./y1.log"
	//toAddFileName2 := "./y1.log"
	//dstZipFileName := "./demo34.zip"

	if err := AddNewFilesToZip("TO_30_2_1312070561061797907.zip", []string{"file_basic_op.go"}, "xyz.zip"); err != nil {
		t.Logf("add files to zip fail, err: %v", err)
	} else {
		t.Logf("add files to zip succ.")
	}
}
