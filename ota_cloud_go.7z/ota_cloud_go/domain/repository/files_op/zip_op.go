package files_op

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"time"
)

// addFileToZip 是一个辅助函数，用于将文件添加到 ZIP 存档中
func addFileToZip(zipWriter *zip.Writer, filename string) error {
	file, err := os.Open(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	// 获取文件信息
	fileInfo, err := file.Stat()
	if err != nil {
		return err
	}

	// 创建文件头，并设置修改时间
	header, err := zip.FileInfoHeader(fileInfo)
	if err != nil {
		return err
	}
	header.Modified = time.Now().UTC() // 设置修改时间

	// 创建文件写入器
	w, err := zipWriter.CreateHeader(header)
	if err != nil {
		return fmt.Errorf("zipwrite create fail, %v", err)
	}

	_, err = io.Copy(w, file)
	if err != nil {
		return fmt.Errorf("io copy file to zip fail, %v", err)
	}
	return err
}

// ZipFiles 将多个文件压缩成一个zip file, zipFile 是压缩后的文件名（绝对路径），toZipFiles 为要zip的文件名列表(绝对路径)
func ZipFiles(zipFile string, toZipFiles ...string) error {
	if zipFile == "" || len(toZipFiles) <= 0 {
		return fmt.Errorf("input param is invalid")
	}

	outFile, err := os.Create(zipFile)
	if err != nil {
		return fmt.Errorf("open zip file fail, err: %v", err)
	}
	defer outFile.Close()

	zipWriter := zip.NewWriter(outFile)
	defer zipWriter.Close()

	for _, file := range toZipFiles {
		if err := addFileToZip(zipWriter, file); err != nil {
			return fmt.Errorf("Failed to add file %s to ZIP: %s", file, err)
		}
	}
	return nil
}

// FileSize 获取文件大小
func FileSize(file *os.File) int64 {
	fi, err := file.Stat()
	if err != nil {
		return 0
	}
	return fi.Size()
}

// AddNewFilesToZip 在现有的 zip文件中添加新文件并更新原来的zip文件名
func AddNewFilesToZip(srcZipName string, toAddFileNames []string, dstZipFileName string) error {
	srcZipFileHandle, err := os.Open(srcZipName)
	if err != nil {
		return fmt.Errorf("open file fail, fileName: %v", srcZipName)
	}
	defer srcZipFileHandle.Close()

	// 读取现有的 ZIP 文件内容
	sourceZipReader, err := zip.NewReader(srcZipFileHandle, FileSize(srcZipFileHandle))
	if err != nil {
		return fmt.Errorf("read zip files fail, err: %v", err)
	}

	// 创建一个新的 ZIP 文件
	dstFile, err := os.Create(dstZipFileName)
	if err != nil {
		return fmt.Errorf("create dst zip file fail, fileName: %v", dstZipFileName)
	}
	defer dstFile.Close()

	// 创建 ZIP 写入器
	zipWriter := zip.NewWriter(dstFile)
	defer zipWriter.Close()

	for _, file := range sourceZipReader.File {
		if err := copyZipEntry(zipWriter, file); err != nil {
			return err
		}
	}

	// 添加新文件到新的 ZIP 文件中
	for _, file := range toAddFileNames {
		if err := addFileToZip(zipWriter, file); err != nil {
			return err
		}
	}
	return nil
}

// copyZipEntry 复制现有 ZIP 文件中的条目
func copyZipEntry(zipWriter *zip.Writer, file *zip.File) error {
	// 打开原始 ZIP 条目
	readCloser, err := file.Open()
	if err != nil {
		return err
	}
	defer readCloser.Close()

	file.FileHeader.Modified = time.Now().UTC()
	// 创建新的条目
	writer, err := zipWriter.CreateHeader(&file.FileHeader)
	if err != nil {
		return err
	}

	// 将数据从原始条目复制到新的条目
	_, err = io.Copy(writer, readCloser)
	return err
}
