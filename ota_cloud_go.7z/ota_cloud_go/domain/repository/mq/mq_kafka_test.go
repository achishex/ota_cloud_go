package mq

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/repository/mock"
	"encoding/json"
	"fmt"
	"github.com/Shopify/sarama"
	"testing"
	"time"
)

type ToPubDataType struct {
	A int
	B float32
	C string
}

var RecvData []*ToPubDataType

func TestPubAndSubAsync(t *testing.T) {
	mock.LoggerMock()

	pubNode := NewKafkaPublisher([]string{"10.240.34.35:9092"},
		WithProducerReturn(true),
		WithProducerPartitions(sarama.NewHashPartitioner),
		WithProducerRequireAcks(int(sarama.WaitForAll)))
	if pubNode == nil {
		t.Logf("new pub node fail, is nil")
		return
	}
	defer pubNode.Close()

	topic := "topic_c2_event_notice" //"dev_self_test_alarm_report"
	subNode, e := NewKafkaConsumer([]string{"10.240.34.35:9092"},
		"cuav-cloud-service", ///*"cuav-cloud-go-alarm-async"*"/
		WithConsumerReturnError(true))
	if e != nil || subNode == nil {
		t.Logf("new sub node fail, e: %v", e)
	} else {
		t.Logf("new sub node succ")
	}
	ctx, cancelFunc := context.WithTimeout(context.Background(), 5*time.Second)
	go func() {
		var msgHandle MessageHandler = &DemoConsumerHandler{}
		e := subNode.Consume(ctx, topic, msgHandle)
		t.Logf("conumer self stop: %v, e: %v", time.Now(), e)
	}()

	testNums := 10
	for i := 0; i < 10; i++ {
		toData := &ToPubDataType{
			A: 100 + i,
			B: float32(9000 + i),
			C: fmt.Sprintf("str:%v", i),
		}

		e := pubNode.Publish(context.Background(), topic, "test_partition", toData)
		if e != nil {
			t.Logf("pub data fail, e: %v, i: %v", e, i)
		} else {
			t.Logf("pub data succ, i: %v", i)
		}
	}

	time.Sleep(5 * time.Second)
	t.Logf("wait to done. %v", time.Now())
	defer cancelFunc()
	t.Logf("expect nums: %v, receive data len: %v", testNums, len(RecvData))
	for _, item := range RecvData {
		if item == nil {
			continue
		}
		t.Logf("item: %+v", item)
	}
}

type DemoConsumerHandler struct{}

func (a *DemoConsumerHandler) Handle(ctx context.Context, message interface{}) error {
	logger.Errorf("not called.")
	return nil
}

func (a *DemoConsumerHandler) HandleBatch(ctx context.Context, message []*sarama.ConsumerMessage) error {
	for _, item := range message {
		if item == nil {
			logger.Infof("is nil ")
			continue
		}
		newItem := &ToPubDataType{}
		err := json.Unmarshal(item.Value, newItem)
		if err != nil {
			logger.Errorf("unmarshal alarm record fail, origin value:%v", item.Value)
			continue
		}
		logger.Infof("parse data: %+v", newItem)
		RecvData = append(RecvData, newItem)
	}
	return nil
}
