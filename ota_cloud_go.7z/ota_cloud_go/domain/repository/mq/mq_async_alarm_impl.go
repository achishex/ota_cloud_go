package mq

func init() {}
