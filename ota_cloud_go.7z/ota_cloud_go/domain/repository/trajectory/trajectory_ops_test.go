package trajectory

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"encoding/xml"
	"github.com/twpayne/go-kml/v3"
	"strings"
	"testing"
	"time"
)

func TestWriteTrajectoryToGpxFile(t *testing.T) {

}

func TestWriteTrajectoryToKmlFile(t *testing.T) {
	mock.LoggerMock()

	trackId := "track_id_2"
	fileName := "create_file.kml"
	tm := time.Now().UTC()
	trackInfo := []*KmlNodeInfo{
		&KmlNodeInfo{
			DroneLatitude:  11.11,
			DroneLongitude: 111.22,
			DroneHeight:    1111.33,
			CreateTime:     &tm,
		},
		&KmlNodeInfo{
			DroneLatitude:  22.11,
			DroneLongitude: 222.22,
			DroneHeight:    2222.33,
			CreateTime:     &tm,
		},
		&KmlNodeInfo{
			DroneLatitude:  33.11,
			DroneLongitude: 333.22,
			DroneHeight:    333.33,
			CreateTime:     &tm,
		},
	}
	data := WriteTrajectoryToKmlFile(trackId, fileName, trackInfo)
	t.Logf("data: \n %s\n", string(data))
}

func TestParseKmlFile(t *testing.T) {
	var fileData string
	fileData = `
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/3.0">
  <Document>
    <Placemark>
      <name>CDATA example</name>
      <description>&lt;h1&gt;CDATA Tags are useful!&lt;/h1&gt; &lt;p&gt;&lt;font color=&#34;red&#34;&gt;Text is &lt;i&gt;more readable&lt;/i&gt; and &lt;b&gt;easier to write&lt;/b&gt; when you can avoid using entity references.&lt;/font&gt;&lt;/p&gt;</description>
      <Point>
        <coordinates>102.595626,14.996729</coordinates>
      </Point>
    </Placemark>
  </Document>
</kml>`

	r := strings.NewReader(fileData)
	var existingKML = kml.KML(nil)
	if err := xml.NewDecoder(r).Decode(existingKML); err != nil {
		t.Logf("decode fail, err: %v", err)
		return
	}
	t.Logf("elements: %v", existingKML)

}
