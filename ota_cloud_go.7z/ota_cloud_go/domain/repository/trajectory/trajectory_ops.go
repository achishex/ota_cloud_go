package trajectory

import (
	"bytes"
	"encoding/xml"
	"errors"
	"os"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/tkrajina/gpxgo/gpx"
	"github.com/twpayne/go-kml/v3"
)

type GpxNodeInfo struct {
	DroneLatitude  float64
	DroneLongitude float64
	DroneHeight    float64
	CreateTime     *time.Time
}

type KmlNodeInfo struct {
	DroneLatitude  float64
	DroneLongitude float64
	DroneHeight    float64
	CreateTime     *time.Time
}

func WriteTrajectoryToGpxFile(trackId string, fileName string, items []*GpxNodeInfo) []byte {
	if fileName == "" || len(items) <= 0 || trackId == "" {
		return nil
	}

	if len(items) <= 0 {
		logger.Infof("uav track info list is empty")
		return nil
	}

	var needCreatNewFile bool = false
	gpxData, err := gpx.ParseFile(fileName)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			logger.Errorf("parse gpx file fail, err: %v, fileName: %v", err, fileName)
			return nil
		}
		needCreatNewFile = true

		gpxData = new(gpx.GPX)
		gpxData.Creator = "skyfend.com"
		gpxData.Version = "1.1"
	}

	if gpxData == nil {
		logger.Errorf("parse gpx handle is nil, file name: %v", fileName)
		return nil
	}

	newTrack := gpx.GPXTrack{}
	newTrack.Name = trackId

	var points []gpx.GPXPoint
	var segments []gpx.GPXTrackSegment

	for i := 0; i < len(items); i++ {
		if items[i] == nil {
			continue
		}

		var gpxPoint gpx.GPXPoint

		gpxPoint.Point = gpxPoint.Add(items[i].DroneLatitude, items[i].DroneLongitude, items[i].DroneHeight)
		gpxPoint.Elevation.SetValue(items[i].DroneHeight)

		if items[i].CreateTime != nil {
			gpxPoint.Timestamp = *(items[i].CreateTime)
		}

		points = append(points, gpxPoint)
	}

	segments = append(segments, gpx.GPXTrackSegment{
		Points: points,
	})

	if needCreatNewFile {
		newTrack.Segments = segments
	} else {
		newTrack.Segments = append(newTrack.Segments, segments...)
	}

	//将新轨迹添加到 已有的 gpx 结构中
	gpxData.Tracks = append(gpxData.Tracks, newTrack)
	xmlOutput, err := gpxData.ToXml(gpx.ToXmlParams{Indent: true})
	if err != nil {
		logger.Errorf("to xml output fail, err: %v", err)
		return nil
	}

	return xmlOutput
}

func WriteTrajectoryToKmlFile(trackId string, fileName string, items []*KmlNodeInfo) []byte {
	if fileName == "" || len(items) <= 0 || trackId == "" {
		return nil
	}

	if len(items) <= 0 {
		logger.Infof("uav track info list is empty")
		return nil
	}

	var needCreatNewFile bool = false
	kmlFile, err := os.Open(fileName)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			logger.Errorf("open file: %v fail: %v", fileName, err)
			return nil
		}
		needCreatNewFile = true

		kmlFile, err = os.Create(fileName)
		if err != nil {
			logger.Errorf("create file: %v, fail: %v", err)
			return nil
		}
	}

	if kmlFile == nil {
		logger.Errorf("open file obj is nil, file: %v", fileName)
		return nil
	}
	defer kmlFile.Close()

	var buffer bytes.Buffer
	if needCreatNewFile {

		var trackList []kml.Element

		for i := 0; i < len(items); i++ {
			if items[i] == nil {
				continue
			}
			if items[i].CreateTime == nil {
				continue
			}

			var tmEleList []kml.Element //WhenElement
			var lonLatAlt []kml.Element //GxCoordElement

			tmEleList = append(tmEleList, kml.When(*(items[i].CreateTime)))
			lonLatAlt = append(lonLatAlt, kml.GxCoord(kml.Coordinate{
				Lon: items[i].DroneLongitude, // Longitude in degrees.
				Lat: items[i].DroneLatitude,  // Latitude in degrees.
				Alt: items[i].DroneHeight,    // Altitude in meters.
			}))

			if len(tmEleList) > 0 {
				trackList = append(trackList, tmEleList...)
			}
			if len(lonLatAlt) > 0 {
				trackList = append(trackList, lonLatAlt...)
			}
		}

		k := kml.KML(
			kml.Document(
				kml.Name(trackId),
				kml.Placemark(
					kml.GxTrack(trackList...),
				),
			),
		)
		logger.Infof("kml: %+v", k)

		encoder := xml.NewEncoder(&buffer)
		encoder.Indent("", "  ")
		if err := encoder.Encode(k); err != nil {
			logger.Errorf("write kml data to file fail, err: %v", err)
			return nil
		}
		return buffer.Bytes()
	}

	/////////////////////////////////////////////
	var existingKML kml.KMLElement
	if err := xml.NewDecoder(kmlFile).Decode(&existingKML); err != nil {
		logger.Errorf("error decoding XML: %v", err)
		return nil
	}

	logger.Infof("exist kml: %v", existingKML)

	var coordinates []kml.Element //kml.GxCoordElement
	var tmList []kml.Element      //*kml.WhenElement

	for i := 0; i < len(items); i++ {
		if items[i] == nil {
			continue
		}
		if items[i].CreateTime == nil {
			continue
		}

		coordinates = append(coordinates, kml.GxCoord(kml.Coordinate{
			Lon: items[i].DroneLongitude, // Longitude in degrees.
			Lat: items[i].DroneLatitude,  // Latitude in degrees.
			Alt: items[i].DroneHeight,    // Altitude in meters.
		}))

		tmList = append(tmList, kml.When(*(items[i].CreateTime)))
	}

	var trackList []kml.Element
	if len(tmList) > 0 {
		trackList = append(trackList, tmList...)
	}

	if len(coordinates) > 0 {
		trackList = append(trackList, coordinates...)
	}

	track := kml.GxTrack(trackList...)
	pm := kml.Placemark(track)

	//
	documentEle, ok := existingKML.Child.(*kml.DocumentElement)
	if !ok {
		logger.Errorf("not document element items")
		return nil
	}
	if documentEle == nil {
		logger.Errorf("document element is nil")
		return nil
	}

	for i := 0; i < len(documentEle.Children); i++ {
		placeMarkEle, ok := documentEle.Children[i].(*kml.PlacemarkElement)
		if !ok {
			continue
		}
		if placeMarkEle == nil {
			continue
		}
		placeMarkEle.Children = append(placeMarkEle.Children, pm)
	}

	encoder := xml.NewEncoder(&buffer)
	encoder.Indent("", "  ")
	if err := encoder.Encode(existingKML); err != nil {
		logger.Errorf("write kml data to file fail, err: %v", err)
		return nil
	}
	return buffer.Bytes()
}
