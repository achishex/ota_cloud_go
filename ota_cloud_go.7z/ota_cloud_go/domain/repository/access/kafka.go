package access

import (
	"cuav-cloud-go-service/config"
	"encoding/json"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/Shopify/sarama"
)

func SendKafkaMsg(topic string, data any) {
	con := sarama.NewConfig()
	con.Producer.RequiredAcks = sarama.WaitForAll
	con.Producer.Partitioner = sarama.NewRandomPartitioner
	con.Producer.Return.Successes = true
	// 假设 Kafka 集群地址为 "localhost:9092"
	logger.Info("Kafka ip addr:", config.GetConfig().Kafka.BootStrapServers)
	bootstrapServers := strings.Split(config.GetConfig().Kafka.BootStrapServers, ",")
	producer, err := sarama.NewSyncProducer(bootstrapServers, con)
	if err != nil {
		logger.Errorf("Failed to create producer: %s", err)
	}
	defer producer.Close()
	dataJson, err := json.Marshal(data)
	if err != nil {
		logger.Errorf("Failed to serialize NoticeItem: %s\n", err)
		return
	}

	// 创建一个消息，指定主题为 "my-topic"
	msg := &sarama.ProducerMessage{
		Topic: topic, // 指定主题
		Value: sarama.StringEncoder(dataJson),
	}

	// 发送消息
	partition, offset, err := producer.SendMessage(msg)
	if err != nil {
		logger.Errorf("Failed to send message: %s", err)
	}

	logger.Info("Partition: %d, Offset: %d", partition, offset)
}

type NoticeItem struct {
	Key  string `json:"key"`
	Data TbCode `json:"data"`
}

type TbCode struct {
	TbCode string `json:"tbCode"`
}
