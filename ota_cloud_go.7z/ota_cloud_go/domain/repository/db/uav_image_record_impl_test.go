package db

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"encoding/json"
	"testing"
)

func TestUavImage(t *testing.T) {
	InitTestMsg()
	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)

	strMsg := `
	{"c2sn":"fakeC2Sn","sn":"fakeCn","msgid":"26e33115-144e-432d-8be2-06cd8a5bff80","eventid":"fakeEventID","s3msg":[{"s3_path":"eventImage/fakeC2Sn/fakeCn/fakeEventID_0.jpg","index":0},{"s3_path":"eventImage/fakeC2Sn/fakeCn/fakeEventID_1.jpg","index":1},{"s3_path":"eventImage/fakeC2Sn/fakeCn/fakeEventID_2.jpg","index":2}]}
	`
	var msg bean.EventCaptureT
	err := json.Unmarshal([]byte(strMsg), &msg)
	if err != nil {
		t.Error("err = ", err)
	}
	t.Logf("msg = %+v", msg)
	for k, v := range msg.S3Msg {
		t.Log("k=", k, " v = ", v)
	}
	t.Log("msgID = ", msg.MsgID)
	msgByte, err := json.Marshal(&msg.S3Msg)
	if err != nil {
		t.Error("err = ", err)
	}

	var info []*bean.EventImageData
	infoItem := bean.EventImageData{
		ID:      12,
		C2Sn:    msg.C2sn,
		Sn:      msg.Sn,
		MsgID:   msg.MsgID,
		EventID: msg.EventID,
		S3Msg:   msgByte,
	}
	info = append(info, &infoItem)

	imageDbHandler := NewEventImageRecordDBHandler(db)
	imageDbHandler.Insert(info)
	val, err := imageDbHandler.QueryItems(msg.EventID)
	if err != nil {
		t.Error("err = ", err)
	}
	t.Logf("val = %+v", val[0])
	dbS3Msg := val[0].S3Msg
	var dbs3RawMsg []bean.EventS3UrlT
	err = json.Unmarshal(dbS3Msg, &dbs3RawMsg)
	if err != nil {
		t.Error("err = ", err)
	}
	t.Logf("dbs3RawMsg = %+v", dbs3RawMsg)
	for _, v := range dbs3RawMsg {
		t.Log("path = ", v.S3Path)
	}
}
