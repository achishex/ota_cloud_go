package db

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/apimap"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/mock"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"testing"
	"time"
)

func InitTestMsg() {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
}

func TestFendUavRecordDbOP(t *testing.T) {
	InitTestMsg()
	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)
	// 插入：
	dbFendArea := NewUavRecordDBHandler(db)
	var ids []int64
	// 准备 devRelations 数据
	type Isn struct {
		C2sn        string `json:"c2sn"`
		DetectDevSN string `json:"detectDevSN"`
	}
	asn := Isn{
		C2sn:        "23232b-f3ff3f3",
		DetectDevSN: "111111",
	}
	bsn := Isn{
		C2sn:        "23232b-bbbb",
		DetectDevSN: "123456",
	}
	devRelations := make([]Isn, 0)
	devRelations = append(devRelations, asn)
	devRelations = append(devRelations, bsn)
	// devRelations := []map[string]string{
	// 	{"c2sn": "23232b-f3ff3f3", "sn": "abcdefg"},
	// 	{"c2sn": "23232b-bbbb", "sn": "aaaaa"},
	// }
	startTime := time.Now()
	// time.Sleep(2 * time.Millisecond)
	// startTime1 := time.Now().UTC().Format(time.RFC3339Nano)
	// time.Sleep(time.Millisecond)
	// startTiime2 := time.Now().UTC().Format(time.RFC3339Nano)
	// time.Sleep(time.Millisecond)
	// endTime1 := time.Now().UTC().Format(time.RFC3339Nano)
	// time.Sleep(time.Millisecond)
	// endTime2 := tme.Now().UTC().Format(time.RFC3339Nano)
	// time.Sleep(3 * time.Millisecond)
	endTime := time.Now()
	videotime := []map[string]string{
		{"startTime": time.Now().Add(3 * time.Second).UTC().Format(time.RFC3339Nano), "endTime": time.Now().Add(2 * time.Minute).UTC().Format(time.RFC3339Nano)},
		{"startTime": time.Now().Add(2 * time.Second).UTC().Format(time.RFC3339Nano), "endTime": time.Now().Add(3 * time.Minute).UTC().Format(time.RFC3339Nano)},
	}
	devRelationsJSON, err := json.Marshal(devRelations)
	if err != nil {
		t.Log(err)
	}

	timeJSON, err := json.Marshal(videotime)
	if err != nil {
		t.Log(err)
	}

	tbCode := "000001"
	c2sn := "32032323-323238-3232323"
	var items []*bean.FencedUavRecord
	for i := 1; i < 10; i++ {

		startlon := 113.9980
		startla := 22.5970

		endlon := 113.9981
		endla := 22.5969

		startsite := apimap.GetSite(startlon, startla)
		endSite := apimap.GetSite(endlon, endla)
		item := &bean.FencedUavRecord{
			ID:             int64(i),
			SerialNum:      "ABC123",
			ObjID:          "12345",
			DroneName:      "Drone 1",
			StartTime:      startTime.UTC(),
			EndTime:        endTime.Add(7 * time.Minute).UTC(),
			Duration:       3600,
			AreaID:         1,
			PilotLongitude: 123.456,
			PilotLatitude:  78.910,
			HomeLongitude:  12.345,
			HomeLatitude:   67.890,
			StartLongitude: startlon,
			StartLatitude:  startla,
			SN:             "XYZ789",
			TbCode:         tbCode,
			Status:         0,
			C2SN:           c2sn,
			Type:           2,
			Longitude:      123.456789,
			Latitude:       78.9101112,
			AreaName:       "hello",
			Freq:           123.456,
			Devrelations:   devRelationsJSON,
			Eventid:        "event123",
			Videotime:      timeJSON,
			StartSite:      startsite,
			EndSite:        endSite,
			// EndTime:        time.Now().Add(6 * time.Minute).Format(time.RFC3339Nano),
		}

		ids = append(ids, item.ID)
		items = append(items, item)
		// e := dbFendArea.AddOneItem(item)
		// t.Logf("add one item, e: %v", e)
	}
	//create data in db
	t.Logf("ids = %+v", ids)
	dbFendArea.Insert(items)

	// //qury data by id
	// queryItem, e := dbFendArea.QueryItems(ids)
	// t.Logf("query items, e: %v, items: %+v", e, queryItem)

	// //update data
	// for k, it := range queryItem {
	// 	t.Logf("query item: %d, %+v", k, it)
	// 	dbFendArea.UpdateItems("id", []any{it.ID}, "status", it.ID+1)
	// }

	//qurey data by condiction
	strStartTime := startTime.UTC().Format(time.DateTime)
	endTime = time.Now().Add(1 * time.Second)
	strEndTime := endTime.UTC().Format(time.DateTime)
	t.Log("strStartTime = ", strStartTime)
	t.Log("strEndTime = ", strEndTime)
	conData, num, err := dbFendArea.GetFencedUAVRecords(tbCode, strStartTime, strEndTime, c2sn, 1, 3)
	if err != nil {
		t.Errorf("err = %v", err)
	} else {
		t.Logf("conData = %+v", conData)
		t.Log("num = ", num)
		for _, v := range conData {
			t.Logf("conData = %+v", v)
			// t.Log("start = ", v.StartTime.Format(time.DateTime))
			// t.Log("end = ", v.EndTime.Format(time.RFC3339))
			t.Log("end = ", v.EndTime.Format(time.RFC3339Nano))

			var Snindex []*pb.Snindex
			err := json.Unmarshal(v.Devrelations, &Snindex)
			if err != nil {
				t.Error("err = ", err)
			} else {
				t.Log("snindex = ", Snindex)
			}

		}
	}

	// delete data
	// for _, id := range ids {
	// 	e := dbFendArea.DelItems("id", []any{id})
	// 	t.Logf("delete item with ID %d, e: %+v", id, e)
	// }
	// t.Logf("delete items, e: %+v", e)
}

// func TestFendAlterTable(t *testing.T) {
// 	InitTestMsg()
// 	db, _ := config.InitDB()
// 	defer config.CloseDB(db)
// 	t.Logf("create db: %v", db)

// 	dbFendArea := NewUavRecordDBHandler(db)
// 	err := dbFendArea.AlterTable()

// 	if err != nil {
// 		t.Errorf("err = %v", err)
// 	} else {
// 		t.Log("alter table ok ")
// 	}
// }
