package db

import (
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/common/constant"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"
)

type UavRecordDBImpl struct {
	tabName string
	dbOps   *gorm.DB
	isDebug bool
}

// NewUavRecordDBImpl 创建告警记录写表
func NewUavRecordDBImpl(db *gorm.DB) UavRecordDBOps {
	return &UavRecordDBImpl{
		dbOps:   db,
		isDebug: true,
		tabName: bean.FencedUavRecord{}.TableName(),
	}
}

func NewUavRecordDBHandler(db *gorm.DB) *UavRecordDBImpl {

	handler := UavRecordDBImpl{
		dbOps:   db,
		isDebug: true,
		tabName: bean.FencedUavRecord{}.TableName(),
	}
	// handler.AlterTable()
	return &handler
}

func (m *UavRecordDBImpl) checkInParam() error {
	if m == nil || m.dbOps == nil {
		return fmt.Errorf("obj is nil or db handle is nil")
	}
	return nil
}

// Insert 增加记录
func (a *UavRecordDBImpl) Insert(items []*bean.FencedUavRecord) (int64, error) {
	if e := a.checkInParam(); e != nil {
		return 0, e
	}
	if len(items) == 0 {
		return 0, nil
	}

	insertRet := a.dbOps.Table(a.tabName).Create(items)
	if insertRet.Error != nil {
		logger.Errorf("insert items to tab: %s,  err: %v", a.tabName, insertRet.Error)
		return 0, insertRet.Error
	}

	return insertRet.RowsAffected, nil
}
func (a *UavRecordDBImpl) Updates(whereCond string, whereValue []any, fieldNewValue any) (int64, error) {
	if a == nil {
		return 0, errors.New("is empty for object")
	}
	if len(whereCond) == 0 || len(whereValue) == 0 {
		return 0, errors.New("where cond or where value is empty")
	}

	var execuateDb *gorm.DB = nil
	execuateDb = a.dbOps.Table(a.tabName).Where(whereCond, whereValue...).Updates(fieldNewValue)
	if execuateDb == nil || execuateDb.Error != nil {
		return 0, fmt.Errorf("update ,fail, err: %v", execuateDb.Error)
	}
	return execuateDb.RowsAffected, nil
}
func (a *UavRecordDBImpl) UpdateItems(whereCond string, whereValue []any, fieldName string, fieldNewValue any) (int64, error) {
	if a == nil {
		return 0, errors.New("is empty for object")
	}
	if len(whereCond) == 0 || len(whereValue) == 0 {
		return 0, errors.New("where cond or where value is empty")
	}

	if len(fieldName) == 0 {
		return 0, errors.New("update field name is empty")
	}
	var execuateDb *gorm.DB = nil
	execuateDb = a.dbOps.Table(a.tabName).Where(whereCond, whereValue...).Update(fieldName, fieldNewValue)
	if execuateDb == nil || execuateDb.Error != nil {
		return 0, fmt.Errorf("update on feildName: %v, fail, err: %v", fieldName, execuateDb.Error)
	}
	return execuateDb.RowsAffected, nil
}

// DelItems 根据条件删除记录（物理删除）
func (a *UavRecordDBImpl) DelItems(whereCond string, whereVal []any) error {
	if a == nil || a.dbOps == nil {
		return fmt.Errorf("input param is nil")
	}
	if len(whereVal) == 0 {
		return fmt.Errorf("where cond is empty")
	}
	if len(whereVal) == 0 {
		return fmt.Errorf("where cond value is empty")
	}

	var toDelItem []bean.FencedUavRecord
	delRet := a.dbOps.Table(a.tabName).Where(whereCond, whereVal...).Delete(&toDelItem)
	if delRet.Error != nil {
		return fmt.Errorf("del item fail, e: %w, whereCond: %v, whereVal: %v", delRet.Error, whereCond, whereVal)
	}

	logger.Infof("del item nums: %v", delRet.RowsAffected)
	return nil
}

// DelItemOnID 根据主键删除记录
func (a *UavRecordDBImpl) DelItemOnID(ids []int64) error {
	if a == nil || a.dbOps == nil {
		return fmt.Errorf("input param is nil")
	}

	if len(ids) == 0 {
		return nil
	}
	var (
		delRet     *gorm.DB = nil
		toDelItems []bean.FencedUavRecord
	)
	delRet = a.dbOps.Table(a.tabName).Delete(&toDelItems, ids)

	if delRet == nil || delRet.Error != nil {
		return fmt.Errorf("del item by key id: %v, fail, e: %v", ids, delRet.Error)
	}
	logger.Infof("del item nums: %v\n", delRet.RowsAffected)
	return nil
}

func (a *UavRecordDBImpl) QueryItemOnCond(whereCond string, whereVal []any, orderAsc map[string]bool, offset int, limit int) ([]*bean.FencedUavRecord, error) {
	if err := a.checkInParam(); err != nil {
		return nil, err
	}
	if len(whereVal) == 0 {
		return nil, fmt.Errorf("where cond is empty")
	}
	if len(whereVal) == 0 {
		return nil, fmt.Errorf("where cond value is empty")
	}

	var execuateDb *gorm.DB = nil
	// eg: db.Where("name = ? AND age >= ?", "jinzhu", "22")
	execuateDb = a.dbOps.Table(a.tabName).Where(whereCond, whereVal...)
	for fieldName, direct := range orderAsc {
		if len(fieldName) == 0 {
			continue
		}

		if direct == false { // desc
			execuateDb = execuateDb.Order(fmt.Sprintf("%s desc", fieldName))
		} else {
			execuateDb = execuateDb.Order(fmt.Sprintf("%s asc", fieldName))
		}
	}

	if offset > 0 {
		execuateDb = execuateDb.Offset(offset)
	}
	if limit > 0 {
		execuateDb = execuateDb.Limit(limit)
	}

	var findRet []bean.FencedUavRecord
	e := execuateDb.Find(&findRet).Error
	if e != nil {
		return nil, fmt.Errorf("find fail, e: %v", e)
	}

	var ret []*bean.FencedUavRecord
	for _, v := range findRet {
		vv := v
		ret = append(ret, &vv)
	}
	return ret, nil
}

// AddOneItem 增加记录
func (m *UavRecordDBImpl) AddOneItem(item *bean.FencedUavRecord) error {
	if err := m.checkInParam(); err != nil {
		return err
	}
	if item == nil {
		return fmt.Errorf("input is item is nil")
	}

	e := m.dbOps.Table(m.tabName).Create(item).Error
	if e != nil {
		return fmt.Errorf("insert new item to db fail, e: %v, new item: %v", e, item)
	}
	return nil
}

// QueryItems 根据逐渐查询记录
func (m *UavRecordDBImpl) QueryItems(ids []int64) ([]*bean.FencedUavRecord, error) {
	if err := m.checkInParam(); err != nil {
		return nil, err
	}
	if len(ids) == 0 {
		return nil, nil
	}

	var queryRet []bean.FencedUavRecord
	e := m.dbOps.Table(m.tabName).Find(&queryRet, ids).Error
	if e != nil {
		return nil, fmt.Errorf("query by id: %v, fail, e: %v", ids, e)
	}

	var ret []*bean.FencedUavRecord = nil
	for _, v := range queryRet {
		vv := v
		ret = append(ret, &vv)
	}
	return ret, nil
}
func (m *UavRecordDBImpl) GetFencedUAVRecords(tbCode string, startTime, endTime string, c2SN string, pageIndex int, pageSize int) ([]*bean.FencedUavRecord, int64, error) {
	var records []*bean.FencedUavRecord
	offset := (pageIndex - 1) * pageSize
	var totalRecords int64

	logger.Debug("tbcode = ", tbCode, " startTime = ", startTime, " endTime = ", endTime, "c2Sn = ", c2SN, "pageIndex = ", pageIndex, " pageSize = ", pageSize)
	if len(c2SN) == 0 {
		// 查询总记录数
		queryStr := "tb_code = ? AND start_time >= ? AND end_time <= ? AND risk_level >= ? "
		result := m.dbOps.Model(&bean.FencedUavRecord{}).Where(queryStr, tbCode, startTime, endTime, constant.AlarmLevelLow).
			Count(&totalRecords)
		if result.Error != nil {
			logger.Error("count query fail, startTime = ", startTime, " endTime = ", endTime, "c2Sn = ", c2SN)
			return nil, 0, result.Error
		}

		result = m.dbOps.Where(queryStr, tbCode, startTime, endTime, constant.AlarmLevelLow).
			Order("start_time").Offset(offset).Limit(pageSize).Find(&records)

		if result.Error != nil {
			logger.Error("qurey fail,startTime = ", startTime, " endTime = ", endTime, "c2Sn = ", c2SN, " pageIndex = ", pageIndex, " pageSize = ", pageSize)
			return nil, totalRecords, result.Error
		}
	} else {
		queryStr := "tb_code = ? AND start_time >= ? AND end_time <= ? AND c2_sn = ? AND risk_level >= ?"
		result := m.dbOps.Model(&bean.FencedUavRecord{}).Where(queryStr, tbCode, startTime, endTime, c2SN, constant.AlarmLevelLow).
			Count(&totalRecords)
		if result.Error != nil {
			logger.Error("count query fail, startTime = ", startTime, " endTime = ", endTime, "c2Sn = ", c2SN)
			return nil, 0, result.Error
		}

		result = m.dbOps.Where(queryStr, tbCode, startTime, endTime, c2SN, constant.AlarmLevelLow).
			Order("start_time").Offset(offset).Limit(pageSize).Find(&records)

		if result.Error != nil {
			logger.Error("qurey fail,startTime = ", startTime, " endTime = ", endTime, "c2Sn = ", c2SN, " pageIndex = ", pageIndex, " pageSize = ", pageSize)
			return nil, totalRecords, result.Error
		}
	}

	return records, totalRecords, nil
}
