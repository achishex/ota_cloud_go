package db

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/mock"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"testing"
	"time"
)

func TestAlarmRecordOP(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)

	dbAlarm := NewDBModelTplWrapper[bean.FendAreaAlarm](db).SetTabName(bean.FendAreaAlarm{}.TableName())

	// 批量删除
	nums := 1000
	var ids []int64
	for i := 0; i < nums; i++ {
		ids = append(ids, 111111111+int64(i))
	}
	dbAlarm.DelItemOnID(ids)

	v := []*bean.FendAreaAlarm{}
	for i := 0; i < nums; i++ {
		v = append(v, &bean.FendAreaAlarm{
			ID:          111111111 + int64(i),
			TbCode:      fmt.Sprintf("tb_code_:%v", i),
			DevSn:       fmt.Sprintf("devSn_:%v", i),
			ObjID:       fmt.Sprintf("objID_%v", i),
			RiskLevel:   int32(i % 4),
			ThreatLevel: int32(i % 100),
			CreateTime:  time.Now().UTC(),
			UpdateTime:  time.Now(),
			Status:      int32(i % 2),
		})
	}
	n, e := dbAlarm.Insert(v)
	t.Logf("insert e: %v, ret n: %v, nums: %v", e, n, nums)

	updateWhere := "id in (?,?)"
	updateWhereVal := []any{111112110, 111112109}
	updateFieldName := "status"
	fieldNewValue := 1000

	n, e = dbAlarm.UpdateItems(updateWhere, updateWhereVal, updateFieldName, fieldNewValue)
	t.Logf("update ret nums: %v, e: %v", n, e)

	ids = []int64{}
	for i := 0; i < nums; i++ {
		ids = append(ids, 111111111+int64(i))
	}

	e = dbAlarm.DelItemOnID(ids)
	if e != nil {
		t.Logf("del ids fail, e: %v, ids: %v", e, ids)
	}
	//
	t.Logf("utc: %v, nowTm: %v", time.Now().UTC(), time.Now())
	rQuery := callRawQuery(0, time.Now().UTC().UnixMilli(), "000001", dbAlarm)
	for _, item := range rQuery {
		if item == nil {
			continue
		}
		t.Logf("%+v\n", item)
	}
}

func callRawQuery(beginTm, endTm int64, tbCode string, dbops DbOpsTplInterface[bean.FendAreaAlarm]) []*pb.AlarmCheckRspItem {
	bTm := time.UnixMilli(beginTm)
	eTm := time.UnixMilli(endTm)

	//whereCond := `SELECT   i.id, i.event_id, i.create_time  FROM t_fenced_area_alarm  i JOIN (SELECT event_id , MAX(create_time) AS max_create_time FROM t_fenced_area_alarm  where tb_code = ? and create_time >= ? and create_time < ? and status = ? GROUP BY  event_id  ) m ON i.event_id  = m.event_id AND i.create_time = m.max_create_time ORDER BY i.create_time  desc limit ?`
	whereCond := `SELECT  i.* FROM t_fenced_area_alarm  i JOIN (
    SELECT event_id , MAX(create_time) AS max_create_time FROM
        t_fenced_area_alarm  where tb_code = ? and create_time >= ? and create_time < ? and status = ?
    GROUP BY  event_id  ) m ON i.event_id  = m.event_id AND i.create_time = m.max_create_time ORDER BY
    i.create_time  desc limit ?;`

	whereValue := []any{tbCode, bTm, eTm, 0, 3}
	alarmItems, err := dbops.RawQueryRun(whereCond, whereValue)
	if err != nil {
		logger.Errorf("query alarm record fail, err: %v, tbCode: %v", err, tbCode)
		return nil
	}

	var retData []*pb.AlarmCheckRspItem
	for _, v := range alarmItems {
		if v == nil {
			continue
		}
		retData = append(retData, &pb.AlarmCheckRspItem{
			// 告警id(每次告警不同)
			Id: v.ID,
			// 无人机唯一标识
			Sn:    v.DevSn,
			ObjId: v.ObjID,
			// 风险等级： 1: low, 2: middle, 3: high
			RiskLevel: v.RiskLevel,
			// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
			ThreatLevel: v.ThreatLevel,
			// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
			EventId: v.EventId,
			// 租户id
			TbCode: v.TbCode,
			// 设备名字
			DevName: v.DevName,
			// 告警的时间点（毫秒）
			CreateTime: v.CreateTime.UnixMilli(),
			// 一次 相同eventID的告警持续时间（毫秒）
			DurTime: v.DurTime,
		})
	}
	return retData
}
