package db

import (
	"cuav-cloud-go-service/deploy/bean"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"
)

type UavEventImageDBImpl struct {
	tabName string
	dbOps   *gorm.DB
	isDebug bool
}

func NewEventImageRecordDBHandler(db *gorm.DB) *UavEventImageDBImpl {

	handler := UavEventImageDBImpl{
		dbOps:   db,
		isDebug: true,
		tabName: bean.EventImageData{}.TableName(),
	}
	return &handler
}
func (m *UavEventImageDBImpl) checkInParam() error {
	if m == nil || m.dbOps == nil {
		return fmt.Errorf("obj is nil or db handle is nil")
	}
	return nil
}

// Insert 增加记录
func (a *UavEventImageDBImpl) Insert(items []*bean.EventImageData) (int64, error) {

	for _, item := range items {
		fmt.Println("UavRecordDBImpl item = ", item)
		logger.Debugf("UavRecordDBImpl item = %+v", item)
	}

	if e := a.checkInParam(); e != nil {
		return 0, e
	}
	//
	if len(items) == 0 {
		return 0, nil
	}

	insertRet := a.dbOps.Table(a.tabName).Create(items)
	if insertRet.Error != nil {
		logger.Errorf("insert items to tab: %s,  err: %v", a.tabName, insertRet.Error)
		return 0, insertRet.Error
	}

	logger.Infof("insert item to tab: %s, success insert nums: %v, to insert nums: %v", a.tabName, insertRet.RowsAffected, len(items))
	return insertRet.RowsAffected, nil
}

// QueryItems 根据逐渐查询记录
func (m *UavEventImageDBImpl) QueryItems(eventID string) ([]*bean.EventImageData, error) {
	if err := m.checkInParam(); err != nil {
		return nil, err
	}

	var queryRet []*bean.EventImageData
	e := m.dbOps.Table(m.tabName).Where("event_id = ?", eventID).Find(&queryRet).Error
	if e != nil {
		return nil, fmt.Errorf("query by event_id: %v, fail, e: %v", eventID, e)
	}

	return queryRet, nil
}
