package db

import (
	"gorm.io/gorm"
)

type BaseAccessImpl struct {
	db *gorm.DB
}

func NewBaseAccessImpl(db *gorm.DB) BaseAccess {
	return &BaseAccessImpl{
		db: db,
	}
}

func (b *BaseAccessImpl) DB() *gorm.DB {
	return b.db
}

func (b *BaseAccessImpl) Insert(tx *gorm.DB, entity any) error {
	if tx == nil {
		tx = b.db
	}
	return tx.Create(entity).Error
}

func (b *BaseAccessImpl) InsertBatch(tx *gorm.DB, entitys any, size int) (int64, error) {
	if tx == nil {
		tx = b.db
	}
	res := tx.CreateInBatches(entitys, size)
	return res.RowsAffected, res.Error
}

func (b *BaseAccessImpl) Update(tx *gorm.DB, model any, val any, cond any, args ...any) (int64, error) {
	if tx == nil {
		tx = b.db
	}
	res := tx.Model(model).Where(cond, args...).UpdateColumns(val)
	return res.RowsAffected, res.Error
}

func (b *BaseAccessImpl) Updates(tx *gorm.DB, entitys any) (int64, error) {
	if tx == nil {
		tx = b.db
	}
	res := tx.Updates(entitys)
	return res.RowsAffected, res.Error
}
func (b *BaseAccessImpl) Delete(tx *gorm.DB, model any) error {
	if tx == nil {
		tx = b.db
	}
	return tx.Delete(model).Error
}

func (b *BaseAccessImpl) Find(tx *gorm.DB, vals any, query any, args ...any) error {
	if tx == nil {
		tx = b.db
	}
	return tx.Where(query, args...).Find(vals).Error
}

func (b *BaseAccessImpl) First(tx *gorm.DB, val any, query any, args ...any) error {
	if tx == nil {
		tx = b.db
	}
	return tx.Where(query, args...).First(val).Error
}
