package db

import (
	"cuav-cloud-go-service/deploy/bean"

	"gorm.io/gorm"
)

// AlarmRecordDBOps 告警记录数据db 访问接口
type UavRecordDBOps interface {
	// Insert 插入记录
	Insert(items []*bean.FencedUavRecord) (int64, error)
	// UpdateItems 更新数据库表字段
	UpdateItems(whereCond string, whereValue []any, fieldName string, fieldNewValue any) (int64, error)

	// DelItems 根据条件删除记录（物理删除）
	DelItems(whereCond string, whereVal []any) error

	// // DelItemOnID 根据主键删除记录
	// DelItemOnID(ids []int64) error
	// QueryItems 根据逐渐查询记录
	QueryItems(ids []int64) ([]*bean.FencedUavRecord, error)

	// QueryItemOnCond 查询记录
	QueryItemOnCond(whereCond string, whereVal []any, orderAsc map[string]bool, offset int, limit int) ([]*bean.FencedUavRecord, error)
	Updates(whereCond string, whereValue []any, fieldNewValue any) (int64, error)
	//
	// RawQueryRun(whereCond string, whereVal []any) ([]*bean.FencedUavRecord, error)
}

// 基础db操作层
type BaseAccess interface {
	DB() *gorm.DB
	Insert(tx *gorm.DB, entity any) error
	InsertBatch(tx *gorm.DB, entitys any, size int) (int64, error)
	Update(tx *gorm.DB, model any, val any, cond any, args ...any) (int64, error)
	Delete(tx *gorm.DB, model any) error
	Updates(tx *gorm.DB, model any) (int64, error)
	Find(tx *gorm.DB, vals any, query any, args ...any) error
	First(tx *gorm.DB, val any, query any, args ...any) error
}

// 白名单管理
type UavWhitelistAccess interface {
	BaseAccess
}
