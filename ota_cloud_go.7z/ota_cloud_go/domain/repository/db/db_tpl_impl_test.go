package db

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
	"time"
)

func TestDbTplDemo(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)

	dbAlarm := NewDBModelTplWrapper[bean.FendAreaAlarm](db).SetTabName(bean.FendAreaAlarm{}.TableName())
	//
	toInsertDbList := []*bean.FendAreaAlarm{
		{ID: 101, TbCode: "test_tpl_model_tbcode", CreateTime: time.Now()},
		{ID: 102, TbCode: "test_tpl_model_tbcode", CreateTime: time.Now()},
	}
	ret, e := dbAlarm.Insert(toInsertDbList)
	if e != nil {
		t.Logf("insert failed, e: %v", e)
	} else {
		t.Logf("insert success, affected rows: %v", ret)
	}
	e = dbAlarm.DelItemOnID([]int64{101, 102})
	if e != nil {
		t.Logf("del items fail, e: %v", e)
	} else {
		t.Logf("del items success")
	}

}

func TestGetHightRiskLevel(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)
	dbAlarm := NewDBModelTplWrapper[bean.FendAreaAlarm](db).SetTabName(bean.FendAreaAlarm{}.TableName())

	getdb := dbAlarm.GetDBHandle()

	startTime := time.Date(2024, 8, 20, 0, 0, 0, 0, time.UTC)
	endTime := time.Date(2024, 8, 21, 0, 0, 59, 0, time.UTC)
	var maxRiskLevel int32

	err := getdb.Model(&bean.FendAreaAlarm{}).
		Select("COALESCE(MAX(risk_level), 0)").
		Where("create_time BETWEEN ? AND ?", startTime, endTime).
		Scan(&maxRiskLevel).Error
	if err != nil {
		t.Fatalf("failed to query maximum risk level: %v", err)
	}
	t.Log("maxRiskLevel = ", maxRiskLevel)
}
