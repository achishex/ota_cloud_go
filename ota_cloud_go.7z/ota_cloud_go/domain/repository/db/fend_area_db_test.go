package db

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/mock"
	"fmt"
	"testing"
	"time"
)

func TestFendAreaDbOP(t *testing.T) {
	mock.LoggerMock()
	//
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	db, _ := config.InitDB()
	defer config.CloseDB(db)
	t.Logf("create db: %v", db)
	// 插入：
	dbFendArea := NewDBModelTplWrapper[bean.FencedAreaConfig](db)
	dbFendArea.SetTabName(bean.FencedAreaConfig{}.TableName())

	var ids []int64
	for i := 0; i < 3; i++ {
		item := &bean.FencedAreaConfig{
			ID:                10000 + int64(i),
			TbCode:            fmt.Sprintf("tbcode:%v", i),
			AreaName:          fmt.Sprintf("areamName:%v", i),
			AreaType:          i % 2,
			AreaPerimeter:     111.1111,
			AreaSquare:        222.2222,
			CentroidLongitude: 333.333,
			CentroidLatitude:  44.444,
			Geometry:          "{}",
			CreateTime:        time.Now().UnixMilli(),
			UpdateTime:        time.Now().UnixMilli(),
			DeleteTime:        time.Now().UnixMilli(),
		}

		ids = append(ids, item.ID)
		n, e := dbFendArea.Insert([]*bean.FencedAreaConfig{item})
		if e != nil {
			t.Logf("insert fence area fail, e: %v", e)
		} else {
			t.Logf("add one item, e: %v, ret nums: %v", e, n)
		}

	}
	//
	queryItem, e := dbFendArea.QueryItems(ids)
	t.Logf("query items, e: %v, items: %+v", e, queryItem)
	for _, v := range queryItem {
		t.Logf("query value: %+v", v)
	}
	//
	whereCond := "tb_code=?"
	whereVal := []any{"tbcode:1"}
	qRet, e := dbFendArea.QueryItemOnCond(whereCond, whereVal, nil, 0, 0)
	for _, v := range qRet {
		t.Logf("query items e: %v, qRet: %+v", e, v)
	}

	e = dbFendArea.DelItemOnID(ids)
	t.Logf("delete items, e: %+v", e)
}
