package redis

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"github.com/mitchellh/mapstructure"
	"github.com/redis/go-redis/v9"
	"google.golang.org/protobuf/proto"
	"sync"
	"testing"
	"time"
)

type ExpireMsIDDemo struct {
	ID    int64 `json:"id"`
	ExpMs int64 `json:"exp_ms"`
}

func (c *ExpireMsIDDemo) String() string {
	data, _ := json.Marshal(c)
	return string(data)
}
func (c *ExpireMsIDDemo) FromString(data string) {
	json.Unmarshal([]byte(data), c)
}

func TestRedisClient(t *testing.T) {
	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))
	fieldValuesMap := map[string]any{
		"a1": 1,
		"a2": true,
		"a3": 1.23,
		"a4": 1.11111,
		"a5": "aba123 sdfad111",
	}
	keyMap := "test:1:aaa"
	err := c.HSet(keyMap, fieldValuesMap)
	t.Logf("err: %v", err)

	v, e := c.HGet(keyMap, "a1")
	t.Logf("a1, v: %v, e: %v", v, e)

	v, e = c.HGet(keyMap, "a2")
	t.Logf("a2, v: %v, e: %v", v, e)

	v, e = c.HGet(keyMap, "a3")
	t.Logf("a3, v: %v, e: %v", v, e)

	v, e = c.HGet(keyMap, "a4")
	t.Logf("a4, v: %v, e: %v", v, e)

	v, e = c.HGet(keyMap, "a5")
	t.Logf("a5, v: %v, e: %v", v, e)
	//
	structKey := "test:2:bb"
	type ItemRedis struct {
		B bool    `redis:"b"`
		C int8    `redis:"c"`
		D int16   `redis:"d"`
		E int32   `redis:"e"`
		A int     `redis:"a"`
		F float32 `redis:"f"`
		G int64   `redis:"g"`
		H float64 `redis:"h"`
		K string  `redis:"k"`
	}
	var xy = ItemRedis{
		B: false,
		C: 12,
		D: 123,
		E: 123123,
		A: 111111,
		F: 12.123,
		G: 12312313123,
		H: 123.1231231,
		K: "this is demo",
	}
	e = c.HSetStruct(structKey, xy)
	t.Logf("hset struct, err: %v", e)

	e = c.HSetStruct("struct_redis_ptr", &xy)
	t.Logf("hset struct_redis_ptr, err: %v", e)

	v, e = c.HGet(structKey, "a")
	t.Logf("a, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "b")
	t.Logf("b, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "c")
	t.Logf("c, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "d")
	t.Logf("d, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "e")
	t.Logf("e, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "f")
	t.Logf("f, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "g")
	t.Logf("g, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "h")
	t.Logf("h, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "i")
	t.Logf("i, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "j")
	t.Logf("j, v: %v, e: %v", v, e)

	v, e = c.HGet(structKey, "k")
	t.Logf("k, v: %v, e: %v", v, e)

	v1, e1 := c.HGetAll(structKey)
	t.Logf("hgetall, v: %v, e: %v", v1, e1)
	for k, v := range v1 {
		t.Logf("K...K: %v, v: %v", k, v)
	}

	v1, e1 = c.HGetAll("struct_redis_ptr")
	t.Logf("hgetall ptr, v: %v, e: %v", v1, e1)

	//
	c.HDel(structKey, []string{"a", "b", "c", "d", "e"}...)
	v2, e2 := c.HGetAll(structKey)
	t.Logf("after del, hgetall, v: %v, e: %v", v2, e2)

	v2, e2 = c.HGetAll("not_exist_any_hash")
	t.Logf("empty hash, hgetall, v: %v, e: %v", v2, e2)

	saddKey := "test:sadd:1"
	eAd := c.SAdd(saddKey, "111")
	t.Logf("111, eadd: %v", eAd)

	paramVar := []any{}
	for _, v := range []string{"a", "b", "c"} {
		paramVar = append(paramVar, v)
	}
	eAd = c.SAdd(saddKey, paramVar...)
	t.Logf("eadd: %v", eAd)

	eAd = c.SAdd(saddKey, 222)
	t.Logf("eadd: %v", eAd)

	eAd = c.SAdd(saddKey, true)
	t.Logf("eadd: %v", eAd)

	eAd = c.SAdd(saddKey, false)
	t.Logf("eadd: %v", eAd)

	eAd = c.SAdd(saddKey, 9.123)
	t.Logf("eadd: %v", eAd)
	//
	v11, e11 := c.SMembers(saddKey)
	t.Logf("members: %+v, e: %v", v11, e11)
	//
	e = c.SRem(saddKey, "111")
	t.Logf("rem: %v", e)
	//
	e = c.SRem(saddKey, "123")
	t.Logf("rem: %v", e)
	v11, e11 = c.SMembers(saddKey)
	t.Logf("members: %+v, e: %v", v11, e11)

	existVa, existErr := c.SMembers("not_exist_key")
	t.Logf("not exist val: %v, err: %v", existVa, existErr)

	//
	var xy_delete = ItemRedis{
		B: false,
		C: 12,
		D: 123,
		E: 123123,
		A: 111111,
		F: 12.123,
		G: 12312313123,
		H: 123.1231231,
		K: "this is demo",
	}
	to_del_hash_key := "to_del_key:1"
	e = c.HSetStruct(to_del_hash_key, &xy_delete)
	t.Logf("to delete key add err: %v", e)
	vv, e := c.HGetAll(to_del_hash_key)
	t.Logf("hgetall key -> to_del_key:1, err: %v, ret: %v", e, vv)
	if e == nil {
		vv1, e := TransMapToStruct[ItemRedis](vv)
		if e != nil {
			t.Logf("trans to del value fail, e: %v", e)
		} else {
			t.Logf("to del value: %+v", vv1)
			//
			del_ret := c.DeleteKey(to_del_hash_key)
			t.Logf("to del key ret err: %v\n", del_ret)
			//
			vvn, e := c.HGetAll(to_del_hash_key)
			t.Logf("after del, hgetall key -> to_del_key:1, err: %v, ret: %v", e, vvn)
		}
	}

	// 产生一个唯一key:
	unKey := "unique:1"
	uv, _ := c.GenUniqueKey(unKey, 1*time.Second)
	for i := 0; i < 8; i++ {
		uv1, _ := c.GenUniqueKey(unKey, 1*time.Second)
		time.Sleep(10 * time.Millisecond)
		if uv1 != uv {
			t.Logf("long expire time, not get same value, uv1: %v, uv: %v", uv1, uv)
		} else {
		}
	}

	unKey2 := "unique:2"
	uv2, _ := c.GenUniqueKey(unKey2, 100*time.Millisecond)
	for i := 0; i < 8; i++ {
		uv11, _ := c.GenUniqueKey(unKey2, 100*time.Second)
		time.Sleep(10 * time.Millisecond)
		if uv11 == uv2 {
			t.Logf("short expire time, uv2: %v, uv11: %v", uv2, uv11)
		} else {
		}
	}
	//

	//
	genWithKey := "test_gen_key_3:"
	for i := 0; i < 10; i++ {
		withExpId, err := c.GenUniqueKeyWithGenVal(genWithKey, 30*time.Millisecond,
			func() string {
				id, e := snowflake.GetUniqueID()
				if e != nil {
					return ""
				}

				item := &ExpireMsIDDemo{
					ID:    id,
					ExpMs: time.Now().UnixMilli(),
				}
				return item.String()
			})
		if i >= 5 {
			time.Sleep(70 * time.Millisecond)
		} else {
			time.Sleep(10 * time.Millisecond)
		}

		if err != nil {
			t.Logf("get fail, err: %v, key: %v", err, genWithKey)
		} else {
			item := &ExpireMsIDDemo{}
			item.FromString(withExpId)
			t.Logf("id: %v, expMs: %v", item.ID, item.ExpMs)
		}
	}
}

func TestMapToStruct(t *testing.T) {
	type Person struct {
		Name    string
		Age     int
		Country string
	}

	data := map[string]interface{}{
		"Name":    "Alice",
		"Age":     30,
		"Country": "USA",
	}

	var person Person
	if err := mapstructure.Decode(data, &person); err != nil {
		fmt.Println("Error:", err)
		return
	}

	fmt.Printf("%+v\n", person)

	type ItemRedis struct {
		B bool    `redis:"b"`
		C int8    `redis:"c"`
		D int16   `redis:"d"`
		E int32   `redis:"e"`
		A int     `redis:"a"`
		F float32 `redis:"f"`
		G int64   `redis:"g"`
		H float64 `redis:"h"`
		K string  `redis:"k"`
	}
	var mapItems = map[string]any{
		"b": false,
		"c": 12,
		"d": 123,
		"e": 12345,
		"a": 111,
		"f": 1.123,
		"g": 12323131231,
		"h": 12323131.13123,
		"k": "this demo",
	}

	var itemRedisOne ItemRedis
	if err := mapstructure.Decode(mapItems, &itemRedisOne); err != nil {
		fmt.Println("Error:", err)
		return
	}
	fmt.Printf("item redis: %+v\n", itemRedisOne)

	var mapItemsStr = map[string]string{
		"b": "0",
		"c": "12",
		"d": "123",
		"e": "12345",
		"a": "111",
		"f": "1.123",
		"g": "12323131231",
		"h": "12323131.13123",
		"k": "this demo",
	}
	v, e := TransMapToStruct[ItemRedis](mapItemsStr)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
	} else {
		if v == nil {
			t.Log("parse is nil")
		} else {
			t.Logf("Parse from map to struct: %+v", *v)
		}
	}
}

func TestRedisZSet(t *testing.T) {
	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))
	//
	for i := 0; i < 12; i++ {
		item := &pb.AlarmCheckRspItem{
			Id: int64(i),
		}
		itemStr, _ := proto.Marshal(item)
		e := c.ZADDAtomic("test_zadd_atomic", float64(i), itemStr, 10)
		if e != nil {
			t.Logf("atomic zadd fail, err: %v", e)
		}
	}

	for i := 200; i < 230; i++ {
		item := &pb.AlarmCheckRspItem{
			Id: int64(i),
		}
		itemStr, _ := proto.Marshal(item)
		e := c.ZADDAtomic("test_zadd_atomic", float64(i), itemStr, 10)
		if e != nil {
			t.Logf("atomic zadd fail, err: %v", e)
		}
	}

	members, err := c.ZRange("test_zadd_atomic", 0, 1000)
	if err != nil {
		t.Logf("zrange all members fail, err: %v", err)
	} else {
		for _, v := range members {
			item := &pb.AlarmCheckRspItem{}
			if e := proto.Unmarshal([]byte(v), item); e != nil {
				t.Logf("parse data from redis member fail, err: %v", e)
				continue
			}
			t.Logf("member data: %+v", item)
		}
	}

	for i := 0; i < 10; i++ {
		exist, e := c.CheckKeyExist("test_check_key", 700*time.Millisecond)
		if e != nil {
			t.Logf("check key exist fail, e: %v", e)
		} else {
			t.Logf("check key exist: %v", exist)
		}
		time.Sleep(100 * time.Millisecond)

	}
}

func TestZSetDel(t *testing.T) {
	//ZDelMemberByScore

	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))

	for i := 0; i < 10; i++ {
		dataStr := fmt.Sprintf("value: %v", i)

		e := c.ZADDAtomic("test_del_members", float64(i), dataStr, 1)
		if e != nil {
			t.Logf("atomic zadd fail, err: %v", e)
		}
	}
	members, err := c.ZRange("test_del_members", 0, 1000)
	t.Logf("test_del_members 1）：member: %v, err: %v", members, err)
	c.ZDelMemberByScore("test_del_members", 1, 1)
	members, err = c.ZRange("test_del_members", 0, 1000)
	t.Logf("0-3， test_del_members member: %v, err: %v", members, err)

	c.ZDelMemberByScore("test_del_members", 0, 3)
	members, err = c.ZRange("test_del_members", 0, 1000)
	t.Logf("test_del_members member: %v, err: %v", members, err)
}

func TestSetGet(t *testing.T) {
	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))
	key := "test_1111_set"
	err := c.SetEx(key, "12313", 1000*time.Millisecond)
	t.Logf("err: %+v", err)

	time.Sleep(0 * time.Millisecond)
	v, err := c.Get(key)
	if err == redis.Nil {
		t.Logf("get ret: %v, is nil, err: %v", v, err)
	} else {
		v1, ok := v.(string)
		t.Logf("get ret: %v, v1: %v, err: %v,ok: %v", v, v1, err, ok)
	}

}

func TestLockUnLock(t *testing.T) {
	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))
	c1 := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))

	key := "test_lock_demo:1"
	ttl := 100 * time.Millisecond
	globalId := "test_lock_id_:1"

	wg := sync.WaitGroup{}
	wg.Add(2)
	go func() {
		time.Sleep(10 * time.Millisecond)
		defer wg.Done()
		e := c.Lock(key, ttl, globalId)
		if e != nil {
			t.Logf("2 first) get locker fail, e: %v", e)
		} else {
			t.Logf("lock 2.")
			for i := 0; i < 1; i++ {
				er := c.RefreshTTL(key, globalId, ttl)
				if er != nil {
					t.Logf("refresh fail, er: %v", er)
				} else {
					t.Logf("2 refresh succ, i: %v", i)
				}

			}
		}
	}()

	go func() {
		defer wg.Done()
		e := c1.Lock(key, ttl, globalId)
		if e != nil {
			t.Logf("3 first) get locker fail, e: %v", e)
		} else {
			t.Logf("lock 3.")
			for i := 0; i < 10; i++ {
				er := c1.RefreshTTL(key, globalId, ttl)
				if er != nil {
					t.Logf("refresh fail, er: %v", er)
				} else {
					t.Logf("3 refresh succ, i: %v", i)
				}
				time.Sleep(2 * time.Millisecond)
			}
		}
	}()

	time.Sleep(500 * time.Millisecond)
	c.UnLock(key, globalId)
}

type DeviceInfoPreview struct {
	DeviceId   string `json:"device_id"`
	DeviceType string `json:"device_type"`
}

func (p *DeviceInfoPreview) Unmarshal(data []byte) error {
	if e := json.Unmarshal(data, p); e != nil {
		logger.Errorf("parse device info fail, err: %v", e)
		return e
	}
	return nil
}

func (p *DeviceInfoPreview) Marshal() []byte {
	ret, e := json.Marshal(p)
	if e != nil {
		logger.Errorf("format to json fail, err: %v", e)
		return nil
	}
	return ret
}

func (p *DeviceInfoPreview) MarshalBinary() (data []byte, err error) {
	ret, e := json.Marshal(p)
	if e != nil {
		logger.Errorf("format to json fail, err: %v", e)
		return nil, e
	}
	return ret, nil
}

func (p *DeviceInfoPreview) UnmarshalBinary(data []byte) error {
	if e := json.Unmarshal(data, p); e != nil {
		logger.Errorf("parse device info fail, err: %v", e)
		return e
	}
	return nil
}

func TestSMemberStruct(t *testing.T) {
	mock.LoggerMock()

	devicePreview := &DeviceInfoPreview{
		DeviceType: "a3424",
		DeviceId:   "674563445",
	}

	//deviceInfo := devicePreview.Marshal()
	//if deviceInfo == nil {
	//	logger.Errorf("build device base info fail")
	//	return
	//}
	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))

	tbCodeDevListCacheKey := "a:rel:tbcode:online_device_list:111111"
	if err := c.SAdd(tbCodeDevListCacheKey, devicePreview); err != nil {
		logger.Errorf("add devId and device-tbcode relation to cache fail, %v", err)
	}

	datas, err := c.SMembers(tbCodeDevListCacheKey)
	if err != nil {
		logger.Errorf("smembers fail, err: %v", err)
		return
	}

	for _, data := range datas {
		dstData := &DeviceInfoPreview{}
		err := dstData.UnmarshalBinary([]byte(data))
		if err != nil {
			logger.Errorf("parse fail, err: %v", err)
			continue
		}
		logger.Infof(" %+v", *dstData)
	}
}

type CheckSetExDataType struct {
	X int `json:"x"`
	Y int `json:"y"`
}

func (cs *CheckSetExDataType) MarshalBinary() ([]byte, error) {
	ret, e := json.Marshal(cs)
	if e != nil {
		logger.Errorf("format to json fail, err: %v", e)
		return nil, e
	}
	return ret, nil
}

func (p *CheckSetExDataType) UnmarshalBinary(data []byte) error {
	if e := json.Unmarshal(data, p); e != nil {
		logger.Errorf("parse device info fail, err: %v", e)
		return e
	}
	return nil
}

func TestSetExAndCheck(t *testing.T) {
	mock.LoggerMock()

	c := NewSkyFendRedisClient(WithRedisAddrOpt("10.240.34.36:30356"),
		WithRedisPasswd("ZAQ!2wsx"), WithRedisDB(15))
	var data = &CheckSetExDataType{
		X: 10,
		Y: 123,
	}
	var Wg *routinues.RoutineGroupWrap = routinues.NewRoutineGroupWrap()
	Wg.Run(func() {
		for {
			c.SetEx("check_setex_1", data, 10*time.Second)
			time.Sleep(300 * time.Millisecond)
		}

	})

	Wg.Run(func() {
		for {
			t.Logf("%d", c.GetRedisRow().TTL(context.Background(), "check_setex_1").Val().Milliseconds())
			time.Sleep(1 * time.Second)
		}

	})

	Wg.Wait()
}
