package thirdpartapi

import (
	"context"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/common/response"
	"cuav-cloud-go-service/domain/common/thirdpartapi/model"
	domainModel "cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/infra/clients/http_clients"
	"time"
)

var (
	operationLogAddHandle http_clients.HttpClientRpcType[model.OperationLogAddIn, model.OperationLogAddOut]                          = http_clients.HttpClientCallTpl[model.OperationLogAddIn, model.OperationLogAddOut]
	getTraceDataHandle    http_clients.HttpClientRpcType[request.PageRequest, response.PageResponse[*domainModel.ProtocolUavDetect]] = http_clients.HttpClientCallTpl[request.PageRequest, response.PageResponse[*domainModel.ProtocolUavDetect]]
)

type cloudDataService struct {
	baseUrl string
}

func NewCloudDataService() *cloudDataService {
	baseUrl := "http://cuav-cloud-data-service:8892"
	return &cloudDataService{
		baseUrl: baseUrl,
	}
}

func (o *cloudDataService) OperationLogAdd(in *model.OperationLogAddIn) error {
	url := "/inner/rest/v1/data/operation-log/add"
	_, err := operationLogAddHandle(context.Background(), in, http_clients.WithBaseUrl(o.baseUrl), http_clients.WithUrl(url), http_clients.WithTimeOut(10*time.Second))
	if err != nil {
		return err
	}
	return nil
}

func (o *cloudDataService) GetTraceDataList(req *request.PageRequest) ([]*domainModel.ProtocolUavDetect, error) {
	url := "/inner/rest/v1/data/track-data/get"
	res, err := getTraceDataHandle(context.Background(), req, http_clients.WithBaseUrl(o.baseUrl), http_clients.WithUrl(url), http_clients.WithTimeOut(10*time.Second))
	if err != nil {
		return nil, err
	}
	return res.Data, nil
}
