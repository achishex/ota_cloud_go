package thirdpartapi

import (
	"context"
	"cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/infra/clients/http_clients"
	"time"
)

var (
	getSystemConfigHandle http_clients.HttpClientRpcType[model.GetSystemConfigQuery, model.ApiResponse[[]*model.SystemConfig]] = http_clients.HttpClientCallTpl[model.GetSystemConfigQuery, model.ApiResponse[[]*model.SystemConfig]]
)

type cloudAccountService struct {
	baseUrl string
}

func NewCloudAccountService() *cloudAccountService {
	baseUrl := "http://cuav-cloud-account-service:8882"
	return &cloudAccountService{
		baseUrl: baseUrl,
	}
}

func (o *cloudAccountService) GetSystemConfig(query *model.GetSystemConfigQuery) ([]*model.SystemConfig, error) {
	url := "/inner/rest/v1/account/system-config/list"
	res, err := getSystemConfigHandle(context.Background(), query, http_clients.WithBaseUrl(o.baseUrl), http_clients.WithUrl(url), http_clients.WithTimeOut(10*time.Second))
	if err != nil || res == nil {
		return nil, err
	}
	return res.Data, nil
}
