package model

import "encoding/json"

type GetSystemConfigQuery struct {
	Ids []string `json:"ids"`
}

type SystemConfig struct {
	Id   string `json:"id"`
	Json string `json:"json"`
}

func (cs *SystemConfig) MarshalBinary() ([]byte, error) {
	ret, e := json.Marshal(cs)
	if e != nil {
		return nil, e
	}
	return ret, nil
}

func (p *SystemConfig) UnmarshalBinary(data []byte) error {
	if e := json.Unmarshal(data, p); e != nil {
		return e
	}
	return nil
}
