package model

import "cuav-cloud-go-service/domain/common/constant"

var (
	FenceFieldMap = map[string]string{
		"area_name":  "areaName",
		"area_type":  "areaType",
		"area_range": "areaRange",
	}

	UavWhiteFieldMap = map[string]string{
		"vendor":     "vendor",
		"serial_num": "serialNum",
		"usage":      "usage",
	}
)

type ApiResponse[T any] struct {
	ErrorCode    int32  `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         T
}

type OperationLogAddIn struct {
	LogType         int            `json:"logType"`
	BusinessType    int            `json:"businessType"`
	OperationType   int            `json:"operationType"`
	OperationObject int            `json:"operationObject"`
	TbCode          string         `json:"tbCode"`
	OperatorId      int64          `json:"operatorId"`
	OperatorName    string         `json:"operatorName"`
	Content         map[string]any `json:"content"`
	Status          int            `json:"status"`
	Source          string         `json:"source"`
	ToInfoWindow    int            `json:"toInfoWindow"`
}

type OperationLogAddOut struct{}

func GetUpdateFields(operationType int, updateMap map[string]any) []string {
	var res []string
	var m map[string]string
	if operationType == constant.OperationLogBusinessTypeFenceUpdate {
		m = FenceFieldMap
	} else if operationType == constant.OperationLogBusinessTypeWhitelistUpdate {
		m = UavWhiteFieldMap
	} else {
		return res
	}
	for key := range updateMap {
		if val, ok := m[key]; ok {
			res = append(res, val)
		}
	}

	return res
}

type GetTraceDataIn struct {
	TbCode    string `json:"tbCode"`
	TrackId   string `json:"trackId"`
	Url       string `json:"url"`
	StartTime int64  `json:"startTime"`
	EndTime   int64  `json:"endTime"`
}
