package thirdpartapi

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func Test_apimapService_GetLocationOpenStreetMap(t *testing.T) {
	mock.LoggerMock()
	threadNumber := 100
	for i := 1; i <= threadNumber; i++ {
		go func(number int) {
			for reqNo := 0; reqNo <= 100; reqNo++ {
				res := NewOpenStreetMapService().GetSite(113.986334, 22.634206)
				logger.Infof("thread {%d} reqNo {%d} result: %+v", number, reqNo, res)
			}
		}(i)
	}

}

func Test_apimapService_GetLocationOpenStreetMap2(t *testing.T) {
	mock.LoggerMock()
	reqNo := 1
	now := time.Now()
	for {
		if time.Now().UnixMilli()-now.UnixMilli() > 3600000 {
			break
		}
		this := time.Now().UnixMilli()
		res := NewOpenStreetMapService().GetSite(113.986334, 22.634206)
		logger.Infof("reqNo {%d} result: %+v, cost: %d", reqNo, res, time.Now().UnixMilli()-this)
		reqNo++
		time.Sleep(10 * time.Second)
	}
}
