package thirdpartapi

import (
	"cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"errors"
	"fmt"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/go-resty/resty/v2"
)

type apimapService struct {
	baseUrl string
}

func NewOpenStreetMapService() *apimapService {
	baseUrl := "https://nominatim.openstreetmap.org"
	return &apimapService{
		baseUrl: baseUrl,
	}
}

func (s *apimapService) GetSite(lng, lat float64) string {
	var (
		res *model.OpenStreetMapResponse
		err error
	)
	res, err = s.GetLocationOpenStreetMap(lng, lat)
	// 重试三次
	retryCount := 1
	for err != nil && retryCount < 3 {
		res, err = s.GetLocationOpenStreetMap(lng, lat)
		retryCount++
	}
	if err != nil {
		logger.Error("GetSite error: %s", err.Error())
		return ""
	}
	var address string
	if res != nil {
		// 去掉地区编码
		parts := strings.Split(res.DisplayName, ",")
		if len(parts) >= 2 {
			parts = append(parts[:len(parts)-2], parts[len(parts)-1:]...)
			partTmp := []string{}
			for i := len(parts) - 1; i >= 0; i-- {
				partTmp = append(partTmp, parts[i])
			}
			parts = partTmp
		}
		address = strings.Join(parts, "")
	}
	return address
}

func (s *apimapService) GetLocationOpenStreetMap(lon, lat float64) (*model.OpenStreetMapResponse, error) {
	client := resty.New()
	resp, err := client.R().
		SetQueryParams(map[string]string{
			"format":         "json",
			"lat":            fmt.Sprintf("%f", lat),
			"lon":            fmt.Sprintf("%f", lon),
			"addressdetails": "1",
		}).
		SetHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)").
		SetResult(&model.OpenStreetMapResponse{}).
		Get(s.baseUrl + "/reverse")
	if err != nil {
		return nil, err
	}

	if resp.IsError() {
		return nil, err
	}

	result, ok := resp.Result().(*model.OpenStreetMapResponse)
	if !ok {
		return nil, errors.New("GetLocationOpenStreetMap response data error")
	}
	return result, nil
}
