package utils

func GetTimeByDB(tm int32) (hour, minute, second int32) {
	if tm <= 0 {
		return 0, 0, 0
	}
	second = tm % 100
	minute = (tm / 100) % 100
	hour = (tm / 10000) % 100
	return hour, minute, second
}
