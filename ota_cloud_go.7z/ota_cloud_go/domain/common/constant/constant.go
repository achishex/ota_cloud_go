package constant

const (
	XLanguageHeaderKey   = "Language"
	ContentTypeHeaderKey = "Content-Type"
	ContentTypeJson      = "application/json"
	LanguageZhCN         = "zh-CN"
	LanguageEn           = "en"

	UavWhitelistCachePrefix = "cloud_uav_whitelist:"
	EffectStatus            = 1
	DeleteStatus            = 2

	TrackS3FilePathPrefix = "cloud/track/"
)

// 取证报告常量定义
const (
	// PdfTrajZipFileUrlExpireSecond pdf + 轨迹 zip 的文件 生成的 下载url 有效时间
	PdfTrajZipFileUrlExpireSecond = 3600 * 24 * 7
)
