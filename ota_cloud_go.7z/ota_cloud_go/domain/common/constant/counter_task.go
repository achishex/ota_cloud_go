package constant

import "strconv"

const (
	RedisKeyCounterTaskInProgress = "CounterTaskInProgressList"
	// 任务状态
	CounterTaskStatusInProgress = 1
	CounterTaskStatusCancel     = 2
	CounterTaskStatusEnd        = 3

	// 任务触发方式
	TriggerModeNotLimit = 0
	TriggerModeAuto     = 1
	TriggerModeManual   = 2

	// 查询sfl返回的模式
	SflHitModeNormal             = 2
	SflHitModeGNSS               = 3
	SflHitModeNormalAndGNSS      = 4
	SflHitModeFpv                = 14
	SflHitModeQuanpinduan        = 128
	SflHitModeQuanpinduanAndGNSS = 129

	// 查询spoofer 返回的模式
	SpooferHitModeActiveDefense           = 1
	SpooferHitModeAreaDenial              = 2
	SpooferHitModeSirectionalDisplacement = 3

	//TODO: 查询 sfl200 返回的模式

	// 打击模式（前端映射）
	// sfl hit 模式
	SflHitModeNormalOut             = 10 // normal
	SflHitModeGNSSOut               = 11 // GNSS
	SflHitModeNormalAndGNSSOut      = 12 // normal and GNSS
	SflHitModeFpvOut                = 13 // fpv
	SflHitModeQuanpinduanOut        = 14 // 全频段
	SflHitModeQuanpinduanAndGNSSOut = 15 // 全频段 和 GNSS
	// spoofer 模式
	SpooferHitModeActiveDefenseOut           = 20 // 主动防御
	SpooferHitModeAreaDenialOut              = 21 // 区域拒止
	SpooferHitModeSirectionalDisplacementOut = 22 // 定向驱离
	//sf2oo-hit
	Sfl200HitModeNormalOut             = 110 // normal
	Sfl200HitModeGNSSOut               = 111 // GNSS
	Sfl200HitModeNormalAndGNSSOut      = 112 // normal and GNSS
	Sfl200HitModeFpvOut                = 113 // fpv
	Sfl200HitModeQuanpinduanOut        = 114 // 全频段
	Sfl200HitModeQuanpinduanAndGNSSOut = 115 // 全频段 和 GNSS
	//sfl200-spoofer
	Sfl200HitModeActiveDefenseOut           = 120 // 主动防御
	Sfl200HitModeAreaDenialOut              = 121 // 区域拒止
	Sfl200HitModeSirectionalDisplacementOut = 122 // 定向驱离
	// Sfl200HitModeFreqDirectOut               = 130 // 频谱自动匹配

	// 设备类型
	DeviceTypeSfl     = "Sfl"
	DeviceTypeSpoofer = "Spoofer"
	DeviceTypeSfl200  = "Sfl200"
)

var (
	HitModeMap = map[int]int{
		SflHitModeNormalOut:                      SflHitModeNormal,
		SflHitModeGNSSOut:                        SflHitModeGNSS,
		SflHitModeNormalAndGNSSOut:               SflHitModeNormalAndGNSS,
		SflHitModeFpvOut:                         SflHitModeFpv,
		SflHitModeQuanpinduanOut:                 SflHitModeQuanpinduan,
		SflHitModeQuanpinduanAndGNSSOut:          SflHitModeQuanpinduanAndGNSS,
		SpooferHitModeActiveDefenseOut:           SpooferHitModeActiveDefense,
		SpooferHitModeAreaDenialOut:              SpooferHitModeAreaDenial,
		SpooferHitModeSirectionalDisplacementOut: SpooferHitModeSirectionalDisplacement,
		Sfl200HitModeNormalOut:                   SflHitModeNormal,
		Sfl200HitModeGNSSOut:                     SflHitModeGNSS,
		Sfl200HitModeNormalAndGNSSOut:            SflHitModeNormalAndGNSS,
		Sfl200HitModeFpvOut:                      SflHitModeFpv,
		Sfl200HitModeQuanpinduanOut:              SflHitModeQuanpinduan,
		Sfl200HitModeQuanpinduanAndGNSSOut:       SflHitModeQuanpinduanAndGNSS,
		Sfl200HitModeActiveDefenseOut:            SpooferHitModeActiveDefense,
		Sfl200HitModeAreaDenialOut:               SpooferHitModeAreaDenial,
		Sfl200HitModeSirectionalDisplacementOut:  SpooferHitModeSirectionalDisplacement,
	}

	HitModeDeviceTypeMap = map[int]string{
		SflHitModeNormalOut:                      DeviceTypeSfl,
		SflHitModeGNSSOut:                        DeviceTypeSfl,
		SflHitModeNormalAndGNSSOut:               DeviceTypeSfl,
		SflHitModeFpvOut:                         DeviceTypeSfl,
		SflHitModeQuanpinduanOut:                 DeviceTypeSfl,
		SflHitModeQuanpinduanAndGNSSOut:          DeviceTypeSfl,
		SpooferHitModeActiveDefenseOut:           DeviceTypeSpoofer,
		SpooferHitModeAreaDenialOut:              DeviceTypeSpoofer,
		SpooferHitModeSirectionalDisplacementOut: DeviceTypeSpoofer,
		Sfl200HitModeNormalOut:                   DeviceTypeSfl200,
		Sfl200HitModeGNSSOut:                     DeviceTypeSfl200,
		Sfl200HitModeNormalAndGNSSOut:            DeviceTypeSfl200,
		Sfl200HitModeFpvOut:                      DeviceTypeSfl200,
		Sfl200HitModeQuanpinduanOut:              DeviceTypeSfl200,
		Sfl200HitModeQuanpinduanAndGNSSOut:       DeviceTypeSfl200,
		Sfl200HitModeActiveDefenseOut:            DeviceTypeSfl200,
		Sfl200HitModeAreaDenialOut:               DeviceTypeSfl200,
		Sfl200HitModeSirectionalDisplacementOut:  DeviceTypeSfl200,
	}

	DeviceTypeHitModeOutMap = map[string]int{
		DeviceTypeSfl + strconv.Itoa(SflHitModeNormal):                                             SflHitModeNormalOut,
		DeviceTypeSfl + strconv.Itoa(SflHitModeGNSS):                                               SflHitModeGNSSOut,
		DeviceTypeSfl + strconv.Itoa(SflHitModeNormalAndGNSS):                                      SflHitModeNormalAndGNSSOut,
		DeviceTypeSfl + strconv.Itoa(SflHitModeFpv):                                                SflHitModeFpvOut,
		DeviceTypeSfl + strconv.Itoa(SflHitModeQuanpinduan):                                        SflHitModeQuanpinduanOut,
		DeviceTypeSfl + strconv.Itoa(SflHitModeQuanpinduanAndGNSS):                                 SflHitModeQuanpinduanAndGNSSOut,
		DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeActiveDefense):                              SpooferHitModeActiveDefenseOut,
		DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeAreaDenial):                                 SpooferHitModeAreaDenialOut,
		DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeSirectionalDisplacement):                    SpooferHitModeSirectionalDisplacementOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeNormal):                          Sfl200HitModeNormalOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeGNSS):                            Sfl200HitModeGNSSOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeNormalAndGNSS):                   Sfl200HitModeNormalAndGNSSOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeFpv):                             Sfl200HitModeFpvOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeQuanpinduan):                     Sfl200HitModeQuanpinduanOut,
		DeviceTypeSfl200 + DeviceTypeSfl + strconv.Itoa(SflHitModeQuanpinduanAndGNSS):              Sfl200HitModeQuanpinduanAndGNSSOut,
		DeviceTypeSfl200 + DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeActiveDefense):           Sfl200HitModeActiveDefenseOut,
		DeviceTypeSfl200 + DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeAreaDenial):              Sfl200HitModeAreaDenialOut,
		DeviceTypeSfl200 + DeviceTypeSpoofer + strconv.Itoa(SpooferHitModeSirectionalDisplacement): Sfl200HitModeSirectionalDisplacementOut,
	}

	TaskModeMap = map[int][]int{
		1: {SflHitModeNormalOut, SflHitModeGNSSOut, SflHitModeNormalAndGNSSOut, SflHitModeFpvOut, SflHitModeQuanpinduanOut,
			SflHitModeQuanpinduanAndGNSSOut, Sfl200HitModeNormalOut, Sfl200HitModeGNSSOut, Sfl200HitModeNormalAndGNSSOut, Sfl200HitModeFpvOut,
			Sfl200HitModeQuanpinduanOut, Sfl200HitModeQuanpinduanAndGNSSOut},
		16: {SpooferHitModeActiveDefenseOut, SpooferHitModeAreaDenialOut, SpooferHitModeSirectionalDisplacementOut,
			Sfl200HitModeActiveDefenseOut, Sfl200HitModeAreaDenialOut, Sfl200HitModeSirectionalDisplacementOut},
		256: {},
	}
)
