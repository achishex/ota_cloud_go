package constant

// 操作日志类型
const (
	OperationLogTypeUser = iota + 1
	OperationLogTypeSystem
)

// 业务号
const (
	OperationLogBusinessTypeFence       = 50
	OperationLogBusinessTypeWhitelist   = 60
	OperationLogBusinessTypeCounterRule = 70
)

//
const (
	OperationLogOperationTypeAdd    = 1
	OperationLogOperationTypeUpdate = 2
	OperationLogOperationTypeDelete = 3

	OperationLogBusinessTypeFenceAdd    = 501
	OperationLogBusinessTypeFenceUpdate = 502
	OperationLogBusinessTypeFenceDelete = 503

	OperationLogBusinessTypeWhitelistAdd    = 601
	OperationLogBusinessTypeWhitelistUpdate = 602
	OperationLogBusinessTypeWhitelistDelete = 603

	OperationLogBusinessTypeCounterRuleAdd    = 701
	OperationLogBusinessTypeCounterRuleUpdate = 702
	OperationLogBusinessTypeCounterRuleDelete = 703
)

const (
	OperationLogSourceWeb = "WEB"
	OperationLogSourcePad = "PAD"
)

const (
	OperationLogStatusSuccess = iota + 1
	OperationLogStatusFail
)

const (
	OperationLogToInfoWindow = iota + 1
	OperationLogNotToInfoWindow
)

const (
	ContentFieldNameUavWhiteName  = "uavWhiteName"
	ContentFieldNameFenceAreaName = "fenceName"
	ContentFieldNameUpdateFields  = "updateFields"
	ContentFieldNameRuleName      = "ruleName"
	OptlogFenceI18NPrefix         = "optlog.fence."
	OptlogWhitelistI18NPrefix     = "optlog.whitelist."
	OptlogCounterRuleI18NPrefix   = "optlog.counterRule."
)
