package constant

const (
	// kafka事件通知url
	UrlTaskStatusUpdate = "/notice/v1/task_status_update"
)
