package constant

const (
	AlarmLevelLow    = 1
	AlarmLevelMiddle = 2
	AlarmLevelHight  = 3
)
