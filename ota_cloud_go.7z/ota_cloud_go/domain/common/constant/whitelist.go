package constant

const (
	FriendlyArmy = 2 // 友军
)
