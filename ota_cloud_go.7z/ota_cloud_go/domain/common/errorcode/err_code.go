package errorcode

const (
	ParameterInvalid       = 50000
	ParseTokenPayloadError = 50001
	NotFoundError          = 50002
	RecordDuplication      = 50003
	DBQueryError           = 50004
	GetUniqueIDError       = 50005
	DBCreateError          = 50006
	DBUpdateError          = 50007

	FenceAddError    = 51000
	FenceUpdateError = 51001
	FenceDeleteError = 51002
	FenceExsit       = 51003

	UavWhiteAddError        = 52000
	UavWhiteAddOutLimit     = 52001
	UavWhitelistUpdateError = 52002
	UavWhitelistDeleteError = 52003
)
