package request

// 手动开始反制任务
// counterTaskManualStartRequest 手动开始反制任务
// swagger:model counterTaskManualStartRequest
type CounterTaskManualStartRequest struct {

	// required: true
	// example: "sfl200-123123"
	// 反制设备名称
	DeviceName string `json:"deviceName"`
	// required: true
	// example: "Sfl200"
	// 反制设备类型
	DeviceType string `json:"deviceType" validate:"required"`
	// required: false
	// example: "Sfl"
	// 反制子设备设备类型
	ChildDeviceType string `json:"childDeviceType"`
	// required: true
	// example: "sfl200-sn"
	// 反制设备sn
	DeviceSn string `json:"deviceSn" validate:"required"`
	// required: true
	// example: 1：
	// 打击模式
	HitMode int32 `json:"hitMode" validate:"required"`
	// required: true
	// example: "dj-mav3"
	// 目标名称
	ObjName string `json:"objName"`
	// required: true
	// example: "dj-123"
	// 目标机型
	ObjType string `json:"objType"`
	// required: true
	// example: 30
	// 打击时长， 单位为second
	HitDurTimeSecond int32 `json:"hitDurTimeSecond"`
	// required: true
	// example:
	// 任务额外参数
	ExtraParams map[string]any `json:"extraParams"`
	// required: true
	// example: "000001"
	// 企业编号
	TbCode string `json:"tbCode" validate:"required"`
	// required: true
	// example: "1239852612312"
	// 目标事件id
	TrackId string `json:"trackId"`
}

type CounterTaskAutoStartRequest struct {
	// required: true
	// example: "sfl200-123123"
	// 反制设备名称
	DeviceName string `json:"deviceName"`
	// required: true
	// example: "Sfl200"
	// 反制设备类型
	DeviceType string `json:"deviceType" validate:"required"`
	// required: true
	// example: "sfl200-sn"
	// 反制设备sn
	DeviceSn string `json:"deviceSn" validate:"required"`
	// required: true
	// example: 1：
	// 打击模式
	HitMode int32 `json:"hitMode" validate:"required"`
	// required: true
	// example: "dj-mav3"
	// 目标名称
	ObjName string `json:"objName"`
	// required: true
	// example: "dj-123"
	// 目标机型
	ObjType string `json:"objType"`
	// required: true
	// example: 30
	// 打击时长， 单位为second
	HitDurTimeSecond int32 `json:"hitDurTimeSecond"`
	// required: true
	// example:
	// 任务额外参数
	ExtraParams map[string]any `json:"extraParams"`
	// required: true
	// example: "000001"
	// 企业编号
	TbCode string `json:"tbCode" validate:"required"`
	// required: true
	// example: 12522222
	// 自动规则id
	RuleId int64 `json:"ruleId" validate:"required"`
	// required: true
	// example: "12522222"
	// 目标事件id
	TrackId string `json:"trackId"`
}

// 反制状态反馈
// counterStatusFeedBackRequest 反制状态反馈
// swagger:model counterStatusFeedBackRequest
type CounterStatusFeedBackRequest struct {
	// required: true
	// example: 1: 开始反制， 2: 反制结束
	// 当前反制状态
	Status int32 `json:"status" validate:"oneof=1 2 3 4"`
	// required: true
	// example: "Sfl"
	// 反制设备类型
	DeviceType string `json:"deviceType"`
	// required: true
	// example: "sfl200-sn"
	// 反制设备sn
	DeviceSn string `json:"deviceSn"`
	// required: true
	// example: "000001"
	// 企业编号
	TbCode string `json:"tbCode"`
	// required: true
	// example: "23123123123"
	// 任务id; 当取消任务时需要携带
	TaskId string `json:"taskId"`
}

type CounterTaskQueryRequest struct {

	// required: true
	// example: 123231231
	// 任务id, <= 0 从最新的任务开始查询
	TaskId int64 `json:"taskId"`
	// required: true
	// example: 20
	// 每页大小
	PageSize int32 `json:"pageSize"`
	// 任务状态，
	// required: true
	// example: {1, 2}, 空或不传: 不限制 {1}: 进行中; {2}: 已取消; {3}: 已结束
	StatusList []int `json:"statusList"`
	// 任务触发方式
	// example: 1 ;  0 或 不传: 不限制;  1： 自动； 2： 手动
	// required: false
	TriggerModeList []int `json:"triggerModeList"`
	// 反制设备sn
	// example: "sfl200-123", 空则不限制
	// required: false
	DevSn string `json:"devSn"`
	// 反制模式
	// example: 空 或 不传 所有模式 ； {1}: 无线电打击 {16}: 诱骗 {256}：诱导联动
	// required: false
	ModeList []int `json:"modeList"`
	// 反制规则名
	// example: 空表示不限制
	// required: false
	SearchName string `json:"searchName"`
	// 页码
	// example: 1
	// required: true
	PageNo int32 `json:"pageNo"`
}

type TaskProgressCountRequest struct {
	TbCode string `json:"tbCode"`
}
