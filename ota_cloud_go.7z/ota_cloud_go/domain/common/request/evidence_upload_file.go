package request

// 上传取证报告pdf请求
// EvidenceReportPdfUploadRequest  上传取证报告pdf请求
// swagger:model EvidenceReportPdfUploadRequest
type EvidenceReportPdfUploadRequest struct {
	// required: true
	// example: "12312313"
	//  无人机分析轨迹-目标事件id; form 表单的key: track_id
	TrackId string `protobuf:"bytes,1,opt,name=track_id,json=trackId,proto3" json:"track_id,omitempty" form:"track_id"`
	// required: true
	// example:
	//  文件上传 form 表单的key: file
	File []byte `protobuf:"bytes,2,opt,name=file,proto3" json:"file,omitempty" form:"file"`
	// 文件的文件名，从表单字段解析, 内部参数，前端忽略
	FileName string `protobuf:"bytes,2,opt,name=file_name,proto3" json:"-"`
}
