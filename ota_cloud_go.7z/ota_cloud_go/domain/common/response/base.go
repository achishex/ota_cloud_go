package response

type PageResponse[T any] struct {
	PageIndex int   `json:"pageIndex"`
	PageSize  int   `json:"pageSize"`
	PageTotal int64 `json:"pageTotal"`
	Data      []T   `json:"data"`
}
