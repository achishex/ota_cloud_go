package response

// 上传取证报告pdf 回包
// EvidenceReportPdfUploadResponse   上传取证报告pdf 回包
// swagger:model EvidenceReportPdfUploadResponse
type EvidenceReportPdfUploadResponse struct {
	// required: true
	// example: "12312313"
	//  zip 包的下载链接,是文件名; 前端后续下载时调用接口，而非这个链接
	Url string `protobuf:"bytes,11,opt,name=url,proto3" json:"url,omitempty"`
	// required: true
	// example: 1723820816002
	//  url 过期时间点/时间戳，毫秒，utc
	ExpireTimePoint int64 `protobuf:"bytes,11,opt,name=url,proto3" json:"expireTime,omitempty"`
}

// 上传取证报告pdf 回包
// EvidenceReportPdfUploadResponse   上传取证报告pdf 回包
// swagger:model EvidenceReportPdfUploadResponse
type CaptureFlyingDocumentUploadResponse struct {
	// required: true
	// example: "12312313"
	//  zip 包的下载链接,是文件名; 前端后续下载时调用接口，而非这个链接
	Url string `protobuf:"bytes,11,opt,name=url,proto3" json:"url,omitempty"`
	// required: true
	// example: 1723820816002
	//  url 过期时间点/时间戳，毫秒，utc
	ExpireTimePoint int64 `protobuf:"bytes,11,opt,name=url,proto3" json:"expireTime,omitempty"`
}
