package response

import (
	"time"
)

type CounterTaskQueryRes struct {
	List []*CounterTaskQueryResponse `json:"list"`
	// 页码
	// required: true
	// example: 1
	PageNo int32 `json:"pageNo"`
	// 每页数量
	// required: true
	// example: 10
	PageSize int32 `json:"pageSize"`
	// 总量
	// required: true
	// example: 100
	Total int32 `json:"total"`
}

type CounterTaskQueryResponse struct {
	// required: true
	// example: 123123131
	// 任务id
	Id int64 `json:"id"`
	// 任务名
	// required: true
	// example: task_1232
	Name string `json:"name"`
	// 任务触发方式：1： 自动； 2： 手动
	// required: true
	// example: 1
	TriggerMode int32 `json:"triggerMode"`
	// 任务状态： 1: 进行中; 2: 已取消; 3: 已结束
	// required: true
	// example: 1
	Status int32 `json:"status"`
	// 反制设备sn
	// required: true
	// example: "sfl200"
	DevSn string `json:"devSn"`
	// 反制设备类型
	// required: true
	// example: "Sfl"
	DevType string `json:"devType"`
	// 反制设备名称
	// required: true
	// example: "sfl200"
	DevName string `json:"devName"`
	// 反制模式
	// required: true
	// example: 1
	Mode int32 `json:"mode"`
	// 目标名称
	// required: true
	// example: "dj-123"
	ObjName string `json:"objName"`
	// 目标机型
	// required: true
	// example: "dj-123"
	ObjType string `json:"objType"`
	// 打击时长
	// required: true
	// example: 123
	DurTimeS int32 `json:"durTimeS"`
	// 反制规则
	// required: true
	// example: model.autoCounterRuleSimple
	RuleItem *AutoCounterRuleSimple `json:"ruleItem"`
	// 开始时间
	// required: true
	// example:
	BeginTime int64 `json:"beginTime"`
	// 结束时间
	// required: true
	// example:
	EndTime int64 `json:"endTime"`
}

type AutoCounterRuleSimple struct {

	// required: true
	// example: 12312312313
	// 规则唯一id
	RuleId int64 `json:"ruleId"`
	// required: true
	// example: 自动反制规则1
	// 自动反制名字
	RuleName string `json:"ruleName"`
	// required: false
	// example: model.CounterAreaList
	//新建规则时，创建反制区的数据，和下面的 FenceAreaId 互斥使用
	CounterArea *CounterArea `json:"counterArea,omitempty"`
	// required: false
	// example: 123123131； 其中 0 标识一个无效的围栏区， >0 使用围栏区作为反制区
	//新建规则依赖的已有围栏区id
	FenceAreaItem *FenceResList `json:"fenceAreaItem,omitempty"`
	// required: true
	// example: 0 不禁用任何模式, 1: 禁用无线电打击(0x01), 16: 禁用诱骗(0x10), 256: 禁用诱打联动(0x100); 0x11 ：禁止无线电打击+诱骗; 0x101: 禁止无线电打击+诱导联动; 0x110: 矜持诱骗+诱打联动； 0x111:禁止无线电打击+诱骗+诱打联动
	// 禁用模式
	ForbiddenMode int32 `json:"forbiddenMode"`
	// required: true
	// example: 1 标识开启; 2 关闭该规则
	// 规则是否开启
	RuleEnable int32 `json:"ruleEnable"`
	// required: true
	// example:
	// 自动反制创建事件
	CreateTime time.Time `json:"createTime"`
	// required: true
	// example:
	// 自动反制更新时间
	UpdateTime time.Time `json:"updateTime"`
	// required: true
	// example: 0: 不是全天， 1：全天
	// 全天
	WholeDay int32 `json:"wholeDay"`
	// required: true
	// example: 规则有效开始时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	// 规则有效开始时间点
	BeginTime int32 `json:"beginTime"`
	// required: true
	// example: 规则有效结束时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	// 结束时间
	EndTime int32 `json:"endTime"`
	// required: true
	// example: 0: 不跨天， 1： 跨1天， 2： 跨2天， n:跨n天
	// 跨天
	CrossDay int32 `json:"crossDay"`
	// required: false
	// example: 0-23
	//开始时间小时
	StartHour *int32 `json:"startHour,omitempty"`
	// required: false
	// example: 0-59
	//开始时间分
	StartMinute *int32 `json:"startMinute,omitempty"`
	// required: false
	// example: 0-59
	//开始时间秒
	StartSecond *int32 `json:"startSecond,omitempty"`
	//
	// required: false
	// example: 0-23
	//结束时间小时
	EndHour *int32 `json:"endHour,omitempty"`
	// required: false
	// example: 0-59
	//结束时间分
	EndMinute *int32 `json:"endMinute,omitempty"`
	// required: false
	// example: 0-59
	//结束时间秒
	EndSecond *int32 `json:"endSecond,omitempty"`
}

type CounterArea struct {
	// required: true
	// example: 1
	// 反制区id
	Id int64 `json:"id"`
	// required: true
	// example: 反制区1
	//反制区名字
	AreaName string `json:"areaName,omitempty"`
}

type FenceResList struct {
	// required: true
	// example: 1
	// 围栏区id
	Id int64 `json:"id"`
	// required: true
	// example: 预警区123
	// 围栏区名字
	AreaName string `json:"areaName,omitempty"`
	// required: true
	// example: 围栏区类型：1-预警区 2-核心区
	// 围栏区类型
	AreaType int `json:"areaType,omitempty"`
}

type TaskProgressCount struct {
	// required: true
	// example: 6
	// 进行中数量
	Count int64 `json:"count"`
}
