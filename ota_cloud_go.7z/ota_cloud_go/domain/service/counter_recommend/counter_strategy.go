package counter_recommend

// 反制无人机推荐算法实现源文件
import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/config"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"time"
)

// UavCounterStrategyRecommend 无人机反制设备推荐服务
type UavCounterStrategyRecommend struct {
	tbCode     string
	counterReq *pb.CounterMeasureRecommendRequest
	c2Sn       string

	// 串行召回在线设备对象
	recallHandleSerial []CounterRecallInterface
	// 并行召回在线设备对象
	recallHandleParallel []CounterRecallInterface

	// 被召回的在线设备列表
	recalledDeviceList []*device_manager.DeviceDetail

	// 算法-精排策略列表
	sortStrategy SortProInterface

	// 排序后的设备列表
	sortedDeviceList []*device_manager.DeviceDetail
}

// NewUavCounterStrategyRecommend 创建无人机反制设备推荐服务
func NewUavCounterStrategyRecommend(tbCode string, req *pb.CounterMeasureRecommendRequest) *UavCounterStrategyRecommend {
	var (
		recallSerial         []CounterRecallInterface
		recallHandleParallel []CounterRecallInterface
		recallRpcUrl         = "http://cuav-cloud-service:8891/inner/rest/v1/access/equip/list"
		sortHandle           = NewSortProImpl()
	)

	recallHandleParallel = append(recallHandleParallel, NewCounterRecallOnCacheHandle(config.GlobalRedis), NewCounterRecallRpc(recallRpcUrl, req.GetC2Sn()))

	return &UavCounterStrategyRecommend{
		tbCode:               tbCode,
		c2Sn:                 req.GetC2Sn(),
		counterReq:           req,
		recallHandleSerial:   recallSerial, // 暂时没有串行召回
		recallHandleParallel: recallHandleParallel,
		sortStrategy:         sortHandle,
	}
}

// Recall 根据一定策略召回设备(包括侦测和打击设备等)
func (r *UavCounterStrategyRecommend) Recall(ctx context.Context) error {
	beginTime := time.Now()
	defer func() {
		logger.Infof("recall time ms: %v, tbCode: %v, req: %+v", time.Since(beginTime).Milliseconds(), r.tbCode, r.counterReq)
	}()

	if r == nil {
		logger.Infof("UavCounterStrategyRecommend is nil")
		return errors.New("recommend obj is nil")
	}

	// 串行召回
	for index, _ := range r.recallHandleSerial {
		devList, err := r.recallHandleSerial[index].Recall(ctx, r.tbCode)
		if err != nil {
			logger.Errorf("recall task: %v, fail, tbCode: %v, err: %v", r.recallHandleSerial[index].Name(), r.tbCode, err)
			continue
		}
		r.recalledDeviceList = append(r.recalledDeviceList, devList...)
	}

	var err error
	var taskCtrl = routinues.NewRoutineGroupWrap()
	var recallRet = make(map[string][]*device_manager.DeviceDetail) // key is recall_task_name
	for index, _ := range r.recallHandleParallel {
		recallRet[r.recallHandleParallel[index].Name()] = nil
	}

	// 并行召回
	for i, _ := range r.recallHandleParallel {
		index := i
		taskCtrl.Run(func() {
			devList, err := r.recallHandleParallel[index].Recall(ctx, r.tbCode)
			if err != nil {
				logger.Errorf("recall task: %v, tbCode: %v, fail, err: %v", r.recallHandleParallel[index].Name(), r.tbCode, err)
				return
			}

			recallRet[r.recallHandleParallel[index].Name()] = devList
			logger.Infof("recall task: [%v] done and succ, tbCode: %v, devList len: %v", r.recallHandleParallel[index].Name(), r.tbCode, len(devList))
		})
	}
	taskCtrl.Wait()
	logger.Infof("recall all task done, tbCode: %v, parallel recall task nums: %v", r.tbCode, len(r.recallHandleParallel))

	// 召回后的处理
	r.recalledDeviceList, err = r.RecallPost(ctx, r.tbCode, r.c2Sn, recallRet)
	if err != nil {
		logger.Errorf("post recall fail, err: %v, tb code: %v", err, r.tbCode)
	}
	return nil
}

func (r *UavCounterStrategyRecommend) RecallPost(ctx context.Context, tbCode string, c2Sn string,
	recallDevs map[string][]*device_manager.DeviceDetail) ([]*device_manager.DeviceDetail, error) {

	var retRecallDevList []*device_manager.DeviceDetail = nil

	recallName := NewCounterRecallOnCacheHandle(nil).Name()
	onCacheRecallDev, ok := recallDevs[recallName]
	retRecallDevList = onCacheRecallDev

	if !ok || len(onCacheRecallDev) == 0 {
		logger.Infof("not exist online device, tbCode: %v by recall task: [%v]", tbCode, recallName)
		return retRecallDevList, nil
	}

	recallName = NewCounterRecallRpc("", c2Sn).Name()
	rpcRecallDev, ok := recallDevs[recallName]
	if !ok || len(rpcRecallDev) == 0 {
		logger.Infof("not exist device rpc list, tbCode: %v, by recall task: [%v]", tbCode, recallName)

		// 设置dev name默认值：
		logger.Infof("set default dev name by dev sn.")
		for index, _ := range retRecallDevList {
			retRecallDevList[index].DevName = retRecallDevList[index].GetSn()
		}
		return retRecallDevList, nil
	}

	// reset
	retRecallDevList = nil
	var parentChildRel = make(map[string]map[string]int32) // first key is parent sn, second key is child sn
	for index, _ := range onCacheRecallDev {

		onLineDev := onCacheRecallDev[index]
		if onLineDev == nil {
			continue
		}

		devSn := onLineDev.GetSn()
		toDelSn := ""
		logger.Infof("online device sn: %v, devType: %v", devSn, onLineDev.DeviceType)

		for _, rpcDev := range rpcRecallDev {
			if rpcDev == nil {
				continue
			}

			//if rpcDev.C2Sn != c2Sn {
			//	logger.Infof("dev rpc c2 sn: %v, req c2 sn: %v", rpcDev.C2Sn, c2Sn)
			//	continue
			//}

			logger.Infof("rpc device, sn: %v, parent sn: %v, devName: %v", rpcDev.RpcDeviceSn, rpcDev.ParentSn, rpcDev.DevName)
			//
			if devSn == rpcDev.RpcDeviceSn {
				onLineDev.DevName = rpcDev.DevName

				if rpcDev.ParentSn != "" && rpcDev.ParentSn != rpcDev.RpcDeviceSn {
					toDelSn = rpcDev.RpcDeviceSn
					logger.Infof("devSn: %v is child device, parent sn: %v, del in online device list", rpcDev.RpcDeviceSn, rpcDev.ParentSn)

					childDeviceList, ok := parentChildRel[rpcDev.ParentSn]
					if !ok || len(childDeviceList) <= 0 {
						parentChildRel[rpcDev.ParentSn] = map[string]int32{
							rpcDev.RpcDeviceSn: onLineDev.GetTypeNums(),
						}
					} else {
						parentChildRel[rpcDev.ParentSn][rpcDev.RpcDeviceSn] = onLineDev.GetTypeNums()
					}
				}
			}
		}

		if toDelSn == "" {
			retRecallDevList = append(retRecallDevList, onLineDev)
			logger.Infof("dev has not parent device, tbCode: %v, devSn: %v", tbCode, devSn)
		} else {
			logger.Infof("dev has parent device, need to omit this sub device, sn: %v, tbCode: %v", toDelSn, tbCode)
		}
	}

	for index, _ := range retRecallDevList {
		devItem := retRecallDevList[index]
		if devItem == nil {
			continue
		}

		childDevs, ok := parentChildRel[devItem.GetSn()]
		if !ok || len(childDevs) <= 0 {
			logger.Infof("after recall, sn: %v, has not sub dev, tbCode: %v", devItem.GetSn(), r.tbCode)
			continue
		}

		var childDevList []*device_manager.SubDevItem
		for k, _ := range childDevs {
			childDevList = append(childDevList, &device_manager.SubDevItem{
				Sn:      k,
				DevType: childDevs[k],
			})
		}
		logger.Infof("after recall, sn: %v, sub_dev_sn_list: %s", devItem.GetSn(), childDevList)
		retRecallDevList[index].SubDevList = childDevList
	}

	return retRecallDevList, nil
}

// Sort 排序(包括粗排和精排)
func (r *UavCounterStrategyRecommend) Sort(ctx context.Context) error {
	// 排序算法
	var err error
	r.sortedDeviceList, err = r.sortStrategy.Sort(ctx, r.tbCode, r.counterReq, r.recalledDeviceList)
	if err != nil {
		logger.Errorf("get sorted device list fail, err: %v, tbCode: %v, uavList: %+v", err, r.tbCode, r.counterReq)
		return fmt.Errorf("sort device list fail")
	}
	return nil
}

func (r *UavCounterStrategyRecommend) UavIsFreqDetect() (error, bool) {
	if r == nil || r.counterReq == nil {
		return fmt.Errorf("req body is nil"), false
	}
	if r.counterReq.Sn == "" && r.counterReq.ObjId == "" {
		return nil, true
	}
	return nil, false
}

// recommendDevInReqDetectDev 检查推荐设备是否具有打击能力，检查设备是否在侦测设备列表中,
func recommendDevInReqDetectDev(recommendDev *device_manager.DeviceDetail, reqDetectDevice []*pb.DetectDevices) *device_manager.DeviceDetail {
	if recommendDev == nil {
		return nil
	}

	if len(reqDetectDevice) <= 0 {
		return nil
	}

	var deviceSn string
	switch recommendDev.DeviceType {
	case device_manager.DevTypeSpooferFromHeartBeat:
		deviceSn = recommendDev.SpooferInfo.GetSn()

	case device_manager.DevTypeSfl100FromHeatBeat:
		deviceSn = recommendDev.Sfl100Info.GetSn()

	case device_manager.DevTypeSfl200FromHeatBeat:
		deviceSn = recommendDev.Sfl200Info.GetSn()
	case device_manager.DevTypeDjRemoteControlFromRcUav:
		deviceSn = recommendDev.DjUavInfo.GetSn()

	default:
		return nil
	}

	for i := 0; i < len(reqDetectDevice); i++ {
		if reqDetectDevice[i] == nil {
			continue
		}

		if reqDetectDevice[i].GetSn() == deviceSn {
			return recommendDev
		}
	}
	return nil
}

// Filter 过滤动作
func (r *UavCounterStrategyRecommend) Filter(ctx context.Context) error {
	var filteredDeviceList []*device_manager.DeviceDetail

	_, uavIsFreqDetect := r.UavIsFreqDetect()
	if uavIsFreqDetect {
		logger.Infof("req is freq detect uav, not check distance with device")
	}

	for index, _ := range r.sortedDeviceList {
		if r.sortedDeviceList[index] == nil {
			continue
		}

		if uavIsFreqDetect == true {
			freqDetectDev := recommendDevInReqDetectDev(r.sortedDeviceList[index], r.counterReq.GetDeviceList())
			if freqDetectDev != nil {
				filteredDeviceList = append(filteredDeviceList, freqDetectDev)
				logger.Infof("freq detect device and can hit, dev sn: %v", freqDetectDev.GetSn())
			}
			continue
		}

		if r.sortedDeviceList[index].DistanceValid {
			filteredDeviceList = append(filteredDeviceList, r.sortedDeviceList[index])
			continue
		}
		logger.Infof("as device distance invalid, not to recommend, devSn: %v, devType: %v", r.sortedDeviceList[index].GetSn(), r.sortedDeviceList[index].DeviceType)
	}

	r.sortedDeviceList = filteredDeviceList
	return nil
}

// GetRecommendDevices 获取反制的设备列表
func (r *UavCounterStrategyRecommend) GetRecommendDevices(ctx context.Context, body *pb.CounterMeasureRecommendRequest) ([]*pb.CounterMeasureRecommendResponse, error) {
	var ret []*pb.CounterMeasureRecommendResponse
	for _, devItem := range r.sortedDeviceList {
		if devItem == nil {
			continue
		}

		if item := device_manager.AnalyseCounterDeviceFromDetail(devItem, body); item != nil {
			ret = append(ret, item)
		}
	}
	return ret, nil
}

// GetCounterDeviceListOnUav 给特定无人机分配反制设备列表
func GetCounterDeviceListOnUav(ctx context.Context, tbCode string, requestBody *pb.CounterMeasureRecommendRequest) ([]*pb.CounterMeasureRecommendResponse, error) {
	counterHandler := NewUavCounterStrategyRecommend(tbCode, requestBody)
	if err := counterHandler.Recall(ctx); err != nil {
		if errors.Is(err, ec.GetError(ec.SF_ErrorRecallEmpty)) {
			return nil, nil
		}
		logger.Errorf("recall counter device fail, tbCode: %v, err: %v", tbCode, err)
		return nil, ec.GetError(ec.SF_ErrorCounterRecommendRecallFail)
	}

	if err := counterHandler.Sort(ctx); err != nil {
		logger.Errorf("sort recalled counter devices fail, tbCode: %v, err: %v", tbCode, err)
		return nil, ec.GetError(ec.SF_ErrorCounterRecommendSortFail)
	}

	if err := counterHandler.Filter(ctx); err != nil {
		logger.Errorf("filter counter devices fail, tbCode: %v, err: %v", tbCode, err)
		return nil, ec.GetError(ec.SF_ErrorCounterRecommendFilterFail)
	}

	retDeviceList, err := counterHandler.GetRecommendDevices(ctx, requestBody)
	if err != nil {
		logger.Errorf("get recommend device list fail, tbCode: %v, err: %v", tbCode, err)
		return nil, ec.GetError(ec.SF_ErrorCounterRecommendDevFail)
	}

	logger.Infof("tb code: %v, get counter recommend devices list: %+v", tbCode, retDeviceList)
	return retDeviceList, nil
}
