package counter_recommend

import (
	"context"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/device_manager"
	pb "cuav-cloud-go-service/proto"
	"testing"
)

func TestPostRecall(t *testing.T) {
	mock.LoggerMock()
	recommendItem := &UavCounterStrategyRecommend{}

	onLineRecallItems := []*device_manager.DeviceDetail{
		&device_manager.DeviceDetail{
			DeviceType: device_manager.DevTypeSfl200FromHeatBeat,
			Sfl200Info: &pb.Sfl200SystemStateData{
				Sn: "sfl200-1422323044680",
			},
			C2Sn: "test_1",
		},
		&device_manager.DeviceDetail{
			DeviceType: device_manager.DevTypeSfl100FromHeatBeat,
			Sfl100Info: &pb.SflHeartData{
				Sn: "SFL100-test1",
			},
			C2Sn: "test_1",
		},
		&device_manager.DeviceDetail{
			DeviceType: device_manager.DevTypeSfl100FromHeatBeat,
			Sfl100Info: &pb.SflHeartData{
				Sn: "SFL100-A007",
			},
			C2Sn: "test_1",
		},
		&device_manager.DeviceDetail{
			DeviceType: device_manager.DevTypeSfl100FromHeatBeat,
			Sfl100Info: &pb.SflHeartData{
				Sn: "SFL100-test2",
			},
			C2Sn: "test_1",
		},
	}
	//
	rpcRecallItems := []*device_manager.DeviceDetail{
		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "SFL100-A007",
			DevName:     "SFL100#188",
			C2Sn:        "test_1",
		},

		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "sfl200-1422323044680",
			DevName:     "SFL200#436",
			C2Sn:        "test_1",
		},
		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "SFL100-test1",
			DevName:     "SFL100#401",
			C2Sn:        "test_1",
		},
		&device_manager.DeviceDetail{
			ParentSn:    "",
			RpcDeviceSn: "SFL100-test12",
			DevName:     "SFL100#402",
			C2Sn:        "test_1",
		},
	}

	recallItems := map[string][]*device_manager.DeviceDetail{
		"recall_on_cache": onLineRecallItems,
		"recall_rpc":      rpcRecallItems,
	}

	retItems, err := recommendItem.RecallPost(context.Background(), "00001", "test_1", recallItems)
	if err != nil {
		t.Logf("err: %v", err)
	} else {
		for _, devItem := range retItems {
			if devItem == nil {
				continue
			}
			t.Logf("recall items, devName: %v, devSn: %v, subDevSnList: %s", devItem.DevName, devItem.GetSn(), device_manager.SubDevItemList(devItem.SubDevList))
		}
	}

}

func TestPostRecallOnCacheNil(t *testing.T) {
	mock.LoggerMock()
	recommendItem := &UavCounterStrategyRecommend{}

	rpcRecallItems := []*device_manager.DeviceDetail{
		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "SFL100-A007",
			DevName:     "SFL100#188",
			C2Sn:        "test_1",
		},

		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "sfl200-1422323044680",
			DevName:     "SFL200#436",
			C2Sn:        "test_1",
		},
		&device_manager.DeviceDetail{
			ParentSn:    "sfl200-1422323044680",
			RpcDeviceSn: "SFL100-test1",
			DevName:     "SFL100#401",
			C2Sn:        "test_1",
		},
		&device_manager.DeviceDetail{
			ParentSn:    "",
			RpcDeviceSn: "SFL100-test12",
			DevName:     "SFL100#402",
			C2Sn:        "test_1",
		},
	}

	recallItems := map[string][]*device_manager.DeviceDetail{
		"recall_on_cache": nil,
		"recall_rpc":      rpcRecallItems,
	}

	retItems, err := recommendItem.RecallPost(context.Background(), "00001", "test_1", recallItems)
	if err != nil {
		t.Logf("err: %v", err)
	} else {
		for _, devItem := range retItems {
			if devItem == nil {
				continue
			}
			t.Logf("recall items, devName: %v, devSn: %v, subDevSnList: %s", devItem.DevName, devItem.GetSn(), device_manager.SubDevItemList(devItem.SubDevList))
		}
	}
}
