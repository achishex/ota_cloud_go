package counter_recommend

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/service/device_manager"
	pb "cuav-cloud-go-service/proto"
	"math"
)

// SortImpl 定义sort 实现的方法对象
type SortImpl func(deviceList []*device_manager.DeviceDetail) []*device_manager.DeviceDetail

// dryControlRatioSortImpl 干控比排序实现（具体排序算法2）： 精排
func dryControlRatioSortImpl(deviceList []*device_manager.DeviceDetail) []*device_manager.DeviceDetail {
	if deviceList == nil {
		return nil
	}
	device_manager.SortDeviceListByDryCtrlRat(deviceList)
	return deviceList
}

// baseSortImpl 粗排
func baseSortImpl(deviceList []*device_manager.DeviceDetail) []*device_manager.DeviceDetail {
	if deviceList == nil {
		return nil
	}
	device_manager.SortDeviceListByName(deviceList)
	return deviceList
}

// distanceSortImpl 目标到设备的距离排序（具体排序算法1）：精排
func distanceSortImpl(deviceList []*device_manager.DeviceDetail) []*device_manager.DeviceDetail {
	if deviceList == nil {
		return nil
	}
	// 优先推荐在侦测范围内的设备，同时进入侦测范围，推荐距离更近的。不在侦测范围内， 也推荐距离更近的设备。
	device_manager.SortDeviceListByValidDist(deviceList)
	return deviceList
}

// SortProInterface 排序算法接口定义
type SortProInterface interface {
	Sort(ctx context.Context, tbCode string, uavInfo *pb.CounterMeasureRecommendRequest,
		recallDevList []*device_manager.DeviceDetail) ([]*device_manager.DeviceDetail, error)
}

// SortProcImpl 定义排序算法集合
type SortProcImpl struct {
	sortFunc []SortImpl
}

// NewSortProImpl 创建排序算法集合对象
func NewSortProImpl() SortProInterface {
	ret := &SortProcImpl{}
	ret.sortFunc = append(ret.sortFunc, baseSortImpl, distanceSortImpl, dryControlRatioSortImpl)
	return ret
}

// Sort 排序集合的排序接口实现
func (sp *SortProcImpl) Sort(ctx context.Context,
	tbCode string, uavInfo *pb.CounterMeasureRecommendRequest,
	recallDevList []*device_manager.DeviceDetail) ([]*device_manager.DeviceDetail, error) {

	// calc resource for sort
	devList := NewCalcDistanceAndDryCtrlRate(uavInfo, recallDevList).Calc()

	// begin to sort
	for _, sortHandle := range sp.sortFunc {
		devList = sortHandle(devList)
	}
	return devList, nil
}

// CalcDistanceAndDryCtrlRate 计算坐标距离和干控比对象
type CalcDistanceAndDryCtrlRate struct {
	// 多个设备对象
	deviceList []*device_manager.DeviceDetail
	// 无人机对象
	uavInfo     *pb.CounterMeasureRecommendRequest
	EarthRadius float64 //  6371000.0 米
}

// NewCalcDistanceAndDryCtrlRate 创建坐标距离计算和干控比计算对象
func NewCalcDistanceAndDryCtrlRate(uavInfo *pb.CounterMeasureRecommendRequest, deviceList []*device_manager.DeviceDetail) *CalcDistanceAndDryCtrlRate {

	return &CalcDistanceAndDryCtrlRate{
		deviceList:  deviceList,
		uavInfo:     uavInfo,
		EarthRadius: 6371000.0,
	}
}

// toECEF地理坐标转换为 ECEF 坐标
func (ds *CalcDistanceAndDryCtrlRate) toECEF(lat, lng, alt float64) (x, y, z float64) {
	phi := lat * math.Pi / 180.0    // 纬度转换为弧度
	lambda := lng * math.Pi / 180.0 // 经度转换为弧度
	radius := ds.EarthRadius + alt

	x = radius * math.Cos(phi) * math.Cos(lambda)
	y = radius * math.Cos(phi) * math.Sin(lambda)
	z = radius * math.Sin(phi)
	return
}

// distance 计算两个地理坐标点之间的空间距离（单位：米）
func (ds *CalcDistanceAndDryCtrlRate) distance(lat1, lng1, alt1, lat2, lng2, alt2 float64) float64 {
	// 转换为 ECEF 坐标
	x1, y1, z1 := ds.toECEF(lat1, lng1, alt1)
	x2, y2, z2 := ds.toECEF(lat2, lng2, alt2)

	// 计算欧几里得距离
	d := math.Sqrt(math.Pow(x2-x1, 2) + math.Pow(y2-y1, 2) + math.Pow(z2-z1, 2))
	return d
}

// calcDistanceDryCtrlRatWithObj 计算单个设备到目标距离和干控比值
func (ds *CalcDistanceAndDryCtrlRate) calcDistanceDryCtrlRatWithObj(device *device_manager.DeviceDetail, obj *pb.CounterMeasureRecommendRequest) {
	if device == nil {
		return
	}

	if obj == nil {
		device.DistanceValue = math.MaxFloat64 // 默认是一个很大的距离
		device.DistanceValid = false
		device.IsHasDryCtrlRat = false
		logger.Errorf("uav obj is nil")
		return
	}
	var (
		devLat      float64
		devLng      float64
		devAlt      float64
		maxDistance float64 = math.MaxFloat64
	)

	device.DistanceValid = false
	device.IsHasDryCtrlRat = false
	if device.DeviceType == device_manager.DevTypeSfl100FromHeatBeat {
		devLat, devLng, devAlt = device.Sfl100Info.GetGunLatitude(), device.Sfl100Info.GetGunLongitude(), float64(device.Sfl100Info.GetGunAltitude())
		maxDistance = 3 * 1000 // 3km

	} else if device.DeviceType == device_manager.DevTypeSfl200FromHeatBeat {
		devLat, devLng, devAlt = device.Sfl200Info.GetGunLatitude(), device.Sfl200Info.GetGunLongitude(), device.Sfl200Info.GetGunAltitude()
		maxDistance = 3 * 1000 // 3km;

	} else if device.DeviceType == device_manager.DevTypeSpooferFromHeartBeat {
		devLat, devLng, devAlt = device.SpooferInfo.GetLatitude(), device.SpooferInfo.GetLongitude(), device.SpooferInfo.GetHeight()
		maxDistance = 2 * 1000 // 2km

	} else if device.DeviceType == device_manager.DevTypeDjRemoteControlFromRcUav {
		devLat, devLng, devAlt = device.DjUavInfo.GetLatitude(), device.DjUavInfo.GetLongitude(), 0
		maxDistance = 10 * 1000 // 10km;
	} else {
		logger.Errorf("not support device type: %s in calc distance.", device.DeviceType)
		return
	}
	if device.DeviceType == device_manager.DevTypeDjRemoteControlFromRcUav {
		device.DistanceValue = ds.distance(obj.GetPilotLongitude(), obj.GetPilotLongitude(), 0, devLat, devLng, devAlt)
		device.DistanceValid = true
		device.IsHasDryCtrlRat = false
		if (obj.GetPilotLongitude() == 0 && obj.GetPilotLatitude() == 0) || (obj.GetPilotLongitude() < 0.1 && obj.GetPilotLatitude() < 0.1) {
			device.DistanceValid = false
		}
		if obj.Sn == "" {
			device.DistanceValid = false
		}
		return
	} else {
		device.DistanceValue = ds.distance(obj.GetLatitude(), obj.GetLongitude(), obj.GetAltitude(), devLat, devLng, devAlt)
	}

	logger.Infof("calc distance: %v, maxDistance: %v; obj [lat, lng, alt] => [%v, %v, %v], device [lat, lng, alt] => [%v, %v, %v], devSn: %v, devType: %v, obj sn: %v",
		device.DistanceValue, maxDistance, obj.GetLatitude(), obj.GetLongitude(), obj.GetAltitude(), devLat, devLng, devAlt, device.GetSn(), device.DeviceType, obj.GetSn())

	if device.DistanceValue <= maxDistance {
		device.DistanceValid = true
		logger.Infof("calc distance: %v, valid distance: %v, devSn: %v", device.DistanceValue, device.DistanceValid, device.GetSn())
	} else {
		device.DistanceValid = false
		logger.Infof("calc distance: %v, valid distance: %v, devSn: %v", device.DistanceValue, device.DistanceValid, device.GetSn())
	}

	// 飞手经纬度不存在， 不用计算干控比
	if (obj.GetPilotLongitude() <= 0.0000001 && obj.GetPilotLongitude() > -0.0000001) && (obj.GetPilotLatitude() <= 0.0000001 && obj.GetPilotLatitude() > -0.0000001) {
		device.IsHasDryCtrlRat = false
	} else {
		device.IsHasDryCtrlRat = true
		// spoofer 不再计算干控比
		if device.DeviceType == device_manager.DevTypeSpooferFromHeartBeat {
			device.IsHasDryCtrlRat = false
			logger.Infof("spoofer need not to calc dry ctrl rate, devSn: %v", device.GetSn())

		} else if device.DistanceValid == true {
			device.IsHasDryCtrlRat = true
			logger.Infof("device distance is valid, can calc dry ctrl rate, devSn: %v", device.GetSn())

		} else {
			device.IsHasDryCtrlRat = false
			logger.Infof("device is outside of detect scope, not calc dry ctrl rate, devSn: %v", device.GetSn())
		}
	}

	if device.IsHasDryCtrlRat == true {
		dryCtrlDistance := ds.distance(obj.GetLatitude(), obj.GetLongitude(), obj.GetAltitude(), obj.GetPilotLatitude(), obj.GetPilotLongitude(), 0)
		if dryCtrlDistance != 0.0 {
			device.DryCtrlRat = device.DistanceValue / dryCtrlDistance
		}
		logger.Infof("calc dry ctrl rat: %f, objToDevDistance: %v, dryCtrlDistance: %v, devSn: %v, devType: %v",
			device.DryCtrlRat, device.DistanceValue, dryCtrlDistance, device.GetSn(), device.DeviceType)
	}
	return
}

// Calc 计算无人机到多个设备间距离和干控比值
func (ds *CalcDistanceAndDryCtrlRate) Calc() []*device_manager.DeviceDetail {
	if ds == nil {
		return nil
	}
	for index, _ := range ds.deviceList {
		if ds.deviceList[index] == nil {
			continue
		}
		ds.calcDistanceDryCtrlRatWithObj(ds.deviceList[index], ds.uavInfo)
	}
	return ds.deviceList
}
