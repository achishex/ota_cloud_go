package counter_recommend

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/infra/clients/http_clients"
	"fmt"
	"sort"
	"time"
)

var _ CounterRecallInterface = (*counterRecallOnCache)(nil)
var _ CounterRecallInterface = (*counterRecallRpcImpl)(nil)

var RecallRpcHttpClientHandle http_clients.HttpClientRpcType[DevListReq, DevListResponse] = http_clients.HttpClientCallTpl[DevListReq, DevListResponse]

// CounterRecallInterface 召回通用接口
type CounterRecallInterface interface {
	Recall(ctx context.Context, tbCode string) ([]*device_manager.DeviceDetail, error)
	Name() string
}

// CounterRecallOnCache 从本地缓存召回在线设备详情
type counterRecallOnCache struct {
	devicesMng *device_manager.DeviceManager
}

func NewCounterRecallOnCacheHandle(rds redis.SkyFendRedisOps) CounterRecallInterface {
	return &counterRecallOnCache{
		devicesMng: device_manager.NewDeviceManager(device_manager.WithDevManagerRedisClient(rds)),
	}
}

// Recall 召回 tbcode 下所有在线设备信息
func (cr *counterRecallOnCache) Recall(ctx context.Context, tbCode string) ([]*device_manager.DeviceDetail, error) {
	recallBeginTm := time.Now()
	defer func() {
		logger.Infof("recall cost time: %v ms, tbCode: %v, recall name: %v", time.Since(recallBeginTm).Milliseconds(), tbCode, cr.Name())
	}()
	if cr == nil || cr.devicesMng == nil {
		logger.Errorf("redis handle is nil or recall obj is nil, tbCode: %v", tbCode)
		return nil, fmt.Errorf("redis handle is nil")
	}

	devList, err := cr.devicesMng.GetAllOnlineDeviceOnTbCode(tbCode)
	if err != nil {
		logger.Errorf("recall all online device fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}
	if len(devList) == 0 {
		logger.Infof("recall device list is empty, tbCode: %v", tbCode)
		return nil, nil
	}
	for _, item := range devList {
		if item == nil {
			continue
		}
		logger.Infof("recall device from cache, sn: %v, detail: %+v", item.GetSn(), item)
	}
	return devList, nil
}
func (cr *counterRecallOnCache) Name() string {
	return "recall_on_cache"
}

// counterRecallRpcImpl 从rpc 召回设备详细列表
type counterRecallRpcImpl struct {
	recallUrl string
	c2Sn      string
}

// NewCounterRecallRpc 创建对象
func NewCounterRecallRpc(url string, c2Sn string) CounterRecallInterface {
	return &counterRecallRpcImpl{
		recallUrl: url,
		c2Sn:      c2Sn,
	}
}

func (cr *counterRecallRpcImpl) Recall(ctx context.Context, tbCode string) ([]*device_manager.DeviceDetail, error) {
	rpcBeginTime := time.Now()
	defer func() {
		logger.Infof("recall rpc cost ms: %v, tbCode: %v, recall name: %v", time.Since(rpcBeginTime).Milliseconds(), tbCode, cr.Name())
	}()

	var (
		reqItemList          = new(DevListReqItem)
		maxRecallNums uint32 = 300
	)

	reqItemList.TbCode = tbCode
	reqListBody := &DevListReq{
		PageIndex: 0,
		PageSize:  maxRecallNums,
		Data:      reqItemList,
	}

	responseItemList, err := RecallRpcHttpClientHandle(context.Background(), reqListBody, http_clients.WithTimeOut(100*time.Millisecond), http_clients.WithUrl(cr.recallUrl))
	if err != nil {
		logger.Errorf("recall devList detail fail, err: %v, tbCode: %v", err, tbCode)
		return nil, nil
	}

	if responseItemList.ErrCode != 0 {
		logger.Errorf("recall devlist detail fail, err: %v, errcode: %v", responseItemList.ErrMessage, responseItemList.ErrCode)
		return nil, nil
	}
	logger.Infof("tbCode: %v, to recall dev nums: %v; rpc recall device list nums: %v,", tbCode, maxRecallNums, len(responseItemList.Data.ItemDataList))

	// key 是 devSn
	snInfoList := make(map[string]*DeviceListItem)

	tmpData := responseItemList.Data.ItemDataList
	SortDeviceListByParentSn(tmpData)
	responseItemList.Data.ItemDataList = tmpData

	for index, _ := range responseItemList.Data.ItemDataList {
		dev := responseItemList.Data.ItemDataList[index]
		if dev.Sn == "" {
			continue
		}

		logger.Infof("recall by rpc, item: %+v", dev)

		//if dev.C2SN != cr.c2Sn {
		//	continue
		//}

		if dev.Online == 0 {
			continue
		}

		snInfoList[dev.Sn] = &dev
	}

	var devList []*device_manager.DeviceDetail
	for sn, snInfo := range snInfoList {
		var (
			isHitFlag  = false
			devTypeStr = ""
		)

		switch snInfo.Etype {
		case "Sfl":
			isHitFlag, devTypeStr = true, device_manager.DevTypeSfl100FromHeatBeat

		case "Sfl200":
			isHitFlag, devTypeStr = true, device_manager.DevTypeSfl200FromHeatBeat

		case "radar", "Agx", "DroneID":
			isHitFlag = false
		case "Spoofer":
			isHitFlag, devTypeStr = true, device_manager.DevTypeSpooferFromHeartBeat

		default:
			isHitFlag = false
		}
		if isHitFlag == false {
			continue
		}
		devItem := &device_manager.DeviceDetail{
			DevName:     snInfo.Name,
			ParentSn:    snInfo.ParentSn,
			C2Sn:        snInfo.C2SN,
			RpcDeviceSn: sn,
			DeviceType:  devTypeStr,
		}
		devList = append(devList, devItem)
	}
	//
	for _, dev := range devList {
		if dev == nil {
			continue
		}

		logger.Infof("recall device sn: %v, dev: +v", dev.RpcDeviceSn, *dev)
	}
	return devList, nil
}
func (cr *counterRecallRpcImpl) Name() string {
	return "recall_rpc"
}

// DevListReqItem request info 关键字段
type DevListReqItem struct {
	// c2 sn list ,为空时查全部
	C2SnList []string `json:"c2SnList"`
	// device sn list 为空时查全部
	EquipSnList []string `json:"equipSnList"`
	// tb code
	TbCode string `json:"tbCode"`
	// 名称或列表模糊查询值
	SearchValue string `json:"searchValue"`
}

// DevListReq 分页请求设备信息
type DevListReq struct {
	PageIndex uint32          `json:"pageIndex"`
	PageSize  uint32          `json:"pageSize"`
	Data      *DevListReqItem `json:"data"`
}

// DeviceListItem response items...
// DeviceListItem 设备基本信息字段
type DeviceListItem struct {
	ID             int64  `json:"id"` //1
	C2SN           string `json:"c2Sn"`
	C2Name         string `json:"c2Name"` //1
	Sn             string `json:"sn"`
	Name           string `json:"name"`
	Etype          string `json:"etype"`
	Enable         int32  `json:"enable"` //1
	Online         int32  `json:"online"`
	Electricity    int32  `json:"electricity"`    //1
	WorkStatus     int32  `json:"workStatus"`     //1
	RadarRelevance int32  `json:"radarRelevance"` //1
	ParentSn       string `json:"parentSn"`
}

type RpcRecallDeviceList []DeviceListItem

func (s RpcRecallDeviceList) Len() int           { return len(s) }
func (a RpcRecallDeviceList) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a RpcRecallDeviceList) Less(i, j int) bool { return a[i].ParentSn < a[j].ParentSn }

// SortDeviceListByParentSn 按父sn做初级排序
func SortDeviceListByParentSn(devList RpcRecallDeviceList) {
	sort.SliceStable(RpcRecallDeviceList(devList), func(i, j int) bool {
		if devList[i].ParentSn > devList[j].ParentSn {
			return false
		}
		return true
	})
}

// DevListRespItem 设备获取消息
type DevListRespItem struct {
	ItemDataList []DeviceListItem `json:"data"`
	Total        int32            `json:"total"`
	PageIndex    int32            `json:"pageIndex"`
	PageSize     int32            `json:"pageSize"`
}

// DevListResponse 设备获取信息回包
type DevListResponse struct {
	ErrCode    int32           `json:"errorCode"`
	ErrMessage string          `json:"errorMessage"`
	Data       DevListRespItem `json:"data"`
}
