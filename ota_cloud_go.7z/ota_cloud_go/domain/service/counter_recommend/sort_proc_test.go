package counter_recommend

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/device_manager"
	pb "cuav-cloud-go-service/proto"
	"testing"
)

func TestSortImplWithNoPilotInfo(t *testing.T) {
	mock.LoggerMock()

	uavInfo := &pb.CounterMeasureRecommendRequest{
		Longitude:      114.00265641775967,
		Latitude:       22.597,
		Altitude:       200,
		PilotLatitude:  113.998,
		PilotLongitude: 22.597,
	}
	devList := []*device_manager.DeviceDetail{
		&device_manager.DeviceDetail{
			DeviceType: "/ws/v1/device/nsf4000/heart",
			SpooferInfo: &pb.Nsf4000HeartData{
				Sn:        "spoofer_1",
				Latitude:  22.596999999999337,
				Longitude: 114.02722176207851,
				Height:    0,
			},
		},
		&device_manager.DeviceDetail{
			DeviceType: "/ws/v1/device/sfl/heart",
			Sfl100Info: &pb.SflHeartData{
				Sn:           "sfl100_1",
				GunLatitude:  22.596999999999337,
				GunLongitude: 114.02722176207851,
				GunAltitude:  0.0,
			},
		},
	}
	devListSort := NewCalcDistanceAndDryCtrlRate(uavInfo, devList).Calc()
	for _, dev := range devListSort {
		if dev == nil {
			continue
		}
		t.Logf("sort dev item: %+v", *dev)
	}

}
