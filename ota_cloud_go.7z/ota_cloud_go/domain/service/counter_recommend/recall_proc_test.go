package counter_recommend

import (
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/repository/redis"
	dm "cuav-cloud-go-service/domain/service/device_manager"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"google.golang.org/protobuf/proto"
	"testing"
	"time"
)

var (
	test_tbCode = "test:tb_code:1"
)

func TestSortSliceDevByName(t *testing.T) {
	deviceList := []DeviceListItem{
		DeviceListItem{
			Sn:       "1111",
			ParentSn: "uva8123",
		},
		DeviceListItem{
			Sn:       "2222",
			ParentSn: "34234",
		},
		DeviceListItem{
			Sn:       "7777",
			ParentSn: "Baif",
		},
		DeviceListItem{
			Sn:       "8888",
			ParentSn: "",
		},
		DeviceListItem{
			Sn:       "3333",
			ParentSn: "fghdfghd",
		},
		DeviceListItem{
			Sn:       "44444",
			ParentSn: "baif",
		},
		DeviceListItem{
			Sn:       "55555",
			ParentSn: "ht45aif",
		},
		DeviceListItem{
			Sn:       "8888",
			ParentSn: "",
		},
	}
	SortDeviceListByParentSn(RpcRecallDeviceList(deviceList))
	for _, v := range deviceList {
		t.Logf("%+v", v)
	}
}

func writeDataToCache(t *testing.T) redis.SkyFendRedisOps {
	mock.LoggerMock()

	c := redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
		redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))
	if c == nil {
		t.Logf("init redis handle fail")
		return nil
	}

	deviceHandle := dm.NewDeviceManager(dm.WithDevManagerExp(5*time.Second), dm.WithDevManagerRedisClient(c))

	{
		firstDeviceSn := 5555555 //time.Now().UnixMilli()
		spooferOne := &pb.Nsf4000HeartData{
			Sn:         fmt.Sprintf("spoofer_%v", firstDeviceSn),
			WorkStatus: 30000,
			CreateTime: time.Now().UnixMilli(),
		}
		t.Logf("now: %v", time.Now().UnixMilli())
		data1, err := proto.Marshal(spooferOne)
		if err != nil {
			t.Logf("marshal spoofer fail, err: %v", err)
			return nil
		}
		if len(data1) == 0 {
			t.Logf("marshal sfl200 is empty")
			return nil
		}

		devTypeTest := dm.DevTypeSpooferFromHeartBeat
		devStatus := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data1,
			C2Sn:    "c2sn_1111111",
		}
		//
		time.Sleep(time.Duration(500) * time.Millisecond)
		//
		secondDeviceSn := 66666666 //time.Now().UnixMilli()
		spooferTwo := &pb.Nsf4000HeartData{
			Sn:         fmt.Sprintf("spoofer_%v", secondDeviceSn),
			WorkStatus: 10000,
			CreateTime: time.Now().UnixMilli(),
		}
		data2, err := proto.Marshal(spooferTwo)
		devStatus2 := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data2,
			C2Sn:    "c2sn_22222",
		}
		devStatusMsg := &pb.DevStatusSyncMsg{
			TbCode:  test_tbCode,
			DevInfo: make([]*pb.DevStatusInfo, 0),
		}

		devStatusMsg.DevInfo = append(devStatusMsg.DevInfo, devStatus, devStatus2)
		toWriteDataOne := &pb.DevStatusSyncRequest{
			Items: make(map[string]*pb.DevStatusSyncMsg),
		}
		toWriteDataOne.Items[test_tbCode] = devStatusMsg
		err = deviceHandle.WriteToCache(toWriteDataOne)
		if err != nil {
			t.Logf("write data to cache fail, err: %v", err)
		} else {
			t.Logf("write data to cache succ.")
		}
		t.Logf("tbcode: %v, Write spoofer sn: %v, sn: %v", test_tbCode, firstDeviceSn, secondDeviceSn)

		t.Logf("--------------------- get device cache -------------------")
		queryDeviceDetailList, err := deviceHandle.GetAllOnlineDeviceOnTbCode(test_tbCode)
		if err != nil {
			t.Logf("get device detail fail, err: %v", err)
		} else {

			t.Logf("-------------> print cache.")
			for _, deviceDetail := range queryDeviceDetailList {
				if deviceDetail == nil {
					continue
				}
				t.Logf("device sn: %v,  detail value: %+v", deviceDetail.GetSn(), deviceDetail)
				if deviceDetail.DeviceType == devTypeTest {
					t.Logf("spoofer stat data: %+v", deviceDetail.SpooferInfo)
				}
			}
		}
	}
	return c
}
func TestWriteDataToCache(t *testing.T) {
	c := writeDataToCache(t)
	if c == nil {
		t.Logf("write data to fail")
		return
	}
	t.Logf("-----------------call recall -------------------")
	//deviceList, err := NewCounterRecallHandle(c).Recall(context.Background(), test_tbCode)
	//if err != nil {
	//	t.Logf("recall fail, err: %v", err)
	//} else {
	//	for _, devItem := range deviceList {
	//		if devItem == nil {
	//			continue
	//		}
	//		t.Logf("recall device list: %+v", devItem)
	//	}
	//
	//}

}
