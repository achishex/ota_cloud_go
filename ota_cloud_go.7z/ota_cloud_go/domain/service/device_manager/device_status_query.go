package device_manager

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/infra/clients/http_clients"
	"encoding/json"
	"fmt"
	"reflect"
	"time"
)

const (
	SFL_QUERY_Conf = 9 // 获取sfl配置
)

const ()

// ////
// ////
// // 定义查询请求 request body 和 response body 的公共结构体
// ///
type PayLoadInfo struct {
	Sn string `json:"sn"` //设备sn
	//其他的也可以加
}
type DataInInfo struct {
	OpsCode int32       `json:"opsCode"`
	PayLoad PayLoadInfo `json:"payload"`
}

// StatusQueryIn 状态查询请求值
type StatusQueryIn struct {
	C2Sn string      `json:"c2Sn"`
	Type string      `json:"type"` //设备类型
	Data *DataInInfo `json:"data"`
}

// /////////////////
type DataOutInfo struct {
	Tid       string     `json:"tid"`
	Bid       string     `json:"bid"`
	Timestamp int64      `json:"timestamp"`
	Sn        string     `json:"sn"`
	MsgData   MsgDataOut `json:"msgData"`
}
type ResultOut struct {
	ErrorCode int    `json:"errorCode"`
	ErrorMsg  string `json:"errorMsg"`
}
type MsgDataOut struct {
	Result ResultOut `json:"result"`
	Data   any       `json:"data"`
}

// StatusQueryOut 状态查询返回值
type StatusQueryOut struct {
	ErrorCode    int          `json:"errorCode"`
	ErrorMessage any          `json:"errorMessage"`
	Data         *DataOutInfo `json:"data"`
}

// /////////////////////////////////////////////////////////////////////////////

var statusQueryHandleType http_clients.HttpClientRpcType[StatusQueryIn, StatusQueryOut] = http_clients.HttpClientCallTpl[StatusQueryIn, StatusQueryOut]

// ParseResponse 解析请求的回包
func ParseResponse(in *StatusQueryIn, response *StatusQueryOut) (any, error) {
	if response == nil {
		logger.Errorf("query opcode: %v, device type: %v response is nil", in.Data.OpsCode, in.Type)
		return nil, fmt.Errorf("query fail")
	}

	if response.ErrorCode != 0 {
		logger.Errorf("query opcode: %v, device type: %v, fail, errmsg: %v", in.Data.OpsCode, in.Type, response.ErrorMessage)
		return nil, fmt.Errorf("query fail")
	}

	if response.Data == nil {
		logger.Errorf("query opcode: %v, device type: %v response data is nil", in.Data.OpsCode, in.Type)
		return nil, fmt.Errorf("query fail")
	}
	return response.Data.MsgData.Data, nil
}

// DeviceStatusQueryHandler 设备状态查询请求
type DeviceStatusQueryHandler struct {
	uri     string
	host    string
	timeOut time.Duration //
}

// NewDeviceStatusQueryHandler 创建一个请求句柄; use with option design.
func NewDeviceStatusQueryHandler(host string) *DeviceStatusQueryHandler {
	if host != "" {
		return &DeviceStatusQueryHandler{
			host:    host,
			uri:     "/inner/rest/v1/device/services/get",
			timeOut: 5 * time.Second,
		}
	}

	return &DeviceStatusQueryHandler{
		host:    "http://cuav-cloud-access-service:8883",
		uri:     "/inner/rest/v1/device/services/get",
		timeOut: 5 * time.Second,
	}
}

// SflStatusQuery sfl 查询属性对象
type SflStatusQuery struct {
	*DeviceStatusQueryHandler
	c2Sn   string
	opCode int32 //默认使用过9
	sn     string
}

// SflStatusQueryResposeMsg response的具体业务数据
type SflStatusQueryResposeMsg struct {
	Sn            string `json:"sn"`            //设备标识
	HitTime       int32  `json:"hitTime"`       //打击时长 单位秒
	HitPitch1     int32  `json:"hitPitch1"`     //打击起始俯仰角
	HitPitch2     int32  `json:"hitPitch2"`     //打击终止俯仰角
	HitAngleBegin int32  `json:"hitAngleBegin"` //打击范围起始角度
	HitAngleEnd   int32  `json:"hitAngleEnd"`   //打击范围终止角度
	HitMode       int32  `json:"hitMode"`       // 2：打击飞控图传 (Normal);3：打击GNSS, 4：打击飞控图传 + 打击GNSS; 14：打击FPV ; 128: 打击全频段; 129：打击全频段+GNSS
}

//func (m *SflStatusQueryResposeMsg) Marshal() ([]byte, error) {
//	if m == nil {
//		return nil, fmt.Errorf("obj is nil")
//	}
//
//	return json.Marshal(m)
//}
//func (m *SflStatusQueryResposeMsg) Unmarshal(data []byte, v any) error {
//	return json.Unmarshal(data, m)
//}

// NewSflStatusQueryHandle 创建一个句柄， 调用 Query rpc 调用
func NewSflStatusQueryHandle(c2Sn, deviceSn string, opCode int32, host string) *SflStatusQuery {
	return &SflStatusQuery{
		c2Sn:                     c2Sn,
		sn:                       deviceSn,
		opCode:                   opCode,
		DeviceStatusQueryHandler: NewDeviceStatusQueryHandler(host),
	}
}

// 使用反射将 map 转换为 struct
func mapToStruct(data map[string]interface{}, result interface{}) {
	rv := reflect.ValueOf(result).Elem()
	rt := rv.Type()

	for key, value := range data {
		for i := 0; i < rt.NumField(); i++ {
			field := rt.Field(i)
			if field.Name == key {
				fieldValue := rv.FieldByName(key)
				if fieldValue.CanSet() {
					fieldValue.Set(reflect.ValueOf(value))
				}
			}
		}
	}
}

// Query sfl 状态查询具体接口
func (sfl *SflStatusQuery) Query() (*SflStatusQueryResposeMsg, error) {
	in := &StatusQueryIn{
		C2Sn: sfl.c2Sn,
		Type: "Sfl",
		Data: &DataInInfo{
			OpsCode: sfl.opCode,
			PayLoad: PayLoadInfo{
				Sn: sfl.sn,
			},
		},
	}

	response, err := statusQueryHandleType(context.Background(), in, http_clients.WithBaseUrl(sfl.host), http_clients.WithUrl(sfl.uri), http_clients.WithTimeOut(sfl.timeOut))
	if err != nil {
		logger.Errorf("query opcode: %v, query device type: %v, err: %v", in.Data.OpsCode, in.Type, err)
		return nil, err
	}

	data, err := ParseResponse(in, response)
	if err != nil {
		return nil, err
	}

	switch v := data.(type) {
	case map[string]any:
		s1, _ := json.Marshal(v)
		logger.Infof("is map.")
		queryRet := &SflStatusQueryResposeMsg{}
		json.Unmarshal(s1, queryRet)

		return queryRet, nil
	case *SflStatusQueryResposeMsg:
		queryRet := v
		return queryRet, nil
	default:

		logger.Errorf("response data msgData data not *SflStatusQueryMsg, query opcode: %v, device type: %v", in.Data.OpsCode, in.Type)
		return nil, fmt.Errorf("query fail")

	}

	return nil, fmt.Errorf("not exist result.")
}

type SFl200StatusQuery struct {
}

func (sfl *SFl200StatusQuery) Query() error {
	return nil
}

type SpooferStatusQuery struct {
}

func (sfl *SpooferStatusQuery) Query() error {
	return nil
}
