package device_manager

import (
	"context"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/repository/redis"
	"errors"
	"fmt"
	"testing"
	"time"
)

func TestGetOnlineDeviceDetail(t *testing.T) {
	mock.LoggerMock()

	for {
		rds := redis.NewSkyFendRedisClient(
			redis.WithRedisAddrOpt(fmt.Sprintf("%v:%d", "cuav-base-redis", 6379)), // 10.240.34.36  30356  cuav-base-redis 6379
			redis.WithRedisDB(15),
			redis.WithRedisPasswd("ZAQ!2wsx"))

		//NewDeviceManager(WithDevManagerRedisClient(rds))
		devDetailCacheKey := GetDeviceDetailRedisKey("000003", "sfl200-1421723011464")
		_, err := rds.Get(devDetailCacheKey)
		if err != nil {
			if errors.Is(err, redis.RETNil) {
				fmt.Printf("not exist device detail for key: %v\n", devDetailCacheKey)

				tmRet := rds.GetRedisRow().PTTL(context.Background(), devDetailCacheKey)
				if tmRet.Val() < 0 {
					fmt.Printf("expire tm: %v,key: %v", tmRet.Val(), devDetailCacheKey)
				}

			} else {
				fmt.Printf("get online device detail to cache fail, %v", err)
			}
		}
		time.Sleep(1 * time.Second)

	}

}
