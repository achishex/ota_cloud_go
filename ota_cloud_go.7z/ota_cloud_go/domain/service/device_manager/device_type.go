package device_manager

import "strconv"

type DeviceType uint8 //设备类型
func (d *DeviceType) ToString() string {
	return "deviceType: " + strconv.Itoa(int(*d))
}

// 类型参考c2定义；和c2 保持一致
const (
	//反制枪
	DEV_AEAG DeviceType = 1
	//屏幕
	DEV_SCREEN DeviceType = 2
	//雷达
	DEV_RADAR DeviceType = 3
	//PC端服务
	DEV_PC DeviceType = 4
	//C2 蓝牙
	DEV_C2_BLE DeviceType = 5
	//C2 WiFi
	DEV_C2_WIFI DeviceType = 6
	//C2 droneID
	DEV_V2DRONEID DeviceType = 7
	// DEV_URD360 Urd360
	DEV_URD360 DeviceType = 8
	//NSF4000 cheater
	DEV_NSF4000 DeviceType = 9
	//小枪
	Dev_Blader DeviceType = 10

	//C2_Sfl 云台
	DEV_SFL DeviceType = 11
	//C2_AGX_雷达融合平台
	DEV_AGX DeviceType = 12
	//Sfl200
	DEV_SFL200 DeviceType = 13
	//C2_Fpv 车载
	DEV_FPV DeviceType = 0x17

	//spoofer 电量监测设备
	DEV_SPOOFER_MONITOR DeviceType = 0x18

	DEV_DJ_RemoteControl DeviceType = 99

	//广播模式
	DEV_BROADCAST DeviceType = 255
)

const (
	// DevTypeSfl100FromHeatBeat 根据心跳数据类型定义设备状态类型
	DevTypeSfl100FromHeatBeat = "/ws/v1/device/sfl/heart"
	// DevTypeSfl200FromHeatBeat 根据心跳数据类型定义设备状态类型
	DevTypeSfl200FromHeatBeat = "/ws/v1/device/sfl200/heart"
	// DevTypeSpooferFromHeartBeat 根据心跳数据类型定义设备状态类型
	DevTypeSpooferFromHeartBeat = "/ws/v1/device/nsf4000/heart"
	// DevTypeDjRemoteControlFromRcUav 根据心跳数据类型定义设备状态类型
	DevTypeDjRemoteControlFromRcUav = "/ws/v1/device/dj/rc/uav"
)

const (
	// 待机
	SFL_WORK_Status_UnReady uint32 = 0
	// 全向侦测
	SFL_WORK_Status_AllRound_Detect = 1
	// 定向侦测
	SFL_WORK_Status_Origent_Detect = 2
	// 定向成功
	SFL_WORK_Status_Origent_Succ = 3
	// 定向失败
	SFL_WORK_Status_Origent_Fail = 4
	// 打击飞控图传
	SFL_WORK_Status_Hit_AirControl = 5
	// 打击GNSS
	SFL_WORK_Status_Hit_GNSS = 6
	// 打击飞控图传 + 打击GNSS
	SFL_WORK_Status_Hit_GNSS_AirCtrl = 7
	// 打击FPV
	SFL_WORK_Status_Hit_Fpv = 8
	// 低电量不进行打击
	SFL_WORK_Status_DisHit_Low_Electric = 9
	// 高温不进行打击
	SFL_WORK_Status_DisHit_High_Temp = 10
	// 上电开机中
	SFL_WORK_Status_DisHit_PowerOning = 11
	//  关机
	SFL_WORK_Status_DisHit_PowwerOffing = 12
	// OTA
	SFL_WORK_Status_DisHit_OTA = 13
	// 云台自检
	SFL_WORK_Status_DisHit_SelfChecking = 14
	// 保留 15 - 19 之间
	SFL_WORK_Status_DisHit_Reserve1 = 15
	// 保留 15 - 19 之间
	SFL_WORK_Status_DisHit_Reserve5 = 19
	//允许进入定向
	SFL_WORK_Status_DisHit_Allow_Origent = 20
	//频率不在范围不允许进入定向
	SFL_WORK_Status_DisHit_OutFreq = 21
	//机型不支持进入定向
	SFL_WORK_Status_DisHit_UnSupported = 22
)
