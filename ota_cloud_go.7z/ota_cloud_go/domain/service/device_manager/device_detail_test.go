package device_manager

import (
	pb "cuav-cloud-go-service/proto"
	"google.golang.org/protobuf/proto"
	"testing"
)

func TestMarshUnMarshOnProto(t *testing.T) {
	var byteSrc *pb.SflHeartData = new(pb.SflHeartData)
	byteSrc.Sn = "111110"
	byteSrc.TracerFault = 123

	byteDst, err := proto.Marshal(byteSrc)
	if err != nil {
		t.Logf("format fail, err: %v", err)
	} else {
		pbDst, err := ParseData(byteDst, new(pb.SflHeartData))
		if err != nil {
			t.Logf("parse fail, err: %v", err)
		} else {
			t.Logf("parse data: %+v", pbDst)
		}
	}
}

func TestSortSliceDeviceDetail(t *testing.T) {
	deviceList := []*DeviceDetail{
		&DeviceDetail{
			DryCtrlRat:      10.0,
			IsHasDryCtrlRat: true,
			DistanceValue:   100.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DryCtrlRat:      0.0,
			IsHasDryCtrlRat: false,
			DistanceValue:   20.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DryCtrlRat:      50.0,
			IsHasDryCtrlRat: false,
			DistanceValue:   50.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DryCtrlRat:      30.45,
			IsHasDryCtrlRat: false, // true
			DistanceValue:   1.1,
			DistanceValid:   true,
		},
	}
	//
	SortDeviceListByValidDist(SliceDeviceDetail(deviceList))
	for _, v := range deviceList {
		t.Logf("%v", v.DistanceValue)
	}
	t.Logf("------- sort by dry ctrl rat, the less the fronted--------")
	SortDeviceListByDryCtrlRat(SliceDeviceDetail(deviceList))
	for _, v := range deviceList {
		t.Logf("%v, %v, dis: %v, hasDis: %v", v.DryCtrlRat, v.IsHasDryCtrlRat, v.DistanceValue, v.DistanceValid)
	}
}

func TestSortSliceDevByName(t *testing.T) {
	deviceList := []*DeviceDetail{
		&DeviceDetail{
			DevName:         "mn123",
			DryCtrlRat:      10.0,
			IsHasDryCtrlRat: true,
			DistanceValue:   100.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DevName:         "xpg",
			DryCtrlRat:      0.0,
			IsHasDryCtrlRat: false,
			DistanceValue:   20.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DevName:         "aasdfa",
			DryCtrlRat:      50.0,
			IsHasDryCtrlRat: false,
			DistanceValue:   50.1,
			DistanceValid:   true,
		},
		&DeviceDetail{
			DevName:         "r123123",
			DryCtrlRat:      30.45,
			IsHasDryCtrlRat: false, // true
			DistanceValue:   1.1,
			DistanceValid:   true,
		},
	}
	SortDeviceListByName(SliceDeviceNameList(deviceList))
	for _, v := range deviceList {
		t.Logf("%v", v.DevName)
	}
}
