package device_manager

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"google.golang.org/protobuf/proto"
	"testing"
	"time"
)

// TestSetGetCacheWithRepeatedDevice 测试设备状态读写缓存逻辑
func TestSetGetCacheWithRepeatedDevice(t *testing.T) {
	mock.LoggerMock()

	c := redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
		redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))
	if c == nil {
		t.Logf("init redis handle fail")
		return
	}

	deviceHandle := NewDeviceManager(WithDevManagerExp(50*time.Second), WithDevManagerRedisClient(c))
	{
		sfl200Detail1 := &pb.Sfl200SystemStateData{
			TimeStamp:  uint32(time.Now().UnixMilli()),
			Sn:         "sfl200_1",
			WorkStatus: 30000,
			CreateTime: time.Now().UnixMilli(),
		}
		t.Logf("timeStamp: %v, base: %v", sfl200Detail1.TimeStamp, time.Now().UnixMilli())
		data1, err := proto.Marshal(sfl200Detail1)
		if err != nil {
			t.Logf("marshal sfl200 fail, err: %v", err)
			return
		}
		if len(data1) == 0 {
			t.Logf("marshal sfl200 is empty")
			return
		}

		devTypeTest := DevTypeSfl200FromHeatBeat
		tbCode := "test:tb_code:1"
		devStatus := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data1,
			C2Sn:    "c2sn_1111111",
		}
		//
		sfl200Detail2 := &pb.Sfl200SystemStateData{
			TimeStamp:  uint32(time.Now().UnixMilli()),
			Sn:         "sfl200_1",
			WorkStatus: 10000,
			CreateTime: time.Now().UnixMilli(),
		}
		data2, err := proto.Marshal(sfl200Detail2)
		devStatus2 := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data2,
			C2Sn:    "c2sn_1010101",
		}
		devStatusMsg := &pb.DevStatusSyncMsg{
			TbCode:  tbCode,
			DevInfo: make([]*pb.DevStatusInfo, 0),
		}

		devStatusMsg.DevInfo = append(devStatusMsg.DevInfo, devStatus, devStatus2)
		toWriteDataOne := &pb.DevStatusSyncRequest{
			Items: make(map[string]*pb.DevStatusSyncMsg),
		}
		toWriteDataOne.Items[tbCode] = devStatusMsg
		err = deviceHandle.WriteToCache(toWriteDataOne)
		if err != nil {
			t.Logf("write data to cache fail, err: %v", err)
		} else {
			t.Logf("write data to cache succ.")
		}

		t.Logf("--------------------- get device cache -------------------")
		queryDeviceDetailList, err := deviceHandle.GetAllOnlineDeviceOnTbCode(tbCode)
		if err != nil {
			t.Logf("get device detail fail, err: %v", err)
		} else {

			t.Logf("-------------> print cache.")
			for _, deviceDetail := range queryDeviceDetailList {
				if deviceDetail == nil {
					continue
				}
				t.Logf("device sn: %v,  detail value: %+v", deviceDetail.GetSn(), deviceDetail)
				if deviceDetail.DeviceType == devTypeTest {
					t.Logf("sfl200 stat data: %+v", deviceDetail.Sfl200Info)
				}
			}
		}
	}
}

func TestSetGetCacheWithDiffDevice(t *testing.T) {
	mock.LoggerMock()

	c := redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
		redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))
	if c == nil {
		t.Logf("init redis handle fail")
		return
	}

	deviceHandle := NewDeviceManager(WithDevManagerExp(50*time.Second), WithDevManagerRedisClient(c))

	firstDeviceSn := time.Now().UnixMilli()
	{
		spooferOne := &pb.Nsf4000HeartData{
			Sn:         fmt.Sprintf("spoofer_%v", firstDeviceSn),
			WorkStatus: 30000,
			CreateTime: time.Now().UnixMilli(),
		}
		t.Logf("now: %v", time.Now().UnixMilli())
		data1, err := proto.Marshal(spooferOne)
		if err != nil {
			t.Logf("marshal spoofer fail, err: %v", err)
			return
		}
		if len(data1) == 0 {
			t.Logf("marshal sfl200 is empty")
			return
		}

		devTypeTest := DevTypeSpooferFromHeartBeat
		tbCode := "test:tb_code:1"
		devStatus := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data1,
			C2Sn:    "c2sn_1111111",
		}
		//
		time.Sleep(time.Duration(500) * time.Millisecond)
		//
		secondDeviceSn := time.Now().UnixMilli()
		spooferTwo := &pb.Nsf4000HeartData{
			Sn:         fmt.Sprintf("spoofer_%v", secondDeviceSn),
			WorkStatus: 10000,
			CreateTime: time.Now().UnixMilli(),
		}
		data2, err := proto.Marshal(spooferTwo)
		devStatus2 := &pb.DevStatusInfo{
			DevType: devTypeTest,
			DevItem: data2,
			C2Sn:    "c2sn_22222",
		}
		devStatusMsg := &pb.DevStatusSyncMsg{
			TbCode:  tbCode,
			DevInfo: make([]*pb.DevStatusInfo, 0),
		}

		devStatusMsg.DevInfo = append(devStatusMsg.DevInfo, devStatus, devStatus2)
		toWriteDataOne := &pb.DevStatusSyncRequest{
			Items: make(map[string]*pb.DevStatusSyncMsg),
		}
		toWriteDataOne.Items[tbCode] = devStatusMsg
		err = deviceHandle.WriteToCache(toWriteDataOne)
		if err != nil {
			t.Logf("write data to cache fail, err: %v", err)
		} else {
			t.Logf("write data to cache succ.")
		}
		t.Logf("Write spoofer sn: %v, sn: %v", firstDeviceSn, secondDeviceSn)

		t.Logf("--------------------- get device cache -------------------")
		queryDeviceDetailList, err := deviceHandle.GetAllOnlineDeviceOnTbCode(tbCode)
		if err != nil {
			t.Logf("get device detail fail, err: %v", err)
		} else {

			t.Logf("-------------> print cache.")
			for _, deviceDetail := range queryDeviceDetailList {
				if deviceDetail == nil {
					continue
				}
				t.Logf("device sn: %v,  detail value: %+v", deviceDetail.GetSn(), deviceDetail)
				if deviceDetail.DeviceType == devTypeTest {
					t.Logf("sfl200 stat data: %+v", deviceDetail.Sfl200Info)
				}
			}
		}
	}
}

func TestParseItemFromBin(t *testing.T) {
	originData := []byte{}
	xy := []int8{16, 0, 24, 0, 32, 0, 40, 0, 48, 0, 57, 0, 0, 0, 0, 0, 0, 0, 0, 65, 0, 0, 0, 0, 0, 0, 0, 0, 73, 0, 0, 0, 0, 0, 0, 0, 0, 80, 0, 88, 0, 96, 0, 104, 0, 112, 0, 120, 0, -128, 1, 0, -119, 1, 0, 0, 0, 0, 0, 0, 0, 0, -112, 1, 0}

	for _, v := range xy {
		originData = append(originData, byte(v))
	}

	spooferItem := &pb.Nsf4000HeartData{}
	err := proto.Unmarshal(originData, spooferItem)
	t.Logf("err: %v, data: %v", err, spooferItem)
}

func TestReturnCheck(t *testing.T) {
	//tbCode, devId := "000001", "SFL100-C001"

	var wg = routinues.NewRoutineGroupWrap()
	mock.LoggerMock()
	tbCode := "0000001"
	config.GlobalRedis = redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
		redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))

	wg.Run(func() {
		dmng := NewDeviceManager()
		for {
			sfl200Data := &pb.Sfl200SystemStateData{
				Sn: "sfl200-1111",
			}
			sfl100Data := &pb.SflHeartData{
				Sn: "sfl100-2222",
			}
			sfl200Pb, _ := proto.Marshal(sfl200Data)
			sfl100Pb, _ := proto.Marshal(sfl100Data)
			//
			data := &pb.DevStatusSyncRequest{}
			data.Items = make(map[string]*pb.DevStatusSyncMsg)
			data.Items[tbCode] = &pb.DevStatusSyncMsg{
				TbCode: tbCode,
				DevInfo: []*pb.DevStatusInfo{
					&pb.DevStatusInfo{
						DevType: DevTypeSfl200FromHeatBeat,
						DevItem: sfl200Pb,
						C2Sn:    "c2_sn_1",
					},
					&pb.DevStatusInfo{
						DevType: DevTypeSfl100FromHeatBeat,
						DevItem: sfl100Pb,
						C2Sn:    "c2_sn_1",
					},
				},
			}
			dmng.WriteToCache(data)
			time.Sleep(200 * time.Millisecond)
		}
	})

	time.Sleep(300 * time.Millisecond)
	wg.Run(func() {
		for {
			dmng := NewDeviceManager()
			data, err := dmng.GetAllOnlineDeviceOnTbCode(tbCode)
			if err != nil {
				t.Logf("get all device on tbcode fail, err: %v", err)
			} else {
				for _, item := range data {
					if item == nil {
						//
					} else {
						//t.Logf("data: %+v", item)
					}
				}
			}
			time.Sleep(1 * time.Second)
		}
	})

	time.Sleep(5 * time.Second)
	wg.Run(func() {
		for {
			item := config.GlobalRedis.GetRedisRow().PTTL(context.Background(), "online_device_detail:0000001:sfl100-2222")
			if item.Err() != nil {
				t.Logf("fail, err: %v", item.Err())

			} else if item.Val() < 0 {
				t.Logf("is expired, value: %v", item.Val())

			} else {
				//
			}
			item = config.GlobalRedis.GetRedisRow().PTTL(context.Background(), "online_device_detail:0000001:sfl200-1111")
			if item.Err() != nil {
				t.Logf("fail, err: %v", item.Err())

			} else if item.Val() < 0 {
				t.Logf("is expired, value: %+v", item.Val())

			} else {
			}
			time.Sleep(1 * time.Second)
		}
	})
	wg.Wait()
}
