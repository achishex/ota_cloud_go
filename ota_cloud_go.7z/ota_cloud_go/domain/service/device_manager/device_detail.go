package device_manager

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/infra/clients/http_clients"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"google.golang.org/protobuf/proto"
	"sort"
	"time"
)

// SubDevItem recall subType
type SubDevItem struct {
	Sn      string `json:"devSn"`
	DevType int32  `json:"devType"`
}

type SubDevItemList []*SubDevItem

func (sl SubDevItemList) String() string {
	ret := ""
	for _, item := range sl {
		if item == nil {
			continue
		}
		v, _ := json.Marshal(item)
		ret += fmt.Sprintf("%s", v)
	}
	return ret
}

// DeviceDetail 存放所有设备类型和设备详情数据 (逻辑中使用设备)
type DeviceDetail struct {
	// 这是从 缓存中获取到的设备信息
	// DeviceType 设备类型，比如：DevTypeSfl100FromHeatBeat; DevTypeSpooferFromHeartBeat; DevTypeSfl200FromHeatBeat；
	DeviceType string
	// 侦测设备对应的c2Sn
	C2Sn string
	// 侦测设备 名字
	DevName string

	// sfl200 设备详情
	Sfl200Info *pb.Sfl200SystemStateData
	// spoofer 设备详情
	SpooferInfo *pb.Nsf4000HeartData
	// sfl100 设备详情
	Sfl100Info *pb.SflHeartData
	//大疆无人机
	DjUavInfo *pb.DjRemoteControlUavData

	// 这是算法得到的数据
	// 干控比值； 该值比距离更加具有优先级
	DryCtrlRat float64
	// 是否是有干控比, true: 有，false: 没有。
	IsHasDryCtrlRat bool
	// 对象到设备的距离(经计算)， 设备属性不使用该字段
	DistanceValue float64
	// 距离是否有有效？ true: 有效， false: 无效, 设备属性不使用该字段
	DistanceValid bool

	// 这是从rpc 获取到的设备信息
	// 父设备的sn,如果存在父设备则填充（这是从rpc请求得到的设备列表）
	ParentSn string
	// 通过 rpc 召回的当前的device sn
	RpcDeviceSn string

	// SubDevItem 所有召回后，一个设备下面的子设备列表
	SubDevList []*SubDevItem
}

// GetSn 获取 sn
func (s *DeviceDetail) GetSn() string {
	if s == nil {
		return ""
	}
	if s.DeviceType == DevTypeSfl100FromHeatBeat {
		return s.Sfl100Info.GetSn()
	} else if s.DeviceType == DevTypeSfl200FromHeatBeat {
		return s.Sfl200Info.GetSn()
	} else if s.DeviceType == DevTypeSpooferFromHeartBeat {
		return s.SpooferInfo.GetSn()
	} else if s.DeviceType == DevTypeDjRemoteControlFromRcUav {
		return s.DjUavInfo.GetSn()
	} else {
	}
	return ""
}
func (s *DeviceDetail) GetTypeNums() int32 {
	switch s.DeviceType {
	case DevTypeSfl100FromHeatBeat:
		return 11

	case DevTypeSfl200FromHeatBeat:
		return 13

	case DevTypeSpooferFromHeartBeat:
		return 9

	default:
		return 0

	}
}

// SliceDeviceNameList
type SliceDeviceNameList []*DeviceDetail

func (s SliceDeviceNameList) Len() int           { return len(s) }
func (a SliceDeviceNameList) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a SliceDeviceNameList) Less(i, j int) bool { return a[i].DevName < a[j].DevName }

// SortDeviceListByName 按名字做初级排序
func SortDeviceListByName(devList SliceDeviceNameList) {
	sort.SliceStable(SliceDeviceDetail(devList), func(i, j int) bool {
		if devList[i].DevName > devList[j].DevName {
			return false
		}
		return true
	})
}

// SliceDeviceDetail 定义排序实现方法，需要测试
type SliceDeviceDetail []*DeviceDetail

func (s SliceDeviceDetail) Len() int           { return len(s) }
func (a SliceDeviceDetail) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a SliceDeviceDetail) Less(i, j int) bool { return a[i].DistanceValue < a[j].DistanceValue }

// SortDeviceListByValidDist 优先推荐在侦测范围内的设备，同时进入侦测范围，推荐距离更近的。不在侦测范围内， 也推荐距离更近的设备。
func SortDeviceListByValidDist(devList SliceDeviceDetail) {
	sort.SliceStable(SliceDeviceDetail(devList), func(i, j int) bool {
		if devList[i].DistanceValue > devList[j].DistanceValue {
			return false
		}
		return true
	})
	sort.SliceStable(SliceDeviceDetail(devList), func(i, j int) bool {
		if devList[i].DistanceValid == false {
			return false
		}
		if devList[j].DistanceValid == false {
			return true
		}
		if devList[i].DistanceValue > devList[j].DistanceValue {
			return false
		}
		return true
	})
}

func SortDeviceListByDryCtrlRat(devList SliceDeviceDetail) {
	sort.SliceStable(SliceDeviceDetail(devList), func(i, j int) bool {
		if devList[i].IsHasDryCtrlRat == false {
			return false
		}
		if devList[j].IsHasDryCtrlRat == false {
			return true
		}
		if devList[i].DryCtrlRat > devList[j].DryCtrlRat {
			return false
		}
		return true
	})
}

func GetDeviceTypeFromStr(devType string) int32 {
	if devType == DevTypeSpooferFromHeartBeat {
		return int32(DEV_NSF4000)
	} else if devType == DevTypeSfl200FromHeatBeat {
		return int32(DEV_SFL200)
	} else if devType == DevTypeSfl100FromHeatBeat {
		return int32(DEV_SFL)
	} else if devType == DevTypeDjRemoteControlFromRcUav {
		return int32(DEV_DJ_RemoteControl)
	}
	return 0
}

// CalcSpooferIsWork 计算是否可以工作
func CalcSpooferIsWork(deviceInfo *pb.Nsf4000HeartData) (bool, error) {
	if deviceInfo == nil {
		return false, fmt.Errorf("device is nil")
	}
	if deviceInfo.GetEnable() == true && deviceInfo.GetWorkStatus() == 1 && (deviceInfo.GetWorkMode() >= 1 && deviceInfo.GetWorkMode() <= 4) {
		logger.Infof("spoofer is working, devInfo: %+v", deviceInfo)
		return true, nil
	}

	return false, nil
}

// CalcSfl200IsHit 计算是否在打击中
func CalcSfl200IsHit(deviceInfo *pb.Sfl200SystemStateData) (bool, error) {
	if deviceInfo == nil {
		return false, fmt.Errorf("device is nil")
	}
	status := deviceInfo.WorkStatus
	if status == SFL_WORK_Status_UnReady ||
		status == SFL_WORK_Status_Hit_AirControl ||
		status == SFL_WORK_Status_Hit_GNSS ||
		status == SFL_WORK_Status_Hit_GNSS_AirCtrl ||
		status == SFL_WORK_Status_Hit_Fpv ||
		status == SFL_WORK_Status_DisHit_Low_Electric ||
		status == SFL_WORK_Status_DisHit_High_Temp ||
		status == SFL_WORK_Status_DisHit_PowerOning ||
		status == SFL_WORK_Status_DisHit_PowwerOffing ||
		status == SFL_WORK_Status_DisHit_OTA ||
		status == SFL_WORK_Status_DisHit_SelfChecking ||
		(status >= SFL_WORK_Status_DisHit_Reserve1 && status <= SFL_WORK_Status_DisHit_Reserve5) {

		logger.Infof("sfl200 is working, devInfo: %+v", deviceInfo)
		return true, nil
	}
	return false, nil
}

// CalcSfl100IsHit 计算是否在打击中
func CalcSfl100IsHit(deviceInfo *pb.SflHeartData) (bool, error) {
	status := uint32(deviceInfo.WorkStatus)
	if status == SFL_WORK_Status_UnReady ||
		status == SFL_WORK_Status_Hit_AirControl ||
		status == SFL_WORK_Status_Hit_GNSS ||
		status == SFL_WORK_Status_Hit_GNSS_AirCtrl ||
		status == SFL_WORK_Status_Hit_Fpv ||
		status == SFL_WORK_Status_DisHit_Low_Electric ||
		status == SFL_WORK_Status_DisHit_High_Temp ||
		status == SFL_WORK_Status_DisHit_PowerOning ||
		status == SFL_WORK_Status_DisHit_PowwerOffing ||
		status == SFL_WORK_Status_DisHit_OTA ||
		status == SFL_WORK_Status_DisHit_SelfChecking ||
		(status >= SFL_WORK_Status_DisHit_Reserve1 && status <= SFL_WORK_Status_DisHit_Reserve5) {

		logger.Infof("sfl100 is working, devInfo: %+v", deviceInfo)
		return true, nil
	}
	return false, nil
}

// CalcDjRemoteControlIsHit 计算是否在打击中
func CalcDjRemoteControlUavIsHit(deviceInfo *pb.DjRemoteControlUavData) (bool, error) {

	if deviceInfo.SerialNum != "" {
		logger.Infof("DjRemote is working, devInfo: %+v", deviceInfo)
		return true, nil
	}
	return false, nil
}

// AnalyseCounterDeviceFromDetail 从设备详情中获取推荐设备信息
func AnalyseCounterDeviceFromDetail(deviceDetail *DeviceDetail, body *pb.CounterMeasureRecommendRequest) *pb.CounterMeasureRecommendResponse {
	if deviceDetail == nil {
		return nil
	}

	var retDevice = new(pb.CounterMeasureRecommendResponse)
	retDevice.IsHitting = false

	retDevice.DevName = deviceDetail.DevName
	retDevice.C2Sn = deviceDetail.C2Sn
	retDevice.DevType = GetDeviceTypeFromStr(deviceDetail.DeviceType)
	for _, item := range deviceDetail.SubDevList {
		retDevice.SubDevList = append(retDevice.SubDevList, &pb.SubDevItem{
			DevSn:   item.Sn,
			DevType: item.DevType,
		})
	}

	devSitNode := new(geo.LonLatLocation)
	uavLonLat := new(geo.LonLatLocation)

	uavLonLat.Longitude = body.GetLongitude()
	uavLonLat.Latitude = body.GetLatitude()
	uavLonLat.Altitude = body.GetAltitude()

	if deviceDetail.DeviceType == DevTypeSpooferFromHeartBeat {
		retDevice.DevSn = deviceDetail.SpooferInfo.GetSn()

		isWork, err := CalcSpooferIsWork(deviceDetail.SpooferInfo)
		if err != nil || isWork == true {
			retDevice.IsHitting = true
			logger.Infof("spoofer is working, devSn: %v, heat beat: %+v", retDevice.DevSn, deviceDetail.SpooferInfo)
		}
		devSitNode.Longitude = deviceDetail.SpooferInfo.GetLongitude()
		devSitNode.Latitude = deviceDetail.SpooferInfo.GetLatitude()
		devSitNode.Altitude = deviceDetail.SpooferInfo.GetHeight()

	} else if deviceDetail.DeviceType == DevTypeSfl100FromHeatBeat {
		retDevice.DevSn = deviceDetail.Sfl100Info.GetSn()

		isWork, err := CalcSfl100IsHit(deviceDetail.Sfl100Info)
		if err != nil || isWork == true {
			retDevice.IsHitting = true
		}

		devSitNode.Longitude = deviceDetail.Sfl100Info.GetGunLongitude()
		devSitNode.Latitude = deviceDetail.Sfl100Info.GetGunLatitude()
		devSitNode.Altitude = float64(deviceDetail.Sfl100Info.GetGunAltitude())

	} else if deviceDetail.DeviceType == DevTypeSfl200FromHeatBeat {
		retDevice.DevSn = deviceDetail.Sfl200Info.GetSn()

		isWork, err := CalcSfl200IsHit(deviceDetail.Sfl200Info)
		if err != nil || isWork == true {
			retDevice.IsHitting = true
		}

		devSitNode.Longitude = deviceDetail.Sfl200Info.GetGunLongitude()
		devSitNode.Latitude = deviceDetail.Sfl200Info.GetGunLatitude()
		devSitNode.Altitude = deviceDetail.Sfl200Info.GetGunAltitude()
	} else if deviceDetail.DeviceType == DevTypeDjRemoteControlFromRcUav {
		retDevice.DevSn = deviceDetail.DjUavInfo.GetSn()

		CalcDjRemoteControlUavIsHit(deviceDetail.DjUavInfo)
		retDevice.IsHitting = false

		retDevice.RcSn = deviceDetail.DjUavInfo.RcSn
		retDevice.DevName = deviceDetail.DjUavInfo.DroneName
		devSitNode.Longitude = deviceDetail.DjUavInfo.GetLongitude()
		devSitNode.Latitude = deviceDetail.DjUavInfo.GetLatitude()
		return retDevice
	} else {
		return nil
	}

	agRet, _ := geo.CalcAngleByLocation(devSitNode, uavLonLat)
	if agRet != nil {
		retDevice.AzimuthAngle = agRet.AzimuthAngle
		retDevice.PitchAngle = agRet.PitchAngle
		retDevice.RadialDistance = agRet.RadialDistance
	}
	return retDevice
}

// ParseData 将 pb 二进制数据反序列化 成特定类型
func ParseData[T proto.Message](data []byte, message T) (T, error) {
	// 创建一个新的 msg 变量，使用 T 的类型
	var msg T = proto.Clone(message).(T)
	if err := proto.Unmarshal(data, msg); err != nil {
		return msg, err
	}
	return msg, nil
}

// TransToDeviceDetail 将 pb 协议转化具体的设备详情
func TransToDeviceDetail(deviceSrc *pb.DevStatusInfo) (*DeviceDetail, error) {
	if deviceSrc == nil {
		return nil, fmt.Errorf("src device info is nil")
	}

	// 设备详情数据
	var (
		err       error
		retDevice *DeviceDetail = new(DeviceDetail)
	)
	retDevice.DeviceType = deviceSrc.GetDevType()
	retDevice.C2Sn = deviceSrc.GetC2Sn()
	//retDevice.DevName = deviceSrc.GetDevName()

	if deviceSrc.DevType == DevTypeSpooferFromHeartBeat {
		retDevice.SpooferInfo, err = ParseData(deviceSrc.GetDevItem(), new(pb.Nsf4000HeartData))
		if err != nil {
			logger.Errorf("parse spoofer info from byte fail, err: %v", err)
			return nil, fmt.Errorf("parse spoofer from byte fail")
		}

	} else if deviceSrc.DevType == DevTypeSfl100FromHeatBeat {
		retDevice.Sfl100Info, err = ParseData(deviceSrc.GetDevItem(), new(pb.SflHeartData))
		if err != nil {
			logger.Errorf("parse sfl100 info from byte fail, err: %v", err)
			return nil, fmt.Errorf("parse sfl100 from byte fail")
		}

	} else if deviceSrc.DevType == DevTypeSfl200FromHeatBeat {
		retDevice.Sfl200Info, err = ParseData(deviceSrc.GetDevItem(), new(pb.Sfl200SystemStateData))
		if err != nil {
			logger.Errorf("parse Sfl200Info info from byte fail, err: %v", err)
			return nil, fmt.Errorf("parse Sfl200Info from byte fail")
		}

	} else if deviceSrc.DevType == DevTypeDjRemoteControlFromRcUav {
		retDevice.DjUavInfo, err = ParseData(deviceSrc.GetDevItem(), new(pb.DjRemoteControlUavData))
		if err != nil {
			logger.Errorf("parse DjRemote info from byte fail, err: %v", err)
			return nil, fmt.Errorf("parse DjRemote from byte fail")
		}

	} else {
		return nil, nil
	}
	return retDevice, nil
}

// DeviceDetailData 请求查询的条件字段
type DeviceDetailData struct {
	TbCode      string `json:"tbCode"`
	SiteCode    string `json:"siteCode"`
	C2Sn        string `json:"c2Sn"`
	Sn          string `json:"sn"`
	SearchValue string `json:"searchValue"`
}
type DeviceDetailRequest struct {
	PageIndex uint32            `json:"pageIndex"`
	PageSize  uint32            `json:"pageSize"`
	Data      *DeviceDetailData `json:"data"`
}

type DeviceDetailResponse[T any] struct {
	ErrorCode    int `json:"errorCode"`
	ErrorMessage any `json:"errorMessage"`
	Data         *T  `json:"data"`
}

type DeviceDetailItems[Y any] struct {
	PageIndex int   `json:"pageIndex"`
	PageSize  int   `json:"pageSize"`
	PageTotal int64 `json:"pageTotal"`
	Data      []*Y  `json:"data"`
}

type DeviceDetailItem struct {
	Id   int64  `json:"id"`
	Name string `json:"name"`
}

func GetDeviceDetail(tbCode string, c2Sn string, devSn string, beginIndex, pageSize int32) (string, error) {
	req := &DeviceDetailRequest{
		PageIndex: uint32(beginIndex),
		PageSize:  uint32(pageSize),
		Data: &DeviceDetailData{
			TbCode: tbCode,
			Sn:     devSn,
			C2Sn:   c2Sn,
		},
	}

	rsp, err := http_clients.HttpClientCallTpl[DeviceDetailRequest, DeviceDetailResponse[DeviceDetailItems[DeviceDetailItem]]](context.Background(),
		req, http_clients.WithBaseUrl("http://cuav-cloud-access-service:8883"),
		http_clients.WithUrl("inner/rest/v1/device/access/list"),
		http_clients.WithTimeOut(1*time.Second))
	if err != nil {
		logger.Errorf("get device detail fail, err: %v, req: %+v", err, *req)
		return "", err
	}
	if rsp == nil {
		logger.Debugf("get device detail is empty, req: %+v", *req)
		return "", nil
	}
	//logger.Infof("query detail response: %+v", *rsp)

	if rsp.Data != nil {
		for _, item := range rsp.Data.Data {
			if item != nil {
				logger.Debugf("response: %+v", *item)
				return item.Name, nil
			}
		}
	}
	return "", nil
}
