package device_manager

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/redis"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"errors"
	"fmt"
	"google.golang.org/protobuf/proto"
	"time"
)

type DeviceManager struct {
	rds             redis.SkyFendRedisOps
	onlineDevExpire time.Duration // 10 second
}

type DeviceManagerOptions = func(*DeviceManager)

// WithDevManagerExp 设置在线设备状态缓存有效时间参数
func WithDevManagerExp(devStatusExp time.Duration) DeviceManagerOptions {
	return func(m *DeviceManager) {
		if devStatusExp <= 0 {
			devStatusExp = 5 * time.Second
		}
		m.onlineDevExpire = devStatusExp
	}
}
func WithDevManagerRedisClient(r redis.SkyFendRedisOps) DeviceManagerOptions {
	return func(m *DeviceManager) {
		if r == nil {
			r = config.GlobalRedis
		}
		m.rds = r
	}
}

func NewDeviceManager(opts ...DeviceManagerOptions) *DeviceManager {
	devMng := &DeviceManager{
		rds:             config.GlobalRedis,
		onlineDevExpire: 20 * time.Second,
	}
	for _, optHandle := range opts {
		optHandle(devMng)
	}
	return devMng
}

// GetTbCodesRedisKey 返回 tbcode所有缓存的key
func GetTbCodesRedisKey() string {
	return fmt.Sprintf("tbcode:all_tbcode_list:2300")
}

// GetDeviceTbCodeRelationRedisKey 返回 tbcode 下所有在线设备列表缓存 key, 该key是device-tbcode关系set集合。
func GetDeviceTbCodeRelationRedisKey(tbCode string) string {
	return fmt.Sprintf("rel:tbcode:online_device_list:%v", tbCode)
}

// GetDeviceDetailRedisKey 返回 tbcode, devId 的在线设备状态详情key
func GetDeviceDetailRedisKey(tbCode string, devId string) string {
	return fmt.Sprintf("online_device_detail:%s:%s", tbCode, devId)
}

// GetSfl200DevId 根据sfl200 info 获取 devId
func GetSfl200DevId(deviceInfo []byte) string {
	if len(deviceInfo) <= 0 {
		return ""
	}

	devItem := &pb.Sfl200SystemStateData{}
	err := proto.Unmarshal(deviceInfo, devItem)
	if err != nil {
		logger.Errorf("parse sfl200 device info fail, e: %v", err)
		return ""
	}
	//logger.Debugf("sfl200 heat beat info: %+v", devItem)
	return devItem.Sn
}

// GetDjUavDevId 根据DjUav info 获取 devId
func GetDjUavDevId(deviceInfo []byte) string {
	if len(deviceInfo) <= 0 {
		return ""
	}

	devItem := &pb.DjRemoteControlUavData{}
	err := proto.Unmarshal(deviceInfo, devItem)
	if err != nil {
		logger.Errorf("parse GetDjUavDevId device info fail, e: %v", err)
		return ""
	}
	//logger.Debugf("sfl200 heat beat info: %+v", devItem)
	return devItem.SerialNum
}

func GetSfl100DeviId(deviceInfo []byte) string {
	if len(deviceInfo) <= 0 {
		return ""
	}

	devItem := &pb.SflHeartData{}
	err := proto.Unmarshal(deviceInfo, devItem)
	if err != nil {
		logger.Errorf("parse sfl100 device info fail, e: %v", err)
		return ""
	}
	//logger.Debugf("sfl100 heat beat info: %+v", devItem)
	return devItem.Sn
}

func GetSpooferDeviceId(deviceInfo []byte) string {
	if len(deviceInfo) <= 0 {
		return ""
	}

	devItem := &pb.Nsf4000HeartData{}
	err := proto.Unmarshal(deviceInfo, devItem)
	if err != nil {
		logger.Errorf("parse spoofer device info fail, e: %v", err)
		return ""
	}
	//logger.Debugf("spoofer heat beat info: %+v", devItem)
	return devItem.Sn
}

// GetDeviceIdFromDetail 从设备详情中获取设备id; TODO:
func GetDeviceIdFromDetail(devTypeStr string, deviceInfo []byte) string {
	switch devTypeStr {
	case DevTypeSfl100FromHeatBeat:
		return GetSfl100DeviId(deviceInfo)

	case DevTypeSpooferFromHeartBeat:
		return GetSpooferDeviceId(deviceInfo)

	case DevTypeSfl200FromHeatBeat:
		return GetSfl200DevId(deviceInfo)
	case DevTypeDjRemoteControlFromRcUav:
		return GetDjUavDevId(deviceInfo)

	}
	return ""
}

type DeviceInfoPreview struct {
	DeviceId   string `json:"device_id"`
	DeviceType string `json:"device_type"`
}

func (p *DeviceInfoPreview) MarshalBinary() (data []byte, err error) {
	ret, e := json.Marshal(p)
	if e != nil {
		logger.Errorf("format to json fail, err: %v", e)
		return nil, e
	}
	return ret, nil
}

func (p *DeviceInfoPreview) UnmarshalBinary(data []byte) error {
	if e := json.Unmarshal(data, p); e != nil {
		logger.Errorf("parse device info fail, err: %v", e)
		return e
	}
	return nil
}

//
//func (p *DeviceInfoPreview) Unmarshal(data []byte) error {
//	if e := json.Unmarshal(data, p); e != nil {
//		logger.Errorf("parse device info fail, err: %v", e)
//		return e
//	}
//	return nil
//}
//
//func (p *DeviceInfoPreview) Marshal() []byte {
//	ret, e := json.Marshal(p)
//	if e != nil {
//		logger.Errorf("format to json fail, err: %v", e)
//		return nil
//	}
//	return ret
//}

type DefineDevStatusInfo struct {
	pb.DevStatusInfo
}

// MarshalBinary 实现 encoding的方法BinaryMarshaler
func (deviceStatus *DefineDevStatusInfo) MarshalBinary() ([]byte, error) {
	return proto.Marshal(deviceStatus)
}

// UnmarshalBinary 主要是实现 encoding.BinaryUnmarshaler 方法
func (deviceStatus *DefineDevStatusInfo) UnmarshalBinary(data []byte) error {
	return proto.Unmarshal(data, deviceStatus)
}

// WriteToCache 将device info 写入到缓存中
func (d *DeviceManager) WriteToCache(data *pb.DevStatusSyncRequest) error {
	if data == nil {
		return fmt.Errorf("input sync device status is nil")
	}

	for tbCodeFlag, _ := range data.Items {
		if tbCodeFlag == "" {
			logger.Errorf("get tb code is empty")
			continue
		}

		if data.Items[tbCodeFlag] == nil {
			logger.Errorf("online device detail list nil, tbCode: %v", tbCodeFlag)
			continue
		}

		go func(tbCode string, devDetailItems *pb.DevStatusSyncMsg) {
			beginTime := time.Now()

			var storeDeviceToCache bool = false
			for index, _ := range devDetailItems.DevInfo {
				oneDevice := devDetailItems.DevInfo[index]
				if oneDevice == nil {
					logger.Errorf("device detail is nil, tbCode: %v", tbCode)
					continue
				}

				devId := GetDeviceIdFromDetail(oneDevice.GetDevType(), oneDevice.GetDevItem())
				if devId == "" {
					logger.Errorf("get device id from device detail fail, tbCode: %v", tbCode)
					continue
				}

				// 先存储在线设备 详情 信息。
				devDetailCacheKey := GetDeviceDetailRedisKey(tbCode, devId)
				oneDeviceWrapper := &DefineDevStatusInfo{}
				oneDeviceWrapper.DevType = oneDevice.GetDevType()
				oneDeviceWrapper.C2Sn = oneDevice.GetC2Sn()
				oneDeviceWrapper.DevItem = oneDevice.GetDevItem()

				if err := d.rds.SetEx(devDetailCacheKey, oneDeviceWrapper, d.onlineDevExpire); err != nil {
					logger.Errorf("set online device detail to cache fail, %v", err)
					continue
				}
				//logger.Debugf("write device info to cache, key: %v, value: %v", devDetailCacheKey, oneDeviceWrapper)

				// 再存储 tbcode 和在线设备id，设备类型 映射 关系。
				tbCodeDevListCacheKey := GetDeviceTbCodeRelationRedisKey(tbCode)
				devicePreview := &DeviceInfoPreview{
					DeviceId:   devId,
					DeviceType: oneDevice.GetDevType(),
				}

				if err := d.rds.SAdd(tbCodeDevListCacheKey, devicePreview); err != nil {
					logger.Errorf("add devId and device-tbcode relation to cache fail, %v", err)
					continue
				}
				//logger.Infof("set device-tbcode relation key: %v, item: %s", tbCodeDevListCacheKey, deviceInfo)
				storeDeviceToCache = true
			}

			if storeDeviceToCache {
				tbCodeCacheKey := GetTbCodesRedisKey()
				if err := d.rds.SAdd(tbCodeCacheKey, tbCode); err != nil {
					logger.Errorf("set tbCode to cache fail, %v", err)
				}
			}

			costTmMs := time.Since(beginTime).Milliseconds()
			if costTmMs > 1*1000 {
				logger.Errorf("cost %d ms", costTmMs)
			}
		}(tbCodeFlag, data.Items[tbCodeFlag])
	}
	return nil
}

// GetAllDeviceCacheTbCode 获取在线设备缓存对应的所有tbcode
func (d *DeviceManager) GetAllDeviceCacheTbCode() ([]string, error) {
	allTbCodeCacheKey := GetTbCodesRedisKey()
	ret, err := d.rds.SMembers(allTbCodeCacheKey)
	if err != nil {
		logger.Errorf("get all device tbcode cache fail, %v", err)
		return nil, err
	}
	return ret, nil
}

// GetDeviceIdListOnTbCode 获取 tbcode 下所有在线设备id 列表
func (d *DeviceManager) GetDeviceIdListOnTbCode(tbCode string) ([]*DeviceInfoPreview, error) {
	deviceListOnTbCodeCacheKey := GetDeviceTbCodeRelationRedisKey(tbCode)
	devIdList, err := d.rds.SMembers(deviceListOnTbCodeCacheKey)
	if err != nil {
		logger.Errorf("get all device id list by tbcode fail, %v", err)
		return nil, err
	}
	for i := 0; i < 3; i++ {
		if len(devIdList) > 0 {
			break
		}
		devIdList, err = d.rds.SMembers(deviceListOnTbCodeCacheKey)
		if err != nil {
			logger.Errorf("get all device id list by tbcode fail, %v", err)
		}
		time.Sleep(10 * time.Millisecond)
	}
	if len(devIdList) == 0 {
		logger.Infof("get all device id is empty, by tbCode: %v, ret item nums: %v", tbCode, len(devIdList))
		return nil, nil
	}

	var deviceRetList []*DeviceInfoPreview
	for _, devId := range devIdList {
		if len(devId) == 0 {
			continue
		}
		devicePreview := &DeviceInfoPreview{}
		if err := devicePreview.UnmarshalBinary([]byte(devId)); err != nil {
			logger.Errorf("parse device preview fail, err: %v, tbCode: %v", err)
			continue
		}
		deviceRetList = append(deviceRetList, devicePreview)
		logger.Infof("get dev preview: %+v, tbCode: %v", devicePreview, tbCode)
	}

	return deviceRetList, nil
}
func (d *DeviceManager) DeleteToCodeDeviceRel(tbCode string, devId string, devType string) {
	deviceListOnTbCodeCacheKey := GetDeviceTbCodeRelationRedisKey(tbCode)

	devicePreview := &DeviceInfoPreview{
		DeviceId:   devId,
		DeviceType: devType,
	}

	if err := d.rds.SRem(deviceListOnTbCodeCacheKey, devicePreview); err != nil {
		logger.Errorf("del devId and device-tbcode relation to cache fail, %v", err)
		return
	}
	logger.Debugf("del dev and tbcode relation succ, key: %v, tbCode: %v, devId: %v, devType: %v", deviceListOnTbCodeCacheKey, tbCode, devId, devType)
}

// GetOnlineDeviceDetail 获取设备详情
func (d *DeviceManager) GetOnlineDeviceDetail(tbCode string, devId string, devType string) (*pb.DevStatusInfo, error) {
	devDetailCacheKey := GetDeviceDetailRedisKey(tbCode, devId)
	data, err := d.rds.Get(devDetailCacheKey)
	if err != nil {
		if errors.Is(err, redis.RETNil) {
			logger.Errorf("not exist device detail for key: %v", devDetailCacheKey)
			tmRet := d.rds.GetRedisRow().PTTL(context.Background(), devDetailCacheKey)
			logger.Infof("expire tm: %v,key: %v", tmRet.Val(), devDetailCacheKey)
			return nil, nil
		} else {
			logger.Errorf("get online device detail to cache fail, %v", err)
			return nil, fmt.Errorf("get online dev fail, err: %v", err)
		}
	}
	dstData := data.(string)
	statusData := &DefineDevStatusInfo{}
	if err := statusData.UnmarshalBinary([]byte(dstData)); err != nil {
		logger.Errorf("parse fail,tbCode: %v, devType: %v, devId: %v", tbCode, devType, devId)
		return nil, fmt.Errorf("dev detail type is not DefineDevStatusInfo, tbCode: %v, devType: %v, devId: %v", tbCode, devType, devId)
	}

	return &(statusData.DevStatusInfo), nil
}

// GetAllOnlineDeviceOnTbCode 获取某个 tbcode 下在线设备的状态信息
func (d *DeviceManager) GetAllOnlineDeviceOnTbCode(tbCode string) ([]*DeviceDetail, error) {
	deviceList, err := d.GetDeviceIdListOnTbCode(tbCode)
	if err != nil {
		logger.Errorf("get device list fail, %v", err)
		return nil, err
	}
	if len(deviceList) == 0 {
		logger.Errorf("get online device list empty, tbCode: %v", tbCode)
		return nil, nil
	}

	var retItem []*DeviceDetail
	for _, deviceItem := range deviceList {
		if deviceItem == nil {
			continue
		}
		logger.Debugf("deviceId: %v, devType: %v", deviceItem.DeviceId, deviceItem.DeviceType)

		item, err := d.GetOnlineDeviceDetail(tbCode, deviceItem.DeviceId, deviceItem.DeviceType)
		if err != nil {
			logger.Errorf("get online device detail fail, %v, tbCode: %v", err, tbCode)
			continue
		}
		if item == nil {
			logger.Debugf("not exist uav detail cache, tbCode: %v, devId: %v, devType: %v, need to del relation", tbCode, deviceItem.DeviceId, deviceItem.DeviceType)
			//d.DeleteToCodeDeviceRel(tbCode, deviceItem.DeviceId, deviceItem.DeviceType)
			continue
		}

		dstItem, err := TransToDeviceDetail(item)
		if err != nil || dstItem == nil {
			continue
		}
		retItem = append(retItem, dstItem)
	}
	return retItem, nil
}
