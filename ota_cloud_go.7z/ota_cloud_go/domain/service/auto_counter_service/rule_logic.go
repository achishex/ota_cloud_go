package auto_counter_service

import (
	"context"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/domain/service/alarm_service"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
)

const (
	Rule_UnDelete = 0 //规则未删除
	Rule_Deleted  = 1 //规则已删除

)

const (
	CounterAreaInRule int32 = 1 //规则适用反制区
	FenceAreaInRule   int32 = 2 //规则适用围栏区
)

const (
	Run_No_Whole_day = 0
	Rule_Whole_Day   = 1
)

// AutoCounterRuleOps 自动反制规则表操作
type AutoCounterRuleOps struct {
	dbOps AutoCounterRuleDBType // key: 规则表操作句柄
}

// NewAutoCounterRuleOps 创建自动反制规则表
func NewAutoCounterRuleOps(dbHandle AutoCounterRuleDBType) *AutoCounterRuleOps {
	if dbHandle == nil {
		// 使用默认的全局db
		return &AutoCounterRuleOps{
			dbOps: AutoCounterRuleDBHandle,
		}
	}
	//
	return &AutoCounterRuleOps{
		dbOps: dbHandle,
	}
}

// CheckRuleExist 检查规则是否存在
func (acr *AutoCounterRuleOps) CheckRuleExist(tbCode string, ruleName string, ruleId int64) (error, bool) {
	if tbCode == "" || ruleName == "" || ruleId <= 0 {
		return errors.New("input param in valid"), false
	}
	if acr.dbOps == nil {
		return errors.New("counter area handle is nil"), false
	}

	whereCond := "tb_code = ? and  rule_name = ? and id != ? and is_delete = ?"
	whereValue := []any{tbCode, ruleName, ruleId, Rule_UnDelete}

	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v, areaName: %v, areaId: %v", err, tbCode, ruleName, ruleId)
		return err, false
	}
	if len(ruleItems) > 0 {
		return nil, true
	}
	return nil, false
}

func (acr *AutoCounterRuleOps) QueryFenceAreaBind(tbCode string, fenceId int64) (error, bool) {
	if acr.dbOps == nil {
		return errors.New("counter area handle is nil"), false
	}

	whereCond := "tb_code = ? and  fence_area_id = ? and is_delete = ?" //未删除
	whereValue := []any{tbCode, fenceId, Rule_UnDelete}

	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v, fence area id: %v", err, tbCode, fenceId)
		return err, false
	}
	if len(ruleItems) > 0 {
		for _, item := range ruleItems {
			if item == nil {
				continue
			}
			logger.Infof("rule items: %+v", *item)
		}
		return nil, true
	}
	return nil, false
}

func (acr *AutoCounterRuleOps) QueryFenceAreaBindIds(tbCode string, fenceId int64) (error, []*model.AutoCounterRuleConfig) {
	if acr.dbOps == nil {
		return errors.New("counter area handle is nil"), nil
	}

	whereCond := "tb_code = ? and  fence_area_id = ? and is_delete = ?"
	whereValue := []any{tbCode, fenceId, Rule_UnDelete}

	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v, fence area id: %v", err, tbCode, fenceId)
		return err, nil
	}
	return nil, ruleItems
}

func GetStartEndTime(tm *pb.RuleInvalidTime) (beginTime int32, endTime int32) {
	if tm == nil {
		return 0, 0
	}
	beginTime = tm.GetStartHour()*10000 + tm.GetStartMinute()*100 + tm.GetStartSecond()
	endTime = tm.GetEndHour()*10000 + tm.GetEndMinute()*100 + tm.GetEndSecond()
	return beginTime, endTime
}

// InsertRuleItem 插入一个新的规则记录
func (acr *AutoCounterRuleOps) InsertRuleItem(tbCode string, ruleId int64,
	counterAreaId int64, fenceAreaId int64, item *pb.AutoCounterRuleCreateRequest) error {

	if acr.dbOps == nil {
		return errors.New("counter rule  db handle is nil")
	}

	wholeDay := int32(0)
	crossDay := int32(0)
	ruleTimeDay := item.GetRuleTimeDay()
	if ruleTimeDay != nil {
		wholeDay = ruleTimeDay.GetWholeDay()
		crossDay = ruleTimeDay.GetCrossDay()
	}

	nowTime := time.Now().UTC()
	beginTime, endTime := GetStartEndTime(item.GetRuleTimeDay())
	var ruleDurationTime int32 = 0
	if item.GetRuleTimeDay() != nil {
		ruleDurationTime = item.GetRuleTimeDay().RuleDurationTime
	}

	dbItem := &model.AutoCounterRuleConfig{
		ID:            ruleId,
		TbCode:        tbCode,
		RuleName:      item.GetRuleName(),
		CounterAreaId: counterAreaId,
		FenceAreaId:   fenceAreaId,
		WholeDay:      wholeDay,
		CrossDay:      crossDay,
		BeginTime:     beginTime,
		EndTime:       endTime,
		ForbiddenMode: item.GetForbiddenMode(),
		RuleEnable:    item.GetRuleEnable(),
		CreateTime:    &nowTime,
		UpdateTime:    &nowTime,
		RuleDurTime:   ruleDurationTime,
	}
	//
	_, err := acr.dbOps.Insert([]*model.AutoCounterRuleConfig{dbItem})
	logger.Infof("insert auto counter rule item: %+v", *dbItem)

	return err
}

func buildCounterAreaInfo(dbHandle *CounterAreaOps, counterAreaId int64, tbCode string) *pb.CounterAreaList {
	if dbHandle == nil || counterAreaId <= 0 || tbCode == "" {
		return nil
	}

	counterArea, err := dbHandle.QueryCounterArea(tbCode, counterAreaId)
	if len(counterArea) <= 0 || err != nil {
		return nil
	}

	var ret pb.CounterAreaList
	for _, item := range counterArea {
		if item == nil {
			continue
		}
		ret.Id = item.ID
		ret.AreaName = item.AreaName
		ret.AreaPerimeter = item.AreaPerimeter
		ret.AreaSquare = item.AreaSquare
		ret.CentroidLongitude = item.CentroidLongitude
		ret.CentroidLatitude = item.CentroidLatitude
		ret.Geometry = item.Geometry
		if item.CreateTime != nil {
			ret.CreateTime = strconv.FormatInt(item.CreateTime.UTC().UnixMilli(), 10)
		}
		if item.UpdateTime != nil {
			ret.UpdateTime = strconv.FormatInt(item.UpdateTime.UTC().UnixMilli(), 10)
		}
		//
		return &ret
	}
	return nil
}

func buildFenceAreaInfo(dbHandle *FenceAreaOps, tbCode string, fenceAreaId int64) *pb.FenceResList {
	if dbHandle == nil || tbCode == "" || fenceAreaId <= 0 {
		return nil
	}
	fenceArea, err := dbHandle.QueryFenceAreaByTbCodeAndId(tbCode, fenceAreaId)
	if err != nil {
		logger.Errorf("query fence area fail, err: %v", err)
		return nil
	}
	if len(fenceArea) <= 0 {
		return nil
	}

	var ret pb.FenceResList

	for _, item := range fenceArea {
		if item == nil {
			continue
		}
		ret.Id = item.ID
		ret.AreaName = item.AreaName
		ret.AreaType = int32(item.AreaType)
		ret.AreaPerimeter = item.AreaPerimeter
		ret.AreaSquare = item.AreaSquare
		ret.CentroidLongitude = item.CentroidLongitude
		ret.CentroidLatitude = item.CentroidLatitude
		ret.Geometry = item.Geometry
		ret.CreateTime = strconv.FormatInt(item.CreateTime, 10)
		ret.UpdateTime = strconv.FormatInt(item.UpdateTime, 10)
		return &ret
	}
	return nil
}

// QueryRules 分页查询规则; loadDelete 查询删除的规则
func QueryRules(tbCode string, requestBody *pb.AutoCounterRuleQueryRequest, loadDelete bool) (*pb.AutoCounterRulePagingQueryResponse, error) {
	var ret = &pb.AutoCounterRulePagingQueryResponse{
		PageIndex: requestBody.PageIndex,
		PageSize:  requestBody.PageSize,
	}

	ruleOps := NewAutoCounterRuleOps(nil)
	items, nums, err := ruleOps.QueryRuleItems(tbCode, requestBody.GetPageIndex(), requestBody.GetPageSize(), loadDelete)
	if err != nil {
		logger.Errorf("query rule items fail, err: %v, req item: %+v", err, requestBody.String())
		return nil, ec.GetError(ec.SF_ErrorAutoCounterRuleQuery)
	}
	ret.TotalNums = nums

	if len(items) <= 0 {
		logger.Infof("query auto counter rule is empty")
		return ret, nil
	}

	for _, item := range items {
		if item == nil {
			continue
		}

		validTime := &pb.RuleInvalidTime{}
		if item.WholeDay == Rule_Whole_Day {
			validTime.WholeDay = proto.Int32(item.WholeDay)
		} else {
			validTime.WholeDay = proto.Int32(item.WholeDay)
			validTime.CrossDay = proto.Int32(item.CrossDay)
			//
			sH, sM, sS := utils.GetTimeByDB(item.BeginTime)
			validTime.StartHour, validTime.StartMinute, validTime.StartSecond = proto.Int32(sH), proto.Int32(sM), proto.Int32(sS)
			eH, eM, eS := utils.GetTimeByDB(item.EndTime)
			validTime.EndHour, validTime.EndMinute, validTime.EndSecond = proto.Int32(eH), proto.Int32(eM), proto.Int32(eS)

		}
		retItem := &pb.AutoCounterRuleQueryResponse{
			RuleName:      item.RuleName,
			RuleTimeDay:   validTime,
			ForbiddenMode: item.ForbiddenMode,
			RuleEnable:    item.RuleEnable,
			RuleId:        item.ID,
			UpdateTime:    item.UpdateTime.UTC().UnixMilli(),
		}

		if item.CounterAreaId > 0 { // 反制区
			counterAreaOps := NewCounterAreaOpsHandler(nil)
			retItem.CounterArea = buildCounterAreaInfo(counterAreaOps, item.CounterAreaId, tbCode)
		}

		if item.FenceAreaId > 0 { // 围栏区
			fenceAreaOps := NewFenceAreaOpsHandler(nil)
			retItem.FenceAreaItem = buildFenceAreaInfo(fenceAreaOps, tbCode, item.FenceAreaId)

		}
		ret.Data = append(ret.Data, retItem)
	}
	return ret, nil
}

// QueryRuleItems 查询规则信息； needDelete 是否加载删除的规则
func (acr *AutoCounterRuleOps) QueryRuleItems(tbCode string, pageIndex int64, pageSize int32, needDelete bool) ([]*model.AutoCounterRuleConfig, int32, error) {
	if acr.dbOps == nil {
		return nil, 0, errors.New("counter rule  db handle is nil")
	}
	whereCondCount := "tb_code = ?"
	whereValueCount := []any{tbCode}

	whereCond := "tb_code = ?"
	whereValue := []any{tbCode}

	if needDelete { // 加载删除记录
		whereCond += " and is_delete = ?"
		whereValue = append(whereValue, Rule_Deleted)

		//
		whereCondCount += " and is_delete = ?"
		whereValueCount = append(whereValueCount, Rule_Deleted)

	} else { // 加载未删除记录
		whereCond += " and is_delete = ?"
		whereValue = append(whereValue, Rule_UnDelete)

		//
		whereCondCount += " and is_delete = ?"
		whereValueCount = append(whereValueCount, Rule_UnDelete)
	}

	orderAsc := map[string]bool{
		"create_time": false,
	}

	var retNums int64 = 0
	nums, err := acr.dbOps.CountItems(whereCondCount, whereValueCount)
	if err == nil {
		retNums = nums
	}

	offset := int(pageIndex-int64(1)) * int(pageSize)
	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, orderAsc, offset, int(pageSize))
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v", err, tbCode)
		return nil, 0, err
	}

	if len(ruleItems) > 0 {
		for _, item := range ruleItems {
			if item == nil {
				continue
			}
			logger.Infof("query rule items: %+v", *item)
		}
		return ruleItems, int32(retNums), nil
	}
	return nil, int32(retNums), nil
}

func (acr *AutoCounterRuleOps) QueryRuleByRuleId(tbCode string, ruleId int64) (*model.AutoCounterRuleConfig, error) {
	if acr.dbOps == nil {
		return nil, errors.New("counter rule  db handle is nil")
	}

	whereCond := "id = ? and tb_code = ?"
	whereValue := []any{ruleId, tbCode}

	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v, ruleId: %v", err, tbCode, ruleId)
		return nil, err
	}
	if len(ruleItems) > 0 {
		for _, item := range ruleItems {
			if item == nil {
				continue
			}
			logger.Infof("query rule items: %+v", *item)
			return item, nil
		}
	}
	return nil, nil
}

func (acr *AutoCounterRuleOps) UpdateItems(tbCode string, ruleId int64, ruleEnable int32, delFenceAreaId bool) error {
	if acr.dbOps == nil {
		return errors.New("counter rule  db handle is nil")
	}

	whereStr := "id=? and tb_code=?"
	whereVal := []any{ruleId, tbCode}

	nowTime := time.Now().UTC()
	updateTimeField := "update_time"

	var fieldName string
	var fieldValue any
	if ruleEnable > 0 {
		fieldName = "rule_enable"
		fieldValue = ruleEnable

		_, err := acr.dbOps.Updates(whereStr, whereVal, map[string]any{fieldName: fieldValue, updateTimeField: &nowTime})
		if err != nil {
			logger.Errorf("update rule_enable to %v fail, err: %v", ruleEnable, err)
		} else {
			logger.Infof("update rule_enable to %v success", ruleEnable)
		}
	}

	if delFenceAreaId {
		fieldName = "fence_area_id"
		fieldValue = 0

		_, err := acr.dbOps.Updates(whereStr, whereVal, map[string]any{fieldName: fieldValue, updateTimeField: &nowTime})
		if err != nil {
			logger.Errorf("update fence_area_id to 0 fail, err: %v", err)
		} else {
			logger.Infof("update fence_area_id to 0 success")
		}
	}
	return nil
}

func (acr *AutoCounterRuleOps) DeleteRuleById(tbCode string, ruleId int64) error {
	if acr.dbOps == nil {
		return errors.New("counter rule  db handle is nil")
	}

	whereStr := "id=? and tb_code=?"
	whereVal := []any{ruleId, tbCode}

	fieldName := "is_delete"
	fieldValue := Rule_Deleted
	//
	deleteTimeField := "delete_time"
	nowTm := time.Now().UTC()

	//
	_, err := acr.dbOps.Updates(whereStr, whereVal, map[string]any{fieldName: fieldValue, deleteTimeField: &nowTm})
	if err != nil {
		logger.Errorf("delete, update is_delete to %v fail, err: %v", fieldValue, err)
	} else {
		logger.Infof("delete, update is_delete to %v success", fieldValue)
	}

	return err
}

func (acr *AutoCounterRuleOps) QueryRuleByFenceId(tbCode string, fenceId int64) (*model.AutoCounterRuleConfig, error) {
	if acr.dbOps == nil {
		return nil, errors.New("counter area handle is nil")
	}

	whereCond := "tb_code = ? and  fence_area_id = ? and is_delete = ?" //未删除
	whereValue := []any{tbCode, fenceId, Rule_UnDelete}

	order := map[string]bool{
		"create_time": false,
	}
	ruleItems, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, order, 0, 1)
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v, fence area id: %v", err, tbCode, fenceId)
		return nil, err
	}
	if len(ruleItems) > 0 {
		for _, item := range ruleItems {
			if item == nil {
				continue
			}
			logger.Infof("rule items: %+v", *item)
			return ruleItems[0], nil
		}
	}
	return nil, nil
}

type CrossRuleIdSimple struct {
	RuleId   int64
	RuleName string
}

type AreaRuleId struct {
	areaId int64
	ruleId int64
}

// CheckGeometryCross 判断两个多边形 是否存在交集
func CheckGeometryCross(srcGeo string, dstGeo string) (error, bool) {
	if srcGeo == "" || dstGeo == "" {
		return nil, false
	}

	srcGeoParsed, err := geo.ParseGeoJsonToPolygons(srcGeo)
	if err != nil {
		return err, false
	}

	dstGeoParsed, err := geo.ParseGeoJsonToPolygons(dstGeo)
	if err != nil {
		return err, false
	}

	err, exist := alarm_service.CalcOverLapInArea(&geo.PolygonUnionList{
		PolygonListItems: srcGeoParsed},
		&geo.PolygonUnionList{
			PolygonListItems: dstGeoParsed,
		})
	if err != nil || exist {
		logger.Infof("exist: %v, err: %v", exist, err)
		return err, exist
	}

	if exist == false {
		err, exist = alarm_service.CalcOverLapInArea(&geo.PolygonUnionList{
			PolygonListItems: srcGeoParsed},
			&geo.PolygonUnionList{
				PolygonListItems: dstGeoParsed,
			})
	}
	return err, exist
}

// QueryAreaCross 检查和规则ruleId的区域有交叉的区域
func (acr *AutoCounterRuleOps) QueryAreaCross(ctx context.Context, tbCode string, ruleId int64,
	counterArea *pb.CounterAreaCreateRequest /*当前反制区*/, fenceArea *bean.FencedAreaConfig /*当前围栏区*/) ([]CrossRuleIdSimple, error) {

	var geoData string
	if counterArea != nil {
		geoData = counterArea.GetGeometry() //当前的经纬度
	}
	if fenceArea != nil {
		geoData = fenceArea.Geometry //当前的经纬度
	}

	if acr.dbOps == nil {
		return nil, errors.New("counter area handle is nil")
	}
	var whereCond string
	var whereValue []any

	whereCond = "tb_code = ? and is_delete = ? and id != ?"
	whereValue = []any{tbCode, Rule_UnDelete, ruleId}

	order := map[string]bool{
		"create_time": false,
	}

	//找出规则所有的围栏区 或者 反制区，判断反制区或者围栏区 是否和当前的是否存在交集
	ruleDetail, err := acr.dbOps.QueryItemOnCond(whereCond, whereValue, order, 0, 0) //查询所有规则
	if err != nil {
		logger.Errorf("query rule item fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}

	var counterAreaRuleIds map[int64]CrossRuleIdSimple = make(map[int64]CrossRuleIdSimple) //key is areaid, value is  ruleid
	var fenceAreaRuleIds map[int64]CrossRuleIdSimple = make(map[int64]CrossRuleIdSimple)   //key is areaid, value is  ruleid
	for _, v := range ruleDetail {
		if v == nil {
			continue
		}
		if v.ID == ruleId {
			//过滤本次 规则
			continue
		}

		if v.FenceAreaId > 0 { // 围栏区
			fenceAreaRuleIds[v.FenceAreaId] = CrossRuleIdSimple{
				RuleId:   v.ID,
				RuleName: v.RuleName,
			}
			continue
		}

		if v.CounterAreaId > 0 { // 反制区 -> 规则
			counterAreaRuleIds[v.CounterAreaId] = CrossRuleIdSimple{
				RuleId:   v.ID,
				RuleName: v.RuleName,
			}
		}
	}
	logger.Infof("counter area rule simple: %v, fence area rule simple: %v", counterAreaRuleIds, fenceAreaRuleIds)

	var ret []CrossRuleIdSimple
	var areaCounterList map[int64]*model.CounterAreaConfig //key: ruleId
	var areaFenceList map[int64]*bean.FencedAreaConfig     //key: ruleId

	if len(counterAreaRuleIds) > 0 { //取出 反制区列表详情
		areaCounterList, _ = NewCounterAreaOpsHandler(nil).QueryCounterAreaList(tbCode, counterAreaRuleIds)
		if len(areaCounterList) == 0 {
			return nil, nil
		}

		for ruleId, area := range areaCounterList {
			if area == nil {
				continue
			}

			dstAreaGeo := area.Geometry
			srcAreaGeo := geoData

			if err, exist := CheckGeometryCross(srcAreaGeo, dstAreaGeo); err == nil && exist == true {
				var ruleName string
				_, ok := counterAreaRuleIds[area.ID]
				if ok {
					logger.Infof("cross, area id: %v, ruleName: %v", area.ID, fenceAreaRuleIds[area.ID].RuleName)
					ruleName = counterAreaRuleIds[area.ID].RuleName
				}

				ret = append(ret, CrossRuleIdSimple{
					RuleId:   ruleId,
					RuleName: ruleName,
				})
			}
		}
	}

	if len(fenceAreaRuleIds) > 0 { // 取出围栏区详情
		areaFenceList, _ = NewFenceAreaOpsHandler(nil).QueryFenceAreaList(tbCode, fenceAreaRuleIds)
		if len(areaFenceList) == 0 {
			return nil, nil
		}

		for ruleId, area := range areaFenceList {
			if area == nil {
				continue
			}

			dstAreaGeo := area.Geometry
			srcAreaGeo := geoData

			if err, exist := CheckGeometryCross(srcAreaGeo, dstAreaGeo); err == nil && exist == true {
				var ruleName string
				_, ok := fenceAreaRuleIds[area.ID]
				if ok {
					ruleName = fenceAreaRuleIds[area.ID].RuleName
				}

				ret = append(ret, CrossRuleIdSimple{
					RuleId:   ruleId,
					RuleName: ruleName,
				})
			}
		}
	}
	return ret, nil
}
