package auto_counter_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/mq"
	"fmt"
	"github.com/Shopify/sarama"
	"strings"
)

var (
	// mqPublisher 定义一个全局的消息发布对象（用于告警记录发布）
	mqPublisher mq.MessagePublisher = nil
)

// InitMsgPublisher 初始化消息队列发布
func InitMsgPublisher() {
	logger.Info("Kafka ip addr:", config.GetConfig().Kafka.BootStrapServers)
	bootstrapServers := strings.Split(config.GetConfig().Kafka.BootStrapServers, ",")

	mqPublisher = mq.NewKafkaPublisher(bootstrapServers,
		mq.WithProducerReturn(true),
		mq.WithProducerRequireAcks(int(sarama.WaitForAll)),
		mq.WithProducerPartitions(sarama.NewHashPartitioner))

	if mqPublisher == nil {
		logger.Errorf("new kafka publisher client fail")
	}
}

type RuleNotify struct {
	statusPublisher mq.MessagePublisher
}

func NewRuleNotifyImpl() *RuleNotify {
	return &RuleNotify{
		statusPublisher: mqPublisher,
	}
}

type NoticeItem struct {
	Key  string `json:"key"`
	Data TbCode `json:"data"`
}

type TbCode struct {
	TbCode string `json:"tbCode"`
}

// Notify  send rule modity notify to client
func (f *RuleNotify) Notify(tbCode string) error {
	if f.statusPublisher == nil {
		logger.Errorf("create alarm status update pub obj fail, is nil")
		return fmt.Errorf("create alarm status update pub fail, is nil")
	}
	noticeItem := &model.NoticeItem{
		Key: "/notice/v1/auto_counter_rule_modify",
		Data: TbCode{
			TbCode: tbCode,
		},
	}

	err := f.statusPublisher.Publish(context.Background(), config.GetConfig().Kafka.EventNoticeTopic, tbCode, noticeItem)
	if err != nil {
		logger.Errorf("publish fail, err: %v, data: %v", err, noticeItem)
		return err
	}
	logger.Infof("send kafka notify for alarm status modify, value: %+v.", noticeItem)
	return nil
}
