package auto_counter_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
)

// InitRes 初始化自动反制资源
func InitRes(ctx context.Context) {
	InitCounterArea()
	//
	InitAutoCounterRule()
	//
	InitFenceArea()
	//
	InitMsgPublisher()
}

// CounterAreaDBHandlerType  自动反制规则表操作类型
type CounterAreaDBHandlerType = db.DbOpsTplInterface[model.CounterAreaConfig]

// CounterAreaDbHandle 反制区表操作对象
var CounterAreaDbHandle CounterAreaDBHandlerType = nil

// InitCounterArea 在主流程中注册该函数
func InitCounterArea() CounterAreaDBHandlerType {
	CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](config.GetDB()).SetTabName(model.CounterAreaConfig{}.TableName())
	return CounterAreaDbHandle
}

//	/////////////////////////////////////////////////////////////////////////////////
//	/////////////////////////////////////////////////////////////////////////////////
//
// AutoCounterRuleDBType  自动反制规则表操作类型
type AutoCounterRuleDBType = db.DbOpsTplInterface[model.AutoCounterRuleConfig]

// AutoCounterRuleDBHandle  自动反制规则表操作对象
var AutoCounterRuleDBHandle AutoCounterRuleDBType = nil

// InitAutoCounterRule 在主流程中注册该函数
func InitAutoCounterRule() AutoCounterRuleDBType {
	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](config.GetDB()).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	return AutoCounterRuleDBHandle
}

//	/////////////////////////////////////////////////////////////////////////////
//
// FenceAreaDBType 围栏区表操作类型
type FenceAreaDBType = db.DbOpsTplInterface[bean.FencedAreaConfig]

var FenceAreaDBHandle FenceAreaDBType = nil

// InitFenceArea 在主流程中注册该函数
func InitFenceArea() FenceAreaDBType {
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](config.GetDB()).SetTabName(bean.FencedAreaConfig{}.TableName())
	return FenceAreaDBHandle
}
