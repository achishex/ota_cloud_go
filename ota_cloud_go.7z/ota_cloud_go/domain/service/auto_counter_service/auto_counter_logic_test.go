package auto_counter_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/domain/service/device_manager"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"google.golang.org/protobuf/proto"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestLoadRuleByTbCode(t *testing.T) {
	//
	tbCode := "000001"

	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ruleLists := LoadRules(tbCode)
	if len(ruleLists) <= 0 {
		t.Logf("load rule by tbcode: %v fail, err: is empty", tbCode)
	} else {
		for i := 0; i < len(ruleLists); i++ {
			t.Logf("rule: %+v", ruleLists[i])
		}
	}
}

func TestAutoCounterOnUav(t *testing.T) {
	uavOne := &pb.DevLocationInfo{}
	uavTwo := &pb.DevLocationInfo{}

	//
	tbCode := "000001"

	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ruleLists := LoadRules(tbCode)
	if len(ruleLists) <= 0 {
		t.Logf("load rule by tbcode: %v fail, err: is empty", tbCode)
	} else {
		for i := 0; i < len(ruleLists); i++ {
			t.Logf("rule: %+v", ruleLists[i])
		}
	}
	uavList := []*pb.DevLocationInfo{
		uavOne,
		uavTwo,
	}

	for i := 0; i < len(uavList); i++ {
		if uavList[i] == nil {
			continue
		}

		NewAutoCounterService().AutoCounterEachUav(tbCode, uavList[i], ruleLists)
	}
}

func TestFilter(t *testing.T) {
	tbCode := "000001"
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
		//
		config.ServiceCfg.Redis.Host = "10.240.34.36"
		config.ServiceCfg.Redis.Port = 30356
		config.ServiceCfg.Redis.DataBase = 15
		config.ServiceCfg.Redis.Password = "ZAQ!2wsx"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](dbHandler).SetTabName(model.CounterAreaConfig{}.TableName())
	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	//初始化 redis handle.
	config.GlobalRedis = redis.NewSkyFendRedisClient(
		redis.WithRedisAddrOpt(fmt.Sprintf("%v:%d", config.ServiceCfg.Redis.Host, config.ServiceCfg.Redis.Port)),
		redis.WithRedisDB(config.ServiceCfg.Redis.DataBase),
		redis.WithRedisPasswd(config.ServiceCfg.Redis.Password),
	) //

	uavOne := &pb.DevLocationInfo{
		Longitude: 113.99731402504435, // 经度
		Latitude:  22.597524973906644, // 纬度
		// 设备sn (无人机)
		Sn: "dj-mav3-1231",
		// 设备 objID,真实设备有objID就填充。
		ObjID: "",
		// c2 sn(如果是侦测的无人机，需要填充侦测的c2; 如果是c2本身，则填充c2 sn)
		C2Sn: "a1b990c7-0eec-4531-bfdf-837ce154e6bf",
		// 无人机名字
		Name: "dj-mav3",
		// 侦测设备的sn
		DetectDevSn: "sfl200",
		// 标识本次请求id（由调用方来设置，服务方转发）
		UniqueId: time.Now().UnixMilli(),
		// 飞手经度
		PilotLongitude: 114.08500798614935,
		// 飞手纬度
		PilotLatitude: 22.611183496839246,
		// 返航点经度
		HomeLongitude: 114.08500798614935,
		// 返航点纬度
		HomeLatitude: 22.611183496839246,
		// 无人机频率
		Freq: 0.0,
		// 侦测设备类型, 比如: Sfl, Sfl200
		EType: "Sfl200",
	}

	uavTwo := &pb.DevLocationInfo{
		Longitude: 114.12792333038756, // 经度 114.12792333038756,22.644140611451334
		Latitude:  22.644140611451334, // 纬度
		// 设备sn (无人机)
		Sn: "dj-mav3-1231",
		// 设备 objID,真实设备有objID就填充。
		ObjID: "",
		// c2 sn(如果是侦测的无人机，需要填充侦测的c2; 如果是c2本身，则填充c2 sn)
		C2Sn: "a1b990c7-0eec-4531-bfdf-837ce154e6bf",
		// 无人机名字
		Name: "dj-mav3",
		// 侦测设备的sn
		DetectDevSn: "sfl200",
		// 标识本次请求id（由调用方来设置，服务方转发）
		UniqueId: time.Now().UnixMilli(),
		// 飞手经度
		PilotLongitude: 114.12792333038756,
		// 飞手纬度
		PilotLatitude: 22.644140611451334,
		// 返航点经度
		HomeLongitude: 114.12792333038756,
		// 返航点纬度
		HomeLatitude: 22.644140611451334,
		// 无人机频率
		Freq: 0.0,
		// 侦测设备类型, 比如: Sfl, Sfl200
		EType: "Sfl200",
	}
	_ = uavTwo
	//

	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	ruleLists := LoadRules(tbCode)
	if len(ruleLists) <= 0 {
		t.Logf("load rule by tbcode: %v fail, err: is empty", tbCode)
	} else {
		for i := 0; i < len(ruleLists); i++ {
			t.Logf("rule: %+v", ruleLists[i])
		}
	}

	filter := NewRuleFilterImpl(tbCode, uavOne, ruleLists)
	filtered := filter.FilterByTaskCancelStatus()
	t.Logf("not exist cancel item, filter result: %v", filtered)
	{
		//set and check exist
		countertask.NewCancelTaskImpl(nil).LogCancelOnUav(tbCode, uavOne.GetSn(), uavOne.GetObjID(), uavOne.GetFreq())

		filtered := filter.FilterByTaskCancelStatus()
		t.Logf("after set filter result: %v", filtered)

		time.Sleep(3 * time.Second)
		filteredTimeout := filter.FilterByTaskCancelStatus()
		t.Logf("after set filter result: %v", filteredTimeout)
	}

	{
		filter.ruleList = nil
		filter.ruleList = append(filter.ruleList, &pb.AutoCounterRuleQueryResponse{
			RuleEnable: 1,
			RuleTimeDay: &pb.RuleInvalidTime{
				StartHour:        proto.Int32(2),
				EndHour:          proto.Int32(8),
				EndMinute:        proto.Int32(30),
				CrossDay:         proto.Int32(1),
				RuleDurationTime: 3600 * 24,
			},
		})
		filterByTime := filter.FilterByTimeAndEnable()
		if filterByTime == false {
			t.Logf("filter by time")
		} else {
			t.Logf("not filter by time.")
		}
	}

	{
		//测试无人机位置在反制区； 或者围栏区位置关系
		filterByLoc := filter.FilterByLocAndUniqueCross()
		if filterByLoc {
			t.Logf("not filter by location of uav")
		} else {
			t.Logf("filter by loca uav and area.")
		}

	}
}

func TestFilterByMode(t *testing.T) {
	tbCode := "000001"

	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())
	CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](dbHandler).SetTabName(model.CounterAreaConfig{}.TableName())

	ruleLists := LoadRules(tbCode)
	if len(ruleLists) <= 0 {
		t.Logf("load rule by tbcode: %v fail, err: is empty", tbCode)
	} else {
		for i := 0; i < len(ruleLists); i++ {
			t.Logf("rule: %+v", ruleLists[i])
		}
	}

	uavOne := &pb.DevLocationInfo{
		Longitude: 113.99731402504435, // 经度
		Latitude:  22.597524973906644, // 纬度
		// 设备sn (无人机)
		Sn: "dj-mav3-1231",
		// 设备 objID,真实设备有objID就填充。
		ObjID: "",
		// c2 sn(如果是侦测的无人机，需要填充侦测的c2; 如果是c2本身，则填充c2 sn)
		C2Sn: "a1b990c7-0eec-4531-bfdf-837ce154e6bf",
		// 无人机名字
		Name: "dj-mav3",
		// 侦测设备的sn
		DetectDevSn: "sfl200",
		// 标识本次请求id（由调用方来设置，服务方转发）
		UniqueId: time.Now().UnixMilli(),
		// 飞手经度
		PilotLongitude: 114.08500798614935,
		// 飞手纬度
		PilotLatitude: 22.611183496839246,
		// 返航点经度
		HomeLongitude: 114.08500798614935,
		// 返航点纬度
		HomeLatitude: 22.611183496839246,
		// 无人机频率
		Freq: 0.0,
		// 侦测设备类型, 比如: Sfl, Sfl200, Spoofer
		EType: "Sfl",
	}
	filter := NewRuleFilterImpl(tbCode, uavOne, ruleLists[0:1])
	advisedUavList := []*pb.CounterMeasureRecommendResponse{
		&pb.CounterMeasureRecommendResponse{
			// 反制设备的sn
			DevSn: "test_sfl200",
			// 反制设备名字
			DevName: "sfl200-device-name",
			// 反制设备的类型，比如: device_manager.DeviceType 类型
			DevType: int32(device_manager.DEV_NSF4000),
			// 设备是否在打击中; true: is hitting, false: not hitting
			IsHitting: false,
			// 侦测设备对应 c2Sn
			C2Sn: "c2_sn_1231312313",
			// 无人机到设备的距离（单位为米）
			TargetDistance: 100,
			// 子设备信息
			SubDevList: []*pb.SubDevItem{
				&pb.SubDevItem{
					DevSn:   "sfl100-子设备",
					DevType: int32(device_manager.DEV_SFL),
				},
			},
			// 径向距离
			RadialDistance: 100,
			// 俯仰角
			PitchAngle: 100,
			// 方位角
			AzimuthAngle: 100,
		}}
	filter.SetAdviseDeviceList(advisedUavList)
	//
	deviceRuleList := filter.FilterByMode()
	if len(deviceRuleList) <= 0 {
		t.Logf("filter by mod is empty")
	} else {
		t.Logf("not filter by mode.")
		for i := 0; i < len(deviceRuleList); i++ {
			if deviceRuleList[i] == nil {
				continue
			}
			//
			t.Logf("device: %v", deviceRuleList[i])
		}
	}
}

func TestGetDeviceWorkMode(t *testing.T) {
	//tbCode := "000001"
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
		//
		config.ServiceCfg.Redis.Host = "10.240.34.36"
		config.ServiceCfg.Redis.Port = 30356
		config.ServiceCfg.Redis.DataBase = 15
		config.ServiceCfg.Redis.Password = "ZAQ!2wsx"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](dbHandler).SetTabName(model.CounterAreaConfig{}.TableName())
	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	//初始化 redis handle.
	config.GlobalRedis = redis.NewSkyFendRedisClient(
		redis.WithRedisAddrOpt(fmt.Sprintf("%v:%d", config.ServiceCfg.Redis.Host, config.ServiceCfg.Redis.Port)),
		redis.WithRedisDB(config.ServiceCfg.Redis.DataBase),
		redis.WithRedisPasswd(config.ServiceCfg.Redis.Password),
	) //

	device := &pb.CounterMeasureRecommendResponse{
		// 反制设备的sn
		DevSn: "test_sfl200",
		// 反制设备名字
		DevName: "sfl200-device-name",
		// 反制设备的类型，比如: device_manager.DeviceType 类型
		DevType: int32(device_manager.DEV_SFL), // int32(device_manager.DEV_NSF4000),
		// 设备是否在打击中; true: is hitting, false: not hitting
		IsHitting: false,
		// 侦测设备对应 c2Sn
		C2Sn: "c2_sn_1231312313",
		// 无人机到设备的距离（单位为米）
		TargetDistance: 100,
		// 子设备信息
		SubDevList: []*pb.SubDevItem{
			&pb.SubDevItem{
				DevSn:   "sfl100-子设备",
				DevType: int32(device_manager.DEV_SFL),
			},
		},
		// 径向距离
		RadialDistance: 100,
		// 俯仰角
		PitchAngle: 100,
		// 方位角
		AzimuthAngle: 100,
	}

	ts := createPostServer(t)
	if ts == nil {
		return
	}
	defer ts.Close()

	err, item := GetDeviceWorkMode(device, ts.URL)
	if err != nil {
		t.Logf("get device work mode fail, err: %v", err)
	} else {
		if item == nil {
			t.Logf("get device work mode is empty")
		} else {
			t.Logf("get device work mode: %v", *item)
		}
	}
}

func createTestServer(fn func(w http.ResponseWriter, r *http.Request)) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(fn))
}

func createPostServer(t *testing.T) *httptest.Server {
	ts := createTestServer(func(w http.ResponseWriter, r *http.Request) {
		t.Logf("Method: %v", r.Method)
		t.Logf("Path: %v", r.URL.Path)
		t.Logf("rawQuery: %v", r.URL.RawQuery)
		//
		t.Logf("Content-Type: %v", r.Header.Get(http.CanonicalHeaderKey("Content-Type")))

		if r.Method != "POST" {
			return
		}

		var body []byte
		var err error
		//
		switch r.URL.Path {
		case "/inner/rest/v1/device/services/get":
			response := &device_manager.StatusQueryOut{
				ErrorCode:    0,
				ErrorMessage: "succ",
				Data: &device_manager.DataOutInfo{
					Tid:       "tid_1",
					Bid:       "bid_1",
					Timestamp: time.Now().UTC().UnixMilli(),
					Sn:        "device_sn",
					MsgData: device_manager.MsgDataOut{
						Result: device_manager.ResultOut{
							ErrorCode: 0,
							ErrorMsg:  "succ",
						},
						Data: &device_manager.SflStatusQueryResposeMsg{
							Sn:            "sn_device_1",
							HitTime:       10,
							HitPitch1:     1,
							HitPitch2:     1,
							HitAngleBegin: 1,
							HitAngleEnd:   1,
							HitMode:       2,
						},
					},
				},
			}
			body, err = json.Marshal(response)
			if err != nil {
				t.Logf("marshal response fail, err: %v", err)
				return
			}

			t.Logf("response: %v", *response)

		default:
			return
		}
		w.Header().Set(http.CanonicalHeaderKey("Content-Type"), "application/json; charset=utf-8")
		_, _ = w.Write(body)
	})
	return ts
}

func TestCounterAutoTaskStart(t *testing.T) {
	tbCode := "000001"

	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	AutoCounterRuleDBHandle = db.NewDBModelTplWrapper[model.AutoCounterRuleConfig](dbHandler).SetTabName(model.AutoCounterRuleConfig{}.TableName())
	FenceAreaDBHandle = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())
	CounterAreaDbHandle = db.NewDBModelTplWrapper[model.CounterAreaConfig](dbHandler).SetTabName(model.CounterAreaConfig{}.TableName())
	countertask.CounterTaskDBHandle = db.NewDBModelTplWrapper[model.CounterTask](dbHandler).SetTabName(model.CounterTask{}.TableName())

	ruleLists := LoadRules(tbCode)
	if len(ruleLists) <= 0 {
		t.Logf("load rule by tbcode: %v fail, err: is empty", tbCode)
	} else {
		for i := 0; i < len(ruleLists); i++ {
			t.Logf("rule: %+v", ruleLists[i])
		}
	}

	request := &request.CounterTaskAutoStartRequest{
		DeviceName: "sfl200-device",
		DeviceType: "Sfl200",
		DeviceSn:   "sfl200-sn-123231",
		HitMode:    2,
		ObjName:    "无人机1", //sn
		ObjType:    "123",  //objId
		ExtraParams: map[string]any{
			"freq":  12.3123,
			"objId": "123",
		}, //存放 freq  and obj id for auto counter task.
		HitDurTimeSecond: 30, // 30s
		TbCode:           "000001",
		RuleId:           1295421463029743812,
	}
	countertask.NewCounterTaskOps(nil).CounterAutoTaskStart(context.Background(), request, 1295421463029743830)
}
