package auto_counter_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/domain/service/counter_recommend"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"strconv"
	"time"
)

const (
	RuleEnable  = 1 //规则打开
	RuleDisable = 2 //规则关闭
)

const (
	RuleNoWholeDay = 0 //不是全天
	RuleWholeDay   = 1 //是全天
)

const (
	RuleNoCrossDay = 0 //不跨天
	RuleCrossDay1  = 1 //跨1天
)

const (
	ModeNoDisable            int32 = 0     // 不禁用任何模式
	ModeRadioHitDisable      int32 = 0x01  //禁用无线电打击,
	ModeSpooferDisable       int32 = 0x10  //禁用诱骗
	ModeSpooferAndHitDisable int32 = 0x100 //禁用诱打联动
	// example: 0 不禁用任何模式, 0x01(1): 禁用无线电打击, 0x10(16): 禁用诱骗, 0x100(256): 禁用诱打联动,
	// 0x11(17): 禁止无线打击+诱骗; 0x101(257): 禁止无线打击+诱打联动; 0x110(272): 禁止诱骗+诱打联动;
	// 0x111(273): 禁止无线电打击+诱骗+诱打联动
	//
)

// LoadRules 加载本地自动处置规则
func LoadRules(tbCode string) []*pb.AutoCounterRuleQueryResponse {
	rulesList, err := QueryRules(tbCode, &pb.AutoCounterRuleQueryRequest{
		PageIndex: 1,
		PageSize:  1000, //暂时一次性全部拉过来
	}, false)

	if err != nil {
		logger.Errorf("query rule list fail, err: %v, tbCode: %v", err, tbCode)
		return nil
	}

	return rulesList.GetData()
}

// AutoCounterService 自动反制服务(推荐一个设备用于打击, 属于后台任务)
type AutoCounterService struct {
	// 定义一个已经被推荐的设备列表，每次推荐需要先排除已经被推荐设备列表。// key是设备 sn
	AdvisedDevice map[string]bool //key:  sn
}

func NewAutoCounterService() *AutoCounterService {
	return &AutoCounterService{
		AdvisedDevice: make(map[string]bool),
	}
}

// AutoCounter 自动反制(入口), tbCode 和 无人机列表
func (ac *AutoCounterService) AutoCounter(tbCode string, uavList []*pb.DevLocationInfo) {
	if tbCode == "" || len(uavList) == 0 {
		logger.Errorf("input param is nil for auto counter")
		return
	}

	ruleList := LoadRules(tbCode)
	if len(ruleList) <= 0 {
		return
	}

	routinues.GoSafe(func() {
		for i := 0; i < len(uavList); i++ {
			if uavList[i] == nil {
				continue
			}
			ac.AutoCounterEachUav(tbCode, uavList[i], ruleList) //对每个无人机使用反制规则进行反制
		}
	})
}

// DeviceIsChosen 设备是否已被选中
func (ac *AutoCounterService) DeviceIsChosen(device *pb.CounterMeasureRecommendResponse) bool {
	if device == nil {
		return false
	}

	key := GetHasAdvisedDeviceKey(device.DevSn)
	_, ok := ac.AdvisedDevice[key]
	if ok {
		return true
	}
	return false
}

func (ac *AutoCounterService) SetDeviceChosen(device *pb.CounterMeasureRecommendResponse) {
	if device == nil {
		return
	}
	key := GetHasAdvisedDeviceKey(device.DevSn)
	ac.AdvisedDevice[key] = true
}

func IsFreqDevice(uav *pb.DevLocationInfo) bool {
	if uav == nil {
		return false
	}
	if uav.GetSn() == "" && uav.GetObjID() == "" {
		return true
	}
	return false
}

type DeviceStatusInfo struct {
	Mode        int32   // 参考： constant.定义的mode
	ComplexMode []int32 //参考： constant.定义的mode
}

// GetDeviceWorkMode 通过查询, 获取设备配置
func GetDeviceWorkMode(device *pb.CounterMeasureRecommendResponse, host string) (error, *DeviceStatusInfo) {
	if device == nil {
		return fmt.Errorf("device is nil"), nil
	}

	var retDeviceStatus *DeviceStatusInfo = nil
	defer func() {
		if retDeviceStatus != nil {
			logger.Infof("return device status info: %v", *retDeviceStatus)
		}
	}()

	if device.DevType == int32(device_manager.DEV_SFL) {
		response, err := device_manager.NewSflStatusQueryHandle(device.GetC2Sn(), device.GetDevSn(), device_manager.SFL_QUERY_Conf, host).Query()
		if err != nil {
			logger.Errorf("query sfl config fail, err: %v, sfl sn: %v", err, device.GetDevSn())
			return fmt.Errorf("query fail: %v", err), nil
		}

		devType := constant.DeviceTypeSfl + strconv.Itoa(int(response.HitMode))
		mode, ok := constant.DeviceTypeHitModeOutMap[devType]
		if ok {
			retDeviceStatus = &DeviceStatusInfo{
				Mode: int32(mode),
			}
			return nil, retDeviceStatus

		} else {
			logger.Infof("not exist map for sfl hit mode: %v", response.HitMode)
			return fmt.Errorf("hit mode not exit"), nil
		}

	} else if device.DevType == int32(device_manager.DEV_SFL200) {

		//TODO: 默认使用 normal
		retDeviceStatus = &DeviceStatusInfo{
			ComplexMode: []int32{int32(constant.Sfl200HitModeNormalOut), int32(constant.Sfl200HitModeActiveDefenseOut)},
		}
		return nil, retDeviceStatus

	} else if device.DevType == int32(device_manager.DEV_NSF4000) {

		retDeviceStatus = &DeviceStatusInfo{
			Mode: constant.SpooferHitModeActiveDefenseOut,
		}
		return nil, retDeviceStatus
	}
	return fmt.Errorf("not support device type"), nil
}

// CheckDeviceStatusInRule 检查设备状态是否满足规则的使能; deviceWithRule 是设备信息， deviceStatus 设备查询到的状态信息
func CheckDeviceStatusInRule(deviceWithRule *DeviceWithRuleId, deviceWorkMode *DeviceStatusInfo) bool {
	if deviceWithRule == nil {
		return false
	}
	if deviceWorkMode == nil {
		logger.Infof("not support work mode.")
		//没有状态信息，则返回true
		return false
	}

	if len(deviceWithRule.RuleOption) <= 0 {
		logger.Errorf("not exist rule")
		return false
	}

	if deviceWithRule.RuleOption[0].CapacityDisable == ModeNoDisable {

		if deviceWithRule.Device.DevType == int32(device_manager.DEV_SFL200) {
			deviceWithRule.DeviceEnable.ComplexMode = deviceWorkMode.ComplexMode
		} else {
			deviceWithRule.DeviceEnable.Mode = deviceWorkMode.Mode
		}
		return true
	}

	if deviceWithRule.RuleOption[0].CapacityDisable == ModeRadioHitDisable { //禁用无线电打击

		if deviceWithRule.Device.DevType == int32(device_manager.DEV_SFL200) {
			for i := 0; i < len(deviceWorkMode.ComplexMode); i++ {
				if deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeActiveDefenseOut || //是 spoofer 诱导一种
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeAreaDenialOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeSirectionalDisplacementOut {

					//取其中的一个模式
					deviceWithRule.DeviceEnable.ComplexMode = []int32{deviceWorkMode.ComplexMode[i]}
					return true
				}
			}
		}

		if deviceWithRule.Device.DevType == int32(device_manager.DEV_NSF4000) {
			deviceWithRule.DeviceEnable.Mode = deviceWorkMode.Mode
			return true
		}

		logger.Infof("rule disable: %v, device mode: %v", deviceWithRule.RuleOption[0].CapacityDisable, deviceWorkMode.Mode)
		return false
	}

	if deviceWithRule.RuleOption[0].CapacityDisable == ModeSpooferDisable {

		if deviceWithRule.Device.DevType == int32(device_manager.DEV_SFL200) {
			for i := 0; i < len(deviceWorkMode.ComplexMode); i++ {
				if deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeNormalOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeGNSSOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeNormalAndGNSSOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeFpvOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeQuanpinduanOut ||
					deviceWorkMode.ComplexMode[i] == constant.Sfl200HitModeQuanpinduanAndGNSSOut {

					//取其中的一个模式
					deviceWithRule.DeviceEnable.ComplexMode = []int32{deviceWorkMode.ComplexMode[i]}
					return true
				}
			}
		}

		if deviceWithRule.Device.DevType == int32(device_manager.DEV_SFL) {
			deviceWithRule.DeviceEnable.Mode = deviceWorkMode.Mode
			return true
		}

		logger.Infof("rule disable: %v, device mode: %v", deviceWithRule.RuleOption[0].CapacityDisable, deviceWorkMode.Mode)
		return false
	}
	return false
}

// AutoCounterEachUav 对每台无人机根据所有规则列表， 进行自动反制
func (ac *AutoCounterService) AutoCounterEachUav(tbCode string, oneUav *pb.DevLocationInfo, ruleList []*pb.AutoCounterRuleQueryResponse) {

	filter := NewRuleFilterImpl(tbCode, oneUav, ruleList)
	if !filter.Filter() { //不存在反制规则列表
		logger.Infof("after filter, not valid rule to auto counter.")
		return
	}

	uavInfo := &pb.CounterMeasureRecommendRequest{
		// 无人机sn.
		Sn: oneUav.GetSn(),
		// 无人机的objID,能拿到就填
		ObjId: oneUav.GetObjID(),
		// 无人机名字
		Name: oneUav.GetName(),
		// 无人机经度
		Longitude: oneUav.GetLongitude(),
		// 无人机纬度
		Latitude: oneUav.GetLatitude(),
		// 无人机高度,单位为米
		//TODO:
		Altitude: 0.0,
		// 飞手的经度
		PilotLongitude: oneUav.GetPilotLongitude(),
		// 飞手的纬度
		PilotLatitude: oneUav.GetPilotLatitude(),
		// c2 sn
		C2Sn: oneUav.GetC2Sn(),
		// 侦测设备列表：用于频谱侦测设备的分配
		// TODO: 需要传递一个 eType, devName
		DeviceList: []*pb.DetectDevices{
			&pb.DetectDevices{
				EType: oneUav.GetEType(),
				Sn:    oneUav.GetDetectDevSn(),
			},
		},
	}

	adviseDeviceList, err := counter_recommend.GetCounterDeviceListOnUav(context.Background(), tbCode, uavInfo)
	if err != nil {
		logger.Errorf("counter device advise fail, err: %v, tbCode: %v, uavSn: %v", err, tbCode, oneUav.GetSn())
		return
	}

	if len(adviseDeviceList) == 0 {
		logger.Infof("no device for advise to counter, tbCode: %v, uavSn: %v", tbCode, oneUav.GetSn())
		return
	}

	filter.SetAdviseDeviceList(adviseDeviceList)

	deviceRuleList := filter.FilterByMode()
	if len(deviceRuleList) == 0 {
		logger.Debugf("has no device to advise.")
		return
	}

	var chosenDevice *DeviceWithRuleId = nil
	for i := 0; i < len(deviceRuleList); i++ {
		counterDevice := deviceRuleList[i]
		if counterDevice == nil {
			continue
		}

		if counterDevice.Device == nil {
			continue
		}

		err, deviceWorkMode := GetDeviceWorkMode(counterDevice.Device, "")
		if err != nil {
			logger.Errorf("get device work mode fail, %v", err)
			continue
		}

		permit := CheckDeviceStatusInRule(counterDevice, deviceWorkMode)
		if permit == false {
			logger.Infof("not permit for device by rule")
			continue
		}

		// 查询该设备默认的工作模式， 如果工作模式和规则禁用的模式匹配，则过滤该设备
		isChosen := ac.DeviceIsChosen(counterDevice.Device)
		if isChosen {
			continue
		}

		ac.SetDeviceChosen(counterDevice.Device)
		chosenDevice = counterDevice
		break
	}

	if chosenDevice == nil {
		logger.Infof("no valid device to advise for uav, uav sn: %v, obj: %v", oneUav.GetSn(), oneUav.GetObjID())
		return
	}

	// 触发打击，等待回来创建任务
	autoCounterTaskHandle := NewAutoCounterTaskImpl(chosenDevice, tbCode, oneUav)
	if err := autoCounterTaskHandle.CounterWithDevice(); err != nil {
		logger.Errorf("auto counter with device fail")
		return
	}
	if err := autoCounterTaskHandle.BuildTask(); err != nil {
		logger.Errorf("build auto counter task fail.")
		return
	}
	return
}

func GetHasAdvisedDeviceKey(devSn string) string {
	key := fmt.Sprintf("rule:device:%s", devSn)
	return key
}

// NewRuleFilterImpl 创建一个rule filter
func NewRuleFilterImpl(tbCode string, uav *pb.DevLocationInfo, ruleList []*pb.AutoCounterRuleQueryResponse) *RuleFilterImpl {
	return &RuleFilterImpl{
		curTime:  time.Now().UTC(), //当前反制的时间点
		tbCode:   tbCode,           // 租户编码
		uav:      uav,              // 本次无人机的信息
		ruleList: ruleList,         // 逻辑内不要修改 rule list.
	}

}

// RuleFilterImpl 无人机自动反制规则过滤实现，包括各种场景的过滤
type RuleFilterImpl struct {
	//入参: 逻辑依赖的数据
	tbCode  string
	uav     *pb.DevLocationInfo //自动推荐打击的无人机
	curTime time.Time           //自动打击推荐的时间点

	// 每个无人机适用的反制规则列表 (无人机是否在反制区，多个反制区取最新的); 去除不满足的规则，最后得到能触发打击的规则 列表
	ruleList []*pb.AutoCounterRuleQueryResponse

	// 从推荐设备的接口获取设备列表
	adviceDeviceList []*pb.CounterMeasureRecommendResponse
}

// SetAdviseDeviceList 设置自动打击推荐设备列表
func (rf *RuleFilterImpl) SetAdviseDeviceList(devList []*pb.CounterMeasureRecommendResponse) {
	for i := 0; i < len(devList); i++ {
		if devList[i] != nil {
			continue
		}
		logger.Infof("set advised device list: %+v", *(devList[i]))
	}

	rf.adviceDeviceList = devList
}

// FilterByTimeAndEnable 根据规则中设定的时间和当前时间，得到存在有效规则; true 存在规则， 没被过滤掉， false 不存在规则， 表示被过滤掉
func (rf *RuleFilterImpl) FilterByTimeAndEnable() bool {
	nowTime := time.Now().UTC()

	var ruleListTmp []*pb.AutoCounterRuleQueryResponse
	for i := 0; i < len(rf.ruleList); i++ {
		if rf.ruleList[i].GetRuleEnable() != RuleEnable {
			continue
		}

		if rf.ruleList[i].GetRuleTimeDay().GetWholeDay() == int32(RuleWholeDay) { // 全天
			ruleListTmp = append(ruleListTmp, rf.ruleList[i])
			continue
		}

		//规则是在一段时间
		if rf.ruleList[i].GetRuleTimeDay().GetCrossDay() <= RuleNoCrossDay { //不跨天（当日）
			startTime := time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(),
				int(rf.ruleList[i].GetRuleTimeDay().GetStartHour()),
				int(rf.ruleList[i].GetRuleTimeDay().GetStartMinute()),
				int(rf.ruleList[i].GetRuleTimeDay().GetStartSecond()),
				0, time.UTC).UTC()

			endTime := startTime.Add(time.Duration(rf.ruleList[i].GetRuleTimeDay().RuleDurationTime) * time.Second).UTC()

			if rf.curTime.UnixMilli() >= startTime.UnixMilli() && rf.curTime.UnixMilli() <= endTime.UnixMilli() {
				logger.Infof("not cross day, current time: %v, begin time: %v, end time: %v", rf.curTime.UnixMilli(), startTime, endTime)
				ruleListTmp = append(ruleListTmp, rf.ruleList[i])
			}
			continue
		}

		// 跨天: 次日
		startTime := time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(),
			int(rf.ruleList[i].GetRuleTimeDay().GetStartHour()),
			int(rf.ruleList[i].GetRuleTimeDay().GetStartMinute()),
			int(rf.ruleList[i].GetRuleTimeDay().GetStartSecond()),
			0, time.UTC).UTC()

		endTime := startTime.Add(time.Duration(rf.ruleList[i].GetRuleTimeDay().RuleDurationTime) * time.Second).UTC()

		if rf.curTime.UnixMilli() >= startTime.UnixMilli() && rf.curTime.UnixMilli() <= endTime.UnixMilli() {
			logger.Debugf("cross day, nowTime: %v, start time: %v, endTime: %v; s_nowTm: %v; s_starTm: %v, s_endTm: %v",
				rf.curTime.UnixMilli(), startTime.UnixMilli(), endTime.UnixMilli(),
				rf.curTime, startTime, endTime)

			ruleListTmp = append(ruleListTmp, rf.ruleList[i])
		} else {
			logger.Debugf("nowTime: %v, start time: %v, endTime: %v; s_nowTm: %v; s_starTm: %v, s_endTm: %v",
				rf.curTime.UnixMilli(), startTime.UnixMilli(), endTime.UnixMilli(),
				rf.curTime, startTime, endTime)
		}
	}

	rf.ruleList = ruleListTmp
	if len(rf.ruleList) == 0 {
		logger.Debugf("not exist valid rule list for auto counter.")
		return false
	}
	return true
}

// CheckUavInArea 计算无人机是否在圈内
func CheckUavInArea(areaSite string, uav *pb.DevLocationInfo) (error, bool) {
	item, err := geo.ParseGeoJsonToPolygons(areaSite)
	if err != nil {
		logger.Errorf("parse geo fail, origin src: %v", areaSite)
		return err, false
	}
	exist, err := geo.GeoCheckPointInPolygons(uav.GetLongitude(), uav.GetLatitude(), item)
	return err, exist
}

// FilterByLocAndUniqueCross 使用规则中的位置空间来检查无人机是否可以触发自动反制; 最终存在反制区：true 没被过滤掉， 不存在反制区：false 表示被过滤掉
func (rf *RuleFilterImpl) FilterByLocAndUniqueCross() bool {
	// 定义满足一定条件的反制规则
	var ruleListTmp []*pb.AutoCounterRuleQueryResponse
	// 是频谱侦测到无人机。
	if IsFreqDetectUav(rf.uav.GetSn(), rf.uav.GetObjID()) {
		return true
	}

	for i := 0; i < len(rf.ruleList); i++ {
		// 使用反制区
		area := rf.ruleList[i].GetCounterArea()
		if area != nil { //反制区存在
			//
			err, exist := CheckUavInArea(area.GetGeometry(), rf.uav)
			if err == nil && exist {
				ruleListTmp = append(ruleListTmp, rf.ruleList[i])
			}

		} else {

			// 使用围栏区
			area := rf.ruleList[i].GetFenceAreaItem()
			if area != nil { //存在

				err, exist := CheckUavInArea(area.GetGeometry(), rf.uav)
				if err == nil && exist {
					ruleListTmp = append(ruleListTmp, rf.ruleList[i])
				}
			}
		}
	}

	rf.ruleList = ruleListTmp // 取交叉反制区最新的规则
	logger.Debugf("after check uav in fence, area or counter area, area info len: %v", len(rf.ruleList))

	// 取多个区域交叉时最新的区域 (从多个中取一个)
	if IsFreqDetectUav(rf.uav.GetSn(), rf.uav.GetObjID()) == false && len(rf.ruleList) > 1 {
		var ret []*pb.AutoCounterRuleQueryResponse
		var cmpTime int64 = int64(-1)
		var tmpNode *pb.AutoCounterRuleQueryResponse = nil

		for i := 0; i < len(rf.ruleList); i++ {
			if rf.ruleList[i].GetCounterArea() != nil {
				tm, err := strconv.ParseInt(rf.ruleList[i].GetCounterArea().GetUpdateTime(), 10, 64)
				if err != nil {
					continue
				}

				if cmpTime <= tm {
					cmpTime = tm
					tmpNode = rf.ruleList[i]
				}
			}

			if rf.ruleList[i].GetFenceAreaItem() != nil {
				tm, err := strconv.ParseInt(rf.ruleList[i].GetFenceAreaItem().GetUpdateTime(), 10, 64)
				if err != nil {
					continue
				}

				if cmpTime <= tm {
					cmpTime = tm
					tmpNode = rf.ruleList[i]
				}
			}
		}

		if tmpNode != nil {
			logger.Debugf("exist valid rule item, %+v", *tmpNode)
			ret = append(ret, tmpNode)
		}
		rf.ruleList = ret
	}

	if len(rf.ruleList) == 0 {
		logger.Debugf("not exist rule list after FilterByLocAndUniqueCross")
		return false
	}
	return true
}

type DeviceWithDisable struct {
	Device          *pb.CounterMeasureRecommendResponse
	CapacityDisable int32 // 0:不禁用， 1: 禁用 hit ; 2: 禁用 reduce.
}

// DeviceRuleDisable 规则id 和设备的能力选项
type DeviceRuleDisable struct {
	// RuleItem 具体规则
	RuleItem *pb.AutoCounterRuleQueryResponse

	// CapacityDisable RuleItem 规则的使能情况:
	// ModeNoDisable            int32 = 0     // 不禁用任何模式
	// ModeRadioHitDisable      int32 = 0x01  // 禁用无线电打击,
	// ModeSpooferDisable       int32 = 0x10  // 禁用诱骗
	// ModeSpooferAndHitDisable int32 = 0x100 // 禁用诱打联动
	CapacityDisable int32
}
type DeviceCounterMode struct {
	Mode        int32   //设备当前的模式, 参考constant.
	ComplexMode []int32 // //设备当前的模式, 参考constant.
}

// DeviceWithRuleId 带有满足规则列表的打击设备
type DeviceWithRuleId struct {
	Device *pb.CounterMeasureRecommendResponse // 单个反制设备
	//处理完后最多有一个规则可用
	RuleOption []DeviceRuleDisable // 每个反制设备具有规则列表和每个规则的关闭能力
	// 设备允许能力：用于下发给谁设备。
	DeviceEnable DeviceCounterMode
}

// FilterByMode 根据规则模式过滤反制无人机; 返回每个设备具有的规则列表;
func (rf *RuleFilterImpl) FilterByMode() []*DeviceWithRuleId {
	var deviceList []*DeviceWithRuleId

	//如果是频谱侦测到的无人机，优先使用反制设备 sfl（normal模式优先），其次推荐Spoofer（模式无所谓）
	if IsFreqDetectUav(rf.uav.GetSn(), rf.uav.GetObjID()) { //如果是频谱侦测无人机
		//for i := 0; i < len(rf.adviceDeviceList); i++ {
		//	if rf.adviceDeviceList[i].DevType == int32(device_manager.DEV_SFL) {
		//		ret.Device = rf.adviceDeviceList[i]
		//	} else {
		//		//
		//	}
		//	var ruleIdOpt []DeviceRuleDisable
		//	deviceList = append(deviceList, &DeviceWithRuleId{
		//		Device:     rf.adviceDeviceList[i],
		//		RuleOption: ruleIdOpt,
		//	})
		//}
		// 如果是频谱侦测到的无人机，不推荐设备
		return deviceList
	}

	for i := 0; i < len(rf.adviceDeviceList); i++ {
		if rf.adviceDeviceList[i] == nil {
			continue
		}

		if len(rf.ruleList) > 1 {
			logger.Errorf("auto counter rule exist more than one for no-freq-detect uav")
			continue
		}

		var ruleIdOpt []DeviceRuleDisable
		for j := 0; j < len(rf.ruleList); j++ {
			if rf.ruleList[j] == nil {
				continue
			}

			if rf.ruleList[j].ForbiddenMode == ModeNoDisable { // 0x00: 不禁止任何模式
				ruleIdOpt = append(ruleIdOpt, DeviceRuleDisable{
					RuleItem:        rf.ruleList[j],
					CapacityDisable: ModeNoDisable,
				})

			} else if rf.ruleList[j].ForbiddenMode == ModeRadioHitDisable { // 0x01: 禁用无线电打击
				if rf.adviceDeviceList[i].DevType != int32(device_manager.DEV_SFL) {
					ruleIdOpt = append(ruleIdOpt, DeviceRuleDisable{
						RuleItem:        rf.ruleList[j],
						CapacityDisable: ModeRadioHitDisable,
					})
				}

			} else if rf.ruleList[j].ForbiddenMode == ModeSpooferDisable { //0x10: 禁用诱骗
				if rf.adviceDeviceList[i].DevType != int32(device_manager.DEV_NSF4000) {
					ruleIdOpt = append(ruleIdOpt, DeviceRuleDisable{
						RuleItem:        rf.ruleList[j],
						CapacityDisable: ModeSpooferDisable,
					})
				}

			} else if rf.ruleList[j].ForbiddenMode == ModeSpooferAndHitDisable { //0x100 禁用诱打联动
				if rf.adviceDeviceList[i].DevType != int32(device_manager.DEV_NSF4000) &&
					rf.adviceDeviceList[i].DevType != int32(device_manager.DEV_SFL200) &&
					rf.adviceDeviceList[i].DevType != int32(device_manager.DEV_SFL) {
					ruleIdOpt = append(ruleIdOpt, DeviceRuleDisable{
						RuleItem:        rf.ruleList[j],
						CapacityDisable: ModeSpooferAndHitDisable,
					})
				}
				continue

			} else if rf.ruleList[j].ForbiddenMode == ModeRadioHitDisable|ModeSpooferDisable { //0x11: 禁止无线电打击+诱骗
				continue
			} else if rf.ruleList[j].ForbiddenMode == ModeRadioHitDisable|ModeSpooferAndHitDisable { //0x101: 禁止无线电打击+ 诱打联动
				continue
			} else if rf.ruleList[j].ForbiddenMode == ModeSpooferDisable|ModeSpooferAndHitDisable { // 0x110: 禁止诱骗+诱打联动
				continue
			} else if rf.ruleList[j].ForbiddenMode == ModeRadioHitDisable|ModeSpooferDisable|ModeSpooferAndHitDisable { //0x111: 禁止无线电打击+诱骗+诱打联动
				continue
			}
		}

		if len(ruleIdOpt) == 0 {
			logger.Infof("has no fit rule for device, device sn: %v", rf.adviceDeviceList[i].GetDevSn())
			continue // 没有满足的规则
		}

		deviceList = append(deviceList, &DeviceWithRuleId{
			Device:     rf.adviceDeviceList[i],
			RuleOption: ruleIdOpt,
		})
	}

	return deviceList
}

// IsFreqDetectUav 判断是否是频谱侦测到无人机
func IsFreqDetectUav(uavSn string, objId string) bool {
	if uavSn == "" && objId == "" {
		return true
	}
	return false
}

// FilterByTaskCancelStatus 使用无人机最新的工作任务状态来检查无人机是否可以触发自动反制;
// 比如: 通过取消按钮停止这次打击。 终止后，在该目标本次事件的余下时段内，打击设备不再对其发起自动打击任务。
// 当该目标离开侦测范围后再次进入自动反制规则区域，将再次触发自动打击任务。
// 结果：true 没被过滤掉， false 表示被过滤掉
func (rf *RuleFilterImpl) FilterByTaskCancelStatus() bool {

	// 只有在无人机当前状态是 已取消，当前入侵事件id不存在(之前消失过)时才会被进入打击范围。
	if rf == nil || rf.tbCode == "" || rf.uav == nil {
		return false
	}

	if IsFreqDetectUav(rf.uav.GetSn(), rf.uav.GetObjID()) {
		if rf.uav.GetFreq() <= 0.00001 {
			logger.Infof("uav is freq detect and freq is 0")
			return true
		}
	}

	// 在取消反制任务时添加记录，如果有持续被触发打击，当存在取消反制时，则需要打击
	err, noExist := countertask.NewCancelTaskImpl(nil).FreshLogCancelOnUav(rf.tbCode, rf.uav.GetSn(), rf.uav.GetObjID(), rf.uav.GetFreq())
	if err != nil {
		logger.Errorf("check cancel task on uav fail, err: %v", err)
		return false
	}

	if noExist == 1 {
		return true
	}
	logger.Debug("cancel task is on valid, rf.uav.Sn: %v", rf.uav.GetSn())
	return false
}

// Filter 会更新每个无人机的规则列表； true， 存在反制规则， 没被过滤掉； false 不存在反制规则， 表示被过滤掉
func (rf *RuleFilterImpl) Filter() bool {
	if !rf.FilterByTaskCancelStatus() {
		return false
	}

	if !rf.FilterByTimeAndEnable() {
		return false
	}

	if !rf.FilterByLocAndUniqueCross() {
		return false
	}
	return true
}
