package auto_counter_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/infra/clients/http_clients"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"time"
)

const (
	SFL_HIT_OPSCODE     = 8 //打击opscode
	Spoofer_HIT_OPSCODE = 1 //spoofer 打击
)

// 自动任务的触发，包括数据构建，下发， 回包处理; 支持使用多种设备进行打击

type AutoTaskPayLoad struct {
	Sn            string `json:"sn"`
	HitMode       int32  `json:"hitMode"`
	DeviceName    string `json:"deviceName"`
	TargetUavType string `json:"targetUavType"` //无人机sn
}

type AutoTaskData struct {
	OpsCode int32           `json:"opsCode"`
	PayLoad AutoTaskPayLoad `json:"payload"`
}
type AutoTaskCommand struct {
	C2Sn string       `json:"c2Sn"`
	Type string       `json:"type"`
	Data AutoTaskData `json:"data"`
}

// sfl hit request body
type TaskHitSflRequestBody struct {
	DeviceType string          `json:"deviceType"`
	Command    AutoTaskCommand `json:"command"`
}
type TaskHitRequestResponse struct {
	ErrorCode    int  `json:"errorCode"`
	ErrorMessage any  `json:"errorMessage"`
	Data         bool `json:"data"`
}

// sflTaskHitReqHandle 定义sfl 打击 rpc handle.
var sflTaskHitReqHandle http_clients.HttpClientRpcType[TaskHitSflRequestBody, TaskHitRequestResponse] = http_clients.HttpClientCallTpl[TaskHitSflRequestBody, TaskHitRequestResponse]

// spoofer hit request
type HitSpooferPayLoad struct {
	Enable     bool   `json:"enable"`
	Sn         string `json:"sn"`
	HitMode    int32  `json:"hitMode"`
	DeviceName string `json:"deviceName"`
}

type HitSpooferData struct {
	OpsCode int32             `json:"opsCode"`
	PayLoad HitSpooferPayLoad `json:"payload"`
}
type HitSpooferCommand struct {
	C2Sn string         `json:"c2Sn"`
	Type string         `json:"type"`
	Data HitSpooferData `json:"data"`
}
type HitSpooferReqBody struct {
	DeviceType string            `json:"deviceType"`
	Command    HitSpooferCommand `json:"command"`
}

// spooferTaskHitReqHandle 定义sfl 打击 rpc handle.
var spooferTaskHitReqHandle http_clients.HttpClientRpcType[HitSpooferReqBody, TaskHitRequestResponse] = http_clients.HttpClientCallTpl[HitSpooferReqBody, TaskHitRequestResponse]

// ////////////////////////////////////////////////
// sfl200-sfl100- 定向打击
type Sfl200FreqDirectHitRequest struct {
	Sn           string  `json:"sn"`
	DroneHorizon float64 `json:"droneHorizon"` //方向角
	DronePitch   float64 `json:"dronePitch"`   // 俯仰角
	DeviceName   string  `json:"deviceName"`
	HitMode      int32   `json:"hitMode"`
}

type Sfl200HitOrientProperty struct {
	Request Sfl200FreqDirectHitRequest `json:"Sfl200FreqDirectHitRequest"`
}
type Sfl200HitOrientCommand struct {
	GateWaySn string                  `json:"gatewaySn"` //c2sn
	Property  Sfl200HitOrientProperty `json:"property"`
}
type Sfl200HitOrientReqBody struct {
	DeviceType string                 `json:"deviceType"` //Sfl200
	Command    Sfl200HitOrientCommand `json:"command"`
}

// sfl200-sfl100 精准打击 前无人机必须是这个设备协议解析发现的
type Sfl200DealUavRequest struct {
	Sn             string `json:"sn"`
	Type           int32  `json:"type"` // // 侦测类型， 0是频谱或雷达，1是协议解析
	ObjId          string `json:"objId"`
	DroneSn        string `json:"droneSn"`
	Classification int32  `json:"classification"` // 分类, 0-5,代表无人机，鸟等
	HitMode        int32  `json:"hitMode"`
}
type Sfl200HitUavProperty struct {
	Request Sfl200DealUavRequest `json:"Sfl200DealUavRequest"`
}
type Sfl200HitUavCommand struct {
	GateWaySn string               `json:"gatewaySn"` //c2sn
	Property  Sfl200HitUavProperty `json:"property"`
}
type Sfl200HitUavReqBody struct {
	DeviceType string              `json:"deviceType"` //Sfl200
	Command    Sfl200HitUavCommand `json:"command"`
}

var sfl200UavHitReqHandle http_clients.HttpClientRpcType[Sfl200HitUavReqBody, TaskHitRequestResponse] = http_clients.HttpClientCallTpl[Sfl200HitUavReqBody, TaskHitRequestResponse]

// sfl200-spoofer 精准打击 使用诱骗
type Sfl200StartNsf4000Request struct {
	Sn        string `json:"sn"`
	StartStop int32  `json:"startStop"` // // 0：停止打击 1：开启打击
	WorkType  int32  `json:"workType"`  // 2：区域拒止 3：主动防御 4：定向驱离
}

type Sfl200SpooferProperty struct {
	Request Sfl200StartNsf4000Request `json:"Sfl200StartNsf4000Request"`
}
type Sfl200SpooferHitCommand struct {
	GateWaySn string                `json:"gatewaySn"` //c2sn
	Property  Sfl200SpooferProperty `json:"property"`
}
type Sfl200SpooferHitReqBody struct {
	DeviceType string                  `json:"deviceType"` //Sfl200
	Command    Sfl200SpooferHitCommand `json:"command"`
}

var sfl200SpooferHandler http_clients.HttpClientRpcType[Sfl200SpooferHitReqBody, TaskHitRequestResponse] = http_clients.HttpClientCallTpl[Sfl200SpooferHitReqBody, TaskHitRequestResponse]

// /////////////////////////////////////////////////////////////////////////
// AutoCounterTask 自动反制任务定义
type AutoCounterTask struct {
	deviceInfo *DeviceWithRuleId   ////反制的设备
	tbCode     string              //租户编码
	uav        *pb.DevLocationInfo //被反制的无人机
	host       string
	uri        string
	tmOut      time.Duration
}

// NewAutoCounterTaskImpl 创建一个自动反制任务
func NewAutoCounterTaskImpl(dev *DeviceWithRuleId, tbCode string, uav *pb.DevLocationInfo) *AutoCounterTask {
	return &AutoCounterTask{
		deviceInfo: dev,    //反制的设备
		tbCode:     tbCode, //租户编码
		uav:        uav,    //被反制的无人机
		uri:        "/inner/rest/v1/device/task/set",
		host:       "http://cuav-cloud-access-service:8883",
		tmOut:      5 * time.Second,
	}
}

// CounterWithDevice 使用不同设备进行反制
func (act *AutoCounterTask) CounterWithDevice() error {
	if act == nil {
		return errors.New("handle not init")
	}

	if act.tbCode == "" || act.deviceInfo == nil || act.uav == nil {
		logger.Infof("not exist tb code or device or uav")
		return nil
	}

	if len(act.deviceInfo.RuleOption) <= 0 {
		logger.Infof("no exist any rule for counter.")
		return nil
	}

	if act.deviceInfo.Device == nil {
		logger.Infof("not exist any counter device for counter")
		return nil
	}

	var err error = nil
	switch act.deviceInfo.Device.DevType {
	case int32(device_manager.DEV_SFL200):
		// 使用sfl200 来反制 无人机
		err = act.CounterBySFL200()

	case int32(device_manager.DEV_SFL):
		//使用 sfL100 反制无人机
		err = act.CounterBySFL100()

	case int32(device_manager.DEV_NSF4000):
		//使用spoofer 进行反制无人机
		err = act.CounterBySpoofer()

	default:
		return fmt.Errorf("not support dev type")
	}

	if err != nil {
		logger.Errorf("auto counter fail, %v", err)
		return err
	}
	return nil
}

// CounterBySFL100 使用 sfl100 进行反制
func (act *AutoCounterTask) CounterBySFL100() error {
	if err := act.CheckInParam(); err != nil {
		return err
	}

	mode, ok := constant.HitModeMap[int(act.deviceInfo.DeviceEnable.Mode)]
	if !ok {
		logger.Errorf("not support sfl hit mode fail, src mode: %v", act.deviceInfo.DeviceEnable.Mode)
		return fmt.Errorf("mode not is exist")
	}

	var uavSn string
	if act.uav != nil {
		uavSn = act.uav.GetSn()
	}

	in := &TaskHitSflRequestBody{
		DeviceType: constant.DeviceTypeSfl,
		Command: AutoTaskCommand{
			C2Sn: act.deviceInfo.Device.GetC2Sn(),
			Type: "Sfl",
			Data: AutoTaskData{
				OpsCode: SFL_HIT_OPSCODE,
				PayLoad: AutoTaskPayLoad{
					Sn:            act.deviceInfo.Device.GetDevSn(),
					HitMode:       int32(mode),
					DeviceName:    act.deviceInfo.Device.GetDevName(),
					TargetUavType: uavSn,
				},
			},
		},
	}

	response, err := sflTaskHitReqHandle(context.Background(), in, http_clients.WithBaseUrl(act.host), http_clients.WithUrl(act.uri), http_clients.WithTimeOut(act.tmOut))
	if err != nil {
		logger.Errorf("sfl hit request fail, err: %v", err)
		return fmt.Errorf("sfl hit request fail, %v", err)
	}

	if response == nil {
		logger.Errorf("sfl hit response is nil")
		return fmt.Errorf("sfl hit response is nil")
	}
	logger.Infof("sfl hit response: %+v", *response)

	if response.Data == false { //TODO:
		logger.Errorf("sfl100 hit response fail, tbCode: %v, device sn: %v", act.tbCode, act.deviceInfo.Device.GetDevSn())
		return fmt.Errorf("sfl100 auto hit reponse fail")
	}
	return nil
}

func (act *AutoCounterTask) BuildTask() error {
	if err := act.CheckInParam(); err != nil {
		return err
	}
	var devType string
	var hitMode int32
	var ruleId int64

	if act.deviceInfo.Device.GetDevType() == int32(device_manager.DEV_SFL) {
		devType = constant.DeviceTypeSfl
		hitMode = act.deviceInfo.DeviceEnable.Mode

	} else if act.deviceInfo.Device.GetDevType() == int32(device_manager.DEV_NSF4000) {
		devType = constant.DeviceTypeSpoofer
		hitMode = act.deviceInfo.DeviceEnable.Mode

	} else if act.deviceInfo.Device.GetDevType() == int32(device_manager.DEV_SFL200) {
		devType = constant.DeviceTypeSfl200
		if len(act.deviceInfo.DeviceEnable.ComplexMode) > 0 {
			hitMode = act.deviceInfo.DeviceEnable.ComplexMode[0]
		} else {
			logger.Errorf("not any mode for sfl200")
		}
	}

	if len(act.deviceInfo.RuleOption) > 0 && act.deviceInfo.RuleOption[0].RuleItem != nil {
		ruleId = act.deviceInfo.RuleOption[0].RuleItem.GetRuleId()
	}

	var extParam = map[string]any{
		"freq":  act.uav.GetFreq(),
		"objId": act.uav.GetObjID(),
	}

	request := &request.CounterTaskAutoStartRequest{
		DeviceName:       act.deviceInfo.Device.GetDevName(),
		DeviceType:       devType,
		DeviceSn:         act.deviceInfo.Device.GetDevSn(),
		HitMode:          int32(hitMode),
		ObjName:          act.uav.GetSn(),    //sn
		ObjType:          act.uav.GetObjID(), //objId
		ExtraParams:      extParam,           //存放 freq  and obj id for auto counter task.
		HitDurTimeSecond: 30,                 // 30s
		TbCode:           act.tbCode,
		RuleId:           ruleId,
		TrackId:          act.uav.GetTrackId(),
	}

	taskId, err := snowflake.GetUniqueID()
	if err != nil {
		logger.Errorf("gen task error: %s", err.Error())
		return errors.New("gen task error")
	}
	logger.Infof("auto counter task req: %+v", *request)

	err = countertask.NewCounterTaskOps(nil).CounterAutoTaskStart(context.Background(), request, taskId)
	return err
}

// CounterBySFL200 使用 sfl200 进行反制 和诱骗
func (act *AutoCounterTask) CounterBySFL200() error {
	if err := act.CheckInParam(); err != nil {
		return err
	}
	if len(act.deviceInfo.DeviceEnable.ComplexMode) <= 0 {
		logger.Errorf("no exist mode for sfl200")
		return fmt.Errorf("no exist mode for sfl200")
	}

	mode := act.deviceInfo.DeviceEnable.ComplexMode[0] // 暂时取sfl200 第一种模式进行反制
	if mode == constant.Sfl200HitModeNormalOut ||
		mode == constant.Sfl200HitModeGNSSOut ||
		mode == constant.Sfl200HitModeNormalAndGNSSOut ||
		mode == constant.Sfl200HitModeFpvOut ||
		mode == constant.Sfl200HitModeQuanpinduanOut ||
		mode == constant.Sfl200HitModeQuanpinduanAndGNSSOut {

		////is hit.
		//hitMode, ok := constant.HitModeMap[int(mode)]
		//if !ok {
		//	logger.Errorf("not support sfl200 hit mode, src mode: %v", mode)
		//	return fmt.Errorf("mode not exist")
		//}

		in := &Sfl200HitUavReqBody{
			DeviceType: constant.DeviceTypeSfl200,
			Command: Sfl200HitUavCommand{
				GateWaySn: act.deviceInfo.Device.GetC2Sn(),
				Property: Sfl200HitUavProperty{
					Request: Sfl200DealUavRequest{
						Sn:             act.deviceInfo.Device.GetDevSn(),
						Type:           1,
						ObjId:          act.uav.GetObjID(),
						DroneSn:        act.uav.GetSn(),
						Classification: 0x05, //无人机
						HitMode:        int32(constant.HitModeMap[int(mode)]),
					},
				},
			},
		}
		response, err := sfl200UavHitReqHandle(context.Background(), in, http_clients.WithBaseUrl(act.host), http_clients.WithUrl(act.uri), http_clients.WithTimeOut(act.tmOut))
		if err != nil {
			logger.Errorf("sfl200-uav hit request fail, err: %v", err)
			return fmt.Errorf("sfl200-uav hit request fail, %v", err)
		}

		if response == nil {
			logger.Errorf("sfl200-uav hit response is nil")
			return fmt.Errorf("sfl200-uav hit response is nil")
		}

		logger.Infof("sfl200-sfl100  hit response: %+v", *response)
		if response.Data == false { //TODO:
			logger.Errorf("sfl200-sfl100 hit fail, tbCode: %v, deviceSn: %v", act.tbCode, act.deviceInfo.Device.GetDevSn())
			return fmt.Errorf("sfl200-sfl100 fail")
		}
		return nil

	} else if mode == constant.Sfl200HitModeActiveDefenseOut ||
		mode == constant.Sfl200HitModeAreaDenialOut ||
		mode == constant.Sfl200HitModeSirectionalDisplacementOut {

		spooferMode, ok := constant.HitModeMap[int(mode)]
		if !ok {
			logger.Errorf("not support sfl200-spoofer hit mode fail, src mode: %v", mode)
			return fmt.Errorf("mode not is exist")
		}

		in := &Sfl200SpooferHitReqBody{
			DeviceType: constant.DeviceTypeSfl200,
			Command: Sfl200SpooferHitCommand{
				GateWaySn: act.deviceInfo.Device.GetC2Sn(),
				Property: Sfl200SpooferProperty{
					Request: Sfl200StartNsf4000Request{
						Sn:        act.deviceInfo.Device.GetDevSn(),
						StartStop: 1,
						WorkType:  int32(spooferMode) + 1,
					},
				},
			},
		}
		response, err := sfl200SpooferHandler(context.Background(), in, http_clients.WithBaseUrl(act.host), http_clients.WithUrl(act.uri), http_clients.WithTimeOut(act.tmOut))
		if err != nil {
			logger.Errorf("sfl200-spoofer hit request fail, err: %v", err)
			return fmt.Errorf("sfl200-spoofer hit request fail, %v", err)
		}

		if response == nil {
			logger.Errorf("sfl200-spoofer hit response is nil")
			return fmt.Errorf("sfl200-spoofer hit response is nil")
		}

		logger.Infof("sfl200-spoofer hit response: %+v", *response)

		if response.Data == false { //TODO:
			logger.Errorf("sfl200-spoofer hit fail, tbCode: %v, deviceSn: %v", act.tbCode, act.deviceInfo.Device.GetDevSn())
			return fmt.Errorf("sfl200-spoofer fail")
		}
		return nil
	}
	return nil
}

func (act *AutoCounterTask) CheckInParam() error {
	if act == nil || act.deviceInfo == nil || act.deviceInfo.Device == nil {
		return fmt.Errorf("device info is nil")
	}
	return nil
}

// CounterBySpoofer 使用spoofer 进行诱骗
func (act *AutoCounterTask) CounterBySpoofer() error {
	if err := act.CheckInParam(); err != nil {
		return err
	}

	mode, ok := constant.HitModeMap[int(act.deviceInfo.DeviceEnable.Mode)]
	if !ok {
		logger.Errorf("not support spoofer hit mode fail, src mode: %v", act.deviceInfo.DeviceEnable.Mode)
		return fmt.Errorf("mode is exist")
	}

	in := &HitSpooferReqBody{
		DeviceType: constant.DeviceTypeSpoofer,
		Command: HitSpooferCommand{
			C2Sn: act.deviceInfo.Device.GetC2Sn(),
			Type: constant.DeviceTypeSpoofer,
			Data: HitSpooferData{
				OpsCode: Spoofer_HIT_OPSCODE,
				PayLoad: HitSpooferPayLoad{
					Enable:     true,
					Sn:         act.deviceInfo.Device.GetDevSn(),
					HitMode:    int32(mode),
					DeviceName: act.deviceInfo.Device.GetDevName(),
				},
			},
		},
	}
	response, err := spooferTaskHitReqHandle(context.Background(), in, http_clients.WithBaseUrl(act.host), http_clients.WithUrl(act.uri), http_clients.WithTimeOut(act.tmOut))

	if err != nil {
		logger.Errorf("spoofer hit request fail, err: %v", err)
		return fmt.Errorf("spoofer hit request fail, %v", err)
	}

	if response == nil {
		logger.Errorf("spoofer hit response is nil")
		return fmt.Errorf("spoofer hit response is nil")
	}
	logger.Infof("spoofer hit response: %+v", *response)

	if response.Data == false { //TODO:
		logger.Errorf("spoofer hit response fail, tbCode: %v, device sn: %v", act.tbCode, act.deviceInfo.Device.GetDevSn())
		return fmt.Errorf("spoofer auto hit reponse fail")
	}
	return nil
}
