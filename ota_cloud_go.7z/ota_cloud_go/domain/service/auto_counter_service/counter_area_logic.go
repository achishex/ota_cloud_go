package auto_counter_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/model"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"time"
)

type CounterAreaOps struct {
	dbOps CounterAreaDBHandlerType
}

func NewCounterAreaOpsHandler(dbHandle CounterAreaDBHandlerType) *CounterAreaOps {
	if dbHandle == nil {
		// 使用默认的全局db
		return &CounterAreaOps{
			dbOps: CounterAreaDbHandle,
		}
	}
	//
	return &CounterAreaOps{
		dbOps: dbHandle,
	}
}

func (ca *CounterAreaOps) CheckCounterAreaExist(tbCode string, areaName string, areaId int64) (error, bool) {
	if tbCode == "" || areaName == "" || areaId <= 0 {
		return errors.New("input param in valid"), false
	}
	if ca.dbOps == nil {
		return errors.New("counter area handle is nil"), false
	}

	whereCond := "tb_code = ? and  area_name = ? and id != ?"
	whereValue := []any{tbCode, areaName, areaId}

	counterAreaList, err := ca.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query counter area fail, err: %v, tbCode: %v, areaName: %v, areaId: %v", err, tbCode, areaName, areaId)
		return err, false
	}
	if len(counterAreaList) > 0 {
		return nil, true
	}
	return nil, false
}
func (ca *CounterAreaOps) InsertCounterAreaItem(item *pb.CounterAreaCreateRequest, tbCode string, id int64) error {
	if ca == nil || item == nil || ca.dbOps == nil {
		return errors.New("input counter area item is nil")
	}

	nowTmUTC := time.Now().UTC()

	modelItem := &model.CounterAreaConfig{
		ID:                id,
		TbCode:            tbCode,
		AreaName:          item.GetAreaName(),
		AreaPerimeter:     item.GetAreaPerimeter(),
		AreaSquare:        item.GetAreaSquare(),
		CentroidLongitude: item.GetCentroidLongitude(),
		CentroidLatitude:  item.GetCentroidLatitude(),
		Geometry:          item.GetGeometry(),
		CreateTime:        &nowTmUTC,
		UpdateTime:        &nowTmUTC,
		DeleteTime:        nil,
		FenceAreaId:       item.GetFenceAreaId(),
	}

	n, err := ca.dbOps.Insert([]*model.CounterAreaConfig{
		modelItem,
	})
	if err != nil {
		logger.Errorf("insert counter area item fail, err: %v", err)
		return err
	}
	logger.Infof("insert new counter area succ item nusm: %v", n)
	return nil
}
func (ca *CounterAreaOps) DeleteCounterAreaItem(id int64) error {
	if id <= 0 {
		return errors.New("id is invalid")
	}

	if err := ca.dbOps.DelItemOnID([]int64{id}); err != nil {
		logger.Errorf("delete counter area item fail, id: %v, err: %v", id, err)
		return err
	}
	return nil
}

func (ca *CounterAreaOps) QueryCounterAreasByTbCode(tbCode string) ([]*model.CounterAreaConfig, error) {

	whereCond := "tb_code = ?"
	whereValue := []any{tbCode}

	counterAreaList, err := ca.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query counter area fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}
	return counterAreaList, nil
}

func (ca *CounterAreaOps) QueryCounterArea(tbCode string, id int64) ([]*model.CounterAreaConfig, error) {
	whereCond := "id = ? and tb_code = ?"
	whereValue := []any{id, tbCode}

	counterAreaList, err := ca.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query counter area fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}
	return counterAreaList, nil
}

// QueryCounterAreaList  idList, key is areaId, value is ruleId; ret map key is ruleId
func (ca *CounterAreaOps) QueryCounterAreaList(tbCode string, areaRuleId map[int64]CrossRuleIdSimple /* key */) (map[int64]*model.CounterAreaConfig, error) {
	if len(areaRuleId) == 0 {
		return nil, nil
	}

	var areaIds []int64
	for id, _ := range areaRuleId {
		areaIds = append(areaIds, id)
	}

	counterAreaList, err := ca.dbOps.QueryItems(areaIds)
	if err != nil {
		logger.Errorf("query counter area fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}

	var ret = make(map[int64]*model.CounterAreaConfig)
	for areaId, ruleId := range areaRuleId {
		for _, areaInfo := range counterAreaList {
			if areaInfo == nil {
				continue
			}

			if areaInfo.ID == areaId {
				ret[ruleId.RuleId] = areaInfo
			}
		}
	}
	return ret, nil
}

// 围栏区db 业务操作
// FenceAreaOps 围栏区类型
type FenceAreaOps struct {
	dbOps FenceAreaDBType
}

// NewFenceAreaOpsHandler 创建一个新的 fence area ops
func NewFenceAreaOpsHandler(dbHandle FenceAreaDBType) *FenceAreaOps {
	if dbHandle == nil {
		// 使用默认的全局db
		return &FenceAreaOps{
			dbOps: FenceAreaDBHandle,
		}
	}
	//
	return &FenceAreaOps{
		dbOps: dbHandle,
	}
}

func (fao *FenceAreaOps) QueryFenceAreaByTbCodeAndId(tbCode string, fenceAreaId int64) ([]*bean.FencedAreaConfig, error) {
	whereCond := "id = ? and tb_code = ?"
	whereValue := []any{fenceAreaId, tbCode} //查询围栏区信息

	fenceAreaList, err := fao.dbOps.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("query fence area fail, err: %v, tbCode: %v, id: %v", err, tbCode, fenceAreaId)
		return nil, err
	}
	return fenceAreaList, nil
}

// QueryFenceAreaList idList, key is areaId, value is ruleId; ret map key is ruleId
func (fao *FenceAreaOps) QueryFenceAreaList(tbCode string, areaRuleId map[int64]CrossRuleIdSimple) (map[int64]*bean.FencedAreaConfig, error) {
	if len(areaRuleId) == 0 {
		return nil, nil
	}

	var areaIds []int64
	for id, _ := range areaRuleId {
		areaIds = append(areaIds, id)
	}

	fenceAreaList, err := fao.dbOps.QueryItems(areaIds)
	if err != nil {
		logger.Errorf("query fence area fail, err: %v, tbCode: %v", err, tbCode)
		return nil, err
	}

	var ret = make(map[int64]*bean.FencedAreaConfig)
	for areaId, ruleId := range areaRuleId {
		for _, areaInfo := range fenceAreaList {
			if areaInfo == nil {
				continue
			}

			if areaInfo.ID == areaId {
				ret[ruleId.RuleId] = areaInfo
			}
		}
	}
	return ret, nil
}
