package evidence_report

import (
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	thirdpartapiModel "cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/model"
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type ProtocolUavOps struct {
}

func NewProtocolUavOpsHandle() *ProtocolUavOps {

	return &ProtocolUavOps{}
}

// QueryProtocolUavList 查询协议解析的无人机信息列表
func (p *ProtocolUavOps) QueryProtocolUavList(url, trackId, tbCode string, index int, startTime, endTime int64) ([]*model.ProtocolUavDetect, error) {
	if trackId == "" || tbCode == "" {
		logger.Errorf("track id is empty or tbCode is empty")
		return nil, errors.New("track is empty or tbCode is empty")
	}

	return thirdpartapi.NewCloudDataService().GetTraceDataList(&request.PageRequest{
		PageIndex: index,
		PageSize:  1000,
		Data: thirdpartapiModel.GetTraceDataIn{
			TbCode:    tbCode,
			TrackId:   trackId,
			Url:       url,
			StartTime: startTime,
			EndTime:   endTime,
		},
	})
}
