package evidence_report

import (
	"archive/zip"
	"bytes"
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/common/response"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/uav_record"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"os"
	"testing"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/log"
)

func TestTargetEventTrajectoryGen_QueryPost(t *testing.T) {
	defer func() {
		if r := recover(); r != nil {
			log.Errorf("CaptureFlyingDocumentUpload consumer panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
		}
	}()
	mock.LoggerMock()
	config.InitConfig("./application-dev.yml")
	_, err := config.InitDB()
	if err != nil {
		log.Fatalf("InitSqlite err %v", err)
		return
	}
	InitRes(context.Background())
	dataJson := "{\"data\":[{\"droneLongitude\":113.9994104,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599171528},{\"droneLongitude\":113.9994104,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599171528},{\"droneLongitude\":113.9995588,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599174528},{\"droneLongitude\":113.9995588,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599174528},{\"droneLongitude\":113.9997073,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599177529},{\"droneLongitude\":113.9997073,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599177529},{\"droneLongitude\":113.9998558,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599180529},{\"droneLongitude\":113.9998558,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599180529},{\"droneLongitude\":114.0000042,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599183530},{\"droneLongitude\":114.0000042,\"droneLatitude\":22.597,\"droneAltitude\":0.0,\"createTime\":1723599183530}],\"pageTotal\":10,\"pageIndex\":2,\"pageSize\":10}"
	data := response.PageResponse[*model.ProtocolUavDetect]{}
	if err := json.Unmarshal([]byte(dataJson), &data); err != nil {
		return
	}
	type args struct {
		targetEvent *pb.TargetEventStatusNotifyItem
	}
	tests := []struct {
		name string
		te   *TargetEventTrajectoryGen
		args args
	}{
		{name: "000", te: &TargetEventTrajectoryGen{
			name: "0000",
			uavLists: map[string]any{
				UavCommonTableName: data.Data,
			},
		}, args: args{&pb.TargetEventStatusNotifyItem{TrackId: "1326793820892037123", TbCode: "000001"}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.te.QueryPost(tt.args.targetEvent)
		})
		if err := os.WriteFile("11111222333"+".zip", tt.te.trajectoryZipFile, 0700); err != nil {
			// if err := ioutil.WriteFile("11111"+".zip", buffer.Bytes(), 0700); err != nil {
			log.Errorf("Read zip file error: %s", err.Error())
			return
		}
	}

	r := res()
	if err := os.WriteFile("11111222"+".zip", r, 0700); err != nil {
		// if err := ioutil.WriteFile("11111"+".zip", buffer.Bytes(), 0700); err != nil {
		log.Errorf("Read zip file error: %s", err.Error())
	}
}

func res() []byte {
	buffer := bytes.Buffer{}
	zipWriter := zip.NewWriter(&buffer)
	// defer zipWriter.Close()
	if err := addFileToZip(zipWriter, "1111"+TrackFileSuffixGpx, []byte("12345")); err != nil {
		log.Errorf("Add gpxFile to zip error: %s", err.Error())
		return nil
	}
	if err := addFileToZip(zipWriter, "11111"+TrackFileSuffixKml, []byte("12345")); err != nil {
		log.Errorf("Add kmlFile to zip error: %s", err.Error())
		return nil
	}
	if err := zipWriter.Close(); err != nil {
		log.Errorf("Add kmlFile to zip error: %s", err.Error())
		return nil
	}
	r := buffer.Bytes()

	return r
}

func TestFormatDay(t *testing.T) {
	tm := time.Now().UTC()
	s := GetS3FileName(&tm, "dj", "trackId.zip", "zh")
	t.Logf(s)
}
func TestCrossPhotoUrl(t *testing.T) {
	toTestSrc := []uav_record.ImageUrlInfo{
		{Url: "https://cloud-evidence-report.s3.cn-northwest-1.amazonaws.com.cn/cloud/track/demo-test.txt?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAVVMOXO7XHGUU5W62%2F20240815%2Fcn-northwest-1%2Fs3%2Faws4_request&X-Amz-Date=20240815T013849Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&response-expires=Thu%2C%2015%20Aug%202024%2002%3A38%3A49%20GMT&X-Amz-Signature=2dbdaee9e604caaebbfd35620e2fd3a05dff47badda7c51e8632c0f43399d8a1",
			TimeCreate: time.Now().UTC(),
		},
		{Url: "https://cloud-evidence-report.s3.cn-northwest-1.amazonaws.com.cn/cloud/track/demo-test.txt?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAVVMOXO7XHGUU5W62%2F20240815%2Fcn-northwest-1%2Fs3%2Faws4_request&X-Amz-Date=20240815T013849Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&response-expires=Thu%2C%2015%20Aug%202024%2002%3A38%3A49%20GMT&X-Amz-Signature=2dbdaee9e604caaebbfd35620e2fd3a05dff47badda7c51e8632c0f43399d8a1",
			TimeCreate: time.Now().UTC(),
		},
	}
	photoUrl := EvidenceReportGenInfo{
		PhoneUrlList: toTestSrc,
	}
	data := buildPhoneUrlList(&photoUrl)

	//
	listPhotoUrl := buildPhoneUrlFromBin(data)
	for index, v := range listPhotoUrl.ToList() {
		//t.Logf("url: %v", v.PhotoUrl)

		if v.PhotoUrl != toTestSrc[index].Url {
			t.Logf("not eq.")
		} else {
			t.Logf("eq, url: %v", v.PhotoUrl)
		}
	}
}
