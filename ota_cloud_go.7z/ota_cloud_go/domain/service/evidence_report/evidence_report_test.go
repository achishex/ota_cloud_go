package evidence_report

import (
	"bytes"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/infra/protocals"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"testing"
	"time"
)

func TestHttpUrl(t *testing.T) {
	originUrl := "cloud/track/1303527669113946113.zip"
	d1 := GetHttpUrl(originUrl)
	if d1 != originUrl {
		t.Logf("is invalid url, d1: %v", d1)
	}

	originUrl2 := "https://cloud-evidence-report.s3.cn-northwest-1.amazonaws.com.cn/cloud/track/22222-221.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256\\u0026X-Amz-Credential=AKIAVVMOXO7XHGUU5W62%2F20240813%2Fcn-northwest-1%2Fs3%2Faws4_request\\u0026X-Amz-Date=20240813T134503Z\\u0026X-Amz-Expires=3600\\u0026X-Amz-SignedHeaders=host\\u0026response-expires=Tue%2C%2013%20Aug%202024%2014%3A45%3A03%20GMT\\u0026X-Amz-Signature=06824c44fa998993f00a680dd53c0855254c360a1f7c4771d85ea7f34983946b"
	d2 := GetHttpUrl(originUrl2)
	if d2 != originUrl2 {
		t.Logf("is invalid url, d2: %v", d2)
	} else {
		t.Logf("is valid url, d2: %v", d2)
	}
}

type DemoUrlJson struct {
	ErrCode int32  `json:"errorCode"`
	ErrMsg  string `json:"errorMessage"`
	SeqId   string `json:"seqId"`
	Url     string `json:"url"`
}

type DemoData struct {
	Url string `json:"url"`
}

func TestJsonUrl(t *testing.T) {
	var d = &protocals.HttpResponse{
		ErrorMessage: "",
		ErrorCode:    100,
		SeqId:        "123",
		CostTimeMs:   123,
		Data: &DemoData{
			Url: "https://cloud-evidence-report.s3.cn-northwest-1.amazonaws.com.cn/cloud/track/12312313.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAVVMOXO7XHGUU5W62%2F20240813%2Fcn-northwest-1%2Fs3%2Faws4_request&X-Amz-Date=20240813T142725Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&response-expires=Tue%2C%2013%20Aug%202024%2015%3A27%3A25%20GMT&X-Amz-Signature=429497de34f7b69fbe9314c9ffcde7ed0e41cfde0c8aaa590fee471c832cdf30",
		},
	}

	var buf bytes.Buffer
	encoder := json.NewEncoder(&buf)
	encoder.SetEscapeHTML(false) // 禁用 HTML 转义
	err := encoder.Encode(d)

	dbin := buf.Bytes()
	if err != nil {
		t.Logf("marshal fail, err: %v", err)
	} else {
		t.Logf("marshal: %v", string(dbin))
		var s = &protocals.HttpResponse{}
		err = json.Unmarshal(dbin, s)
		t.Logf("unmarhal url: %v", s.Data)
		if err != nil {
			t.Logf("unmarshal fail, err: %v", err)
		} else {
		}
	}
}

func TestEvidenceReport(t *testing.T) {
	mock.LoggerMock()
	//
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	// mock db init
	countertask.MockCounterTaskDBType(dbHandler)
	alarm_service.MockAlarmDB(dbHandler)
	alarm_service.MockUavRecordDB(dbHandler)
	alarm_service.MockUavEventImageDb(dbHandler)
	MockTargetEventDbHandle(dbHandler)

	serviceEvReport := NewEvidenceReportService()
	testReqData := &pb.TargetEventStatusNotifyRequest{
		NotifyItems: make([]*pb.TargetEventStatusNotifyItem, 0),
	}

	// var trackId1 string = "1303769721257590785"
	// beginTime, _ := time.Parse("2006-01-02 15:04:05", "2024-08-08 12:00:00")
	// endTime, _ := time.Parse("2006-01-02 15:04:05", "2024-08-08 14:00:00")

	type param struct {
		Body []*pb.TargetEventStatusNotifyItem `json:"body"`
	}

	data := "{\"body\":[{\"trackId\":\"1304222931171016709\",\"status\":1,\"startTime\":1723704632794,\"endTime\":1723704687341,\"tbCode\":\"000001\",\"serialNum\":\"lno7jplus\",\"objId\":\"\",\"freq\":0.0,\"droneModel\":\"DJI Air 2S2\",\"startPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"endPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"startPoint\":{\"homeLongitude\":113.998,\"homeLatitude\":22.597},\"endPoint\":{\"homeLongitude\":113.998,\"homeLatitude\":22.597},\"startDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"endDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"startLonLat\":{\"longitude\":114.0167579,\"latitude\":22.597},\"endLonLat\":{\"longitude\":114.0167579,\"latitude\":22.597},\"uavDbNode\":{\"dbName\":\"cuav_data\",\"dbTableName\":\"t_protocol_uav\"},\"droneName\":\"DJI Air 2S2#plus\"},{\"trackId\":\"1304222974120689667\",\"status\":1,\"startTime\":1723704674304,\"endTime\":1723704683578,\"tbCode\":\"000001\",\"serialNum\":\"0gx6tplus\",\"objId\":\"\",\"freq\":0.0,\"droneModel\":\"DJI Air 2S1\",\"startPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"endPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"startPoint\":{\"homeLongitude\":113.998,\"homeLatitude\":22.597},\"endPoint\":{\"homeLongitude\":113.998,\"homeLatitude\":22.597},\"startDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"endDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"startLonLat\":{\"longitude\":113.9980633,\"latitude\":22.597},\"endLonLat\":{\"longitude\":113.9980633,\"latitude\":22.597},\"uavDbNode\":{\"dbName\":\"cuav_data\",\"dbTableName\":\"t_protocol_uav\"},\"droneName\":\"DJI Air 2S1#plus\"},{\"trackId\":\"1304222931171016705\",\"status\":1,\"startTime\":1723704632594,\"endTime\":1723704687541,\"tbCode\":\"000001\",\"serialNum\":\"dlyh9\",\"objId\":\"\",\"freq\":5.78,\"droneModel\":\"DJI Air 2S1\",\"startPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"endPilot\":{\"pilotLongitude\":113.998,\"pilotLatitude\":22.597},\"startPoint\":{\"homeLongitude\":0.0,\"homeLatitude\":0.0},\"endPoint\":{\"homeLongitude\":0.0,\"homeLatitude\":0.0},\"startDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"endDevRelations\":[{\"c2sn\":\"0000000000\",\"sn\":\"trace0000000000\",\"siteCode\":\"001\",\"longitude\":114.00217686935765,\"latitude\":22.597}],\"startLonLat\":{\"longitude\":114.0078018,\"latitude\":22.597},\"endLonLat\":{\"longitude\":114.0078018,\"latitude\":22.597},\"uavDbNode\":{\"dbName\":\"cuav_data\",\"dbTableName\":\"t_protocol_uav\"},\"droneName\":\"DJI Air 2S1#lyh9\"}]}"

	myparms := &param{}
	if err := json.Unmarshal([]byte(data), myparms); err != nil {
		return
	}
	testReqData.NotifyItems = myparms.Body
	// testReqData.NotifyItems = []*pb.TargetEventStatusNotifyItem{&pb.TargetEventStatusNotifyItem{
	// 	TrackId:    trackId1,
	// 	Status:     1,
	// 	StartTime:  beginTime.UTC().UnixMilli(),
	// 	EndTime:    endTime.UTC().UnixMilli(),
	// 	TbCode:     "000001",
	// 	SerialNum:  "dj-123",
	// 	ObjId:      "",
	// 	Freq:       123.123,
	// 	DroneModel: "dj-aaaa",
	// 	UavDBNode: &pb.UavDBInfo{
	// 		DbTableName: "t_protocol_uav",
	// 	},
	// 	StartPilot: &pb.TargetEventPilot{
	// 		// 飞手经度
	// 		PilotLongitude: 11.11,
	// 		// 飞手纬度
	// 		PilotLatitude: 22.22,
	// 	},

	// 	EndPilot: &pb.TargetEventPilot{
	// 		// 飞手经度
	// 		PilotLongitude: 100.11,

	// 		// 飞手纬度
	// 		PilotLatitude: 200.22,
	// 	},

	// 	StartPoint: &pb.TargetEventHomePoint{
	// 		HomeLongitude: 33.22,
	// 		// 返航点纬度
	// 		HomeLatitude: 44.33,
	// 	},

	// 	EndPoint: &pb.TargetEventHomePoint{
	// 		HomeLongitude: 130.22,
	// 		// 返航点纬度
	// 		HomeLatitude: 140.33,
	// 	},
	// 	UavDBNode: &pb.UavDBInfo{
	// 		DbTableName: "t_protocol_uav",
	// 	},
	// },
	// }

	serviceEvReport.TargetEventStatusChangeModify(testReqData)
	<-time.NewTimer(100 * time.Second).C
}
