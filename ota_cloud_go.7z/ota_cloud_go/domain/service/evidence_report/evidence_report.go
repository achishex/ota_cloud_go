package evidence_report

import (
	"bytes"
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/i18nlib"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/errorcode"
	"cuav-cloud-go-service/domain/model"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/repository/files_op"
	"cuav-cloud-go-service/domain/repository/math_utils"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/device_manager"
	"cuav-cloud-go-service/infra/s3Client"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
)

// EvidenceReportService 取证报告服务
type EvidenceReportService struct {
	// s3ClientHandle 用于上传和下载文件
	s3ClientHandle *s3Client.S3ClientS3
}

func NewEvidenceReportService() *EvidenceReportService {
	return &EvidenceReportService{
		//
		s3ClientHandle: s3Client.NewS3ClientS3(
			&s3Client.S3ClientConfig{
				Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
				Region:              config.GetConfig().EvidenceReportS3.Region,
				Ak:                  config.GetConfig().EvidenceReportS3.Ak,
				Sk:                  config.GetConfig().EvidenceReportS3.Sk,
				FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
				StoreType:           s3Client.AwsS3,
				CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
			}),
	}
}

// TargetEventStatusChangeModify 轨迹消失事件通知处理逻辑
func (es *EvidenceReportService) TargetEventStatusChangeModify(reqData *pb.TargetEventStatusNotifyRequest) error {
	if reqData == nil {
		return nil
	}

	// 启动一个线程来处理
	routinues.AsyncRun(true, func() {
		// 对每一个 track id 生成取证报告
		for _, notify := range reqData.GetNotifyItems() {

			if notify == nil {
				continue
			}

			logger.Infof("do evidence report data generate, track_id: %v", notify.GetTrackId())
			NewEvidenceReportTaskGen(notify).GenEvidenceReport()
		}
	})

	return nil
}

// GetHttpUrl 获取有效的url-http
func GetHttpUrl(originUrl string) string {
	if len(originUrl) == 0 {
		return ""
	}
	index := strings.Index(originUrl, "https")
	if index != 0 {
		return ""
	}
	return originUrl
}

// QueryTargetList 查询目标事件列表； 查询该租户下的所有目标事件列表
func (es *EvidenceReportService) QueryTargetList(ctx context.Context, tbCode string, req *pb.TargetEventListRequest) (*pb.TargetEventListResponse, error) {
	if tbCode == "" || req == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	if req.PageIndex <= 0 || req.PageSize <= 0 {
		return nil, fmt.Errorf("PageIndex or PageSize is 0")
	}

	var totalNums *int64 = new(int64)
	var err error
	var targetEventListRet = &pb.TargetEventListResponse{}
	defer func() {
		targetEventListRet.Total = int32(*totalNums)
	}()

	whereCond, whereValue := " tb_code = ? ", []any{tbCode}

	if req.DroneModel != "" {
		whereCond += " and drone_model like ?"
		whereValue = append(whereValue, req.DroneModel+"%")
	}

	if req.Sn != "" {
		whereCond += " and (serial_num = ? or obj_id = ?)"
		whereValue = append(whereValue, req.Sn, req.Sn)
	}

	if req.GetBeginTime() > 0 {
		whereCond += " and event_begin_time >= ?"
		whereValue = append(whereValue, time.UnixMilli(req.GetBeginTime()).UTC())
	}

	if req.GetEndTime() > 0 {
		whereCond += " and event_end_time <=?"
		whereValue = append(whereValue, time.UnixMilli(req.GetEndTime()).UTC())
	}

	if req.GetTrackId() != "" {
		whereCond += " and track_id = ?"
		whereValue = append(whereValue, req.TrackId)
	}

	*totalNums, err = TargetEventDbHandler.CountItems(whereCond, whereValue)
	if err != nil {
		logger.Errorf("query target event items nums fail, err: %v, tbCode: %v", err, tbCode)
		return nil, fmt.Errorf("query target event items  fail.")
	}

	if *totalNums == 0 {
		logger.Infof("query target event items nums is zero, tbCode: %v", tbCode)
		return targetEventListRet, nil
	}

	offset := (int(req.GetPageIndex()) - 1) * int(req.GetPageSize())

	targetEventList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, map[string]bool{"create_at": false}, offset, int(req.GetPageSize()))
	if err != nil {
		logger.Errorf("query item fail, %v, tbCode: %v", err, tbCode)
		return nil, fmt.Errorf("query target event list fail")
	}

	if len(targetEventList) == 0 {
		return targetEventListRet, nil
	}

	var dataItem []*pb.TargetEventItem
	for i := 0; i < len(targetEventList); i++ {
		if targetEventList[i] == nil {
			continue
		}

		serialNums := ""
		if len(targetEventList[i].SerialNum) <= 0 {
			serialNums = targetEventList[i].ObjId
		} else {
			serialNums = targetEventList[i].SerialNum
		}

		var retEventBeginTime *time.Time = targetEventList[i].EventBeginTime
		var retDroneModel string = targetEventList[i].DroneModel

		fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(targetEventList[i].TrackId), i18nlib.GetLangStrInCtx(ctx))
		var responseTargetEventItem = &pb.TargetEventItem{
			Id:                targetEventList[i].TrackId,
			DroneModel:        targetEventList[i].DroneModel,
			SerialNum:         serialNums,
			ReportDownloadUrl: fileName,
			ReportName:        targetEventList[i].ReportName,
		}

		var wg routinues.RoutineGroupWrap
		if responseTargetEventItem.ReportDownloadUrl != "" {
			wg.AsyncRun(true, func() {
				if false == es.s3ClientHandle.CheckPresignedURL(targetEventList[i].EvidenceReportUrl) {
					responseTargetEventItem.ReportUrlExpired = 1
					logger.Errorf("report url is expired, url: %v", responseTargetEventItem.ReportDownloadUrl)
				}
			})
		}

		if targetEventList[i].EventBeginTime != nil {
			responseTargetEventItem.BeginTime = targetEventList[i].EventBeginTime.UnixMilli()
		}
		if targetEventList[i].EventEndTime != nil {
			responseTargetEventItem.EndTime = targetEventList[i].EventEndTime.UnixMilli()
		}

		areaIds := &model.ListAnyType[model.CrossAreaId]{}
		if len(targetEventList[i].AreaIds) > 0 {
			if err := areaIds.Unmarshal(targetEventList[i].AreaIds); err != nil {
				logger.Errorf("unmarshal  area ids from target event item fail, %v, tbCode: %v", err, tbCode)
			}
		}

		areaIdsInt64 := []int64{}
		for _, idItem := range areaIds.ToList() {
			if idItem != nil {
				areaIdsInt64 = append(areaIdsInt64, idItem.AreaId)
			}
		}

		if len(areaIdsInt64) > 0 {
			err, fenceAeaDetails := alarm_service.NewFendAreaOpsService(nil, alarm_service.ResFendAreaDB).GetFenceAreaDetails(tbCode, areaIdsInt64)
			if err != nil {
				logger.Errorf("query area detail fail, err: %v", err)
			}

			for _, fenceAreaDetail := range fenceAeaDetails {
				if fenceAreaDetail != nil {
					responseTargetEventItem.AreaList = append(responseTargetEventItem.AreaList, fenceAreaDetail.AreaName)
				}
			}
		}

		//获取站点信息:
		if len(targetEventList[i].DetectDevicesEnd) > 0 {
			relList := alarm_service.UnmarshalDevRelation(targetEventList[i].DetectDevicesEnd)
			if len(relList) > 0 && relList[0] != nil {
				responseTargetEventItem.SiteCode = relList[0].GetSiteCode()
			}

		} else if len(targetEventList[i].DetectDevicesBegin) > 0 {
			relList := alarm_service.UnmarshalDevRelation(targetEventList[i].DetectDevicesBegin)
			if len(relList) > 0 && relList[0] != nil {
				responseTargetEventItem.SiteCode = relList[0].GetSiteCode()
			}
		} else {
			logger.Errorf("can't get siteCode as ")
		}

		// must not continue before this call.
		wg.Wait()

		dataItem = append(dataItem, responseTargetEventItem)
	}
	targetEventListRet.Data = dataItem
	return targetEventListRet, nil
}

// DownloadReportWithFileName 下载报告并返回下载的文件名, ret first: file name, second: path dir, third: error
func (es *EvidenceReportService) DownloadReportWithFileName(ctx context.Context, tbCode string, trackId string) (string, string, error) {
	whereCond := "tb_code = ? and track_id = ?"
	whereValue := []any{tbCode, trackId}
	targetEventList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, map[string]bool{"create_at": true}, 0, 1)
	if err != nil {
		logger.Errorf("query evidence report download url fail, err: %v, tbCode: %v, trackId: %v", err, tbCode, trackId)
		return "", "", fmt.Errorf("query evidence report download url fail")
	}

	var fileHttpsUrl string
	var retEventBeginTime *time.Time = nil
	var retDroneModel string

	if targetEventList == nil || len(targetEventList) <= 0 {
		logger.Infof("not find and item, tbCode: %v, trackId: %v", tbCode, trackId)
		return "", "", fmt.Errorf("not find any file")
	}
	for _, item := range targetEventList {
		if item == nil {
			continue
		}
		fileHttpsUrl = GetHttpUrl(item.EvidenceReportUrl)

		retEventBeginTime = item.EventBeginTime
		retDroneModel = item.DroneModel
		break
	}
	if fileHttpsUrl == "" {
		logger.Infof("not any down https url for trackId: %v, tbCode: %v", trackId, tbCode)
		return "", "", fmt.Errorf("not have download url")
	}

	fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))
	pathDir, err := os.Getwd()
	localFileName := filepath.Join(pathDir, fileName)

	if err := s3Client.DownloadByPreUrl(fileHttpsUrl, localFileName); err != nil {
		logger.Errorf("download url: %v to local file: %v, fail: %v", fileHttpsUrl, localFileName, err)
		return "", "", fmt.Errorf("download url to file fail")
	}

	return fileName, pathDir, nil
}

// DownloadReportWithCache filename and buf
func (es *EvidenceReportService) DownloadReportWithCache(ctx context.Context, tbCode string, trackId string) (string, []byte, error) {
	whereCond := "tb_code = ? and track_id = ?"
	whereValue := []any{tbCode, trackId}
	targetEventList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, map[string]bool{"create_at": true}, 0, 1)
	if err != nil {
		logger.Errorf("query evidence report download url fail, err: %v, tbCode: %v, trackId: %v", err, tbCode, trackId)
		return "", nil, fmt.Errorf("query evidence report download url fail")
	}

	var fileHttpsUrl string
	var retEventBeginTime *time.Time = nil
	var retDroneModel string

	if targetEventList == nil || len(targetEventList) <= 0 {
		logger.Infof("not find and item, tbCode: %v, trackId: %v", tbCode, trackId)
		return "", nil, fmt.Errorf("not find any file")
	}
	for _, item := range targetEventList {
		if item == nil {
			continue
		}
		fileHttpsUrl = GetHttpUrl(item.EvidenceReportUrl)

		retEventBeginTime = item.EventBeginTime
		retDroneModel = item.DroneModel
		break
	}
	if fileHttpsUrl == "" {
		logger.Infof("not any down https url for trackId: %v, tbCode: %v", trackId, tbCode)
		return "", nil, fmt.Errorf("not have download url")
	}

	fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))
	var (
		buf []byte
	)

	if buf, err = s3Client.DownloadToCacheByPreUrl(fileHttpsUrl); err != nil {
		logger.Errorf("download url: %v to local file: %v, fail: %v", fileHttpsUrl, err)
		return "", nil, fmt.Errorf("download url to file fail")
	}

	return fileName, buf, nil
}

// GetReportDownloadUrl 获取报告下载链接
func (es *EvidenceReportService) GetReportDownloadUrl(ctx context.Context, tbCode string, trackId string) (*pb.EvidenceReportDownloadResponse, error) {
	if tbCode == "" || trackId == "" {
		logger.Errorf("input param is nil, tbCode: %v, trackId: %v", tbCode, trackId)
		return nil, fmt.Errorf("input param is nil")
	}

	whereCond := "tb_code = ? and track_id = ?"
	whereValue := []any{tbCode, trackId}
	targetEventList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, map[string]bool{"create_at": true}, 0, 1)
	if err != nil {
		logger.Errorf("query evidence report download url fail, err: %v, tbCode: %v, trackId: %v", err, tbCode, trackId)
		return nil, fmt.Errorf("query evidence report download url fail")
	}

	var ret = &pb.EvidenceReportDownloadResponse{}
	if targetEventList == nil || len(targetEventList) <= 0 {
		logger.Infof("not find and item, tbCode: %v, trackId: %v", tbCode, trackId)
		return ret, nil
	}
	for _, item := range targetEventList {
		if item == nil {
			continue
		}
		var retEventBeginTime *time.Time = item.EventBeginTime
		var retDroneModel string = item.DroneModel

		fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))
		ret.ResUrl = fileName
		break
	}

	if !es.s3ClientHandle.CheckPresignedURL(ret.ResUrl) {
		ret.ReportUrlExpired = 1
		logger.Errorf("report url is expired, url: %v", ret.ResUrl)
	}
	return ret, nil
}

func buildUavBasicInfo(dst *pb.UavBasicInfo, src *model.UavTargetEventModel) {
	if dst == nil || src == nil {
		return
	}

	dst.ObjId = src.ObjId
	// 无人机机序列号(sn)
	dst.SerialNum = src.SerialNum
	// 无人机objID
	dst.ObjId = src.ObjId
	// 无人机名称
	dst.Name = src.UavName
	// 无人机的机型
	dst.DroneModel = src.DroneModel
	// 无人机频谱
	dst.Freq = math_utils.TruncateToDecimals(src.Freq, 3)
	// 飞手经度
	dst.PilotLongitude = src.PilotLong
	// 飞手纬度
	dst.PilotLatitude = src.PilotLat
	// 返航点经度
	dst.HomeLongitude = src.HomeLong
	// 返航点纬度
	dst.HomeLatitude = src.HomeLat
}

// GetDetectLonLat 获取侦测设备的经纬度信息 ;
func GetDetectLonLat(src json.RawMessage, timeType int32, tbCode string) ([]*pb.TrackDetectDevice, error) {
	relList := alarm_service.UnmarshalDevRelation(src)
	if len(relList) <= 0 {
		return nil, nil
	}
	logger.Debugf("detect device lon,lat nums: %v, timeType: %v", len(relList), timeType)

	var ret []*pb.TrackDetectDevice
	for _, item := range relList {
		if item == nil {
			continue
		}

		devName := item.DeviceName
		if devName == "" {
			devName, _ = device_manager.GetDeviceDetail(tbCode, item.GetC2Sn(), item.GetSn(), 1, 1)
			if devName == "" {
				devName = item.GetSn()
			}
		}

		ret = append(ret, &pb.TrackDetectDevice{
			Sn: item.GetSn(),
			// required: true
			// example: "sfl200"
			// 设备名称
			Name: devName,
			// required: true
			// example: 12.1231231
			// 经度
			Longitude: item.GetLongitude(),
			// required: true
			// example: 114.2363
			// 纬度
			Latitude: item.GetLatitude(),
			// required: true
			// example:  1=> begin, 2=>end
			// 侦测时间类型
			TimeType: timeType,
		})
	}
	return ret, nil
}

func (es *EvidenceReportService) PreviewEvidenceReport(ctx context.Context, tbCode string, trackId string) (*pb.EvidenceReportPreviewResponse, error) {

	whereCond := "track_id = ? and tb_code = ?"
	whereValue := []any{trackId, tbCode}
	targetEventDetail, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, nil, 0, 1)
	if err != nil {
		logger.Errorf("query target event id fail: %v, trackId: %d, tbCode: %v", err, trackId, tbCode)
		return nil, ec.GetError(ec.SF_ErrorPreviewReport)
	}

	if len(targetEventDetail) <= 0 {
		logger.Errorf("query target event is empty, trackId: %v, tbCode: %v", trackId, tbCode)
		return nil, ec.GetError(ec.SF_ErrorTargetNoStop)
	}

	var ret = &pb.EvidenceReportPreviewResponse{
		BaseInfo:   &pb.UavBasicInfo{},
		TrackId:    trackId,
		CatchPilot: false,
		ReportName: targetEventDetail[0].ReportName,
	}
	captureFlying, err := es.GetCaptureFlyingInfoByTrackId(tbCode, trackId)
	if err != nil && err.Error() != "record not found" {
		logger.Errorf("GetCaptureFlyingInfoByTrackId error: %s, trackId: %v, tbCode: %v", err.Error(), trackId, tbCode)
		return nil, ec.GetError(errorcode.DBQueryError)
	}
	if captureFlying != nil {
		ret.CaptureFlying = &pb.DocumentInfo{
			VideoDocuments:      []*pb.DocumentItem{},
			ScreenshotDocuments: []*pb.DocumentItem{},
		}
		for _, doc := range captureFlying.DocumentInfo.VideoDocuments {
			if doc.ExpireAt.Before(time.Now()) {
				url, err := es.GetDownloadUrl(doc.S3Path, constant.PdfTrajZipFileUrlExpireSecond)
				if err != nil {
					logger.Errorf("PreviewEvidenceReport GetDownloadUrl error: %s", err.Error())
				} else {
					doc.Url = url
				}
			}
			ret.CaptureFlying.VideoDocuments = append(ret.CaptureFlying.VideoDocuments, &pb.DocumentItem{
				S3Path:         doc.S3Path,
				Url:            doc.Url,
				Name:           doc.Name,
				Type:           doc.Type,
				PilotLongitude: doc.PilotLongitude,
				PilotLatitude:  doc.PilotLatitude,
				ShootingAt:     doc.ShootingAt,
			})
		}
		for _, doc := range captureFlying.DocumentInfo.ScreenshotDocuments {
			if doc.ExpireAt.Before(time.Now()) {
				url, err := es.GetDownloadUrl(doc.S3Path, constant.PdfTrajZipFileUrlExpireSecond)
				if err != nil {
					logger.Errorf("PreviewEvidenceReport GetDownloadUrl error: %s", err.Error())
				} else {
					doc.Url = url
				}
			}
			ret.CaptureFlying.ScreenshotDocuments = append(ret.CaptureFlying.ScreenshotDocuments, &pb.DocumentItem{
				S3Path:         doc.S3Path,
				Url:            doc.Url,
				Name:           doc.Name,
				Type:           doc.Type,
				PilotLongitude: doc.PilotLongitude,
				PilotLatitude:  doc.PilotLatitude,
				ShootingAt:     doc.ShootingAt,
			})
		}
	}

	var retEventBeginTime *time.Time = targetEventDetail[0].EventBeginTime
	var retDroneModel string = targetEventDetail[0].DroneModel

	fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))

	if targetEventDetail[0].EvidenceReportUrl != "" {
		innerUrl := GetHttpUrl(targetEventDetail[0].EvidenceReportUrl)
		ret.TrackDownloadUrl = fileName

		if !es.s3ClientHandle.CheckPresignedURL(innerUrl) {
			ret.ReportUrlExpired = 1
			logger.Errorf("report url is expired, url: %v", innerUrl)
		}
	}

	buildUavBasicInfo(ret.BaseInfo, targetEventDetail[0])

	ret.StartLonLat = &pb.TrackDroneLonLat{
		Longitude: targetEventDetail[0].BeginLong,
		Latitude:  targetEventDetail[0].BeginLat,
	}
	ret.EndLonLat = &pb.TrackDroneLonLat{
		Longitude: targetEventDetail[0].EndLong,
		Latitude:  targetEventDetail[0].EndLat,
	}

	ret.StartEndTimePoint = &pb.TrackStartStopTime{}
	if targetEventDetail[0].EventBeginTime != nil {
		ret.StartEndTimePoint.TrackBeginTime = targetEventDetail[0].EventBeginTime.UTC().UnixMilli()
	}
	if targetEventDetail[0].EventEndTime != nil {
		ret.StartEndTimePoint.TrackEndTime = targetEventDetail[0].EventEndTime.UTC().UnixMilli()
	}

	mEnd := float64(ret.StartEndTimePoint.TrackEndTime)
	mStart := float64(ret.StartEndTimePoint.TrackBeginTime)
	var startEndTimeDiff float64 = (mEnd - mStart) / 1000.0
	ret.StartEndTimePoint.TrackDurationSecond = proto.Float64(math_utils.TruncateToDecimals(startEndTimeDiff, 3))

	if beginLonLat, err := GetDetectLonLat(targetEventDetail[0].DetectDevicesBegin, 1, tbCode); err == nil && len(beginLonLat) > 0 {
		ret.DetectDevices = append(ret.DetectDevices, beginLonLat...)
	}
	if endLonLat, err := GetDetectLonLat(targetEventDetail[0].DetectDevicesEnd, 2, tbCode); err == nil && len(endLonLat) > 0 {
		ret.DetectDevices = append(ret.DetectDevices, endLonLat...)
	}
	if totalLonLat, err := GetDetectLonLat(targetEventDetail[0].DetectDevicesTotal, 2, tbCode); err == nil && len(totalLonLat) > 0 {
		ret.DetectDevices = append(ret.DetectDevices, totalLonLat...)
	}

	taskDetails := buildTaskIdByJsonMessage(targetEventDetail[0].TaskIds)
	for _, taskDetail := range taskDetails {
		if taskDetail == nil {
			continue
		}
		// 通过 查找反制无人机的经纬度

		ret.CounterDevices = append(ret.CounterDevices, &pb.TrackCounterDevice{
			// 设备sn
			Sn: taskDetail.DevSn,
			// 设备名称
			Name: taskDetail.DevName,
			// example: 和任务保持一致
			// 反制模式
			CounterMode: int32(taskDetail.Mode),
			// 反制时长
			CounterDurationSecond: int32((taskDetail.EndTime.UTC().UnixMilli() - taskDetail.BeginTime.UTC().UnixMilli()) / 1e3),
			// 反制开始时间时间戳， 单位毫秒
			CounterBeginTime: taskDetail.BeginTime.UTC().UnixMilli(),
			// 反制结束时间时间戳， 单位毫秒
			CounterEndTime: taskDetail.EndTime.UTC().UnixMilli(),
			// 反制设备经度
			Longitude: taskDetail.DevLongitude,
			// 反制纬度
			Latitude: taskDetail.DevLatitude,
		})
	}

	alarmList := buildChangeAlarmDetail(targetEventDetail[0].AlarmIds)
	logger.Infof("get alarm change points len: %v", len(alarmList))

	for _, alarm := range alarmList {
		if alarm == nil {
			continue
		}

		alarmNode := &pb.TrackAlarmNode{
			AlarmLevel: alarm.RiskLevel,
			// 告警的时间戳（点）,单位为秒
			AlarmTime: alarm.CreateTime.UTC().UnixMilli(),
		}

		detectDeviceOnChangeAlarm := alarm_service.UnmarshalDevRelation(alarm.Devrelations) //获取告警时的侦测设备
		logger.Infof("detect device nums: %v on alarm id: %v", len(detectDeviceOnChangeAlarm), alarm.ID)

		var devicesOnAlarmChange []*pb.TrackDetectDevice
		for _, device := range detectDeviceOnChangeAlarm {
			if device == nil {
				continue
			}

			devName, _ := device_manager.GetDeviceDetail(tbCode, device.GetC2Sn(), device.GetSn(), 1, 1)
			if devName == "" {
				devName = device.GetSn()
			}
			devicesOnAlarmChange = append(devicesOnAlarmChange, &pb.TrackDetectDevice{
				Sn: device.GetSn(),
				// 设备名称
				Name: devName,
				// 经度
				Longitude: device.GetLongitude(),
				// 纬度
				Latitude: device.GetLatitude(),
			})
		}

		// 获取告警点时的侦测设备列表:
		if len(devicesOnAlarmChange) > 0 {
			alarmNode.Device = devicesOnAlarmChange
		}

		//将告警变化过程的侦测设备也添加到侦测设备列表中
		ret.DetectDevices = append(ret.DetectDevices, devicesOnAlarmChange...)
		ret.AlarmNode = append(ret.AlarmNode, alarmNode)
	}

	// 过滤重复的侦测设备
	var filterDetectDevices = make(map[string]*pb.TrackDetectDevice)
	for index, _ := range ret.DetectDevices {
		detectDev := ret.DetectDevices[index]
		if detectDev == nil {
			continue
		}
		_, ok := filterDetectDevices[detectDev.GetSn()]
		if ok {
			continue
		}
		filterDetectDevices[detectDev.GetSn()] = detectDev
	}

	if len(filterDetectDevices) > 0 {
		ret.DetectDevices = nil
	}

	for detectDev, _ := range filterDetectDevices {
		ret.DetectDevices = append(ret.DetectDevices, filterDetectDevices[detectDev])
	}

	phoneList := buildPhoneUrlFromBin(targetEventDetail[0].PhotoUrls)
	for _, photo := range phoneList {
		if photo == nil {
			continue
		}
		ret.PtzPhotoNodes = append(ret.PtzPhotoNodes, &pb.PhotoPoint{
			TimePoint: photo.PhotoCreated,
			// example: "https:/xxxx.com/xxx"
			// ptz photo url
			Url:  photo.PhotoUrl, //这个需要每次动态生成。
			Path: photo.PhotoPath,
		})
	}

	return ret, nil
}

func (es *EvidenceReportService) QueryTargetEventOnTrackId(tbCode string, trackId string) (*model.UavTargetEventModel, error) {
	whereCond := "track_id = ?"
	whereValue := []any{trackId}
	targetList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, nil, 0, 1)
	if err != nil {
		logger.Errorf("query target list fail, trackId: %v, err: %v", trackId, err)
		return nil, err
	}
	if len(targetList) <= 0 {
		logger.Errorf("query target list is empty, trackId: %v", trackId)
		return nil, fmt.Errorf("target list is empty")
	}
	return targetList[0], nil
}

// getGpxFileUrl TODO:
func getGpxFileUrl(m *model.UavTargetEventModel) string {
	if m == nil {
		return ""
	}
	return ""
}

// getKmlFileUrl TODO:
func getKmlFileUrl(m *model.UavTargetEventModel) string {
	if m == nil {
		return ""
	}
	return ""
}

func (es *EvidenceReportService) WriteTrajectory(tbCode string, trackId string, fileName string) error {
	item, err := es.QueryTargetEventOnTrackId(tbCode, trackId)
	if err != nil {
		logger.Errorf("in gpx write, query target event fail, %v", err)
		return err
	}

	if item == nil {
		logger.Errorf("in gpx write, target event is nil")
		return fmt.Errorf("target event is nil")
	}

	trajectoryZipFileName := item.TrajectoryZipPath //
	if len(trajectoryZipFileName) <= 0 {
		logger.Errorf("not any trajectory zip file on s3, trackId: %v", trackId)
		return fmt.Errorf("trajectory zip file is empty")
	}
	logger.Debugf("trajectory zip file name: %v", trajectoryZipFileName)

	ossClient := s3Client.NewS3ClientS3(
		&s3Client.S3ClientConfig{
			Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
			Region:              config.GetConfig().EvidenceReportS3.Region,
			Ak:                  config.GetConfig().EvidenceReportS3.Ak,
			Sk:                  config.GetConfig().EvidenceReportS3.Sk,
			FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
			StoreType:           s3Client.AwsS3,
			CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
		})

	if err := ossClient.DownloadToLocal(trajectoryZipFileName, fileName); err != nil {
		logger.Errorf("download traj files fail, %v", err)
		return err
	}
	logger.Infof("download trajectory zip and write to file: %v, success", fileName)
	return nil
}

// TrackZipFiles 资源文件压缩包信息
type TrackZipFiles struct {
	pdfFileName           string //本地绝对路径名
	trajectoryZipFileName string //本地绝对路径名
	//
	commonFilePath string //本地压缩文件的存放目录
	zipFilePath    string //本地压缩文件的文件名: {pdf, trajectory zip file} 绝对路径名
}

func GetZipFileOnS3(trackId string) string {
	return trackId + ".zip"
}

func (es *EvidenceReportService) RemoveFiles(zipFiles *TrackZipFiles) error {
	if zipFiles == nil {
		return nil
	}

	if zipFiles.zipFilePath != "" {
		if err := files_op.DeleteFile(zipFiles.zipFilePath); err != nil {
			logger.Errorf("%v", err)
		} else {
			logger.Infof("delete file: %v succ", zipFiles.zipFilePath)
		}
	}
	if zipFiles.trajectoryZipFileName != "" {
		if err := files_op.DeleteFile(zipFiles.trajectoryZipFileName); err != nil {
			logger.Errorf("%v", err)
		} else {
			logger.Infof("delete file: %v succ", zipFiles.trajectoryZipFileName)
		}
	}
	if zipFiles.pdfFileName != "" {
		if err := files_op.DeleteFile(zipFiles.pdfFileName); err != nil {
			logger.Errorf("%v", err)
		} else {
			logger.Infof("delete file: %v succ", zipFiles.pdfFileName)
		}
	}
	return nil
}

func (es *EvidenceReportService) GetTargetEventOnTrackId(tbCode string, trackId string) (*time.Time, string) {
	var retEventBeginTime *time.Time = nil
	var retDroneModel string
	if tbCode == "" || trackId == "" {
		return retEventBeginTime, retDroneModel
	}
	whereCond := "track_id = ?"
	whereValue := []any{trackId}

	targetList, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, nil, 0, 1)
	if err != nil {
		logger.Errorf("query target list fail, err: %v, trackId: %v", err, trackId)
		return retEventBeginTime, retDroneModel
	}
	if len(targetList) <= 0 {
		logger.Errorf("not find target event, trackId: %v", trackId)
		return retEventBeginTime, retDroneModel
	}
	for i := 0; i < len(targetList); i++ {
		if targetList[i] == nil {
			continue
		}
		if targetList[i].EventBeginTime == nil {
			continue
		}
		retEventBeginTime = targetList[i].EventBeginTime
		retDroneModel = targetList[i].DroneModel
		break
	}
	return retEventBeginTime, retDroneModel
}

func GetS3FileName(tm *time.Time, droneModel string, originName string, lang string) string {
	if tm == nil {
		return ""
	}
	yearV := tm.Year()
	monthV := int(tm.Month())
	dayV := tm.Day()
	//
	hourV := tm.Hour()
	minuteV := tm.Minute()
	secondV := tm.Second()

	//20240911-110201
	tmStr := fmt.Sprintf("%04d%02d%02d-%02d%02d%02d", yearV, monthV, dayV, hourV, minuteV, secondV)

	if droneModel == "" {
		logger.Infof("drone model is empty")
	}

	reportStr := fmt.Sprintf("%s-%s-%s", droneModel, tmStr, originName)
	if lang == "en" || lang == "en-US" {
		reportStr = fmt.Sprintf("DroneReport-%s", reportStr)
	} else if lang == "zh-CN" {
		reportStr = fmt.Sprintf("取证报告-%s", reportStr)
	} else {
		return ""
	}
	return reportStr
}

// UploadZipFiles 上传 zip 文件
func (es *EvidenceReportService) UploadZipFiles(ctx context.Context, tbCode string, trackId string, zipFile *TrackZipFiles) (error, string, int64) {
	if tbCode == "" || zipFile == nil {
		logger.Errorf("input param is nil")
		return fmt.Errorf("input param is nil"), "", 0
	}

	var err error
	if len(zipFile.trajectoryZipFileName) <= 0 {
		logger.Errorf("has not any trajectory zip files, ")
		err = files_op.ZipFiles(zipFile.zipFilePath, zipFile.pdfFileName)
	} else {
		err = files_op.AddNewFilesToZip(zipFile.trajectoryZipFileName, []string{zipFile.pdfFileName}, zipFile.zipFilePath)
	}
	if err != nil {
		logger.Errorf("add new files to zip fail, err: %v", err)
		return err, "", 0
	}

	cli := s3Client.NewS3ClientS3(&s3Client.S3ClientConfig{
		Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
		Region:              config.GetConfig().EvidenceReportS3.Region,
		Ak:                  config.GetConfig().EvidenceReportS3.Ak,
		Sk:                  config.GetConfig().EvidenceReportS3.Sk,
		FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
		StoreType:           s3Client.AwsS3,
		CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
	})

	file, err := os.Open(zipFile.zipFilePath)
	if err != nil {
		logger.Errorf("open zip file fail, err: %v, zip file: %v", zipFile.zipFilePath)
		return err, "", 0
	}
	defer file.Close()

	//（中）取证报告-[机型]-[事件开始时间] 取证报告-dj-20240909-121001-1303578855787462656.zip
	//（英）Drone Report-[机型]-[事件开始时间]
	//

	tm, droneModel := es.GetTargetEventOnTrackId(tbCode, trackId)
	if tm == nil {
		logger.Errorf("get not begin time for target event, trackId: %v", trackId)
		return nil, "", 0
	}

	s3RemoteFileName := GetS3FileName(tm, droneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))
	s3RemoteFileName = cli.BuildBaseObjFileName(s3RemoteFileName)
	s3RemoteFileName = s3Client.BuildS3ObjectFile(constant.TrackS3FilePathPrefix, s3RemoteFileName)
	if err := cli.Upload(file, s3RemoteFileName); err != nil {
		logger.Errorf("upload zip file: %v to s3 fail, err: %v", s3RemoteFileName, err)
		return err, "", 0
	}

	url, err := cli.GetDownloadUrl(s3RemoteFileName, constant.PdfTrajZipFileUrlExpireSecond) //下载数据保留7天
	if url == "" || err != nil {
		logger.Errorf("get zip pre download url fail, is empty, err: %v", err)
		return err, "", 0
	}

	return nil, url, time.Now().UTC().UnixMilli() + constant.PdfTrajZipFileUrlExpireSecond
}

func GetRunWorkPath() (string, error) {
	d, err := os.Getwd()
	if err != nil {
		logger.Errorf("get run work path fail, err: %v", err)
		return "", err
	}
	return d, err
}

// UploadPdfFile 上传文件
func (es *EvidenceReportService) UploadPdfFile(ctx context.Context, tbCode string, trackId string, fileContent []byte, filePdfName string) (error, string, int64) {
	var validExpireMs int64 = 0
	if es == nil || es.s3ClientHandle == nil {
		logger.Errorf("s3 client is nil")
		return fmt.Errorf("s3 client handle is nil"), "", validExpireMs
	}

	var zipFiles *TrackZipFiles = new(TrackZipFiles)

	var filePathDir string = "./"
	if p, err := GetRunWorkPath(); err == nil {
		filePathDir = p
	}

	zipFiles.commonFilePath = filePathDir
	zipFiles.zipFilePath = filepath.Join(filePathDir, trackId+".m.zip")

	var pdfFileName = filepath.Join(filePathDir, filePdfName)
	var trajectoryFileName = filepath.Join(filePathDir, trackId+".zip")

	var (
		retEventBeginTime *time.Time = nil
		retDroneModel     string     = ""
		tasks             routinues.RoutineGroupWrap
	)

	tasks.AsyncRun(true, func() {
		err := es.WritePdfFile(tbCode, trackId, fileContent, pdfFileName)
		if err != nil {
			logger.Errorf("write pdf to local file fail, err: %v, trackId: %v, file name: %v", err, trackId, pdfFileName)
			return
		}
		zipFiles.pdfFileName = pdfFileName
	})

	tasks.AsyncRun(true, func() {
		err := es.WriteTrajectory(tbCode, trackId, trajectoryFileName)
		if err != nil {
			logger.Errorf("write trajectory to local file fail, err: %v, trackId: %v, file name: %v", err, trackId, trajectoryFileName)
			return
		}
		zipFiles.trajectoryZipFileName = trajectoryFileName
	})

	tasks.AsyncRun(true, func() {
		// 替换 url 为文件名：
		whereCond := "track_id = ? and tb_code = ?"
		whereValue := []any{trackId, tbCode}
		targetEventDetail, err := TargetEventDbHandler.QueryItemOnCond(whereCond, whereValue, nil, 0, 1)
		if err != nil {
			logger.Errorf("query target event id fail: %v, trackId: %d, tbCode: %v", err, trackId, tbCode)
			return
		}

		if len(targetEventDetail) <= 0 {
			logger.Errorf("query target event is empty, trackId: %v, tbCode: %v", trackId, tbCode)
			return
		}

		retEventBeginTime = targetEventDetail[0].EventBeginTime
		retDroneModel = targetEventDetail[0].DroneModel
	})

	tasks.Wait()
	logger.Infof("do file download done, next to zip and upload to s3.")

	defer func() {
		_ = es.RemoveFiles(zipFiles)
	}()

	var err error
	var url string
	err, url, validExpireMs = es.UploadZipFiles(ctx, tbCode, trackId, zipFiles)
	if err == nil && url != "" {
		err = es.UpdateDownloadUrl(url, tbCode, trackId)
		if err != nil {
			logger.Errorf("err: %v", err)
			return err, "", validExpireMs
		}
	} else if err != nil {
		logger.Errorf("upload zip files fail, err: %v", err)
		return err, "", validExpireMs

	} else if url == "" {
		logger.Errorf("upload zip files url is empty")
		return nil, "", validExpireMs
	} else {
	}

	fileName := GetS3FileName(retEventBeginTime, retDroneModel, GetZipFileOnS3(trackId), i18nlib.GetLangStrInCtx(ctx))
	return err, fileName, validExpireMs
}

func (es *EvidenceReportService) UpdateDownloadUrl(url string, tbCode string, trackId string) error {
	if url == "" || trackId == "" {
		logger.Errorf("input track id or tb code is empty, url: %v, trackId: %v", url, trackId)
		return fmt.Errorf("param is nil")
	}
	//
	if TargetEventDbHandler == nil {
		logger.Errorf("event target db handle is nil")
		return fmt.Errorf("db handle event target is nil")
	}

	whereCond := "track_id = ? and tb_code = ?"
	whereValue := []any{trackId, tbCode}
	toUpdateFieldName := "evidence_report_url"

	n, err := TargetEventDbHandler.UpdateItems(whereCond, whereValue, toUpdateFieldName, url)
	if err != nil {
		logger.Errorf("err: %v, update evidence_report_url value to: %v, fail: %v, track_id: %v, tb_code: %v",
			err, url, err, trackId, tbCode)
		return err
	}
	logger.Infof("update item num: %v, update evidence_report_url value to : %v succ, track_id: %v, tb_code: %v", n, url, trackId, tbCode)
	return nil
}

func (es *EvidenceReportService) WritePdfFile(tbCode string, trackId string, pdfContent []byte, localPdfFile string) error {
	if err := files_op.WriteFile(localPdfFile, pdfContent); err != nil {
		logger.Errorf("pdf write fail, %v", err)
		return err
	}
	logger.Infof("write pdf succ, fileName: %v", localPdfFile)
	return nil
}

func (es *EvidenceReportService) CheckEventTargetExist(trackIds []string) []string {
	if len(trackIds) <= 0 {
		return []string{}
	}

	whereValue := []any{}
	whereCond := "select * from  t_uav_target_event where track_id in ("
	for i := 0; i < len(trackIds); i++ {
		if trackIds[i] == "" {
			continue
		}

		whereValue = append(whereValue, trackIds[i])
		if i == 0 {
			whereCond += "?"
			continue
		}
		whereCond += ",?"
	}

	whereCond += ");"

	for _, id := range trackIds {
		if id == "" {
			continue
		}
		whereCond += " "
	}

	items, err := TargetEventDbHandler.RawQueryRun(whereCond, whereValue)
	if err != nil {
		logger.Errorf("%v", err)
		return []string{}
	}

	var ret []string
	for _, item := range items {
		if item == nil {
			continue
		}

		ret = append(ret, item.TrackId)
	}
	//logger.Debugf("query from t_uav_target_event, trackId list: %v", ret)
	return ret
}

func (es *EvidenceReportService) UpdateReportName(trackId string, reportName string) error {
	whereStr := "track_id"
	whereVal := []any{trackId}

	fieldName := "report_name"
	fieldValue := reportName
	retNum, err := TargetEventDbHandler.UpdateItems(whereStr, whereVal, fieldName, fieldValue)
	if err != nil {
		return err
	}

	logger.Infof("update ret nums: %v, trackId: %v, to name: %v", retNum, trackId, reportName)
	return nil
}

// UploadPdfFile 上传文件
func (es *EvidenceReportService) UploadCaptureFlyingFile(ctx context.Context, tbCode, trackId, fileName string, fileContent []byte) (string, int64, error) {
	var validExpireMs int64 = 0
	if es == nil || es.s3ClientHandle == nil {
		logger.Errorf("s3 client is nil")
		return "", validExpireMs, fmt.Errorf("s3 client handle is nil")
	}
	// 上传黑飞资料
	ossClient := s3Client.NewS3ClientS3(
		&s3Client.S3ClientConfig{
			Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
			Region:              config.GetConfig().EvidenceReportS3.Region,
			Ak:                  config.GetConfig().EvidenceReportS3.Ak,
			Sk:                  config.GetConfig().EvidenceReportS3.Sk,
			FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
			StoreType:           s3Client.AwsS3,
			CliTimeoutSecondCfg: 300, // 5分钟
		})

	uploadData := bytes.NewReader(fileContent)

	//上传 trajactory 文件是 /cloud/track/TO_30_2_
	s3RemoteFileName := ossClient.BuildBaseObjFileName(trackId + "_" + fileName)
	s3RemoteFileName = s3Client.BuildS3ObjectFile(constant.TrackS3FilePathPrefix, s3RemoteFileName)
	if err := ossClient.Upload(uploadData, s3RemoteFileName); err != nil {
		logger.Errorf("upload data to s3 file: %v, fail: %v", s3RemoteFileName, err)
		return "", validExpireMs, nil
	}

	return s3RemoteFileName, validExpireMs, nil
}

func (es *EvidenceReportService) GetEvidenceByTrackId(tbCode, trackId string) (*model.UavTargetEventModel, error) {
	evidence := &model.UavTargetEventModel{}
	if err := TargetEventDbHandler.GetDBHandle().First(evidence, "tb_code = ? and track_id = ?", tbCode, trackId).Error; err != nil {
		return nil, err
	}
	return evidence, nil
}

func (es *EvidenceReportService) SaveCaptureFlyingInfo(captureFlying *model.CaptureFlyingInfo, updateFlag bool) error {
	if len(captureFlying.DocumentInfo.VideoDocuments) == 0 && len(captureFlying.DocumentInfo.ScreenshotDocuments) == 0 {
		return nil
	}
	if updateFlag {
		return CaptureFlyingDbHandler.GetDBHandle().Model(&model.CaptureFlyingInfo{}).Where("id = ?", captureFlying.Id).
			UpdateColumns(map[string]any{"document_info": captureFlying.DocumentInfo}).Error
	}
	return CaptureFlyingDbHandler.GetDBHandle().Create(captureFlying).Error
}

func (es *EvidenceReportService) UpdateCaptureFlyingInfo(tbCode, trackId string, update map[string]any) error {
	return CaptureFlyingDbHandler.GetDBHandle().Model(&model.CaptureFlyingInfo{}).Where("tb_code = ? and track_id = ?", tbCode, trackId).UpdateColumns(update).Error
}

func (es *EvidenceReportService) GetCaptureFlyingInfoByTrackId(tbCode, trackId string) (*model.CaptureFlyingInfo, error) {
	captureFlying := &model.CaptureFlyingInfo{}
	if err := CaptureFlyingDbHandler.GetDBHandle().First(captureFlying, "tb_code = ? and track_id = ?", tbCode, trackId).Error; err != nil {
		return nil, err
	}
	return captureFlying, nil
}

func (es *EvidenceReportService) GetDownloadUrl(remotePath string, expireMs int64) (string, error) {
	if es == nil || es.s3ClientHandle == nil {
		logger.Errorf("s3 client is nil")
		return "", fmt.Errorf("s3 client handle is nil")
	}
	url, err := es.s3ClientHandle.GetDownloadUrl(remotePath, int32(expireMs))

	return url, err
}

func (es *EvidenceReportService) DownloadFile(remotePath string) ([]byte, error) {
	if es == nil || es.s3ClientHandle == nil {
		logger.Errorf("s3 client is nil")
		return nil, fmt.Errorf("s3 client handle is nil")
	}

	return es.s3ClientHandle.DownloadFile(remotePath)
}
