package evidence_report

import (
	"archive/zip"
	"bytes"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/trajectory"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/domain/service/uav_record"
	"cuav-cloud-go-service/infra/s3Client"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/log"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// 定义无人机详情表名（融合后的数据表）
const (
	UavCommonTableName = "common_uav"
)

// EvidenceReportGenTaskManager 取证报告生成任务管理器
type EvidenceReportGenTaskManager struct {
	// targetEvent 目标事件 (入参)
	targetEvent *pb.TargetEventStatusNotifyItem

	// taskRuntime 运行任务池
	taskRuntime routinues.RoutineGroupWrap

	// tasks 任务集合; key 是具体任务名
	tasks map[string]IEvidenceReportTask
}

func NewEvidenceReportTaskGen(item *pb.TargetEventStatusNotifyItem) *EvidenceReportGenTaskManager {
	handler := &EvidenceReportGenTaskManager{
		targetEvent: item,
		tasks:       make(map[string]IEvidenceReportTask),
	}
	// 创建取证报告生成任务并注册到任务池中

	// 创建并注册： 自动反制任务上 获取取证报告数据
	task1 := NewAutoCounterTaskGenTask()
	handler.RegisterTask(task1.Name(), task1)

	// 创建并注册： 告警事件上(威胁等级发生变化相应时间)， 经过 的围栏区id, 获取取证报告数据
	task2 := NewAlarmOnEvidenceReport()
	handler.RegisterTask(task2.Name(), task2)

	// 创建并注册： 轨迹线上 获取取证报告数据
	task3 := NewTrajectoryTargetEventGen()
	handler.RegisterTask(task3.Name(), task3)

	// 创建并注册： 时间线上 获取取证报告数据
	task4 := NewTimelineOnEvidenceReport()
	handler.RegisterTask(task4.Name(), task4)

	return handler
}

// RegisterTask 注册取证报告中某步骤任务
func (evt *EvidenceReportGenTaskManager) RegisterTask(name string, task IEvidenceReportTask) {
	if evt == nil {
		return
	}

	if evt.tasks == nil {
		logger.Errorf("tasks not init on register node: %v", name)
		return
	}

	_, exist := evt.tasks[name]
	if exist {
		logger.Errorf("has register task in task pool, task name: %v", name)
		return
	}

	evt.tasks[name] = task
	logger.Infof("register task on name: %v", name)
}

func (evt *EvidenceReportGenTaskManager) runTask(taskName string) {
	evt.taskRuntime.AsyncRun(true, func() {
		logger.Infof("begin to run task: %v", taskName)
		defer func() {
			logger.Infof("end to run task: %v", taskName)
		}()

		for {
			err := evt.tasks[taskName].QueryData(evt.targetEvent)
			if err != nil {
				logger.Errorf("query data fail, %v", err)
				return
			}
			if evt.tasks[taskName].IsQueryEnd() { // suspendCall
				logger.Infof("query data complete, task: %v", taskName)
				break
			}
		}
		evt.tasks[taskName].QueryPost(evt.targetEvent)
	})
}

// GenEvidenceReport 生成取证报告
func (evt *EvidenceReportGenTaskManager) GenEvidenceReport() {
	if len(evt.tasks) <= 0 {
		logger.Errorf("not register any evidence report gen task.")
		return
	}

	//分多个步骤来构建取证报告; 然后做任务聚合; 每个一个任务一个线程
	for taskName, _ := range evt.tasks {
		evt.runTask(taskName)
	}
	evt.taskRuntime.Wait()

	var reportData = &EvidenceReportGenInfo{
		targetEvent: evt.targetEvent,
	}
	for taskName := range evt.tasks {
		_ = evt.tasks[taskName].CollectGenData(reportData)
	}

	if err := evt.Upload(reportData); err != nil {
		logger.Errorf("upload trajectory to oss fail")
		return
	}

	if err := evt.WriteDB(reportData); err != nil {
		logger.Errorf("write report to db fail")
		return
	}
	logger.Infof("write evidence data gen and write db success, trackId: %v", evt.targetEvent.GetTrackId())
}

// buildCrossAreaIds 序列化 围栏区列表
func buildCrossAreaIds(reportData *EvidenceReportGenInfo) []byte {
	var areaIds model.ListAnyType[model.CrossAreaId]
	for _, areaId := range reportData.CrossAreaId {
		areaIds = append(areaIds, &model.CrossAreaId{
			AreaId: areaId,
		})
	}

	var areaJson []byte
	var err error
	if len(areaIds) > 0 {
		areaJson, err = areaIds.Marshal()
		if err != nil {
			logger.Errorf("marshal area ids fail, err: %v", err)
		}
	}
	return areaJson
}

// buildPhoneUrlFromBin 反序列化 CrossPhotoUrl
func buildPhoneUrlFromBin(data json.RawMessage) model.ListAnyType[model.CrossPhotoUrl] {
	if len(data) <= 0 {
		return nil
	}

	var phoneUrlList model.ListAnyType[model.CrossPhotoUrl]
	if err := phoneUrlList.Unmarshal(data); err != nil {
		logger.Errorf("unmarshal cross photo url fail, err: %v", err)
		return nil
	}
	return phoneUrlList
}

// buildPhoneUrlList 序列化 ptz 拍照 url
func buildPhoneUrlList(reportData *EvidenceReportGenInfo) []byte {
	var err error
	var phoneUrlList model.ListAnyType[model.CrossPhotoUrl]
	for _, phoneUrl := range reportData.PhoneUrlList {
		if phoneUrl.Url == "" {
			continue
		}

		phoneUrlList = append(phoneUrlList, &model.CrossPhotoUrl{
			PhotoUrl:     phoneUrl.Url,
			PhotoCreated: phoneUrl.TimeCreate.UnixMilli(),
		})
	}

	var phoneUrlJson []byte
	if len(phoneUrlList) > 0 {
		phoneUrlJson, err = phoneUrlList.MarshalSpecial()
		if err != nil {
			logger.Errorf("marshal phone url list fail, err: %v", err)
		}
	}
	return phoneUrlJson
}

// buildTaskIdByJsonMessage;
func buildTaskIdByJsonMessage(data json.RawMessage) []*model.CounterTask {
	if data == nil || len(data) <= 0 {
		return nil
	}

	var taskIdList model.ListAnyType[model.CrossTaskId]
	if err := taskIdList.Unmarshal(data); err != nil {
		return nil
	}
	var ids []int64
	for _, item := range taskIdList.ToList() {
		if item == nil {
			continue
		}
		ids = append(ids, item.TaskId)

	}

	err, taskList := countertask.NewCounterTaskOps(nil).QueryTaskDetailList(ids)
	if err != nil {
		logger.Errorf("query task by taskid fail, taskId: %v", ids)
		return nil
	}
	return taskList
}

// buildTaskIdList 序列化 task id
func buildTaskIdList(reportData *EvidenceReportGenInfo) []byte {
	var err error
	var taskIdList model.ListAnyType[model.CrossTaskId]
	for _, taskNode := range reportData.CounterTaskList {
		if taskNode == nil {
			continue
		}

		taskIdList = append(taskIdList, &model.CrossTaskId{
			TaskId: taskNode.ID, // 记录 task ID
		})
	}
	var taskIdJson []byte
	if len(taskIdList) > 0 {
		taskIdJson, err = taskIdList.Marshal()
		if err != nil {
			logger.Errorf("marshal task id list fail, err: %v", err)
		}
	}
	return taskIdJson
}

// buildChangeAlarmDetail 获取告警等级变化点的告警详情列表
func buildChangeAlarmDetail(data json.RawMessage) []*bean.FendAreaAlarm {
	if data == nil || len(data) <= 0 {
		return nil
	}
	var alarmList model.ListAnyType[model.CrossAlarmId]
	if err := alarmList.Unmarshal(data); err != nil {
		return nil
	}

	var ids []int64
	for _, item := range alarmList.ToList() {
		ids = append(ids, item.AlarmId)
	}

	err, alarmModifyItems := alarm_service.NewAlarmOps(alarm_service.ResAlarmDB).QueryAlarmDetails(ids)
	if err != nil {
		logger.Errorf("query alarm change point fail, err: %v", err)
		return nil
	}
	return alarmModifyItems
}

func buildDetectDeviceOnEnd(reportData *EvidenceReportGenInfo) []byte {
	var deviceJson []byte
	deviceJson = alarm_service.MarshalDevRelation(reportData.targetEvent.EndDevRelations)
	return deviceJson
}

func buildDetectDeviceOnStart(reportData *EvidenceReportGenInfo) []byte {
	var deviceJson []byte
	deviceJson = alarm_service.MarshalDevRelation(reportData.targetEvent.StartDevRelations)
	return deviceJson
}

// buildChangeAlarmId 告警id变化点 序列化
func buildChangeAlarmId(reportData *EvidenceReportGenInfo) []byte {
	var err error
	var alarmIds model.ListAnyType[model.CrossAlarmId]
	for _, alarmNode := range reportData.AlarmPointChangeList {
		if alarmNode == nil {
			continue
		}

		alarmIds = append(alarmIds, &model.CrossAlarmId{
			AlarmId: alarmNode.ID,
		})
	}
	var alarmIdJson []byte
	if len(alarmIds) > 0 {
		alarmIdJson, err = alarmIds.Marshal()
		if err != nil {
			logger.Errorf("marshal alarm id list fail, err: %v", err)
		}
	}
	return alarmIdJson
}

// compensationTimeMilliSecond 补充结束时间，延长时间，补充其他task传输的耗时
const compensationTimeMilliSecond = 1000

// WriteDB 取证报告 摘要信息写入 db
func (evt *EvidenceReportGenTaskManager) WriteDB(reportData *EvidenceReportGenInfo) error {
	if reportData == nil || reportData.targetEvent == nil {
		logger.Errorf("report data is nil")
		return fmt.Errorf("report data input is nil")
	}

	id, _ := snowflake.GetUniqueID()
	beginTime := time.UnixMilli(reportData.targetEvent.StartTime).UTC()
	endTime := time.UnixMilli(reportData.targetEvent.EndTime + compensationTimeMilliSecond).UTC()
	nowTime := time.Now().UTC()

	var areaJson []byte = buildCrossAreaIds(reportData)
	var phoneUrlJson []byte = buildPhoneUrlList(reportData)
	var taskIdJson []byte = buildTaskIdList(reportData)
	var alarmIdJson []byte = buildChangeAlarmId(reportData)
	//
	var detectDevOnEnd []byte = buildDetectDeviceOnEnd(reportData)
	var detectDevOnBegin []byte = buildDetectDeviceOnStart(reportData)
	detectDevTotal := alarm_service.MarshalDevRelation(reportData.targetEvent.GetTotalDevRelations())

	item := &model.UavTargetEventModel{
		Id:                 id,
		TrackId:            reportData.targetEvent.GetTrackId(),
		EventBeginTime:     &beginTime,
		EventEndTime:       &endTime,
		DroneModel:         reportData.targetEvent.DroneModel,
		SerialNum:          reportData.targetEvent.SerialNum,
		ObjId:              reportData.targetEvent.ObjId,
		Freq:               reportData.targetEvent.Freq,
		UavName:            reportData.targetEvent.GetUavName(),
		TrajectoryZipPath:  reportData.TrajZipFilePath,
		CreateAt:           &nowTime,
		AreaIds:            areaJson,
		PhotoUrls:          phoneUrlJson,
		TaskIds:            taskIdJson,
		AlarmIds:           alarmIdJson,
		TbCode:             reportData.targetEvent.GetTbCode(),
		DetectDevicesBegin: detectDevOnBegin,
		DetectDevicesEnd:   detectDevOnEnd,
		DetectDevicesTotal: detectDevTotal,
	}

	if reportData.targetEvent.EndPoint != nil {
		item.HomeLong = reportData.targetEvent.EndPoint.HomeLongitude
		item.HomeLat = reportData.targetEvent.EndPoint.HomeLatitude
	} else {
		logger.Errorf("not set end of home point")
	}

	if reportData.targetEvent.EndPilot != nil {
		item.PilotLong = reportData.targetEvent.EndPilot.PilotLongitude
		item.PilotLat = reportData.targetEvent.EndPilot.PilotLatitude
	} else {
		logger.Errorf("not set end of pilot")
	}

	if reportData.targetEvent.StartLonLat != nil {
		item.BeginLong = reportData.targetEvent.StartLonLat.Longitude
		item.BeginLat = reportData.targetEvent.StartLonLat.Latitude
	} else {
		logger.Errorf("not set start of lon, lat")
	}

	if reportData.targetEvent.EndLonLat != nil {
		item.EndLong = reportData.targetEvent.EndLonLat.Longitude
		item.EndLat = reportData.targetEvent.EndLonLat.Latitude
	} else {
		logger.Errorf("not set end of lon, lat")
	}

	if _, err := TargetEventDbHandler.Insert([]*model.UavTargetEventModel{item}); err != nil {
		logger.Errorf("insert evidence report to db fail, err: %v", err)
	}
	return nil
}

// Upload 将 trajectory file to oss.
func (evt *EvidenceReportGenTaskManager) Upload(reportData *EvidenceReportGenInfo) error {
	if len(reportData.TrajectoryZipFile) <= 0 {
		logger.Errorf("not get trajectory zip file for gpx and kml.")
		return nil
	}

	ossClient := s3Client.NewS3ClientS3(
		&s3Client.S3ClientConfig{
			Bucket:              config.GetConfig().EvidenceReportS3.Bucket,
			Region:              config.GetConfig().EvidenceReportS3.Region,
			Ak:                  config.GetConfig().EvidenceReportS3.Ak,
			Sk:                  config.GetConfig().EvidenceReportS3.Sk,
			FilePrefix:          config.GetConfig().EvidenceReportS3.FilePrefix,
			StoreType:           s3Client.AwsS3,
			CliTimeoutSecondCfg: config.GetConfig().EvidenceReportS3.UploadTimeoutSecond,
		})

	uploadData := bytes.NewReader(reportData.TrajectoryZipFile)

	//上传 trajactory 文件是 /cloud/track/TO_30_2_
	s3RemoteFileName := ossClient.BuildBaseObjFileName(GetZipFileOnS3(reportData.targetEvent.TrackId))
	s3RemoteFileName = s3Client.BuildS3ObjectFile(constant.TrackS3FilePathPrefix, s3RemoteFileName)
	if err := ossClient.Upload(uploadData, s3RemoteFileName); err != nil {
		logger.Errorf("upload data to s3 file: %v, fail: %v", s3RemoteFileName, err)
		return nil
	}

	reportData.TrajZipFilePath = s3RemoteFileName
	return nil
}

// IEvidenceReportTask 取证报告任务通用接口
type IEvidenceReportTask interface {

	// QueryData 步骤的操作逻辑
	QueryData(targetEvent *pb.TargetEventStatusNotifyItem) error

	// Name 步骤的名称
	Name() string

	// QueryPost 查询之后的处理
	QueryPost(targetEvent *pb.TargetEventStatusNotifyItem)

	// IsQueryEnd 返回步骤是否完成
	IsQueryEnd() bool

	// CollectGenData 拼接取证报告内容
	CollectGenData(dst *EvidenceReportGenInfo) error
}

// CounterTaskOnEvidenceReport 取证报告-反制任务信息提取
type CounterTaskOnEvidenceReport struct {
	name  string               // 初始化设置
	tasks []*model.CounterTask // 查询结果
}

func NewAutoCounterTaskGenTask() *CounterTaskOnEvidenceReport {
	return &CounterTaskOnEvidenceReport{
		name: "counter_task_on_evidence_report",
	}
}
func (at *CounterTaskOnEvidenceReport) Name() string {
	return at.name
}

// QueryPost 获取反制设备名称，反制模式，反制参数，反制时长等
func (at *CounterTaskOnEvidenceReport) QueryPost(targetEvent *pb.TargetEventStatusNotifyItem) {
	if at == nil {
		return
	}

	if len(at.tasks) <= 0 {
		logger.Debug("has not any task result, task_id: %v", targetEvent.GetTrackId())
		return
	}
}

// CollectGenData 将 反制任务的数据填充到 取证报告数据中
func (at *CounterTaskOnEvidenceReport) CollectGenData(dst *EvidenceReportGenInfo) error {
	if at == nil || dst == nil {
		return nil
	}

	dst.CounterTaskList = at.tasks
	return nil
}

// QueryData 反制任务中取证报告数据获取； 获取反制设备名称，反制模式，反制参数，反制时长等
func (at *CounterTaskOnEvidenceReport) QueryData(targetEvent *pb.TargetEventStatusNotifyItem) error {
	if targetEvent == nil {
		return fmt.Errorf("target event is nil")
	}

	if at == nil {
		return fmt.Errorf("handle is nil")
	}

	err, taskList := countertask.NewCounterTaskOps(nil).QueryTaskListByTrackId(targetEvent.GetTrackId(), targetEvent.GetTbCode())
	if err != nil {
		logger.Errorf("query task by track id fail, err: %v, track_id: %v", err, targetEvent.GetTrackId())
		return fmt.Errorf("query task by track id fail")
	}
	at.tasks = taskList

	if len(taskList) > 0 {
		logger.Infof("counter tasks: %+v, for track id: %v", taskList, targetEvent.GetTrackId())
		return nil
	}
	return nil
}

// IsQueryEnd 本次任务运行是否结束；不需要走后续流程
func (at *CounterTaskOnEvidenceReport) IsQueryEnd() bool {
	return true
}

// AlarmOnEvidenceReport 取证报告-告警信息提取: 危险等级变化提取
type AlarmOnEvidenceReport struct {
	name string
	// alarmList 飞行中危险等级变化的告警点
	alarmList []*bean.FendAreaAlarm
	// 经历的围栏区id
	areaIdOnCross []int64
}

func NewAlarmOnEvidenceReport() *AlarmOnEvidenceReport {
	return &AlarmOnEvidenceReport{
		name: "alarm_level_change_on_evidence_report",
	}
}

// CollectGenData 把危险等级变化点, 所有跨越 围栏区id,  组装到 取证报告数据中
func (ae *AlarmOnEvidenceReport) CollectGenData(dst *EvidenceReportGenInfo) error {
	if ae == nil || dst == nil {
		return nil
	}

	dst.AlarmPointChangeList = ae.alarmList
	dst.CrossAreaId = ae.areaIdOnCross
	return nil
}

func (ae *AlarmOnEvidenceReport) Name() string {
	return ae.name
}

func (ae *AlarmOnEvidenceReport) QueryPost(targetEvent *pb.TargetEventStatusNotifyItem) {
	return
}

// IsQueryEnd 告警变化查询到后不做处理，直接标志结束逻辑
func (ae *AlarmOnEvidenceReport) IsQueryEnd() bool {
	return true
}

func (ae *AlarmOnEvidenceReport) queryInboundAreaIds(targetEvent *pb.TargetEventStatusNotifyItem) error {
	if ae == nil || targetEvent == nil {
		return fmt.Errorf("input param is nil")
	}

	err, alarmItems := alarm_service.NewAlarmOps(alarm_service.ResAlarmDB).QueryAlarmByTrackId(targetEvent.GetTrackId(), targetEvent.GetTbCode())
	if err != nil {
		logger.Errorf("query in bound area ids fail, %v", err)
		return err
	}

	if len(alarmItems) <= 0 {
		return nil
	}

	var areaIds = make(map[int64]bool) //key: is area id
	for _, alarmItem := range alarmItems {
		if alarmItem == nil {
			continue
		}

		if len(alarmItem.InboundAreaIds) <= 0 {
			continue
		}

		var areas model.ListAnyType[model.CrossAreaId]
		if err := areas.Unmarshal(alarmItem.InboundAreaIds); err != nil {
			logger.Errorf("parse in bound area ids from bin fail, err: %v", err)
			continue
		}
		for _, areaItem := range areas {
			if areaItem == nil {
				continue
			}
			areaIds[areaItem.AreaId] = true
		}
	}

	for area, _ := range areaIds {
		ae.areaIdOnCross = append(ae.areaIdOnCross, area)
	}

	if len(ae.areaIdOnCross) > 0 {
		logger.Debugf("cross area ids: %v, trackId: %v", ae.areaIdOnCross, targetEvent.GetTrackId())
	}
	return nil
}

func (ae *AlarmOnEvidenceReport) queryAlarmLevelChangeList(targetEvent *pb.TargetEventStatusNotifyItem) error {
	err, alarmModifyItems := alarm_service.NewAlarmOps(alarm_service.ResAlarmDB).QueryAlarmChangePointByTrackId(targetEvent.GetTrackId(), targetEvent.GetTbCode())
	if err != nil {
		logger.Errorf("query alarm change point fail, err: %v", err)
		return fmt.Errorf("query alarm change point fail")
	}

	ae.alarmList = alarmModifyItems

	if len(alarmModifyItems) > 0 {
		logger.Debugf("get modify alarm by trackId: %v, tbCode: %v, alarms: %+v", targetEvent.GetTrackId(), targetEvent.GetTbCode(), alarmModifyItems)
	}
	return nil
}

// QueryData 获取危险等级变化点的告警，经过围栏区的围栏区id
func (ae *AlarmOnEvidenceReport) QueryData(targetEvent *pb.TargetEventStatusNotifyItem) error {
	if targetEvent == nil {
		return fmt.Errorf("param is nil")
	}

	if ae == nil {
		return fmt.Errorf("handle is nil")
	}

	wg := routinues.NewRoutineGroupWrap()

	wg.AsyncRun(true, func() {
		_ = ae.queryInboundAreaIds(targetEvent)
	})
	wg.AsyncRun(true, func() {
		_ = ae.queryAlarmLevelChangeList(targetEvent)
	})

	wg.Wait()
	return nil
}

// TargetEventTrajectoryGen 取证报告-目标事件轨迹线提取
type TargetEventTrajectoryGen struct {
	name                  string         // 初始化设置
	uavLists              map[string]any // key: table name, value is uav detail list
	index                 int            // uav item id,记录查询过程
	IsQueryEndRet         bool           // 标记当前轨迹查询是否全部查询完
	trajectoryZipFile     []byte
	trajectoryZipFileName string
}

func NewTrajectoryTargetEventGen() *TargetEventTrajectoryGen {
	return &TargetEventTrajectoryGen{
		name:          "target_event_trajectory_gen_task",
		uavLists:      map[string]any{UavCommonTableName: make([]*model.ProtocolUavDetect, 0)},
		index:         1,
		IsQueryEndRet: false,
	}
}
func (te *TargetEventTrajectoryGen) Name() string {
	return te.name
}

// CollectGenData 将轨迹信息填充到 取证报告
func (te *TargetEventTrajectoryGen) CollectGenData(dst *EvidenceReportGenInfo) error {
	if dst == nil {
		return nil
	}
	dst.TrajectoryZipFile = te.trajectoryZipFile
	return nil
}

// QueryData 轨迹线查询查询
func (te *TargetEventTrajectoryGen) QueryData(targetEvent *pb.TargetEventStatusNotifyItem) error {
	if targetEvent == nil {
		logger.Errorf("req target event is nil")
		return fmt.Errorf("target is nil")
	}

	var (
		uavList []*model.ProtocolUavDetect
		err     error
	)
	for i := 0; i < 3; i++ {
		uavList, err = QueryUavListTask(targetEvent.UavDBNode.DbTableName, targetEvent.GetTrackId(), targetEvent.GetTbCode(), te.index, targetEvent.StartTime, targetEvent.EndTime)
		if err != nil {
			logger.Errorf("query protocol uav fail, %v", err)
		}
		if len(uavList) > 0 {
			break
		}
	}

	if len(uavList) == 0 {
		te.IsQueryEndRet = true
		return nil
	}
	if oldList, ok := te.uavLists[UavCommonTableName].([]*model.ProtocolUavDetect); ok {
		oldList = append(oldList, uavList...)
		te.uavLists[UavCommonTableName] = oldList
		te.index++
	}
	return nil
}

const (
	TrackFileSuffixGpx = ".gpx"
	TrackFileSuffixKml = ".kml"
)

// GetFileNameOnTrack 构建 轨迹 gpx / kml 文件名
func GetFileNameOnTrack(trackId string, fileType string) string {
	return trackId + fileType
}

func (te *TargetEventTrajectoryGen) QueryPost(targetEvent *pb.TargetEventStatusNotifyItem) {
	// 写文件
	data, ok := te.uavLists[UavCommonTableName]
	if ok {
		if uavList, ok := data.([]*model.ProtocolUavDetect); ok && len(uavList) > 0 {
			gpxBody := WriteProtocolUavTrajectoryToGpxFile(targetEvent.GetTrackId(),
				GetFileNameOnTrack(targetEvent.GetTrackId(), TrackFileSuffixGpx), uavList)

			kmlBody := WriteProtocolUavTrajectoryToKmlFile(targetEvent.GetTrackId(),
				GetFileNameOnTrack(targetEvent.GetTrackId(), TrackFileSuffixKml), uavList)
			buffer := new(bytes.Buffer)
			zipWriter := zip.NewWriter(buffer)
			if err := addFileToZip(zipWriter, targetEvent.TrackId+TrackFileSuffixGpx, gpxBody); err != nil {
				log.Errorf("Add gpxFile to zip error: %s", err.Error())
				return
			}
			if err := addFileToZip(zipWriter, targetEvent.TrackId+TrackFileSuffixKml, kmlBody); err != nil {
				log.Errorf("Add kmlFile to zip error: %s", err.Error())
				return
			}

			if err := NewEvidenceReportService().CaptureFlyingInfoToZip(zipWriter, targetEvent.TbCode, targetEvent.TrackId); err != nil {
				log.Errorf("Add CaptureFlying file to zip error: %s", err.Error())
				return
			}

			if err := zipWriter.Close(); err != nil {
				log.Errorf("zipWriter Close error: %s", err.Error())
				return
			}
			te.trajectoryZipFile = buffer.Bytes()
		}
	}
}

type zipQueueItem struct {
	body     []byte
	fileName string
}

func (es *EvidenceReportService) CaptureFlyingInfoToZip(zipWriter *zip.Writer, tbCode, trackId string) error {
	captureFlying, err := es.GetCaptureFlyingInfoByTrackId(tbCode, trackId)
	if err != nil && err.Error() != "record not found" {
		return err
	}
	if captureFlying == nil {
		return nil
	}
	// 下载飞手资料
	if captureFlying.DocumentInfo.CompressFlag {
		return nil
	}
	if len(captureFlying.DocumentInfo.VideoDocuments) == 0 && len(captureFlying.DocumentInfo.ScreenshotDocuments) == 0 {
		return nil
	}

	docs := append(captureFlying.DocumentInfo.VideoDocuments, captureFlying.DocumentInfo.ScreenshotDocuments...)
	queue := make(chan zipQueueItem, len(docs))
	var countDown sync.WaitGroup
	countDown.Add(len(docs))
	for _, item := range docs {
		go func(doc model.DocumentItem) {
			defer countDown.Done()
			defer func() {
				if r := recover(); r != nil {
					logger.Errorf("CaptureFlyingInfoToZip panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
				}
			}()
			// 下载文件
			body, err := es.s3ClientHandle.DownloadFile(doc.S3Path)
			if err != nil {
				logger.Errorf("CaptureFlyingInfoToZip DownloadToCacheByPreUrl error: %s", err.Error())
				return
			}
			queue <- zipQueueItem{body: body, fileName: doc.Name}
		}(item)
	}
	doneChan := make(chan struct{})
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Errorf("CaptureFlyingInfoToZip consumer panic : %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
			}
		}()
		for {
			select {
			case zipItem := <-queue:
				if err := addFileToZip(zipWriter, zipItem.fileName, zipItem.body); err != nil {
					logger.Errorf("CaptureFlyingInfoToZip addFileToZip error: %s", err.Error())
				}
			case <-doneChan:
				return
			}
		}
	}()
	countDown.Wait()
	doneChan <- struct{}{}
	captureFlying.DocumentInfo.CompressFlag = true
	if err := es.UpdateCaptureFlyingInfo(captureFlying.TbCode, captureFlying.TrackId,
		map[string]any{"document_info": captureFlying.DocumentInfo}); err != nil {
		logger.Errorf("CaptureFlyingInfoToZip UpdateCaptureFlyingInfo error: %s", err.Error())
	}

	return nil
}

func addFileToZip(zipWriter *zip.Writer, fileName string, body []byte) error {
	writer, err := zipWriter.Create(fileName)
	if err != nil {
		return err
	}
	_, err = writer.Write(body)
	return err
}

// IsQueryEnd 涉及到轨迹数据，需要批量查询，批量写文件
func (te *TargetEventTrajectoryGen) IsQueryEnd() bool {
	return te.IsQueryEndRet
}

// WriteProtocolUavTrajectoryToGpxFile 将协议解析无人机轨迹信息写入 gpx 文件
func WriteProtocolUavTrajectoryToGpxFile(trackId string, fileName string, uavList []*model.ProtocolUavDetect) []byte {
	var gpxItem []*trajectory.GpxNodeInfo
	for _, uav := range uavList {
		if uav == nil {
			continue
		}
		createTime := time.UnixMilli(uav.CreateTime).UTC()
		gpxItem = append(gpxItem, &trajectory.GpxNodeInfo{
			DroneLatitude:  uav.DroneLatitude,
			DroneLongitude: uav.DroneLongitude,
			DroneHeight:    uav.DroneAltitude,
			CreateTime:     &createTime,
		})
	}

	return trajectory.WriteTrajectoryToGpxFile(trackId, fileName, gpxItem)
}

// WriteProtocolUavTrajectoryToKmlFile 将协议解析无人机轨迹写入 kml 文件
func WriteProtocolUavTrajectoryToKmlFile(trackId string, fileName string, uavList []*model.ProtocolUavDetect) []byte {
	var gpxItem []*trajectory.KmlNodeInfo
	for _, uav := range uavList {
		if uav == nil {
			continue
		}
		createTime := time.UnixMilli(uav.CreateTime).UTC()
		gpxItem = append(gpxItem, &trajectory.KmlNodeInfo{
			DroneLatitude:  uav.DroneLatitude,
			DroneLongitude: uav.DroneLongitude,
			DroneHeight:    uav.DroneAltitude,
			CreateTime:     &createTime,
		})
	}

	return trajectory.WriteTrajectoryToKmlFile(trackId, fileName, gpxItem)
}

// QueryProtocolUavListTask 查询协议解析的无人机信息
func QueryUavListTask(url, trackId string, tbCode string, index int, startTime, endTime int64) ([]*model.ProtocolUavDetect, error) {
	var protocolUavGetHandle = NewProtocolUavOpsHandle()

	if protocolUavGetHandle == nil {
		logger.Errorf("protocol uav get handle not init")
		return []*model.ProtocolUavDetect{}, fmt.Errorf("db handle not init")
	}

	logger.Infof("query uav begin id: %v, trackId: %v, tbCode: %v", index, trackId, tbCode)

	uavs, err := protocolUavGetHandle.QueryProtocolUavList(url, trackId, tbCode, index, startTime, endTime)
	if err != nil {
		logger.Errorf("query uav protocol item fail, %v", err)
		return []*model.ProtocolUavDetect{}, err
	}

	if uavs == nil || len(uavs) <= 0 {
		return []*model.ProtocolUavDetect{}, nil
	}

	logger.Debugf("query uav list nums: %v, trackId: %v", len(uavs), trackId)
	return uavs, nil
}

// TimelineOnEvidenceReport  时间线上-取证报告获取
type TimelineOnEvidenceReport struct {
	name         string
	timelineList []*bean.FencedUavRecord
	// photoUrlList 拍照 url 的下载地址
	photoUrlList []uav_record.ImageUrlInfo
}

func NewTimelineOnEvidenceReport() *TimelineOnEvidenceReport {
	return &TimelineOnEvidenceReport{
		name: "timeline_on_evidence_report",
	}
}
func (tl *TimelineOnEvidenceReport) Name() string {
	return tl.name
}

// CollectGenData 将时间线数据填充到取证报告
func (tl *TimelineOnEvidenceReport) CollectGenData(dst *EvidenceReportGenInfo) error {
	if tl == nil || dst == nil {
		return nil
	}

	dst.PhoneUrlList = tl.photoUrlList
	return nil
}

// QueryData 时间线数据查询 拍照文件链接
func (tl *TimelineOnEvidenceReport) QueryData(targetEvent *pb.TargetEventStatusNotifyItem) error {
	if targetEvent == nil {
		return fmt.Errorf("target event is nil")
	}

	err, items := uav_record.QueryFenceUavRecordByTrackId(targetEvent.GetTbCode(), targetEvent.GetTrackId())
	if err != nil {
		logger.Errorf("get record fail: %v, tbCode: %v, trackId: %v", err, targetEvent.GetTbCode(), targetEvent.GetTrackId())
		return err
	}

	eventIdList := []string{}
	tl.timelineList = items
	for _, tlItem := range tl.timelineList {
		if tlItem == nil {
			continue
		}

		if tlItem.Eventid == "" {
			continue
		}
		eventIdList = append(eventIdList, tlItem.Eventid)
	}

	var photoUrlLists []uav_record.ImageUrlInfo
	for _, eventId := range eventIdList {
		if eventId == "" {
			continue
		}

		photoUrlList := uav_record.GetEventImageDownloadURL(eventId)
		if len(photoUrlList) <= 0 {
			continue
		}
		photoUrlLists = append(photoUrlLists, photoUrlList...)
	}

	tl.photoUrlList = photoUrlLists
	if len(photoUrlLists) > 0 {
		logger.Infof("photo url list: %v, trackId: %v", tl.photoUrlList, targetEvent.GetTrackId())
	}
	return nil
}

func (tl *TimelineOnEvidenceReport) QueryPost(targetEvent *pb.TargetEventStatusNotifyItem) {
	logger.Infof("no logic to do.")
	return

}

func (tl *TimelineOnEvidenceReport) IsQueryEnd() bool {
	return true
}

type EvidenceReportGenInfo struct {
	targetEvent *pb.TargetEventStatusNotifyItem // 入参

	// 结果集合
	CounterTaskList      []*model.CounterTask      // 轨迹经历的 反制任务列表
	AlarmPointChangeList []*bean.FendAreaAlarm     // 轨迹经历的 告警等级变化点
	TrajectoryZipFile    []byte                    // 轨迹文件压缩包内容
	PhoneUrlList         []uav_record.ImageUrlInfo // 轨迹经历的ptz 拍照 oss 存储 url
	CrossAreaId          []int64                   // 轨迹经历的 围栏区 id 列表
	TrajZipFilePath      string                    // 取证报告轨迹文件zip在s3路径,不包过 bucket name,
}
