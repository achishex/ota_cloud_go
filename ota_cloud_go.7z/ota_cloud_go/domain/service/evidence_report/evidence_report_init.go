package evidence_report

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"

	"gorm.io/gorm"
)

// InitRes 在主函数中注册，初始化资源
func InitRes(ctx context.Context) {
	// InitEvidenceReport()
	InitTargetEventDbHandle()
	InitCaptureFlyingDbHandle()
}

// type ProtocolUavDbHandleType = db.DbOpsTplInterface[model.ProtocolUavDetect]

// var ProtocolUavDbHandler ProtocolUavDbHandleType = nil

// // MockProtocolUavDbHandle 仅用测试 mock 使用
// func MockProtocolUavDbHandle(dbHandle *gorm.DB) ProtocolUavDbHandleType {
// 	ProtocolUavDbHandler = db.NewDBModelTplWrapper[model.ProtocolUavDetect](dbHandle).SetTabName(model.ProtocolUavDetect{}.TableName())
// 	return ProtocolUavDbHandler
// }

// // InitEvidenceReport 初始化访问db的连接
// func InitEvidenceReport() ProtocolUavDbHandleType {

// 	ProtocolUavDbHandler = db.NewDBModelTplWrapper[model.ProtocolUavDetect](config.GetDataDB()).SetTabName(model.ProtocolUavDetect{}.TableName())
// 	return ProtocolUavDbHandler
// }

// TargetEventDbHandleType 目标事件db 处理句柄类型
type TargetEventDbHandleType = db.DbOpsTplInterface[model.UavTargetEventModel]

var TargetEventDbHandler TargetEventDbHandleType = nil

type CaptureFlyingDbHandleType = db.DbOpsTplInterface[model.CaptureFlyingInfo]

var CaptureFlyingDbHandler CaptureFlyingDbHandleType = nil

// InitTargetEventDbHandle 初始化目标事件句柄
func InitCaptureFlyingDbHandle() CaptureFlyingDbHandleType {
	CaptureFlyingDbHandler = db.NewDBModelTplWrapper[model.CaptureFlyingInfo](config.GetDB()).SetTabName(model.CaptureFlyingInfo{}.TableName())
	return CaptureFlyingDbHandler
}

// InitTargetEventDbHandle 初始化目标事件句柄
func InitTargetEventDbHandle() TargetEventDbHandleType {
	TargetEventDbHandler = db.NewDBModelTplWrapper[model.UavTargetEventModel](config.GetDB()).SetTabName(model.UavTargetEventModel{}.TableName())
	return TargetEventDbHandler
}

// MockTargetEventDbHandle 仅用测试使用
func MockTargetEventDbHandle(dbHandle *gorm.DB) TargetEventDbHandleType {
	TargetEventDbHandler = db.NewDBModelTplWrapper[model.UavTargetEventModel](dbHandle).SetTabName(model.UavTargetEventModel{}.TableName())
	return TargetEventDbHandler
}
