package evidence_report

import (
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/mock"
	"errors"
	"fmt"
	"os"
	"testing"
	"time"

	"github.com/tkrajina/gpxgo/gpx"
	_ "github.com/tkrajina/gpxgo/gpx"
)

func TestGpxFileOp(t *testing.T) {
	fileName := "not_exist_file.gpx"
	gpxHandle, err := gpx.ParseFile(fileName)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			t.Logf("not exist error")
		} else {
			t.Logf("open fail, err: %v", err)
		}

	} else {
		t.Logf("open gpx file, file: %v", gpxHandle)
	}
}

func TestWriteProtocolUavTrajectoryToGpxFile(t *testing.T) {
	mock.LoggerMock()

	mTmp := time.Now().UTC()
	notExistFile := "not_exist.gpx"

	uavList := []*model.ProtocolUavDetect{
		&model.ProtocolUavDetect{
			DroneLongitude: 1.1,
			DroneLatitude:  2.2,
			DroneAltitude:  3.3,
			CreateTime:     mTmp.UnixMilli(),
		},
		&model.ProtocolUavDetect{
			DroneLongitude: 10.1,
			DroneLatitude:  20.2,
			DroneAltitude:  30.3,
			CreateTime:     mTmp.UnixMilli(),
		},
		&model.ProtocolUavDetect{
			DroneLongitude: 100.1,
			DroneLatitude:  200.2,
			DroneAltitude:  300.3,
			CreateTime:     mTmp.UnixMilli(),
		},
		&model.ProtocolUavDetect{
			DroneLongitude: 1000.1,
			DroneLatitude:  2000.2,
			DroneAltitude:  3000.3,
			CreateTime:     mTmp.UnixMilli(),
		},
	}

	WriteProtocolUavTrajectoryToGpxFile("track_id_test.1", notExistFile, uavList)
}

func TestDemoAddItemToGpx(t *testing.T) {
	// 打开要读取的 GPX 文件
	inputFile, err := os.Open("example.gpx")
	if err != nil {
		fmt.Println("Error opening GPX file:", err)
		return
	}
	defer inputFile.Close()

	// 解析 GPX 文件
	gpxData, err := gpx.Parse(inputFile)
	if err != nil {
		fmt.Println("Error parsing GPX file:", err)
		return
	}

	// 创建一个新的轨迹
	newTrack := gpx.GPXTrack{
		Name: "New Track",
		Segments: []gpx.GPXTrackSegment{
			{
				Points: []gpx.GPXPoint{
					gpx.GPXPoint{
						Point: gpx.Point{Latitude: float64(time.Now().UnixMilli()),
							Longitude: float64(time.Now().UnixMilli())},
					},

					gpx.GPXPoint{
						Point: gpx.Point{Latitude: float64(time.Now().UnixMilli()), Longitude: float64(time.Now().UnixMilli())},
					},
				},
			},
		},
	}

	// 将新轨迹添加到现有 GPX 结构
	gpxData.Tracks = append(gpxData.Tracks, newTrack)

	// 打开要保存的 GPX 文件
	outputFile, err := os.Create("example.gpx")
	if err != nil {
		fmt.Println("Error creating GPX file:", err)
		return
	}
	defer outputFile.Close()

	// 保存修改后的 GPX 文件
	xmlOutput, err := gpxData.ToXml(gpx.ToXmlParams{Indent: true})
	if err != nil {
		t.Logf("to xml fail, err: %v", err)
		return
	}
	_, err = outputFile.Write([]byte(xmlOutput))
	if err != nil {
		fmt.Println("Error writing GPX file:", err)
		return
	}

	fmt.Println("New track successfully added and GPX file saved as 'updated_example.gpx'")
}

func TestCreateNewGpxFile(t *testing.T) {
	// 创建一个新的 GPX 对象
	gpxData := gpx.GPX{
		Creator: "Example", // 设置创建者
		Version: "1.1",     // 设置 GPX 版本
	}

	var ele gpx.NullableFloat64
	ele.SetValue(1.1)
	// 创建一个新的轨迹
	newTrack := gpx.GPXTrack{
		Name: "New Track",
		Segments: []gpx.GPXTrackSegment{
			{
				Points: []gpx.GPXPoint{
					gpx.GPXPoint{
						Point:     gpx.Point{Latitude: 123, Longitude: 456, Elevation: ele},
						Timestamp: time.Now(),
					},

					gpx.GPXPoint{
						Point:     gpx.Point{Latitude: 123.1, Longitude: 456.1, Elevation: ele},
						Timestamp: time.Now(),
					},
				},
			},
		},
	}

	// 将新轨迹添加到 GPX 对象中
	gpxData.Tracks = append(gpxData.Tracks, newTrack)

	// 打开要保存的 GPX 文件
	outputFile, err := os.Create("example.gpx")
	if err != nil {
		fmt.Println("Error creating GPX file:", err)
		return
	}
	defer outputFile.Close()

	// 将 GPX 数据转换为 XML 并写入文件
	xmlOutput, err := gpxData.ToXml(gpx.ToXmlParams{Indent: true})
	_, err = outputFile.Write([]byte(xmlOutput))
	if err != nil {
		fmt.Println("Error writing GPX file:", err)
		return
	}

	fmt.Println("New track successfully written to 'new_track.gpx'")
}
