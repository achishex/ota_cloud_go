package alarm_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/domain/repository/redis"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"errors"
	"fmt"
	redisV9 "github.com/redis/go-redis/v9"
	"strconv"
)

// LatestAlarmCacheKey <----> key: common_cache, value: {tbCodes};  use set store.
// key: tbCode_eventId <--> {score: alarmId, member: pb.AlarmCheckRspItem} zset

type LatestAlarmCache struct {
	rdsOps redis.SkyFendRedisOps
}

func NewLatestAlarmCache(rds redis.SkyFendRedisOps) *LatestAlarmCache {
	return &LatestAlarmCache{
		rdsOps: rds,
	}
}

func (l *LatestAlarmCache) checkParam() error {
	if l == nil || l.rdsOps == nil {
		return fmt.Errorf("redis handle is nil")
	}
	return nil
}

// GetCacheAlarmItemKey 最新告警记录key cache key
func (l *LatestAlarmCache) GetCacheAlarmItemKey(tbCode string, eventId int64) string {
	return fmt.Sprintf("cache_alarm_latest:%s:%v", tbCode, eventId)
}

// GetTbCodeEventIdKey 产生存储 tbcode 和 eventID 关系存储的key; 一个tbcode 包含多个 最新的 eventId， field 是 eventID.
func (l *LatestAlarmCache) GetTbCodeEventIdKey(tbCode string) string {
	return fmt.Sprintf("cache_alarm_tbCode_eventId:%v", tbCode)
}

// GetAllTbCodeKey 所有 tbcode  key
func (l *LatestAlarmCache) GetAllTbCodeKey() string {
	return "cache_alarm_tbcode:2024:06:16"
}

// UpdateAlarmItem 更新用户在告警事件上的最新告警记录
func (l *LatestAlarmCache) UpdateAlarmItem(tbCode string, eventId int64, alarmItem *pb.AlarmCheckRspItem) {
	if err := l.checkParam(); err != nil {
		logger.Errorf("check param fail: %v", err)
		return
	}

	if tbCode == "" || eventId <= 0 || alarmItem == nil {
		return
	}

	alarmItemStr, err := json.Marshal(alarmItem)
	if err != nil {
		logger.Errorf("marshal to json fail, val: %+v", alarmItem)
		return
	}
	//增加 告警记录缓存 (string)
	key := l.GetCacheAlarmItemKey(tbCode, eventId)
	err = l.rdsOps.SetEx(key, alarmItemStr, 0)
	if err != nil {
		logger.Errorf("add latest alarm to cache fail, key: %v, score: %v, value: %v, err: %v", key, alarmItem.GetId(), alarmItemStr, err)
		return
	}

	//增加 告警 tbcode 和告警事件id 的关系(member is eventID)
	keyEventIdTbCode := l.GetTbCodeEventIdKey(tbCode)
	err = l.rdsOps.SAdd(keyEventIdTbCode, fmt.Sprintf("%d", eventId))
	if err != nil {
		logger.Errorf("add event id to tbcode fail, err: %v, key: %v, eventId: %v", err, keyEventIdTbCode, eventId)
		return
	}

	// 增加 tbcode 缓存 (member is tbCode)
	tbCodeCacheKey := l.GetAllTbCodeKey()
	if err = l.rdsOps.SAdd(tbCodeCacheKey, tbCode); err != nil {
		logger.Errorf("add tbcode: %v to tbcode set fail, err: %v", tbCode, err)
		return
	}
	//logger.Infof("add latest alarm tbCode: %v, eventId: %v, ", tbCode, eventId)
}

// DelAlarmItem 删除告警事件对应的告警;
func (l *LatestAlarmCache) DelAlarmItem(tbCode string, eventId int64) error {
	if err := l.checkParam(); err != nil {
		logger.Errorf("check param fail: %v", err)
		return err
	}

	// 删除 eventID 告警最新记录
	key := l.GetCacheAlarmItemKey(tbCode, eventId)
	if err := l.rdsOps.DeleteKey(key); err != nil {
		logger.Errorf("del key: %v fail: %v", key, err)
		return err
	}
	// 删除 tbcode 和 eventID关系 (member is eventID)
	key = l.GetTbCodeEventIdKey(tbCode)
	l.rdsOps.SRem(key, fmt.Sprintf("%v", eventId))
	return nil
}

// GetAlarmListByTbCode 获取用户的不同告警事件 最新告警; return map key is eventId (获取后删除这些记录)
func (l *LatestAlarmCache) GetAlarmListByTbCode(tbCode string) (map[int64]*pb.AlarmCheckRspItem, error) {
	if err := l.checkParam(); err != nil {
		logger.Errorf("check param fail: %v", err)
		return nil, err
	}
	if tbCode == "" {
		return nil, nil
	}
	// key  (member is eventID)
	tbCodeEventIDKey := l.GetTbCodeEventIdKey(tbCode)
	eventIDs, err := l.rdsOps.SMembers(tbCodeEventIDKey)
	if err != nil {
		logger.Errorf("has not any eventid in tbcode: %v", tbCode)
		return nil, nil
	}
	if len(eventIDs) > 0 {
		logger.Infof("get eventId, rds key: %v, len: %v, eventId list: %v", tbCodeEventIDKey, len(eventIDs), eventIDs)
	}

	var retMap = make(map[int64]*pb.AlarmCheckRspItem)
	for _, eventIdStr := range eventIDs {
		eventId, err := strconv.ParseInt(eventIdStr, 10, 64)
		if err != nil {
			logger.Errorf("parse eventId from string fail, err: %v", err)
			continue
		}

		retMap[eventId] = nil

		alarmItem, err := l.GetLatestAlarmCacheItem(tbCode, eventId)
		if err != nil {
			logger.Errorf("not find tbcode-eventid detail, tbcode: %v, eventid: %v", tbCode, eventId)
			continue
		}
		if alarmItem == nil {
			continue
		}
		retMap[eventId] = alarmItem
	}
	return retMap, nil
}

// GetLatestAlarmCacheItem 获取 tbcode:eventId 最新的的告警记录
func (l *LatestAlarmCache) GetLatestAlarmCacheItem(tbCode string, eventId int64) (*pb.AlarmCheckRspItem, error) {
	key := l.GetCacheAlarmItemKey(tbCode, eventId)
	alarmRet, err := l.rdsOps.Get(key)
	if err != nil {
		if errors.Is(err, redisV9.Nil) {
			return nil, nil
		}

		logger.Infof("not get tbcode-eventid detail fail, key: %v, err: %v", key, err)
		return nil, nil
	}
	alarmStr, ok := alarmRet.(string)
	if !ok || alarmStr == "" {
		logger.Infof("get tbcode-eventid detail is nil, key: %v", key)
		return nil, nil
	}

	var alarmItem pb.AlarmCheckRspItem
	err = json.Unmarshal([]byte(alarmStr), &alarmItem)
	if err != nil {
		logger.Errorf("parse alarm item fail, eventId: %v, alarmitem: %v, err: %v", eventId, alarmStr, err)
		return nil, err
	}
	return &alarmItem, nil
}

// GetLatestAlarmList 获取所有tbcode下的最新告警记录, map[]map[]any 其中第一个 key is tbcode, second key: eventid
func (l *LatestAlarmCache) GetLatestAlarmList() (map[string]map[int64]*pb.AlarmCheckRspItem, error) {
	if err := l.checkParam(); err != nil {
		logger.Errorf("check param fail: %v", err)
		return nil, err
	}

	tbCodeCacheKey := l.GetAllTbCodeKey()
	tbCodes, err := l.rdsOps.SMembers(tbCodeCacheKey)
	if err != nil {
		logger.Errorf("get all tb codes fail, err: %v", err)
		return nil, err
	}
	if len(tbCodes) <= 0 {
		return nil, nil
	}

	var ret = make(map[string]map[int64]*pb.AlarmCheckRspItem)
	for _, tbCode := range tbCodes {
		if tbCode == "" {
			continue
		}

		items, err := l.GetAlarmListByTbCode(tbCode)
		if err != nil {
			logger.Errorf("err: %v", err)
			continue
		}
		if items == nil {
			continue
		}
		ret[tbCode] = items
	}
	return ret, nil
}
