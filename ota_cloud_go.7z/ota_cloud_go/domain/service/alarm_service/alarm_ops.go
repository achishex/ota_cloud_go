package alarm_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/db"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"strconv"
	"time"
)

type AlarmOps struct {
	alarmDbOps db.DbOpsTplInterface[bean.FendAreaAlarm]
}

// NewAlarmOps 创建对象
func NewAlarmOps(alarmDbOps db.DbOpsTplInterface[bean.FendAreaAlarm]) *AlarmOps {
	return &AlarmOps{alarmDbOps: alarmDbOps}
}

func (a *AlarmOps) QueryUnReadList(tbCode string, beginTm, endTm int64) ([]*pb.AlarmCheckRspItem, error) {
	if tbCode == "" || endTm <= 0 || beginTm >= endTm {
		logger.Error("query alarm un read list fail, begin time: %v, end time: %v, tb_code: %v", beginTm, endTm, tbCode)
		return nil, fmt.Errorf("param invalid")
	}

	if a.alarmDbOps == nil {
		logger.Errorf("alarm record db handle not init, tbcode: %v", tbCode)
		return nil, nil
	}
	bTm := time.UnixMilli(beginTm)
	eTm := time.UnixMilli(endTm)
	whereCond := "tb_code = ? and create_time >= ? and create_time < ? and status = ?"
	whereValue := []any{tbCode, bTm, eTm, 0} // 0: 未处理， 1:手动处理，2：侦测消失事件处理 3：告警侦测降为0

	orderAsc := make(map[string]bool)
	orderAsc["create_time"] = false
	alarmItems, err := a.alarmDbOps.QueryItemOnCond(whereCond, whereValue, orderAsc, 0, 100)
	if err != nil {
		logger.Errorf("query alarm record fail, err: %v, tbCode: %v", err, tbCode)
		return nil, errors.New("query alarm record fail")
	}

	var retData []*pb.AlarmCheckRspItem
	for _, v := range alarmItems {
		if v == nil {
			continue
		}
		retData = append(retData, &pb.AlarmCheckRspItem{
			// 告警id(每次告警不同)
			Id: v.ID,
			// 无人机唯一标识
			Sn:    v.DevSn,
			ObjId: v.ObjID,
			// 风险等级： 1: low, 2: middle, 3: high
			RiskLevel: v.RiskLevel,
			// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
			ThreatLevel: v.ThreatLevel,
			// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
			EventId: v.EventId,
			// 租户id
			TbCode: v.TbCode,
			// 设备名字
			DevName: v.DevName,
			// 告警的时间点（毫秒）
			CreateTime: v.CreateTime.UnixMilli(),
			// 一次 相同eventID的告警持续时间（毫秒）
			DurTime: v.DurTime,
		})
	}
	return retData, nil
}

func (a *AlarmOps) QueryUnReadLatestList(tbCode string, beginTm, endTm int64) ([]*pb.AlarmCheckRspItem, error) {
	if tbCode == "" || endTm <= 0 || beginTm >= endTm {
		logger.Error("query alarm un read list fail, begin time: %v, end time: %v, tb_code: %v", beginTm, endTm, tbCode)
		return nil, fmt.Errorf("param invalid")
	}

	if a.alarmDbOps == nil {
		logger.Errorf("alarm record db handle not init, tbcode: %v", tbCode)
		return nil, nil
	}
	bTm := time.UnixMilli(beginTm)
	eTm := time.UnixMilli(endTm)

	whereCond := `SELECT  i.* FROM t_fenced_area_alarm  i JOIN (
    SELECT event_id , MAX(create_time) AS max_create_time FROM
        t_fenced_area_alarm  where tb_code = ? and create_time >= ? and create_time < ? and status = ?
    GROUP BY  event_id  ) m ON i.event_id  = m.event_id AND i.create_time = m.max_create_time ORDER BY
    i.create_time  desc limit ?;`

	whereValue := []any{tbCode, bTm, eTm, 0, 30}
	alarmItems, err := a.alarmDbOps.RawQueryRun(whereCond, whereValue)
	if err != nil {
		logger.Errorf("query alarm record fail, err: %v, tbCode: %v", err, tbCode)
		return nil, errors.New("query alarm record fail")
	}

	var retData []*pb.AlarmCheckRspItem
	for _, v := range alarmItems {
		if v == nil {
			continue
		}
		retData = append(retData, &pb.AlarmCheckRspItem{
			// 告警id(每次告警不同)
			Id: v.ID,
			// 无人机唯一标识
			Sn:    v.DevSn,
			ObjId: v.ObjID,
			// 风险等级： 1: low, 2: middle, 3: high
			RiskLevel: v.RiskLevel,
			// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
			ThreatLevel: v.ThreatLevel,
			// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
			EventId: v.EventId,
			// 租户id
			TbCode: v.TbCode,
			// 设备名字
			DevName: v.DevName,
			// 告警的时间点（毫秒）
			CreateTime: v.CreateTime.UnixMilli(),
			// 一次 相同eventID的告警持续时间（毫秒）
			DurTime: v.DurTime,
		})
	}
	return retData, nil
}

// UpdateStatusToDealed 更新告警处理状态
func (a *AlarmOps) UpdateStatusToDealed(items []*pb.AlarmStatusUpdateItem) ([]*pb.AlarmStatusUpdateRet, error) {
	if a.alarmDbOps == nil {
		logger.Errorf("db not init")
		return nil, fmt.Errorf("db not init")
	}
	var ret []*pb.AlarmStatusUpdateRet

	for _, item := range items {
		if item == nil {
			continue
		}
		if item.GetId() == "" {
			continue
		}

		id, err := strconv.ParseInt(item.GetId(), 10, 64)
		if err != nil {
			logger.Errorf("parse id from str to int fail, e: %v", item.GetId())
			continue
		}
		updateRet := &pb.AlarmStatusUpdateRet{
			Id:        item.GetId(),
			UpdateRet: 0,
		}
		ret = append(ret, updateRet)
		if item.GetStatus() == 0 {
			logger.Infof("request alarm record status is 0, not need to update.")
			ret[len(ret)-1].UpdateRet = 1
			continue
		}

		whereStr := "id=? and status=?"
		whereVal := []any{id, 0}

		fieldName := "status"
		fieldValue := item.GetStatus()
		retNum, e := a.alarmDbOps.UpdateItems(whereStr, whereVal, fieldName, fieldValue)
		if e != nil {
			ret[len(ret)-1].UpdateRet = 1
			continue
		} else {
			logger.Infof("update status to : %v, nums: %v", item.GetStatus(), retNum)
		}
	}
	return ret, nil
}

// DeleteExpireHistory 删除参数second 之前的高级记录
func (a *AlarmOps) DeleteExpireHistory(tmSecond int64) error {
	if tmSecond <= 0 {
		return fmt.Errorf("history second is nil")
	}

	if a.alarmDbOps == nil {
		return fmt.Errorf("alarm db handle is nil")
	}

	whereCond := "create_time <= ?"
	nowTime := time.Now().UTC().UnixMilli() / 1000
	historySecond := nowTime - tmSecond
	historyTime := time.UnixMilli(historySecond * 1000).UTC()

	logger.Infof("history begin time: %+v", historyTime)

	whereVal := []any{historyTime}
	if err := a.alarmDbOps.DelItems(whereCond, whereVal); err != nil {
		logger.Errorf("delete alarm item fail, err: %v", err)
	} else {
		logger.Infof("delete alarm items success.")
	}
	return nil
}

func (a *AlarmOps) QueryAlarmChangePointByTrackId(trackId, tbCode string) (error, []*bean.FendAreaAlarm) {
	if a == nil {
		return fmt.Errorf("alarm ops is nil"), nil
	}

	if a.alarmDbOps == nil {
		logger.Errorf("fenced area alarm db handle is nil")
		return fmt.Errorf("fenced area alarm db is nil"), nil
	}

	whereCond := `SELECT
   id, tb_code, risk_level,  create_time, update_time, status,
   area_id, alarm_type, longitude, latitude, area_name, devrelations, track_id
FROM (
    SELECT
      id, tb_code,  risk_level,  create_time, update_time, status,  area_id,  alarm_type, longitude, latitude, area_name, devrelations,
      track_id, LAG(risk_level) OVER (ORDER BY id asc)  AS prev_value
    FROM
        t_fenced_area_alarm where track_id = ? and tb_code = ?
) subquery
WHERE risk_level <> prev_value OR prev_value IS NULL;`

	whereValue := []any{trackId, tbCode}

	alarmItems, err := a.alarmDbOps.RawQueryRun(whereCond, whereValue)
	if err != nil {
		logger.Errorf("query alarm items fail, err: %v, trackId: %v, tbCode: %v", err, trackId, tbCode)
		return err, nil
	}
	return nil, alarmItems
}

func (a *AlarmOps) QueryAlarmByTrackId(trackId string, tbCode string) (error, []*bean.FendAreaAlarm) {
	if trackId == "" || tbCode == "" {
		return fmt.Errorf("trackid or tbcode is nil"), nil
	}

	whereCond := `select inbound_area_ids from t_fenced_area_alarm where track_id = ? and tb_code = ?`
	whereValue := []any{trackId, tbCode}
	items, err := a.alarmDbOps.RawQueryRun(whereCond, whereValue)
	if err != nil {
		logger.Errorf("query inbound_area_ids fail, err: %v", err)
		return err, nil
	}
	return nil, items
}

// QueryAlarmDetails 查询告警详情
func (a *AlarmOps) QueryAlarmDetails(ids []int64) (error, []*bean.FendAreaAlarm) {
	if a.alarmDbOps == nil {
		logger.Errorf("alarm db handle is nil")
		return fmt.Errorf("alarm db handle is nil"), nil
	}

	ret, err := a.alarmDbOps.QueryItems(ids)
	if err != nil {
		logger.Errorf("query alarm detail list fail, ids: %v, err: %v", ids, err)
		return err, nil
	}
	return nil, ret
}
