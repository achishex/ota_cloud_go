package alarm_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/mq"
	"cuav-cloud-go-service/domain/repository/redis"
	"gorm.io/gorm"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/Shopify/sarama"
)

// ResFendAreaRedis 定义一个 redis 操作围栏区句柄
var (
	ResFendAreaRedis redis.SkyFendRedisOps = nil
	//
	ResAlarmRecordRedis redis.SkyFendRedisOps = nil

	// ResFendAreaDB 定义一个围栏区表句柄
	ResFendAreaDB db.DbOpsTplInterface[bean.FencedAreaConfig] = nil

	// ResAlarmDB 定义一个告警记录表句柄
	ResAlarmDB db.DbOpsTplInterface[bean.FendAreaAlarm] = nil

	// ResUavRecordmDB 定义一个无人机事件句柄
	ResUavRecordmDB        db.UavRecordDBOps       = nil
	UavRecordDBHandler     *db.UavRecordDBImpl     = nil
	UavEventImageDBHandler *db.UavEventImageDBImpl = nil

	// AlarmRecordMQPubHandler 定义一个全局的消息发布对象（用于告警记录发布）
	AlarmRecordMQPubHandler mq.MessagePublisher = nil

	// 告警状态变更通知发布器
	alarmStatusModifyPubHandler mq.MessagePublisher = nil

	// alarmRecordMQConsumer 定义一个全局的消息消费对象 （用于告警记录消费）
	alarmRecordMQConsumer mq.MessageConsumer = nil

	// alarmRecordMQConsumerHandler 消息队列消费者的消息处理对象
	alarmRecordMQConsumerHandler mq.MessageHandler = nil
)

// InitRedis 创建 redis 句柄
func InitRedis() {
	ResFendAreaRedis = config.GlobalRedis
	ResAlarmRecordRedis = ResFendAreaRedis
}

// MockAlarmDB 告警 db 测试专用
func MockAlarmDB(dbHandle *gorm.DB) {
	ResAlarmDB = db.NewDBModelTplWrapper[bean.FendAreaAlarm](dbHandle).SetTabName(bean.FendAreaAlarm{}.TableName())
}

// MockUavRecordDB only 测试使用
func MockUavRecordDB(dbHandle *gorm.DB) db.UavRecordDBOps {
	ResUavRecordmDB = db.NewUavRecordDBImpl(dbHandle)
	return ResUavRecordmDB
}

// MockUavEventImageDb only 测试使用
func MockUavEventImageDb(dbHandle *gorm.DB) *db.UavEventImageDBImpl {
	UavEventImageDBHandler = db.NewEventImageRecordDBHandler(dbHandle)
	return UavEventImageDBHandler
}

// InitDB 创建 db 句柄
func InitDB() {
	// 围栏区数据db 访问接口
	ResFendAreaDB = db.NewDBModelTplWrapper[bean.FencedAreaConfig](config.GetDB()).SetTabName(bean.FencedAreaConfig{}.TableName())
	// 告警记录db 访问接口
	ResAlarmDB = db.NewDBModelTplWrapper[bean.FendAreaAlarm](config.GetDB()).SetTabName(bean.FendAreaAlarm{}.TableName())
	//
	ResUavRecordmDB = db.NewUavRecordDBImpl(config.GetDB())
	//
	alarmRecordMQConsumerHandler = NewAlarmRecordHandler(ResAlarmDB)
	UavRecordDBHandler = db.NewUavRecordDBHandler(config.GetDB())

	UavEventImageDBHandler = db.NewEventImageRecordDBHandler(config.GetDB())
}

// InitMsgPublisher 初始化消息队列发布
func InitMsgPublisher() {
	logger.Info("Kafka ip addr:", config.GetConfig().Kafka.BootStrapServers)
	bootstrapServers := strings.Split(config.GetConfig().Kafka.BootStrapServers, ",")

	AlarmRecordMQPubHandler = mq.NewKafkaPublisher(bootstrapServers,
		mq.WithProducerReturn(true),
		mq.WithProducerRequireAcks(int(sarama.WaitForAll)),
		mq.WithProducerPartitions(sarama.NewHashPartitioner))

	if AlarmRecordMQPubHandler == nil {
		logger.Errorf("new kafka publisher client fail")
	}
	//
	alarmStatusModifyPubHandler = mq.NewKafkaPublisher(bootstrapServers,
		mq.WithProducerReturn(true),
		mq.WithProducerRequireAcks(int(sarama.WaitForAll)),
		mq.WithProducerPartitions(sarama.NewRandomPartitioner))
	if alarmStatusModifyPubHandler == nil {
		logger.Errorf("new kafka aram status modify pub fail")
	}
}

// InitMsgConsumer 初始化消息消费对象
func InitMsgConsumer(ctx context.Context) {
	logger.Info("Kafka ip addr:", config.GetConfig().Kafka.BootStrapServers)
	bootstrapServers := strings.Split(config.GetConfig().Kafka.BootStrapServers, ",")
	c, e := mq.NewKafkaConsumer(bootstrapServers, config.GetConfig().Kafka.Consumer.AlarmGroupID,
		mq.WithConsumerReturnError(true), mq.WithConsumerOffset(sarama.OffsetOldest))
	if e != nil {
		logger.Errorf("create consumer for alarm fail, err: %v", e)
		return
	}
	if c == nil {
		logger.Errorf("create consumer for alarm record async write nil")
		return
	}
	alarmRecordMQConsumer = c

	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("panic run consume fail, e:%v", e)
			}
		}()

		alarmRecordMQConsumer.Consume(ctx, config.GetConfig().Kafka.AlarmAsyncWriteTopic, alarmRecordMQConsumerHandler)
	}()
}

func InitRes(ctx context.Context) {
	InitRedis()
	InitDB()
	//
	InitMsgPublisher()
	InitMsgConsumer(ctx)
}
