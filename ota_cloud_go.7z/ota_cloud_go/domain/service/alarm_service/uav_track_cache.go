package alarm_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/redis"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"time"
)

type UavDetectCache struct {
	rds            redis.SkyFendRedisOps
	expireTmSecond int64
}

func NewUavDetectCache(rdsHandle redis.SkyFendRedisOps) *UavDetectCache {
	ret := &UavDetectCache{
		expireTmSecond: 10,
	}

	if rdsHandle == nil {
		ret.rds = config.GlobalRedis
	} else {
		ret.rds = rdsHandle
	}

	return ret
}

// GetUavDetailWithTrackIdCacheKey 获取trackId关联的无人机详情缓存信息 key
func GetUavDetailWithTrackIdCacheKey(tbCode, trackId string) string {
	if tbCode == "" || trackId == "" {
		return ""
	}
	return fmt.Sprintf("cloud:uav_detail:key:%v:%v", tbCode, trackId)
}
func (uc *UavDetectCache) StoreUavDetectDetail(tbCode, trackId string, details *pb.DevLocationInfo) error {
	if uc == nil || uc.rds == nil || tbCode == "" || trackId == "" || details == nil {
		logger.Errorf("redis handle is nil or input param tbCode: %v or trackId: %v or uavDetail: %v is nil", trackId, trackId, details)
		return nil
	}

	rdsKey := GetUavDetailWithTrackIdCacheKey(tbCode, trackId)
	if rdsKey == "" {
		logger.Errorf("uav detail cache key is empty")
		return nil
	}

	uavDetailJson, err := json.Marshal(details)
	if err != nil {
		logger.Errorf("marshal data fail, err: %v", err)
		return nil
	}

	uc.rds.SetEx(rdsKey, uavDetailJson, time.Duration(uc.expireTmSecond)*time.Second)
	return nil
}
