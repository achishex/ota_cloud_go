package alarm_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/infra/utils/logs"
	pb "cuav-cloud-go-service/proto"
	"reflect"
	"testing"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/paulmach/orb"
)

func TestGenUniqueId(t *testing.T) {
	tRedisHandle := redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
		redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))

	alarmHandle := &AlarmStrategy{
		fendAreaAlarmProcess: make(map[int]FendAreaAlarmProcessor),
		redisFendAreaOps:     tRedisHandle, // fendArea redis op
		dbFendAreaOps:        nil,          // fend area db op
		alarmRecordPub:       nil,
	}
	for i := 0; i < 10; i++ {
		//
		{
			sn, objId, detectSn := "", "41780", "sfagx-1424823004236"
			devId := GetDevUnique(sn, objId, detectSn)
			tbCode := "000003"
			key := getUavUniqueID(tbCode, devId)
			alarmEventID, expireTm, err := alarmHandle.genAlarmEventIDImpl(key)
			t.Logf("k: %v, alarmID: %v, %v, %v", key, alarmEventID, expireTm, err)
		}

		{
			sn, objId, detectSn := "", "41781", "sfagx-1424823004236"
			devId := GetDevUnique(sn, objId, detectSn)
			tbCode := "000003"
			key := getUavUniqueID(tbCode, devId)
			alarmEventID, expireTm, err := alarmHandle.genAlarmEventIDImpl(key)
			t.Logf("k: %v, alarmID: %v, %v, %v", key, alarmEventID, expireTm, err)
		}

		{
			sn, objId, detectSn := "", "41782", "sfagx-1424823004236"
			devId := GetDevUnique(sn, objId, detectSn)
			tbCode := "000003"
			key := getUavUniqueID(tbCode, devId)
			alarmEventID, expireTm, err := alarmHandle.genAlarmEventIDImpl(key)
			t.Logf("k: %v, alarmID: %v, %v, %v", key, alarmEventID, expireTm, err)
		}
		time.Sleep(300 * time.Millisecond)
		t.Logf("----------------------")
	}

}

func TestParseAndCheckArea(t *testing.T) {
	mock.LoggerMock()

	srcData := `{
	"type": "Feature",
	"geometry": {
		"type": "MultiPolygon",
		"coordinates": [
			[
				[
					[113.9110152268387, 22.639972391718725],
					[113.91260558906173, 22.640520235918228],
					[113.91157562080001, 22.640837101240088],
					[113.9110152268387, 22.639972391718725]
				]
			],
			[
				[
					[113.88960296455004, 22.606928368461467],
					[113.91535217109298, 22.632123038592216],
					[113.90592844279183, 22.632123038592216],
					[113.88960296455004, 22.606928368461467]
				]
			],
			[
				[
					[113.88822967353441, 22.632123038592216],
					[113.90592844279183, 22.632123038592216],
					[113.9110152268387, 22.639972391718725],
					[113.88822967353441, 22.632123038592216]
				]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [106, 0, 108, 13],
		"outline": {
			"type": "esriSLS",
			"color": [106, 0, 108, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	//
	area1, e := geo.ParseGeoJsonToPolygons(srcData)
	if e != nil {
		t.Logf("parse geojson fail, e: %v", e)
	} else {
		t.Logf("parse geojson, data: %v", area1)
	}

	for i1, _ := range area1 { // []orb.Polygon
		var onePolygon orb.Polygon
		onePolygon = area1[i1]

		for i2, _ := range onePolygon { //  []Ring
			var oneRing orb.Ring
			oneRing = onePolygon[i2]

			for i3, _ := range oneRing { //  []Point
				var onePoint orb.Point
				onePoint = oneRing[i3]
				t.Logf("1: %v, 2: %v", onePoint[0], onePoint[1])
			}
		}

	}
}

func TestParseAndCheckArea2(t *testing.T) {
	mock.LoggerMock()

	srcData := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[113.93753227996856, 22.603279745271383],
				[113.93512902069122, 22.60121954496328],
				[113.94251045990019, 22.59995171406089],
				[113.94268212127714, 22.603121269419525],
				[113.93753227996856, 22.603279745271383]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [210, 210, 122, 13],
		"outline": {
			"type": "esriSLS",
			"color": [210, 210, 122, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`

	area1, e := geo.ParseGeoJsonToPolygons(srcData)
	if e != nil {
		t.Logf("parse geojson fail, e: %v", e)
	} else {
		t.Logf("parse geojson, data: %v", area1)
	}

	for i1, _ := range area1 { // []orb.Polygon
		var onePolygon orb.Polygon
		onePolygon = area1[i1]

		for i2, _ := range onePolygon { //  []Ring
			var oneRing orb.Ring
			oneRing = onePolygon[i2]

			for i3, _ := range oneRing { //  []Point
				var onePoint orb.Point
				onePoint = oneRing[i3]
				t.Logf("1: %v, 2: %v", onePoint[0], onePoint[1])
			}
		}
	}
}

// TestCheckCoreInPreArea 检查核心区完全包含在预警区内
func TestCheckCoreInPreArea(t *testing.T) {
	mock.LoggerMock()
	preArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[114.02935910014624, 22.63367309690986],
				[113.98266720561506, 22.608637180494515],
				[113.98541378764631, 22.572501371652063],
				[114.09562039165006, 22.617194272246667],
				[114.02935910014624, 22.63367309690986]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [210, 210, 122, 13],
		"outline": {
			"type": "esriSLS",
			"color": [210, 210, 122, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	preAreaPolygon, e := geo.ParseGeoJsonToPolygons(preArea)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
		return
	}

	coreArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[114.02008938579078, 22.61117267058191],
				[114.01905941752908, 22.58961951573258],
				[114.04549526957982, 22.61053880244085],
				[114.02008938579078, 22.61117267058191]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [106, 0, 108, 13],
		"outline": {
			"type": "esriSLS",
			"color": [106, 0, 108, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	coreAreaPolygon, e := geo.ParseGeoJsonToPolygons(coreArea)
	if e != nil {
		t.Logf("parse core area fail, e: %v", e)
		return
	}

	e, exist := checkOverLapWithinAreas([]*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: coreAreaPolygon,
		},
	}, []*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: preAreaPolygon,
		},
	})
	if e != nil {
		t.Logf("check in area fail, e: %v", e)
		return
	} else if exist {
		t.Logf("core in pre area, exist: %v", exist)
	} else {
		t.Logf("core not in pre area")
	}
}

// 测试不交叉
func TestCheckCoreNotInPreArea(t *testing.T) {
	mock.LoggerMock()
	preArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[113.95829129008774, 22.694500862700618],
				[113.93460202006824, 22.677395779536376],
				[113.9555447080565, 22.657437152106944],
				[114.01562618999002, 22.65395201469081],
				[114.01631283549783, 22.695767820971078],
				[113.95829129008774, 22.694500862700618]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [148, 202, 132, 13],
		"outline": {
			"type": "esriSLS",
			"color": [148, 202, 132, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	preAreaPolygon, e := geo.ParseGeoJsonToPolygons(preArea)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
		return
	}

	coreArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[114.07335579804673, 22.70982216836655],
				[114.05069649628896, 22.70000394276605],
				[114.05103981904287, 22.667693846782253],
				[114.10013497285141, 22.665793015784363],
				[114.10734475068341, 22.697470092863224],
				[114.07335579804673, 22.70982216836655]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [228, 101, 107, 13],
		"outline": {
			"type": "esriSLS",
			"color": [228, 101, 107, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	coreAreaPolygon, e := geo.ParseGeoJsonToPolygons(coreArea)
	if e != nil {
		t.Logf("parse core area fail, e: %v", e)
		return
	}

	e, exist := checkOverLapWithinAreas([]*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: coreAreaPolygon,
		},
	}, []*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: preAreaPolygon,
		},
	})
	if e != nil {
		t.Logf("check in area fail, e: %v", e)
		return
	} else if exist {
		t.Logf("core in pre area, exist: %v", exist)
	} else {
		t.Logf("core not in pre area")
	}
}

// 测试有交叉
func TestCheckCoreCrossPreArea(t *testing.T) {
	mock.LoggerMock()
	preArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[114.17427779248028, 22.689953422728838],
				[114.16432143261702, 22.681717635137034],
				[114.16981459667952, 22.665878191513094],
				[114.2103266816404, 22.650036919040748],
				[114.2213130097654, 22.68266794357527],
				[114.17427779248028, 22.689953422728838]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [106, 0, 108, 13],
		"outline": {
			"type": "esriSLS",
			"color": [106, 0, 108, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	preAreaPolygon, e := geo.ParseGeoJsonToPolygons(preArea)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
		return
	}

	coreArea := `{
	"type": "Feature",
	"geometry": {
		"type": "Polygon",
		"coordinates": [
			[
				[114.20483351757791, 22.66429414654755],
				[114.18251753857402, 22.646551593764652],
				[114.20620680859354, 22.63387693807631],
				[114.20483351757791, 22.66429414654755]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [228, 101, 107, 13],
		"outline": {
			"type": "esriSLS",
			"color": [228, 101, 107, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	coreAreaPolygon, e := geo.ParseGeoJsonToPolygons(coreArea)
	if e != nil {
		t.Logf("parse core area fail, e: %v", e)
		return
	}

	e, exist := checkOverLapWithinAreas([]*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: coreAreaPolygon,
		},
	}, []*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: preAreaPolygon,
		},
	})
	if e != nil {
		t.Logf("check in area fail, e: %v", e)
		return
	} else if exist {
		t.Logf("core in pre area, exist: %v", exist)
	} else {
		t.Logf("core not in pre area")
	}
}

// 测试多边形不交叉
func TestCheckCoreNotCrossPreArea(t *testing.T) {
	mock.LoggerMock()
	preArea := `{
	"type": "Feature",
	"geometry": {
		"type": "MultiPolygon",
		"coordinates": [
			[
				[
					[114.13616896679675, 22.599966488681755],
					[114.15224670713158, 22.57355018236882],
					[114.22234297802711, 22.60313604370015],
					[114.13616896679675, 22.599966488681755]
				]
			],
			[
				[
					[114.17977095654278, 22.528315096402526],
					[114.15224670713158, 22.57355018236882],
					[114.09016371777336, 22.547341219475808],
					[114.17977095654278, 22.528315096402526]
				]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [210, 210, 122, 13],
		"outline": {
			"type": "esriSLS",
			"color": [210, 210, 122, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	preAreaPolygon, e := geo.ParseGeoJsonToPolygons(preArea)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
		return
	}

	coreArea := `{
	"type": "Feature",
	"geometry": {
		"type": "MultiPolygon",
		"coordinates": [
			[
				[
					[114.20826674511696, 22.557804469330858],
					[114.23332930615207, 22.563194318622667],
					[114.220570625364, 22.571804039873243],
					[114.20826674511696, 22.557804469330858]
				]
			],
			[
				[
					[114.220570625364, 22.571804039873243],
					[114.22749281933568, 22.579679608564952],
					[114.20655013134744, 22.581264628681943],
					[114.220570625364, 22.571804039873243]
				]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [106, 0, 108, 13],
		"outline": {
			"type": "esriSLS",
			"color": [106, 0, 108, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	coreAreaPolygon, e := geo.ParseGeoJsonToPolygons(coreArea)
	if e != nil {
		t.Logf("parse core area fail, e: %v", e)
		return
	}

	e, exist := checkOverLapWithinAreas([]*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: coreAreaPolygon,
		},
	}, []*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: preAreaPolygon,
		},
	})
	if e != nil {
		t.Logf("check in area fail, e: %v", e)
		return
	} else if exist {
		t.Logf("core in pre area, exist: %v", exist)
	} else {
		t.Logf("core not in pre area")
	}
}

// 测试多边形有交叉
func TestCheckCoreCorePreAreaMore(t *testing.T) {
	mock.LoggerMock()
	preArea := `{
	"type": "Feature",
	"geometry": {
		"type": "MultiPolygon",
		"coordinates": [
			[
				[
					[113.86425734570338, 22.726691673896543],
					[113.90999328958291, 22.728198270007642],
					[113.92296553662126, 22.75328907799121],
					[113.86425734570338, 22.726691673896543]
				]
			],
			[
				[
					[113.87352706005882, 22.657640958004542],
					[113.93154860546889, 22.728908321866058],
					[113.90999328958291, 22.728198270007642],
					[113.87352706005882, 22.657640958004542]
				]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [210, 210, 122, 13],
		"outline": {
			"type": "esriSLS",
			"color": [210, 210, 122, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	preAreaPolygon, e := geo.ParseGeoJsonToPolygons(preArea)
	if e != nil {
		t.Logf("parse fail, e: %v", e)
		return
	}

	coreArea := `{
	"type": "Feature",
	"geometry": {
		"type": "MultiPolygon",
		"coordinates": [
			[
				[
					[113.91111687113171, 22.702629480335844],
					[113.90339613964862, 22.671897395582693],
					[113.92536879589859, 22.702306176076586],
					[113.91111687113171, 22.702629480335844]
				]
			],
			[
				[
					[113.91111687113171, 22.702629480335844],
					[113.91541243603534, 22.719724832154856],
					[113.88348341992209, 22.70325634173374],
					[113.91111687113171, 22.702629480335844]
				]
			]
		]
	},
	"properties": {
		"type": "esriSFS",
		"color": [106, 0, 108, 13],
		"outline": {
			"type": "esriSLS",
			"color": [106, 0, 108, 153],
			"width": 2,
			"style": "esriSLSSolid"
		},
		"style": "esriSFSSolid"
	}
}`
	coreAreaPolygon, e := geo.ParseGeoJsonToPolygons(coreArea)
	if e != nil {
		t.Logf("parse core area fail, e: %v", e)
		return
	}

	e, exist := checkOverLapWithinAreas([]*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: coreAreaPolygon,
		},
	}, []*geo.PolygonUnionList{
		&geo.PolygonUnionList{
			PolygonListItems: preAreaPolygon,
		},
	})
	if e != nil {
		t.Logf("check in area fail, e: %v", e)
		return
	} else if exist {
		t.Logf("core in pre area, exist: %v", exist)
	} else {
		t.Logf("core not in pre area")
	}
}

// TestTransParamToFendArea check with cross pre and core alarm area.
func TestTransParamToFendArea(t *testing.T) {
	mock.LoggerMock()

	tbCode := "000001"
	c2LonLat := map[string]*pb.C2LocationInfo{
		"0000000000": &pb.C2LocationInfo{
			Longitude: 114.0245083,
			Latitude:  22.597,
			Sn:        "0000000000",
		},
	}
	//
	uavItems := []*pb.DevLocationInfo{
		&pb.DevLocationInfo{
			Longitude:      114.02722176207851,
			Latitude:       22.596999999998935,
			Sn:             "sfl200uav0",
			C2Sn:           "0000000000",
			Name:           "DJI Air SFL2000",
			DetectDevSn:    "sfl200-0",
			UniqueId:       1289368957772759058,
			PilotLongitude: 113.998005,
			PilotLatitude:  22.597002,
			HomeLongitude:  113.998,
			HomeLatitude:   22.597,
		},
	}
	fenceAreaList := []*bean.FencedAreaConfig{
		&bean.FencedAreaConfig{
			ID:                1288729264091430917,
			TbCode:            "000001",
			AreaName:          "55555",
			AreaType:          1,
			AreaPerimeter:     18.4100000,
			AreaSquare:        15549766.0800000,
			CentroidLongitude: 113.9273327,
			CentroidLatitude:  22.5934803,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.91577420043949,22.62570223800276],[113.91045269775394,22.573720843303004],[113.9557713012695,22.581012100173965],[113.91577420043949,22.62570223800276]]]},"properties":{"type":"esriSFS","color":[148,202,132,0.05],"outline":{"type":"esriSLS","color":[148,202,132,0.6],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720097264597,
			UpdateTime:        1720097617210,
			DeleteTime:        0,
		},
		&bean.FencedAreaConfig{
			ID:                1288937131891097612,
			TbCode:            "000001",
			AreaName:          "4444",
			AreaType:          1,
			AreaPerimeter:     22.4700000,
			AreaSquare:        22380883.5300000,
			CentroidLongitude: 113.9510498,
			CentroidLatitude:  22.5086967,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.93285366049457,22.54865420630372],[113.93491359701801,22.48300363198295],[113.98538204184216,22.49442336260127],[113.93285366049457,22.54865420630372]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720145662934,
			UpdateTime:        1720145662934,
			DeleteTime:        0,
		},
		&bean.FencedAreaConfig{
			ID:                1288964181595127808,
			TbCode:            "000001",
			AreaName:          "预警区11",
			AreaType:          1,
			AreaPerimeter:     13.2400000,
			AreaSquare:        11110653.5000000,
			CentroidLongitude: 114.0233029,
			CentroidLatitude:  22.5943785,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[114.00477368715823,22.603816115512295],[114.00494534853519,22.582578808335768],[114.0355010736328,22.582578808335768],[114.04288251284177,22.593118627671647],[114.04236752871093,22.606034749629167],[114.01927907351076,22.605717804088208],[114.00477368715823,22.603816115512295]]]},"properties":{"type":"esriSFS","color":[116,181,216,13],"outline":{"type":"esriSLS","color":[116,181,216,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720151960849,
			UpdateTime:        1720152318343,
			DeleteTime:        0,
		},
		&bean.FencedAreaConfig{
			ID:                1288964254609571840,
			TbCode:            "000001",
			AreaName:          "核心区1",
			AreaType:          2,
			AreaPerimeter:     2.4900000,
			AreaSquare:        409782.1500000,
			CentroidLongitude: 114.0266367,
			CentroidLatitude:  22.5964578,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[114.02376075396728,22.59826588584406],[114.02393241534423,22.593788709716577],[114.02938266406264,22.593709466349942],[114.02981181750502,22.59802816333835],[114.0253057063599,22.59992993188895],[114.02376075396728,22.59826588584406]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720151977367,
			UpdateTime:        1720152351665,
			DeleteTime:        0,
		},
	}

	in := NewAlarmCheckInParam(tbCode, c2LonLat, uavItems, fenceAreaList)
	areaCheckParam := NewCfgFendAreaCheckParams()
	tranInParamsToCfgFendArea(in, areaCheckParam)

	t.Logf("fence area check params: %+v", areaCheckParam)
	for k, v := range areaCheckParam.fendAreaLonLat {
		t.Logf("k: %v, v: %+v", k, *v)
	}

	strategyHandle := NewAlarmStrategy(nil, nil, nil)
	strategyHandle.(*AlarmStrategy).RegisterUniqueAlarmEventId(func(s string) (int64, int64, error) {
		t.Logf("mock gen alarm id.")
		return 1, 100, nil
	})
	strategyHandle.(*AlarmStrategy).RegisterAsyncWriteAlarm(func(item *AlarmRecord) error {
		if item != nil {
			t.Logf("write item value: %v", *item)
		}
		t.Logf("mock async write alarm done.")
		return nil
	})
	strategyHandle.(*AlarmStrategy).RegisterFilterAlarmResponse(func(item []*pb.AlarmCheckRspItem) []*pb.AlarmCheckRspItem {
		t.Logf("mock filter alarm response.")
		return item
	})
	//
	strategyHandle.Check(in)
}

// TestCheckWithNOCrossArea check with no cross pre and core alarm area.
func TestCheckWithNOCrossArea(t *testing.T) {
	mock.LoggerMock()

	tbCode := "000001"
	c2LonLat := map[string]*pb.C2LocationInfo{
		"0000000000": &pb.C2LocationInfo{
			Longitude: 114.0245083,
			Latitude:  22.597,
			Sn:        "0000000000",
		},
	}
	//
	uavItems := []*pb.DevLocationInfo{
		&pb.DevLocationInfo{
			Longitude:      114.02722176207851,
			Latitude:       22.596999999998935,
			Sn:             "sfl200uav0",
			C2Sn:           "0000000000",
			Name:           "DJI Air SFL2000",
			DetectDevSn:    "sfl200-0",
			UniqueId:       1289368957772759058,
			PilotLongitude: 113.998005,
			PilotLatitude:  22.597002,
			HomeLongitude:  113.998,
			HomeLatitude:   22.597,
		},
	}

	fenceAreaList := []*bean.FencedAreaConfig{
		&bean.FencedAreaConfig{
			ID:                1288937131891097612,
			TbCode:            "000001",
			AreaName:          "4444",
			AreaType:          1,
			AreaPerimeter:     22.4700000,
			AreaSquare:        22380883.5300000,
			CentroidLongitude: 113.9510498,
			CentroidLatitude:  22.5086967,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.93285366049457,22.54865420630372],[113.93491359701801,22.48300363198295],[113.98538204184216,22.49442336260127],[113.93285366049457,22.54865420630372]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720145662934,
			UpdateTime:        1720145662934,
			DeleteTime:        0,
		},
		&bean.FencedAreaConfig{
			ID:                1288964181595127808,
			TbCode:            "000001",
			AreaName:          "预警区11",
			AreaType:          1,
			AreaPerimeter:     13.2400000,
			AreaSquare:        11110653.5000000,
			CentroidLongitude: 114.0233029,
			CentroidLatitude:  22.5943785,
			Geometry:          `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[114.00477368715823,22.603816115512295],[114.00494534853519,22.582578808335768],[114.0355010736328,22.582578808335768],[114.04288251284177,22.593118627671647],[114.04236752871093,22.606034749629167],[114.01927907351076,22.605717804088208],[114.00477368715823,22.603816115512295]]]},"properties":{"type":"esriSFS","color":[116,181,216,13],"outline":{"type":"esriSLS","color":[116,181,216,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720151960849,
			UpdateTime:        1720152318343,
			DeleteTime:        0,
		},
		&bean.FencedAreaConfig{
			ID:                1289415595533008900,
			TbCode:            "000001",
			AreaName:          "核心区-不交叉",
			AreaType:          2,
			AreaPerimeter:     5.0200000,
			AreaSquare:        586156.8900000,
			CentroidLongitude: 114.0513229,
			CentroidLatitude:  22.5927548,
			Geometry:          `{"type":"Feature","geometry":{"type":"MultiPolygon","coordinates":[[[[114.05274021457292,22.596903505490417],[114.05722317504893,22.599674374494466],[114.05173001098643,22.603398602040702],[114.05274021457292,22.596903505490417]]],[[[114.05413327026378,22.58794636148069],[114.05274021457292,22.596903505490417],[114.0470951538087,22.593414275634025],[114.05413327026378,22.58794636148069]]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`,
			CreateTime:        1720257063411,
			UpdateTime:        1720257063411,
			DeleteTime:        0,
		},
	}
	in := NewAlarmCheckInParam(tbCode, c2LonLat, uavItems, fenceAreaList)
	areaCheckParam := NewCfgFendAreaCheckParams()
	tranInParamsToCfgFendArea(in, areaCheckParam)

	t.Logf("fence area check params: %+v", areaCheckParam)
	for k, v := range areaCheckParam.fendAreaLonLat {
		t.Logf("k: %v, v: %+v", k, *v)
	}

	strategyHandle := NewAlarmStrategy(nil, nil, nil)
	strategyHandle.(*AlarmStrategy).RegisterUniqueAlarmEventId(func(s string) (int64, int64, error) {
		t.Logf("mock gen alarm id.")
		return 1, 100, nil
	})
	strategyHandle.(*AlarmStrategy).RegisterAsyncWriteAlarm(func(item *AlarmRecord) error {
		if item != nil {
			t.Logf("write item value: %v", *item)
		}
		t.Logf("mock async write alarm done.")
		return nil
	})
	strategyHandle.(*AlarmStrategy).RegisterFilterAlarmResponse(func(item []*pb.AlarmCheckRspItem) []*pb.AlarmCheckRspItem {
		t.Logf("mock filter alarm response.")
		return item
	})
	//
	strategyHandle.Check(in)
}

func TestWriteDetectAndTrackID(t *testing.T) {
	mock.LoggerMock()
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Redis.Host = "10.240.34.36"
		config.ServiceCfg.Redis.Port = 30356
		config.ServiceCfg.Redis.Password = "ZAQ!2wsx"
		config.ServiceCfg.Redis.DataBase = 15

	}
	config.InitRedis()
	strategyHandle := NewAlarmStrategy(config.GlobalRedis, nil, nil)
	handle, ok := strategyHandle.(*AlarmStrategy)
	if !ok {
		t.Logf("fail error, not AlarmStrategy")
		return
	}

	var in *AlarmCheckInParam = new(AlarmCheckInParam)
	in.tbCode = "000001"
	in.uavItems = []*pb.DevLocationInfo{
		&pb.DevLocationInfo{
			TrackId: "test_11111_1",
			DevRelations: []*pb.DevRelation{
				&pb.DevRelation{
					Sn:        "d_11111", // key: d_11111, value: {1.11111, 1.22222, test_11111_1}
					Longitude: 1.11111,
					// 纬度
					Latitude: 1.22222,
				},
				&pb.DevRelation{
					Sn:        "d_2222", // key: d_2222, value: {2.11111,2.22222, test_11111_1}
					Longitude: 2.11111,
					// 纬度
					Latitude: 2.22222,
				},
				&pb.DevRelation{
					Sn:        "d_3333", // key: d_3333, value: {3.11111, 3.22222, test_11111_1}
					Longitude: 3.11111,
					// 纬度
					Latitude: 3.22222,
				},
			},
		},
		&pb.DevLocationInfo{
			TrackId: "test_22222_1",
			DevRelations: []*pb.DevRelation{
				&pb.DevRelation{
					Sn:        "f_11111", // key: f_11111, value: {1.11111, 1.22222,test_22222_1}
					Longitude: 1.11111,
					// 纬度
					Latitude: 1.22222,
				},
				&pb.DevRelation{
					Sn:        "f_2222", // key: f_2222, value: { 2.11111, 2.22222,test_22222_1}
					Longitude: 2.11111,
					// 纬度
					Latitude: 2.22222,
				},
				&pb.DevRelation{
					Sn:        "f_3333", // key: f_3333, value: { 3.11111, 3.22222,test_22222_1}
					Longitude: 3.11111,
					// 纬度
					Latitude: 3.22222,
				},
			},
		},
	}

	handle.WriteUavWithTrackId(in)

	retData := GetTrackIdByDevice("000001", "f_3333", config.GlobalRedis)
	if retData != nil {
		t.Logf("retData: %v", retData)
		for _, item := range retData {
			if item == nil {
				continue
			}
			//
			t.Logf("item: %+v", *item)
		}
	}
}

func DemoLogInfof(template string, args ...interface{}) {
	logger.Infof(template, args...)
}
func TestAccessLog(t *testing.T) {
	if err := logger.Init("../../../application-dev.yml",
		`D:\works\cuavcloudgo\CuavCloudGoService`); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return
	}

	for i := 0; i < 100; i++ {
		logs.Accessf(context.Background(), "this is demo, i: %v", i)
		logs.Accessf(context.Background(), "this is demo 22222.")
		logger.Infof("use logger.info...")
		DemoLogInfof("wrapper demo infof")
		logger.Errorf("this is error....: %v", i)
	}
}

func TestAlarmStrategy_AlarmRiskLevelScoreOnCore(t *testing.T) {

	mock.LoggerMock()
	config.InitConfig("./application-dev.yml")
	ass := NewAlarmStrategy(nil, nil, nil)
	geom := `{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[113.30924553502629,23.118334261320392],[113.3091757975919,23.116464401276005],[113.31144494641882,23.116355859787454],[113.31143421758276,23.118353995852118],[113.30924553502629,23.118334261320392]]]},"properties":{"type":"esriSFS","color":[228,101,107,13],"outline":{"type":"esriSLS","color":[228,101,107,153],"width":2,"style":"esriSLSSolid"},"style":"esriSFSSolid"}}`
	fendAreaLonLatItem, err := geo.ParseGeoJsonToPolygons(geom)
	if err != nil {
		logger.Fatal(",,,,,ccc")
	}
	points, err := geo.UnmarshalToPoint(geom)
	if err != nil {
		logger.Fatal(",,,,,UnmarshalToPoint")
	}
	as := ass.(*AlarmStrategy)
	fenCentroidLongitude := 113.3103372
	fenCentroidLatitude := 23.1173709
	type args struct {
		tbCode         string
		uav            *pb.DevLocationInfo
		fendArea       *bean.FencedAreaConfig
		fendAreaLonLat *geo.PolygonUnionList
	}
	tests := []struct {
		name    string
		as      *AlarmStrategy
		args    args
		want    *AlarmRiskLevel
		wantErr bool
	}{
		{name: "xxx", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.2977974,
				Latitude:  23.0758408,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx1", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.2292716,
				Latitude:  23.1150082,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx2", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.3190770,
				Latitude:  23.1156843,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx3", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.2866189,
				Latitude:  23.1419372,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx4", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.2013743,
				Latitude:  23.1128424,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx5", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.2292716,
				Latitude:  23.1150082,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx488", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.3105958,
				Latitude:  23.1172744,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
		{name: "xxx588", as: as, args: args{
			tbCode: "000001",
			uav: &pb.DevLocationInfo{
				Longitude: 113.3090617,
				Latitude:  23.1137477,
			},
			fendArea: &bean.FencedAreaConfig{
				CentroidLongitude: fenCentroidLongitude,
				CentroidLatitude:  fenCentroidLatitude,
			},
			fendAreaLonLat: &geo.PolygonUnionList{
				PolygonListItems:      fendAreaLonLatItem,
				PolygonPointListItems: points,
			},
		}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.as.AlarmRiskLevelScoreOnCore(tt.args.tbCode, tt.args.uav, tt.args.fendArea, tt.args.fendAreaLonLat)
			if (err != nil) != tt.wantErr {
				t.Errorf("AlarmStrategy.AlarmRiskLevelScoreOnCore() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AlarmStrategy.AlarmRiskLevelScoreOnCore() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestAlarmStrategy_ProcessAlarmOnlyCoreWarningImpl(t *testing.T) {
	type args struct {
		inParam any
	}
	tests := []struct {
		name    string
		as      *AlarmStrategy
		args    args
		want    AlarmCheckResultPtr
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.as.ProcessAlarmOnlyCoreWarningImpl(tt.args.inParam)
			if (err != nil) != tt.wantErr {
				t.Errorf("AlarmStrategy.ProcessAlarmOnlyCoreWarningImpl() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AlarmStrategy.ProcessAlarmOnlyCoreWarningImpl() = %v, want %v", got, tt.want)
			}
		})
	}
}
