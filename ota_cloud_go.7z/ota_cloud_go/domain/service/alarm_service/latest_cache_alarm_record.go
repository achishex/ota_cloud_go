package alarm_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/domain/repository/redis"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"google.golang.org/protobuf/proto"
	"strconv"
	"time"
)

const (
	AlarmCacheKeyPrefix    = "alarm_record:"
	AlarmDelCacheKeyPrefix = "alarm_del"
)

type LatestCacheAlarmRecord struct {
	cacheOps redis.SkyFendRedisOps
	maxNums  int32
}

func (ar *LatestCacheAlarmRecord) GetKey(tbCode string) string {
	if tbCode == "" {
		return ""
	}
	return fmt.Sprintf("%s%s", AlarmCacheKeyPrefix, tbCode)
}

func (ar *LatestCacheAlarmRecord) GetDelAlarmKey(tbCode string, eventId int64) string {
	if tbCode == "" {
		return ""
	}
	return fmt.Sprintf("%s:%s:%d", AlarmDelCacheKeyPrefix, tbCode, eventId)
}

func NewLatestCacheAlarmRecord() *LatestCacheAlarmRecord {
	return &LatestCacheAlarmRecord{
		cacheOps: ResAlarmRecordRedis,
		maxNums:  30,
	}
}

// FetchItems 获取指定租户id的最新告警缓存记录
func (ar *LatestCacheAlarmRecord) FetchItems(tbCode string, n int32) ([]*pb.AlarmCheckRspItem, error) {
	rdsKey := ar.GetKey(tbCode)
	if len(rdsKey) <= 0 {
		logger.Errorf("get redis key is empty, tbCode: %s", tbCode)
		return nil, fmt.Errorf("get redis key is empty")
	}
	if n <= 0 {
		return nil, nil
	}

	vStr, e := ar.cacheOps.ZRange(rdsKey, 0, int64(n-1))
	if e != nil {
		return nil, e
	}

	var ret []*pb.AlarmCheckRspItem
	for _, v := range vStr {
		item := &pb.AlarmCheckRspItem{}
		e := proto.Unmarshal([]byte(v), item)
		if e != nil {
			continue
		}
		ret = append(ret, item)
	}
	return ret, nil
}

// DelItems 根据 alarmID 删除 tbcode下的缓存 alarm
func (ar *LatestCacheAlarmRecord) DelItems(tbCode string, alarmIds []int64) error {
	if len(alarmIds) <= 0 {
		return nil
	}

	rdsKey := ar.GetKey(tbCode)
	if len(rdsKey) <= 0 {
		logger.Errorf("del key is empty, tbCode: %s", tbCode)
		return fmt.Errorf("del redis key is empty")
	}

	for _, id := range alarmIds {
		n, err := ar.cacheOps.ZDelMemberByScore(rdsKey, float64(id), float64(id))
		if err != nil {
			logger.Errorf("del member by score, e: %v", err)
			continue
		}
		logger.Infof("del cache by alarm id: %v, del nums: %v", id, n)
	}
	return nil
}

// InsertDelItem 插入已删除报警记录标记
func (ar *LatestCacheAlarmRecord) InsertDelItem(tbCode string, items []*pb.AlarmStatusUpdateItem, expireTime time.Duration) error {
	if items == nil {
		return nil
	}
	for index, _ := range items {
		eventId, _ := strconv.ParseInt(items[index].GetEventId(), 10, 64)
		rdsKey := ar.GetDelAlarmKey(tbCode, eventId)

		err := ar.cacheOps.SetEx(rdsKey, strconv.FormatInt(int64(items[index].GetRiskLevel()), 10), expireTime)
		if err != nil {
			logger.Errorf("set del item flag fail, e: %v, key: %v", err, rdsKey)
			continue
		}
		//logger.Infof("set del item flag success, tbcode:eventId,  %v", rdsKey)
	}
	return nil
}

// IsDelItems 判断是否是已删除的告警记录
func (ar *LatestCacheAlarmRecord) IsDelItems(tbCode string, eventId int64, riskLevel int32) (bool, error) {
	if tbCode == "" {
		return false, fmt.Errorf("tbCode is nil")
	}

	rdsKey := ar.GetDelAlarmKey(tbCode, eventId)
	data, err := ar.cacheOps.Get(rdsKey)
	if err != nil {
		if errors.Is(err, redis.RETNil) {
			return false, nil
		}
		return false, err
	}
	v, ok := data.(string)
	if !ok {
		return false, nil
	}
	if v != strconv.FormatInt(int64(riskLevel), 10) {
		return false, nil
	}
	return true, nil
}

// SetItem 向指定的租户id 增加告警记录缓存()
func (ar *LatestCacheAlarmRecord) SetItem(tbCode string, item *pb.AlarmCheckRspItem) error {
	if item == nil {
		logger.Errorf("input value is nil")
		return fmt.Errorf("input value is nil")
	}

	rdsKey := ar.GetKey(tbCode)
	if len(rdsKey) <= 0 {
		logger.Errorf("get redis key is empty, tbCode: %s", tbCode)
		return fmt.Errorf("get redis key is empty")
	}
	vStr, e := proto.Marshal(item)
	if e != nil {
		logger.Errorf("marshal alarm fail, e: %v, item: %+v", e, item)
		return e
	}
	// 使用告警id 作为 score.
	e = ar.cacheOps.ZADDAtomic(rdsKey, float64(item.GetId()), vStr, ar.maxNums)
	if e != nil {
		logger.Errorf("set alarm item to redis fail, err: %v", e)
	} else {
		logger.Infof("set alarm record to cache, key: %v, value: %+v", tbCode, item)
	}
	return e
}
