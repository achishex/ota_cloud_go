package alarm_service

import "fmt"

// 定义告警级别
const (
	RiskAlarNo      = 0 // 无危险等级
	RiskAlarmLow    = 1 // 低危险等级
	RiskAlarmMiddle = 2 // 中危险等级
	RiskAlarmHigh   = 3 // 高危险等级
)

// 定义告警级别下的分数段
const (
	highUpper   = 100
	highLower   = 80
	middleUpper = 79
	middleLower = 50
	lowUpper    = 49
	lowLower    = 1
)

// 以 c2 经纬度为中心，无人机经纬度之间的距离边界定义
const (
	// DistUpperBoundaryOnLowRisk 低风险的距离上边界
	DistUpperBoundaryOnLowRisk = 500 // 单位是米
	// DistLowBoundaryOnLowRisk 低风险的距离下边界
	DistLowBoundaryOnLowRisk = 2000
	//DistUpperBoundaryOnMiddleRisk  中风险的距离上边界
	DistUpperBoundaryOnMiddleRisk = 200
	// DistLowBoundaryOnMiddleRisk 中风险的距离下边界
	DistLowBoundaryOnMiddleRisk = 500
	// DistUpperBoundaryOnHighRisk 低风险的距离上边界
	DistUpperBoundaryOnHighRisk = 0
	// DistLowBoundaryOnHighRisk 低风险的距离下边界
	DistLowBoundaryOnHighRisk = 200
)

// CalcRiskOnNoFendArea 返回 风险等级和 具体分数
func CalcRiskOnNoFendArea(dist float64) (int, int) {
	var riskLevel = RiskAlarmLow
	var alarmScore = lowLower

	if dist >= DistUpperBoundaryOnLowRisk {
		riskLevel = RiskAlarmLow
		alarmScore = CalcLowRiskOnNoFendArea(dist)

	} else if dist > DistUpperBoundaryOnMiddleRisk {
		riskLevel = RiskAlarmMiddle
		alarmScore = CalcMiddleRiskOnNoFendArea(dist)
	} else {
		riskLevel = RiskAlarmHigh
		alarmScore = CalcHighRiskOnNoFendArea(dist)
	}
	return riskLevel, alarmScore
}

// CalcLowRiskOnNoFendArea 根据距离计算低风险分数
func CalcLowRiskOnNoFendArea(dist float64) int {
	var score int = lowLower
	if dist >= float64(DistLowBoundaryOnLowRisk) {
		score = lowLower
		return score
	}
	if dist == float64(DistUpperBoundaryOnLowRisk) {
		score = lowUpper
		return score
	}
	diff := dist - float64(DistUpperBoundaryOnLowRisk)
	score = int(diff*50/float64(DistLowBoundaryOnLowRisk-DistLowBoundaryOnLowRisk)) + lowLower
	if score >= lowUpper {
		fmt.Printf("more than low risk, dist: %v, score: %v\n", dist, score)
		score = lowUpper
	}
	return score
}

// CalcMiddleRiskOnNoFendArea 根据距离计算 中风险分数
func CalcMiddleRiskOnNoFendArea(dist float64) int {
	var score int = middleLower
	diff := dist - float64(DistUpperBoundaryOnMiddleRisk)
	score = int(diff*30/float64(DistLowBoundaryOnMiddleRisk-DistUpperBoundaryOnMiddleRisk)) + middleLower
	if score >= middleUpper {
		fmt.Printf("more than middle risk, dist: %v, score: %v\n", dist, score)
		score = middleUpper
	}
	return score
}

// CalcHighRiskOnNoFendArea  根据距离计算 高风险分数
func CalcHighRiskOnNoFendArea(dist float64) int {
	var score = highLower
	if dist == DistLowBoundaryOnHighRisk {
		return score
	}

	diff := dist - DistUpperBoundaryOnHighRisk
	score = int(diff*20/float64(DistLowBoundaryOnHighRisk-DistUpperBoundaryOnHighRisk)) + 80
	if score >= 100 {
		fmt.Printf("more than high risk, dist: %v, score: %v\n", dist, score)
		score = 100
	}
	return score
}

// CalcHighRiskOnOnlyCoreFendArea 计算 只有核心区下 高风险的分数
func CalcHighRiskOnOnlyCoreFendArea(dist float64) int {
	return highLower + 10
}

// CalcHighRiskScoreOnlyCoreFendArea 计算 只有核心区 下 高风险 级别和分数
func CalcHighRiskScoreOnlyCoreFendArea(dist float64) (int, int) {
	return RiskAlarmHigh, CalcHighRiskOnOnlyCoreFendArea(dist)
}

// CalcMiddleRiskScoreOnCoreFendArea 返回 核心区下 中风险等级和分数
func CalcMiddleRiskScoreOnCoreFendArea(dist float64) (int, int) {
	//if dist <= 500 {
	//	return RiskAlarmMiddle, int(30*(dist/500) + 50)
	//}
	return RiskAlarmMiddle, 50
}

// CalcLowRiskScoreOnCoreFendArea 返回 核心区下 低风险等级和分数
func CalcLowRiskScoreOnCoreFendArea(dist float64) (int, int) {
	//if dist > DistLowBoundaryOnLowRisk {
	//	return RiskAlarmLow, 1
	//}
	//
	//score := int(50 * (dist - DistUpperBoundaryOnLowRisk) / (DistLowBoundaryOnLowRisk - DistUpperBoundaryOnLowRisk))
	return RiskAlarmLow, 20
}

// CalcRiskScoreOnCoreFendArea 计算核心区 下等级和分数
func CalcRiskScoreOnCoreFendArea(dist float64, intersection bool) (int, int) {
	if intersection { //有交集
		return CalcMiddleRiskScoreOnCoreFendArea(dist)
	}
	return CalcLowRiskScoreOnCoreFendArea(dist)
}

// CalcMiddleRiskScoreOnCoreInMix  获取核心区在混合模式下的 中等报警等级和分数
func CalcMiddleRiskScoreOnCoreInMix(dist float64) int {
	var score int = middleLower
	diff := dist - float64(DistLowBoundaryOnMiddleRisk)
	score = int(diff*30/float64(DistLowBoundaryOnLowRisk-DistLowBoundaryOnMiddleRisk)) + middleLower
	if score >= middleUpper {
		fmt.Printf("more than middle risk, dist: %v, score: %v\n", dist, score)
		score = middleUpper
	}
	return score
}

// CalcHighRiskScoreOnCoreInMix  获取核心区在混合模式下的 高等报警等级和分数
func CalcHighRiskScoreOnCoreInMix(dist float64) int {
	var score int = highLower
	diff := dist
	score = int(diff*20/float64(DistLowBoundaryOnMiddleRisk)) + highLower
	if score >= highUpper {
		fmt.Printf("more than high risk, dist: %v, score: %v\n", dist, score)
		score = highUpper
	}
	return score
}

// CalcRiskScoreOnCoreInMix 获取核心区在混合模式下的 报警等级和分数
func CalcRiskScoreOnCoreInMix(dist float64, intersection500, intersection2k bool) (int, int) {
	if intersection500 {
		return RiskAlarmHigh, CalcHighRiskScoreOnCoreInMix(dist)
	} else if intersection2k {
		return RiskAlarmMiddle, CalcMiddleRiskScoreOnCoreInMix(dist)
	} else {
		return RiskAlarNo, 0 // 大于 则直接设置为无告警， 依赖于预警区的判断
	}
	//if dist >= DistLowBoundaryOnLowRisk {
	//	return RiskAlarNo, 0 // 大于 则直接设置为无告警， 依赖于预警区的判断
	//}
	//if dist > 500 {
	//	//中威胁等级：目标到核心区的距离介于500m至2000m时。
	//	return RiskAlarmMiddle, CalcMiddleRiskScoreOnCoreInMix(dist)
	//} else {
	//	//高威胁等级：目标到核心区的最近距离小于等于500m及进入核心区时。
	//	return RiskAlarmHigh, CalcHighRiskScoreOnCoreInMix(dist)
	//}
}

// CalcHighRiskOnOnlyForeFendArea 计算 预警区 下 高风险下 风险分数
func CalcHighRiskOnOnlyForeFendArea(dist float64) int {
	return highLower + 10
}

// CalcHighRiskScoreOnlyForeFendArea 返回 预警区下 高风险等级和风险分数
func CalcHighRiskScoreOnlyForeFendArea(dist float64) (int, int) {
	return RiskAlarmHigh, CalcHighRiskOnOnlyForeFendArea(dist)
}

// CalcMiddleRiskScoreOnlyForeFendArea 返回 预警区下 中风险等级和分数
func CalcMiddleRiskScoreOnlyForeFendArea(dist float64) (int, int) {
	//if dist <= 500 {
	//	return RiskAlarmMiddle, int(30*(dist/500) + 50)
	//}
	return RiskAlarmMiddle, 50
}

// CalcLowRiskScoreOnlyForeFendArea 返回 预警区 下 低风险等级和分数
func CalcLowRiskScoreOnlyForeFendArea(dist float64) (int, int) {
	if dist > DistLowBoundaryOnLowRisk {
		return RiskAlarmLow, 1
	}

	score := int(50 * (dist - DistUpperBoundaryOnLowRisk) / (DistLowBoundaryOnLowRisk - DistUpperBoundaryOnLowRisk))
	return RiskAlarmLow, score
}

// CalcRiskScoreOnlyForeFendArea 计算 预警区下的等级和分数
func CalcRiskScoreOnlyForeFendArea(dist float64, intersection bool) (int, int) {
	if intersection {
		return CalcMiddleRiskScoreOnlyForeFendArea(dist)
	}
	return CalcLowRiskScoreOnlyForeFendArea(dist)
}

// CalcUavRiskScoreOnFendAreas 根据新老等级和分数，得到有效的等级和分数
func CalcUavRiskScoreOnFendAreas(oldRiskLevel, oldScore, newRiskLevel, newScore int) (int, int) {
	var (
		retRiskLevel = oldRiskLevel
		retScore     = oldScore
	)

	// 先取最大的危险等级
	if oldRiskLevel < newRiskLevel {
		retRiskLevel = newRiskLevel
		retScore = newScore

	} else if oldRiskLevel == newRiskLevel {
		// 危险等级相同，取分数最高的
		if oldScore < newScore {
			retScore = newScore
		}
	} else {
	}

	return retRiskLevel, retScore
}
