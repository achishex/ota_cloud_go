package alarm_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/mq"
	pb "cuav-cloud-go-service/proto"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type AlarmStatusUpdateNotify struct {
	statusPublisher mq.MessagePublisher
}

func NewAlarmStatusUpdateNotify() *AlarmStatusUpdateNotify {
	return &AlarmStatusUpdateNotify{
		statusPublisher: alarmStatusModifyPubHandler,
	}
}

func (f *AlarmStatusUpdateNotify) DeleteAlarmFromCache(data map[int64]*pb.AlarmStatusUpdateItem) error {
	var tbCodeSet = make(map[string][]int64) // tbcode 下的告警id 列表
	for alarmId, _ := range data {
		if data[alarmId] == nil {
			continue
		}
		if _, ok := tbCodeSet[data[alarmId].TbCode]; !ok {
			tbCodeSet[data[alarmId].TbCode] = []int64{alarmId}
		} else {
			tbCodeSet[data[alarmId].TbCode] = append(tbCodeSet[data[alarmId].TbCode], alarmId)
		}
	}
	logger.Infof("to get tbcode to del in cache: %+v", tbCodeSet)

	for tbCode, _ := range tbCodeSet {
		if len(tbCode) == 0 {
			continue
		}
		NewLatestCacheAlarmRecord().DelItems(tbCode, tbCodeSet[tbCode])
	}
	return nil
}

// Notify map key is alarm id
func (f *AlarmStatusUpdateNotify) Notify(data map[int64]*pb.AlarmStatusUpdateItem, tbCode string) error {
	if f.statusPublisher == nil {
		logger.Errorf("create alarm status update pub obj fail, is nil")
		return fmt.Errorf("create alarm status update pub fail, is nil")
	}
	if len(data) == 0 {
		//logger.Infof("to update alarm status  data is empty")
		return nil
	}

	var toNotify []*pb.AlarmStatusUpdateItem
	for k, _ := range data {
		if data[k] == nil {
			continue
		}
		toNotify = append(toNotify, data[k])
	}
	noticeItem := &model.NoticeItem{
		Key:  "/notice/v1/alarm_status_update",
		Data: toNotify,
	}

	err := f.statusPublisher.Publish(context.Background(), config.GetConfig().Kafka.EventNoticeTopic, tbCode, noticeItem)
	if err != nil {
		logger.Errorf("publish fail, err: %v, data: %v", err, noticeItem)
		return err
	}
	//logger.Infof("send kafka notify for alarm status modify, value: %+v.", toNotify)
	return nil
}

func (f *AlarmStatusUpdateNotify) Add(data []*pb.AlarmCheckAddItem, tbCode string) error {
	if f.statusPublisher == nil {
		logger.Errorf("create alarm status update pub obj fail, is nil")
		return fmt.Errorf("create alarm status update pub fail, is nil")
	}
	if len(data) == 0 {
		//logger.Infof("to update alarm status  data is empty")
		return nil
	}

	noticeItem := &model.NoticeItem{
		Key:  "/notice/v1/alarm_status_add",
		Data: data,
	}

	err := f.statusPublisher.Publish(context.Background(), config.GetConfig().Kafka.EventNoticeTopic, tbCode, noticeItem)
	if err != nil {
		logger.Errorf("publish fail, err: %v, data: %v", err, noticeItem)
		return err
	}
	//logger.Infof("send kafka add for alarm status modify, value: %+v.", data)
	return nil
}

// FlagNonAlarmReport 标记已处理的告警记录, key: alarmId; 需要缓存，并设置有效期
func (f *AlarmStatusUpdateNotify) FlagNonAlarmReport(data map[int64]*pb.AlarmStatusUpdateItem, userAction bool) error {
	var tbCodeSet = make(map[string][]*pb.AlarmStatusUpdateItem) // tbcode 下的告警id 列表
	for alarmId, _ := range data {
		if alarmId <= 0 {
			continue
		}

		if data[alarmId] == nil {
			continue
		}
		if _, ok := tbCodeSet[data[alarmId].TbCode]; !ok {
			tbCodeSet[data[alarmId].TbCode] = []*pb.AlarmStatusUpdateItem{data[alarmId]}
		} else {
			tbCodeSet[data[alarmId].TbCode] = append(tbCodeSet[data[alarmId].TbCode], data[alarmId])
		}
	}
	if len(tbCodeSet) > 0 {
		logger.Infof("to get tb code to del in cache: %+v", tbCodeSet)
	}

	for tbCode, _ := range tbCodeSet {
		if len(tbCode) == 0 {
			continue
		}
		// 区分用户手动操作确认还是告警过期删除
		if userAction {
			NewLatestCacheAlarmRecord().InsertDelItem(tbCode, tbCodeSet[tbCode], 120*time.Second) // 120s过期
		}
	}
	return nil
}
