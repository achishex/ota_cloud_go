package alarm_service

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/domain/repository/mq"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/infra/utils/routinues"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"reflect"
	"runtime/debug"
	"strconv"
	"time"

	"github.com/paulmach/orb"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// AlarmCheckInParam 告警检查入参
type AlarmCheckInParam struct {
	tbCode    string
	c2Loc     map[string]*pb.C2LocationInfo // c2 经纬度列表; key: 是c2
	uavItems  []*pb.DevLocationInfo         //无人机列表
	fendAreas []*bean.FencedAreaConfig      //围栏区列表（从本地缓存读取）
}

func NewAlarmCheckInParam(tbCode string, c2 map[string]*pb.C2LocationInfo, uavs []*pb.DevLocationInfo, fa []*bean.FencedAreaConfig) *AlarmCheckInParam {
	//
	return &AlarmCheckInParam{
		tbCode:    tbCode,
		c2Loc:     c2,
		uavItems:  uavs,
		fendAreas: fa,
	}
}

// AlarmCheckResultPtr 告警检查结果
type AlarmCheckResultPtr = *pb.AlarmCheckResponse

// AlarmStrategyInterface check 无人机告警接口
type AlarmStrategyInterface interface {
	Check(in *AlarmCheckInParam) (AlarmCheckResultPtr, error)
	// CacheUavDetectData 异步缓存数据，用户后续业务使用
	CacheUavDetectData(in *AlarmCheckInParam) error
}

// NewAlarmStrategy 创建告警检查策略对象句柄
func NewAlarmStrategy(rds redis.SkyFendRedisOps, dbOps db.DbOpsTplInterface[bean.FencedAreaConfig], pub mq.MessagePublisher) AlarmStrategyInterface {
	return &AlarmStrategy{
		fendAreaAlarmProcess: make(map[int]FendAreaAlarmProcessor),
		redisFendAreaOps:     rds,   // fendArea redis op
		dbFendAreaOps:        dbOps, // fend area db op
		alarmRecordPub:       pub,
	}
}

const (
	// FendAreaTypeNoSet 未设置围栏区
	FendAreaTypeNoSet = 0

	//FendAreaPreAlarmOnly 预警围栏区（只存在）
	FendAreaPreAlarmOnly = 1

	// FendAreaTypeCoreOnly 核心区围栏区（只存在）
	FendAreaTypeCoreOnly = 2

	//FendAreaTypePreCoreCross 预警和核心区都存在且存在相交（两者都存在）
	FendAreaTypePreCoreCross = 3

	// FendAreaTypePreCoreNoCross 预警和核心区都存在但不存在相交 （两者都存在）
	FendAreaTypePreCoreNoCross = 4

	// FendAreaTypeDefinedEnd 枚举最大边界值
	FendAreaTypeDefinedEnd = 100
)
const (
	// ForeAlarmArea 预警围栏区
	ForeAlarmArea = 1
	// CoreAlarmArea 核心围栏区
	CoreAlarmArea = 2
)

// FendAreaAlarmProcessor 围栏区预警处理函数
type FendAreaAlarmProcessor func(any) (AlarmCheckResultPtr, error)

//type FendAreaAlarmProcessor func(*cfgFendAreaCheckParam) (AlarmCheckResultPtr, error)

// AlarmStrategy 报警策略服务
type AlarmStrategy struct {
	// 获取无人机告警入侵事件唯一ID sn:
	getIntrusionAlarmId func(uniqueID string) (int64, int64, error)
	// checkRepeatedAlarm 检查某个报警是否是连续重复产生，如果重复则就不上报。
	checkRepeatedAlarm func(uniqueID string) (bool, error)

	// asyncWriteAlarmRecord 异步记录产生的告警记录 	//异步写告警记录到 DB中
	asyncWriteAlarmRecord func(record *AlarmRecord) error

	// filterAlarmResponse 过滤告警记录（只过滤返回给客户端的数据）
	filterAlarmResponse func([]*pb.AlarmCheckRspItem) []*pb.AlarmCheckRspItem

	// 围栏区告警处理逻辑
	fendAreaAlarmProcess map[int]FendAreaAlarmProcessor

	// redisFendAreaOps
	redisFendAreaOps redis.SkyFendRedisOps
	//dbFendAreaOps db
	dbFendAreaOps db.DbOpsTplInterface[bean.FencedAreaConfig]
	//
	alarmRecordPub mq.MessagePublisher
}

// RegisterAsyncWriteAlarm 注册异步写报警记录
func (as *AlarmStrategy) RegisterAsyncWriteAlarm(fn func(record *AlarmRecord) error) {
	if as.asyncWriteAlarmRecord == nil {
		as.asyncWriteAlarmRecord = fn
		return
	}
	logger.Infof("[notice]: not support reset asyncWriteAlarmRecord at same AlarmStrategy obj.")

}

// RegisterFilterAlarmResponse 注册过滤不必要的告警回包
func (as *AlarmStrategy) RegisterFilterAlarmResponse(fn func([]*pb.AlarmCheckRspItem) []*pb.AlarmCheckRspItem) {
	if as.filterAlarmResponse == nil {
		as.filterAlarmResponse = fn
		return
	}
	logger.Infof("[notice]: not support reset filterAlarmResponse at same AlarmStrategy obj.")
}

// RegisterUniqueAlarmEventId 注册产生 id 的函数
func (as *AlarmStrategy) RegisterUniqueAlarmEventId(idGen func(string) (int64, int64, error)) {
	if as.getIntrusionAlarmId == nil { // when AlarmStrategy obj is temp, this condition is ok.
		as.getIntrusionAlarmId = idGen
		return
	}
	logger.Infof("[notice]: not support reset getIntrusionAlarmId at same AlarmStrategy obj.")
}

// RegisterCheckRepeatedAlarm 注册上报重复检查函数。 返回值 true 说明重复，业务方可以做过滤。
func (as *AlarmStrategy) RegisterCheckRepeatedAlarm(checkRepeated func(string) (bool, error)) {
	as.checkRepeatedAlarm = checkRepeated
}

type ExpireMsID struct {
	ID    int64 `json:"id_str"`
	ExpMs int64 `json:"exp_ms"` //时间戳
}

func (s *ExpireMsID) String() string {
	v, e := json.Marshal(s)
	if e != nil {
		logger.Errorf("unmarshal fail, e: %v", e)
		return ""
	}

	return string(v)
}
func (s *ExpireMsID) FromString(data string) error {
	if data == "" {
		return fmt.Errorf("parse from str fail, str is empty")
	}
	err := json.Unmarshal([]byte(data), s)
	if err != nil {
		return fmt.Errorf("parse fail, e: %v", err)
	}
	return nil
}

// genAlarmEventIDImpl 产生告警事件ID 的 (tbcode:sn:objID); 返回 id 和 创建时间戳
func (as *AlarmStrategy) genAlarmEventIDImpl(key string) (int64, int64, error) {
	if as == nil {
		logger.Errorf("AlarmStrategy not init")
		return 0, 0, fmt.Errorf("AlarmStrategy is nil")
	}
	//
	if as.redisFendAreaOps == nil {
		logger.Errorf("AlarmStrategy redis op not init")
		return 0, 0, fmt.Errorf("unique tool handle(redis) is nil")
	}

	withExpId, err := as.redisFendAreaOps.GenUniqueKeyWithGenVal(key, 5*time.Second,
		func() string {
			id, e := snowflake.GetUniqueID()
			if e != nil {
				return ""
			}

			item := &ExpireMsID{
				ID:    id,
				ExpMs: time.Now().UnixMilli(),
			}
			return item.String()
		})
	if err != nil {
		return 0, 0, fmt.Errorf("get unique id fail, e: %v", err)
	}

	expireId := &ExpireMsID{}
	expireId.FromString(withExpId)

	//sVal, err := as.redisFendAreaOps.GenUniqueKey(key, 5*time.Second)
	//if err != nil {
	//	logger.Errorf("get unique id fail, key: %v, err: %v", key, err)
	//	return 0, err
	//}
	//retV, err := strconv.ParseInt(sVal, 10, 64)
	//if err != nil {
	//	logger.Errorf("parse int str to int fail, v: %v, err: %v", sVal, err)
	//	return 0, err
	//}
	return expireId.ID, expireId.ExpMs, nil
}

func (as *AlarmStrategy) checkAlarmRepeated(key string) (bool, error) {
	if as == nil {
		logger.Errorf("AlarmStrategy not init")
		return false, fmt.Errorf("handle is nil")
	}

	if as.redisFendAreaOps == nil {
		logger.Errorf("AlarmStrategy redis op not init")
		return false, fmt.Errorf("unique tool handle(redis) is nil")
	}

	exist, err := as.redisFendAreaOps.CheckKeyExist(key, 5*time.Second)
	if err != nil {
		return false, err
	}
	return exist, err
}

// RegisterFendAreaAlarmCheck 将围栏区的报警处理函数注册到统一对象中, 参数是围栏区类型，包括没有设置围栏区
func (as *AlarmStrategy) RegisterFendAreaAlarmCheck(fendAreaType int, handler FendAreaAlarmProcessor) {
	if as == nil {
		logger.Errorf("alarm strategy obj not init.")
		return
	}

	if fendAreaType >= FendAreaTypeDefinedEnd {
		logger.Errorf("input fendArea type: %v more then defined max value: %v", fendAreaType, FendAreaTypeDefinedEnd)
		return
	}

	if as.fendAreaAlarmProcess == nil {
		as.fendAreaAlarmProcess = make(map[int]FendAreaAlarmProcessor)
	}
	//
	as.fendAreaAlarmProcess[fendAreaType] = handler
	//logger.Infof("register fend area alarm process, fend area type: %v", fendAreaType)
}

// noFendAreaCheckParam 没有围栏区告警检查参数
type noFendAreaCheckParam struct {
	tbCode   string
	c2Loc    map[string]*pb.C2LocationInfo // c2 经纬度列表, key 是 无人机 sn
	uavItems []*pb.DevLocationInfo         //无人机列表

	//
	fendAreas       []*bean.FencedAreaConfig        // 围栏区列表,不会被设置为值； 该值为空
	uavWhitelistMap map[string]*pb.UavWhitelistItem // 白名单列表

}

func NewNoFendAreaCheckParam() *noFendAreaCheckParam {
	return &noFendAreaCheckParam{
		c2Loc: make(map[string]*pb.C2LocationInfo),
	}
}

// tranInParamsToNoFendArea 参数转化
func tranInParamsToNoFendArea(src *AlarmCheckInParam, dst *noFendAreaCheckParam) {
	if src == nil || dst == nil {
		return
	}
	//
	dst.tbCode = src.tbCode
	dst.c2Loc = src.c2Loc
	dst.uavItems = src.uavItems
}

// cfgFendAreaCheckParam 已配置围栏区的报警检查参数类型
type cfgFendAreaCheckParam struct {
	tbCode    string
	uavItems  []*pb.DevLocationInfo    //无人机列表 // client携带过来的数据
	fendAreas []*bean.FencedAreaConfig // 围栏区列表; 从本地服务获取的， 直接复制即可

	//需要手动填充和计算(所有围栏区的信息)， 在解析围栏区字位置字符串后，用于围栏区作为入参计算，后面逻辑不再使用该变量
	fendAreaLonLat map[int64]*geo.PolygonUnionList //geo.PolygonList // 围栏区的经纬度， key: fendAreas 围栏区元素的ID

	//根据预警区和核心是否交集，把围栏区划分下面几种。
	// 只存在预警区或者预警和核心两者 不存在交集下，存储预警区的围栏区信息， 单独计算告警 （需要根据策略来计算）  围栏区的经纬度， key: fendAreas 围栏区元素的ID
	preAlarmArea map[int64]*geo.PolygonUnionList

	// 只存在核心区或者预警和核心两者 不存在交集下，根据 存储核心区的围栏区信息， 单独计算告警（需要根据策略来计算）  围栏区的经纬度， key: fendAreas 围栏区元素的ID
	coreAlarmArea map[int64]*geo.PolygonUnionList

	// 具有预警区又有核心区的围栏区信息 （需要根据策略来计算）  围栏区的经纬度， key: fendAreas 围栏区元素的ID
	mixAlarmArea map[int64]*geo.PolygonUnionList
}

// NewCfgFendAreaCheckParams 初始化一个对象
func NewCfgFendAreaCheckParams() *cfgFendAreaCheckParam {
	return &cfgFendAreaCheckParam{
		fendAreaLonLat: make(map[int64]*geo.PolygonUnionList),
	}
}

// CalcOverLapInArea 计算两个围栏区是否是存在交叉
func CalcOverLapInArea(subItem *geo.PolygonUnionList, parentItem *geo.PolygonUnionList) (error, bool) {
	if subItem == nil || parentItem == nil {
		return fmt.Errorf("sub or parent item is nil"), false
	}

	for i1, _ := range subItem.PolygonListItems { // []orb.Polygon
		var onePolygon orb.Polygon
		onePolygon = subItem.PolygonListItems[i1]

		for i2, _ := range onePolygon { //  []Ring
			var oneRing orb.Ring
			oneRing = onePolygon[i2]

			for i3, _ := range oneRing { //  []Point
				var onePoint orb.Point
				onePoint = oneRing[i3]

				exist, err := geo.GeoCheckPointInPolygons(onePoint[0], onePoint[1], parentItem.PolygonListItems)
				if err != nil {
					continue
				}
				if exist {
					logger.Infof("exist cross, lon: %v, lat: %v; polygon: %v", onePoint[0], onePoint[1], parentItem.PolygonListItems)
					return nil, true
				}
			}
		}
	}
	return nil, false
}

// checkOverLapWithinAreas 计算多个围栏区之间是否存在交叉，包括内包含, 比如 subAreas 为核心围栏区列表，
func checkOverLapWithinAreas(subAreas []*geo.PolygonUnionList, parentAreas []*geo.PolygonUnionList) (error, bool) {
	if len(subAreas) == 0 || len(parentAreas) == 0 {
		return nil, false
	}

	for i, _ := range subAreas {
		subItem := subAreas[i]
		if subItem == nil {
			continue
		}

		for p, _ := range parentAreas {
			parentItem := parentAreas[p]
			if parentItem == nil {
				continue
			}

			err, exist := CalcOverLapInArea(subItem, parentItem)
			if err != nil {
				logger.Errorf("calc sub area in parent area fail, err: %v", err)
				continue
			}
			if exist {
				logger.Infof("core area id: %v, pre area id: %v", subItem.AreaItemDetail.ID, parentItem.AreaItemDetail.ID)
				return nil, true
			}
		}
	}
	return nil, false
}

// tranInParamsToCfgFendArea 转换参数
func tranInParamsToCfgFendArea(src *AlarmCheckInParam, dst *cfgFendAreaCheckParam) {
	if src == nil || dst == nil {
		return
	}

	dst.tbCode = src.tbCode
	dst.uavItems = src.uavItems
	dst.fendAreas = src.fendAreas

	//解析围栏区的关系，根据策略确定围栏区的类型：有预警区，有核心区，分别单独具有预警区和核心区，具有预警和核心区的混合区
	var (
		coreAlarmArea []*geo.PolygonUnionList //从围栏区获取到的临时围栏区
		preAlarmArea  []*geo.PolygonUnionList
	)

	// 把围栏区的经纬度从 字符串中解析出来
	for index, _ := range dst.fendAreas {
		fendArea := dst.fendAreas[index]
		if fendArea == nil {
			continue
		}
		item, err := geo.ParseGeoJsonToPolygons(fendArea.Geometry)
		if err != nil {
			logger.Errorf("parse fend area geometry from json fail, e: %v, fend area: %+v", err, fendArea.Geometry)
			continue
		}
		points, err := geo.UnmarshalToPoint(fendArea.Geometry)
		if err != nil {
			logger.Errorf("parse fend area geometry points from json fail, e: %v， fead area: %+v", err, fendArea)
			continue
		}

		if len(item) == 0 || len(points) == 0 {
			logger.Infof("parse fend area geometry from json is empty,  fend area: %v", fendArea)
			continue
		}

		if dst.fendAreaLonLat == nil {
			logger.Errorf("fend area lon,lat map is nil")
			continue
		}

		if _, ok := dst.fendAreaLonLat[fendArea.ID]; ok {
			logger.Errorf("fend area has parsed  as id repeated, value: %+v", fendArea)
			continue
		}

		dst.fendAreaLonLat[fendArea.ID] = &geo.PolygonUnionList{
			PolygonListItems:      item,
			PolygonPointListItems: points,
			AreaItemDetail:        fendArea,
		}

		switch {
		case fendArea.AreaType == 1: // 预警区 yes it's magic nums, refactor it, go go go
			preAlarmArea = append(preAlarmArea, dst.fendAreaLonLat[fendArea.ID])

		case fendArea.AreaType == 2: // 核心区, yes it's magic nums, refactor it, go go go
			coreAlarmArea = append(coreAlarmArea, dst.fendAreaLonLat[fendArea.ID])
		}
	}

	var isMixAlarmArea bool = false
	if len(coreAlarmArea) > 0 && len(preAlarmArea) > 0 { //检查核心区的点是否在预警区内，在则有交集
		if _, exist := checkOverLapWithinAreas(coreAlarmArea, preAlarmArea); exist {
			isMixAlarmArea = true
		}

		if isMixAlarmArea {
			logger.Infof("alarm aram exist mix mode.")
			if dst.mixAlarmArea == nil {
				dst.mixAlarmArea = make(map[int64]*geo.PolygonUnionList)
			}

			for index, _ := range coreAlarmArea { //将 coreAlarmArea 赋值给 dst.mixAlarmArea
				areaId := coreAlarmArea[index].AreaItemDetail.ID
				dst.mixAlarmArea[areaId] = coreAlarmArea[index]

				logger.Infof("in mix, core area id: %v", coreAlarmArea[index].AreaItemDetail.ID)
			}

			for index, _ := range preAlarmArea { //将 preAlarmArea 赋值给 dst.mixAlarmArea
				areaId := preAlarmArea[index].AreaItemDetail.ID
				dst.mixAlarmArea[areaId] = preAlarmArea[index]
				logger.Infof("in mix, pre area id: %v", preAlarmArea[index].AreaItemDetail.ID)
			}
			return
		}

		// 既有核心区，又有预警区，但是不存在交集
		if dst.coreAlarmArea == nil {
			dst.coreAlarmArea = make(map[int64]*geo.PolygonUnionList)
		}
		if dst.preAlarmArea == nil {
			dst.preAlarmArea = make(map[int64]*geo.PolygonUnionList)
		}

		for index, _ := range coreAlarmArea { // 将 coreAlarmArea 赋值给 dst.coreAlarmArea
			areaId := coreAlarmArea[index].AreaItemDetail.ID
			dst.coreAlarmArea[areaId] = coreAlarmArea[index]
		}

		for index, _ := range preAlarmArea { // 将 preAlarmArea 赋值给 dst.preAlarmArea
			areaId := preAlarmArea[index].AreaItemDetail.ID
			dst.preAlarmArea[areaId] = preAlarmArea[index]
		}
		return
	}

	if len(coreAlarmArea) > 0 { // 只有核心区
		if dst.coreAlarmArea == nil {
			dst.coreAlarmArea = make(map[int64]*geo.PolygonUnionList)
		}

		for index, _ := range coreAlarmArea { // 将 coreAlarmArea 赋值给 dst.coreAlarmArea
			areaId := coreAlarmArea[index].AreaItemDetail.ID
			dst.coreAlarmArea[areaId] = coreAlarmArea[index]
		}
		return
	}
	if len(preAlarmArea) > 0 { // 只有预警区
		if dst.preAlarmArea == nil {
			dst.preAlarmArea = make(map[int64]*geo.PolygonUnionList)
		}
		for index, _ := range preAlarmArea { // 将 preAlarmArea 赋值给 dst.preAlarmArea
			areaId := preAlarmArea[index].AreaItemDetail.ID
			dst.preAlarmArea[areaId] = preAlarmArea[index]
		}
		return
	}
	logger.Errorf("not exist any area id.")
}

func (as *AlarmStrategy) FilterRepeatedAlarm(record *AlarmRecord) (error, *AlarmRecord) {
	var ret = record
	if record == nil || len(record.AlarmItems) <= 0 {
		return nil, ret
	}

	if as.redisFendAreaOps == nil {
		logger.Errorf("redis handle is nil, not init")
		return nil, ret
	}

	var alarmList []*pb.AlarmCheckRspItem
	for index, _ := range record.AlarmItems {
		alarmItem := record.AlarmItems[index]
		//
		if alarmItem == nil {
			continue
		}

		redisKey := fmt.Sprintf("db_filter:%s:%s:%s:%d:%d", alarmItem.TbCode, alarmItem.Sn, alarmItem.ObjId, alarmItem.RiskLevel, alarmItem.ThreatLevel)

		// 判断用户是否已点击删除
		exist, _ := NewLatestCacheAlarmRecord().IsDelItems(alarmItem.TbCode, alarmItem.EventId, alarmItem.RiskLevel)
		if exist {
			logger.Infof("tbCode: %v, eventId: %v, riskLevel: %v has del", alarmItem.TbCode, alarmItem.EventId, alarmItem.RiskLevel)
			continue
		}

		// 不存在则创建,并返回false; 存在则刷新时间，返回true
		exist, err := as.redisFendAreaOps.CheckKeyExistFresh(redisKey, 2*time.Second)
		if err != nil {
			alarmList = append(alarmList, alarmItem)
			logger.Errorf("check key: %v fail: %v", redisKey, err)
			continue
		}

		// exist ; filter this alarm
		if exist {
			// logger.Infof("FilterRepeatedAlarm alarm key exist %s", redisKey)
			continue
		}

		logger.Infof("FilterRepeatedAlarm new alarm key %s", redisKey)
		alarmList = append(alarmList, alarmItem)
	}

	ret.AlarmItems = alarmList
	return nil, ret
}

func (as *AlarmStrategy) asyncAlarmRecord(record *AlarmRecord) error {
	if as == nil || as.alarmRecordPub == nil || record == nil {
		logger.Errorf("alarm record pub handle not init")
		return fmt.Errorf("alarm record pub handle not init")
	}
	if len(record.AlarmItems) <= 0 {
		logger.Infof("sync to kafka, tb_code: %v, alarm item is empty", record.TbCode)
		return nil
	}
	// 增加过滤策略，只有等级和分数发生变化后，才会落库，如果不发生变化，则不落库

	_, record = as.FilterRepeatedAlarm(record)

	go func() error {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("RegisterSubHandlers error: %s", utils.ErrTrace(fmt.Sprintf("%+v", e)))
			}
		}()

		err := as.alarmRecordPub.Publish(context.Background(), config.GetConfig().Kafka.AlarmAsyncWriteTopic, record.TbCode, record)
		if err != nil {
			logger.Errorf("write to kafka fail, err: %v, topic: %v", err, config.GetConfig().Kafka.AlarmAsyncWriteTopic)
			return err
		}
		//logger.Infof("sync to kafka, tb_code: %v, alarm: %v", record.TbCode, record.AlarmItems)
		return nil
	}()
	return nil
}

func DetectDeviceWithTrackIdKey(tbCode string, devSn string) string {
	if tbCode == "" || devSn == "" {
		return ""
	}
	return "cloud:" + tbCode + "_" + devSn
}

type DetectDevTrackIdRel struct {
	TrackId   string  `json:"track_id"`
	Longitude float64 `json:"longitude,omitempty"`
	// 纬度
	Latitude float64 `json:"latitude,omitempty"`
}

func GetTrackIdByDevice(tbCode string, deviceSn string, redisHandle redis.SkyFendRedisOps) []*DetectDevTrackIdRel {
	if tbCode == "" || deviceSn == "" || redisHandle == nil {
		logger.Errorf("input param is nil")
		return nil
	}

	data, err := redisHandle.Get(DetectDeviceWithTrackIdKey(tbCode, deviceSn))
	if err != nil {
		logger.Errorf("get trackId fail err: %v, key: %v", err, DetectDeviceWithTrackIdKey(tbCode, deviceSn))
		return nil
	}

	item, ok := data.(string)
	if !ok {
		logger.Errorf("trackId info is not []byte")
		return nil
	}
	if len(item) <= 0 {
		logger.Errorf("track id list is empty")
		return nil
	}

	var dstItem model.ListAnyType[DetectDevTrackIdRel]
	if err := dstItem.Unmarshal([]byte(item)); err != nil {
		logger.Errorf("unmarshal fail err: %v, item: %v", err, item)
		return nil
	}
	return dstItem
}

// WriteUavWithTrackId 记录无人机的侦测设备，建立和 trackId关系。
func (as *AlarmStrategy) WriteUavWithTrackId(in *AlarmCheckInParam) error {
	if in == nil {
		return nil
	}

	var tbCode = in.tbCode
	if len(tbCode) <= 0 {
		logger.Errorf("tbCode is empty")
		return nil
	}

	var detectDevTrackIdRel = make(map[string]model.ListAnyType[DetectDevTrackIdRel]) //key 是侦测设备的sn

	for i := 0; i < len(in.uavItems); i++ { //对每个无人机
		if in.uavItems[i] == nil {
			continue
		}

		if in.uavItems[i].TrackId == "" {
			logger.Debugf("has not trackId in uav detail, tbCode: %v", tbCode)
			continue
		}

		if len(in.uavItems[i].DevRelations) <= 0 {
			logger.Debugf("has not detect device in uav detail, tbCode: %v", tbCode)
			continue
		}

		for index, _ := range in.uavItems[i].DevRelations {
			var devRel = in.uavItems[i].DevRelations[index]
			if devRel == nil {
				continue
			}

			relKey := DetectDeviceWithTrackIdKey(tbCode, devRel.GetSn())
			_, ok := detectDevTrackIdRel[relKey]
			if !ok {
				detectDevTrackIdRel[relKey] = model.ListAnyType[DetectDevTrackIdRel]{}
			}

			itemList := detectDevTrackIdRel[relKey]
			itemList = append(itemList, &DetectDevTrackIdRel{
				TrackId: in.uavItems[i].TrackId,
				// 经度
				Longitude: devRel.Longitude,
				// 纬度
				Latitude: devRel.Latitude,
			})
			detectDevTrackIdRel[relKey] = itemList
		}
	}

	if as.redisFendAreaOps == nil {
		logger.Errorf("redis handle is nil, tbCode: %v", tbCode)
		return nil
	}

	for key, _ := range detectDevTrackIdRel {
		logger.Debugf("device track id key: %v", key)
		if len(detectDevTrackIdRel[key]) <= 0 {
			continue
		}
		logger.Debugf("detect track id list: %+v", detectDevTrackIdRel[key])

		var item = detectDevTrackIdRel[key]
		value, err := item.Marshal()
		if err != nil {
			logger.Errorf("marsh device track id list fail, err: %v, tbCode: %v", err, tbCode)
			continue
		}

		if err := as.redisFendAreaOps.SetEx(key, value, 1000*time.Second); err != nil {
			logger.Errorf("set redis fail, err: %v, tbCode: %v", err, tbCode)
		}
	}
	return nil
}

// CacheUavDetectData 缓存无人机信息，用于后续业务处理
func (as *AlarmStrategy) CacheUavDetectData(in *AlarmCheckInParam) error {
	if in == nil {
		logger.Errorf("cache data is nil")
		return nil
	}

	tbCode := in.tbCode
	for i := 0; i < len(in.uavItems); i++ {
		if in.uavItems[i] == nil {
			continue
		}

		func(uavDetail *pb.DevLocationInfo) {
			routinues.AsyncRun(true, func() {
				if uavDetail == nil {
					return
				}

				if uavDetail.GetTrackId() == "" {
					logger.Errorf("uav detail has not trackId, uav sn: %v, objId: %v, tbCode: %v", uavDetail.GetSn(), uavDetail.GetObjID(), tbCode)
					return
				}
				// 第一点：begin_point: 将详情存到 string; key: tbCode+trackId
				//  第二点：检查的数据需要存在 zset, member tbCode+trackId, score: 时间戳
				//  第三点：
				// 1. 写入缓存，存在则更新时间戳，不存在则更新 （zset 存储; member tbCode+trackId， score 时间戳，key: xxx）, 提供增加;删除;更新时间戳;查询。
				// 2. 启动定时器任务，检查是否过期， 过期则取出， 过滤掉在 cloud server 发过来的 trackd， 对剩下的并构造 track id notify 发通知。
				// 3. 在 cloud server 收到 trackId 时，需处理完需要删除 缓存中 trackId 的详情。
			})
		}(in.uavItems[i])
	}

	return nil
}

// Check 告警检查具体实现
func (as *AlarmStrategy) Check(in *AlarmCheckInParam) (AlarmCheckResultPtr, error) {
	if in == nil {
		return nil, fmt.Errorf("input param is nil on check step")
	}
	startTime := time.Now()
	defer func() {
		logger.Infof("check cost tm: %d ms, tbCode: %v", time.Since(startTime).Milliseconds(), in.tbCode)
		if e := recover(); e != nil {
			logger.Errorf(fmt.Sprintf("%s\n%s", fmt.Sprint(e), string(debug.Stack())))
		}
	}()

	go func() {
		_ = as.WriteUavWithTrackId(in)
	}()

	var toProcessParam any
	// 注册产生事件 id 函数
	as.RegisterUniqueAlarmEventId(as.genAlarmEventIDImpl)
	// 注册告警重复检查和过滤函数（短时间内一个重复告警将不会被记录和告警）
	as.RegisterCheckRepeatedAlarm(as.checkAlarmRepeated)
	// 注册异步写数据库 函数
	as.RegisterAsyncWriteAlarm(as.asyncAlarmRecord)
	as.RegisterFilterAlarmResponse(as.filterAlarm)

	if in.fendAreas == nil || len(in.fendAreas) == 0 {
		logger.Infof("is no fend area check, tb_code: %v", in.tbCode)
		noAreaCheckParam := NewNoFendAreaCheckParam()
		toProcessParam = noAreaCheckParam

		tranInParamsToNoFendArea(in, noAreaCheckParam)
		as.RegisterFendAreaAlarmCheck(FendAreaTypeNoSet, as.checkNoFendAreaAlarmImpl)

	} else {
		areaCheckParam := NewCfgFendAreaCheckParams()
		toProcessParam = areaCheckParam

		//将请求参数转化内部处理 areaCheckParam 参数
		tranInParamsToCfgFendArea(in, areaCheckParam)

		//注册预警区 告警检测处理函数
		as.RegisterFendAreaAlarmCheck(FendAreaPreAlarmOnly, as.ProcessAlarmOnlyPreWarningImpl)

		// 注册核心区 告警检测处理函数
		as.RegisterFendAreaAlarmCheck(FendAreaTypeCoreOnly, as.ProcessAlarmOnlyCoreWarningImpl)

		// 注册预警+核心区， 存在相交， 告警检测处理函数
		as.RegisterFendAreaAlarmCheck(FendAreaTypePreCoreCross, as.ProcessForeAndCoreWarningInMixImpl)

		// 注册预警+核心区， 不存在相交， 告警检测处理函数
		as.RegisterFendAreaAlarmCheck(FendAreaTypePreCoreNoCross, as.ProcessPreCoreNotCrossImpl)
	}

	return as.checkAlarm(toProcessParam)
}

// AlarmRiskLevel 告警等级封装
type AlarmRiskLevel struct {
	RiskLevel int // 风险等级
	RiskScore int // 等级上的分数
	//
	Sn            string  // 无人机设备sn
	ObjId         string  //设备objID
	DevName       string  //设备名字
	C2Sn          string  //设备sn 对应的c2 sn
	UniqueId      int64   //请求id
	AreaId        int64   //围栏区id
	Longitude     float64 // 经度
	Latitude      float64 // 纬度
	AreaName      string  //围栏区名字
	DevRelations  []*pb.DevRelation
	TrackId       string // 目标事件id
	InboundAreaId []int64
}

// GetDevUnique 构建设备的标识,
func GetDevUnique(sn string, objId string, detectSn string) string {
	return fmt.Sprintf("%s:%s:%s", detectSn, sn, objId)
}

// getUavUniqueID 获取无人机唯一id. (tbcode:sn:objId)
func getUavUniqueID(tbCode string, devId string) string {
	return fmt.Sprintf("%s:%s", tbCode, devId)
}

// getCheckRepeatedAlarmKey 创建一个重复报警检查的唯一key
func getCheckRepeatedAlarmKey(tbCode string, devId string, eventId int64, riskLevel, riskScore int) string {
	return fmt.Sprintf("alarm_check_%s:%s:%d:%d:%d", tbCode, devId, eventId, riskLevel, riskScore)
}

func (as *AlarmStrategy) filterAlarm(items []*pb.AlarmCheckRspItem) []*pb.AlarmCheckRspItem {
	//首先要过滤掉最近删除的同等级下的告警。
	var ret = []*pb.AlarmCheckRspItem{}
	for index, _ := range items {
		if items[index] == nil {
			continue
		}

		exist, _ := NewLatestCacheAlarmRecord().IsDelItems(items[index].GetTbCode(), items[index].GetEventId(), items[index].GetRiskLevel())
		if exist {
			logger.Infof("tbCode: %v, id: %v, eventId: %v, riskLevel: %v has del",
				items[index].GetTbCode(), items[index].GetId(), items[index].GetEventId(), items[index].GetRiskLevel())
			continue
		}
		NewLatestAlarmCache(as.redisFendAreaOps).UpdateAlarmItem(items[index].GetTbCode(), items[index].GetEventId(), items[index])

		ret = append(ret, items[index])
	}
	return ret
}

// buildRespOnC2 构建只有c2且未设置围栏区下的报警等级和分数回包， 入参： 每个无人机在不同c2下的告警等级和分数
func (as *AlarmStrategy) buildRespOnC2(alarmInfos map[string]map[string]AlarmRiskLevel, //key: devsn_objId, key2: c2sn
	tbCode string) []*pb.AlarmCheckRspItem {

	var retData []*pb.AlarmCheckRspItem

	for uavItem, c2AlarmRisk := range alarmInfos {
		if uavItem == "" {
			continue
		}
		if c2AlarmRisk == nil || len(c2AlarmRisk) == 0 {
			continue
		}

		for c2Sn, alarmRiskLevelItem := range c2AlarmRisk {
			alarmEventID, expireTm, err := as.getIntrusionAlarmId(getUavUniqueID(tbCode, uavItem))
			if err != nil {
				logger.Errorf("produce alarm event id fail, err: %v, tbCode: %v", err, tbCode)
				continue
			}

			// check is repeated alarm. if repeated then omit it.
			//checkRepeatedKey := getCheckRepeatedAlarmKey(tbCode, uavItem, alarmEventID,
			//	alarmRiskLevelItem.RiskLevel, alarmRiskLevelItem.RiskScore)
			//
			//// 存在则忽略本次告警上报
			//if repeated, e := as.checkRepeatedAlarm(checkRepeatedKey); e != nil || repeated {
			//	logger.Infof("alarm repeated gen, omit report, tbCode: %v, devId: %v, alarmEventID: %v,"+
			//		"riskLevel: %v, riskScore: %v, e: %v, repeated: %v", tbCode, uavItem, alarmEventID,
			//		alarmRiskLevelItem.RiskLevel, alarmRiskLevelItem.RiskScore, e, repeated)
			//	continue
			//}

			alarmOpID, err := snowflake.GetUniqueID()
			if err != nil {
				logger.Errorf("create unique id fail, e: %v, tb_code: %v, sn: %v", err, tbCode, c2Sn)
				continue
			}

			retAlarmItem := &pb.AlarmCheckRspItem{
				Id:           alarmOpID,
				RiskLevel:    int32(alarmRiskLevelItem.RiskLevel),
				ThreatLevel:  int32(alarmRiskLevelItem.RiskScore),
				EventId:      alarmEventID,
				TbCode:       tbCode,
				Sn:           alarmRiskLevelItem.Sn,
				ObjId:        alarmRiskLevelItem.ObjId,
				DevName:      alarmRiskLevelItem.DevName,
				C2Sn:         alarmRiskLevelItem.C2Sn,
				CreateTime:   time.Now().UnixMilli(),
				DurTime:      time.Now().UnixMilli() - expireTm,
				AlarmType:    1,
				UniqueId:     alarmRiskLevelItem.UniqueId,
				Longitude:    alarmRiskLevelItem.Longitude,
				Latitude:     alarmRiskLevelItem.Latitude,
				DevRelations: alarmRiskLevelItem.DevRelations,
				TrackId:      alarmRiskLevelItem.TrackId,
			}
			retData = append(retData, retAlarmItem)
		}
	}

	//// 缓存最新的告警记录, 用于查询最近告警
	//for k, _ := range retData {
	//	NewLatestCacheAlarmRecord().SetItem(tbCode, retData[k])
	//}
	return retData
}

// checkDevIsDetectedBySn 检查 devSn中的sn 是否存在 c2Sn中。
func (as *AlarmStrategy) checkDevIsDetectedBySn(uavSn *pb.DevLocationInfo, c2Sn *pb.C2LocationInfo) bool {
	if c2Sn == nil || uavSn == nil {
		return false
	}
	for _, rel := range uavSn.GetDevRelations() {
		if rel == nil {
			continue
		}
		if rel.GetC2Sn() == c2Sn.GetSn() {
			return true
		}
	}
	logger.Infof("c2Sn: %v not in uav detect c2sn list", c2Sn.GetSn())
	return false
}

// checkNoFendAreaAlarmImpl 检查在没有围栏区时无人机告警; 存在对不是某个c2侦测到的无人机，也算出报警级别和风险分数
func (as *AlarmStrategy) checkNoFendAreaAlarmImpl(inParam any) (AlarmCheckResultPtr, error) {
	if inParam == nil {
		return nil, fmt.Errorf("in param is nil")
	}

	in, ok := inParam.(*noFendAreaCheckParam)
	if !ok || in == nil {
		return nil, fmt.Errorf("in param is nil")
	}

	if len(in.uavItems) == 0 {
		logger.Infof("uav is empty on check, tb_code: %v", in.tbCode)
		return nil, nil
	}

	if len(in.c2Loc) == 0 {
		logger.Errorf("c2 location is empty on check, tb_code: %v", in.tbCode)
		//需要设置一个默认告警级别
		return nil, nil
	}

	// 每个无人机下的多c2的风险等级和分数
	var alarmRiskOnDev = make(map[string]map[string]AlarmRiskLevel) //first key: dev, second key: c2 sn
	for _, uavItem := range in.uavItems {
		if uavItem == nil {
			continue
		}
		// add log.
		//logger.Infof("uav detail: %+v", uavItem)

		if uavItem.GetSn() == "" && uavItem.GetObjID() == "" {
			logger.Errorf("uav and objID has empty sn, tb_code: %v", in.tbCode)
			continue
		}

		if len(uavItem.GetDevRelations()) <= 0 {
			logger.Errorf("not any c2sn in for uav detect, tb_code: %v", in.tbCode)
			continue
		}

		var alarmRiskOnC2 map[string]AlarmRiskLevel //key: c2 sn
		for _, c2LocItem := range in.c2Loc {
			if c2LocItem == nil {
				continue
			}

			if c2LocItem.GetSn() == "" {
				logger.Errorf("not set c2 sn on calc risk level and score, tb_code: %v", in.tbCode)
				continue
			}

			if !as.checkDevIsDetectedBySn(uavItem, c2LocItem) {
				continue
			}

			var alarmLevelScore AlarmRiskLevel
			dist := geo.GeoDistance(uavItem.GetLongitude(), uavItem.GetLatitude(), c2LocItem.GetLongitude(), c2LocItem.GetLatitude())
			alarmLevelScore.RiskLevel, alarmLevelScore.RiskScore = CalcRiskOnNoFendArea(dist)
			//logger.Infof("risk level: %v, uav: %+v, c2 lon: %v, c2 lat: %v", alarmLevelScore.RiskLevel, uavItem, c2LocItem.GetLongitude(), c2LocItem.GetLatitude())

			alarmLevelScore.Sn = uavItem.GetSn()
			alarmLevelScore.ObjId = uavItem.GetObjID()
			alarmLevelScore.DevName = uavItem.GetName()
			alarmLevelScore.C2Sn = uavItem.GetC2Sn()
			alarmLevelScore.UniqueId = uavItem.GetUniqueId()
			alarmLevelScore.Longitude = uavItem.GetLongitude()
			alarmLevelScore.Latitude = uavItem.GetLatitude()
			alarmLevelScore.DevRelations = uavItem.GetDevRelations()
			alarmLevelScore.TrackId = uavItem.GetTrackId()

			if alarmRiskOnC2 == nil {
				alarmRiskOnC2 = make(map[string]AlarmRiskLevel) //Key: c2
			}

			if _, ok := alarmRiskOnC2[c2LocItem.GetSn()]; !ok {
				alarmRiskOnC2[c2LocItem.GetSn()] = alarmLevelScore

			} else {
				logger.Errorf("c2 sn: %v has repeated alarm level score for uav: %v, tb_code: %v", c2LocItem.GetSn(), uavItem.GetSn(), in.tbCode)
			}
		}

		if len(alarmRiskOnC2) == 0 {
			logger.Errorf("not get risk level and score on uav: %v, tb_code: %v", uavItem.GetSn(), in.tbCode)
			continue
		}

		// devId := GetDevUnique(uavItem.GetSn(), uavItem.GetObjID(), uavItem.GetDetectDevSn())
		devId := uavItem.GetUavUniqueId()
		if _, ok := alarmRiskOnDev[devId]; !ok {
			alarmRiskOnDev[devId] = alarmRiskOnC2
		} else {
			logger.Errorf("uav has repeated risk level sore, tb_code: %v, uav: %v", in.tbCode, uavItem.GetSn())
		}
	}

	var responseAlarmItems = as.buildRespOnC2(alarmRiskOnDev, in.tbCode)

	return &pb.AlarmCheckResponse{
		UavAlarmRiskLevelScores: responseAlarmItems,
	}, nil
}

// getSetFendAreaType 获取用户围栏区的种类
func getSetFendAreaType(fendAreas []*bean.FencedAreaConfig) int {
	var retType = 0b00 // 未设置任何围栏区

	for _, fendAreaItem := range fendAreas {
		if fendAreaItem == nil {
			continue
		}
		if fendAreaItem.AreaType == 1 { //预警区
			retType |= 0b01

		} else if fendAreaItem.AreaType == 2 { //核心区
			retType |= 0b10

		} else {
			logger.Infof("not support fend area type: %v, tb_code: %v", fendAreaItem.AreaType, fendAreaItem.TbCode)
			return -1
		}
	}
	switch retType {
	case 0b00:
		return FendAreaTypeNoSet
	case 0b01:
		return FendAreaPreAlarmOnly
	case 0b10:
		return FendAreaTypeCoreOnly
	case 0b11:
		return FendAreaTypePreCoreCross
	default:
		return -1
	}
}

// AlarmRiskLevelScoreOnCore 计算无人机在一个核心围栏区的告警等级和分数
func (as *AlarmStrategy) AlarmRiskLevelScoreOnCore(tbCode string, uav *pb.DevLocationInfo,
	fendArea *bean.FencedAreaConfig, fendAreaLonLat *geo.PolygonUnionList) (*AlarmRiskLevel, error) {

	if uav == nil || fendArea == nil {
		return nil, fmt.Errorf("uav or fend area is empty, tb_code: %v", tbCode)
	}

	// 判断是是否在围栏区内
	exist, err := geo.GeoCheckPointInPolygons(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonListItems)
	if err != nil {
		logger.Errorf("calc uav in fend area fail, err: %v, uav: %v, fend area: %v", err, uav, fendArea)
		return nil, fmt.Errorf("check in polygons fail, e: %v", err)
	}

	var ret = &AlarmRiskLevel{
		Sn:      uav.GetSn(),
		ObjId:   uav.GetObjID(),
		DevName: uav.GetName(),
	}

	if exist { // 高危险等级: 进入核心区
		diff := geo.GeoDistance(uav.GetLongitude(), uav.GetLatitude(), fendArea.CentroidLongitude, fendArea.CentroidLatitude)
		ret.RiskLevel, ret.RiskScore = CalcHighRiskScoreOnlyCoreFendArea(diff)
		return ret, nil
	}

	// 中低等级
	intersection := geo.GeoCalcMiniDistanceToPolygonsByDistance(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonPointListItems, 500)
	ret.RiskLevel, ret.RiskScore = CalcRiskScoreOnCoreFendArea(0, intersection)
	return ret, nil
}

// ProcessAlarmOnlyCoreWarningImpl 仅设置核心区的告警检查
func (as *AlarmStrategy) ProcessAlarmOnlyCoreWarningImpl(inParam any) (AlarmCheckResultPtr, error) {
	if inParam == nil {
		return nil, nil
	}
	in, ok := inParam.(*cfgFendAreaCheckParam)
	if !ok || in == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	if len(in.uavItems) == 0 {
		logger.Errorf("uav is empty, tbCode: %v", in.tbCode)
		return nil, nil
	}

	if len(in.fendAreas) <= 0 {
		logger.Errorf("core fend area not be set, tbCode: %v", in.tbCode)
		return nil, fmt.Errorf("core fend area not set, tbCode: %v", in.tbCode)
	}

	var inboundAreaId []int64
	// 开始进入 低危险等级
	var uavRiskLevelScore = make(map[string]AlarmRiskLevel) //key: 无人机sn
	for _, uav := range in.uavItems {
		if uav == nil {
			continue
		}

		var (
			riskLevel = RiskAlarmLow
			score     = lowLower
		)

		var areaId int64 = 0
		var areaName string = ""
		for _, fendArea := range in.fendAreas {
			if fendArea == nil {
				continue
			}

			fendAreaLonLatItem, ok := in.coreAlarmArea[fendArea.ID]
			if !ok || fendAreaLonLatItem == nil {
				logger.Errorf("core fend area not parse to lon,lat, value: %+v", fendArea)
				continue
			}

			// 计算无人机在一个围栏区的告警等级和分数
			tmpRiskScore, err := as.AlarmRiskLevelScoreOnCore(in.tbCode, uav, fendArea, fendAreaLonLatItem)
			if err != nil {
				logger.Info("calc risk level score, err: %v", err)
				continue
			}
			// 3. 若用户已设置核心区但未设预警区 高威胁等级：目标进入核心区时。
			if tmpRiskScore.RiskLevel == RiskAlarmHigh {
				inboundAreaId = append(inboundAreaId, fendArea.ID)
			}

			// 对每个无人机获取告警级别更高，分数更高的无人机
			riskLevel, score = CalcUavRiskScoreOnFendAreas(riskLevel, score, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
			if riskLevel == tmpRiskScore.RiskLevel && score == tmpRiskScore.RiskScore {
				areaId = fendArea.ID
				areaName = fendArea.AreaName
			}
		}
		// devId := GetDevUnique(uav.GetSn(), uav.GetObjID(), uav.GetDetectDevSn())
		devId := uav.GetUavUniqueId()
		uavRiskLevelScore[devId] = AlarmRiskLevel{
			RiskLevel:     riskLevel,
			RiskScore:     score,
			Sn:            uav.GetSn(),
			ObjId:         uav.GetObjID(),
			DevName:       uav.GetName(),
			C2Sn:          uav.GetC2Sn(),
			UniqueId:      uav.GetUniqueId(),
			AreaId:        areaId,
			Longitude:     uav.GetLongitude(), // 经度
			Latitude:      uav.GetLatitude(),  // 纬度
			AreaName:      areaName,
			DevRelations:  uav.GetDevRelations(),
			TrackId:       uav.GetTrackId(),
			InboundAreaId: inboundAreaId,
		}
	}

	var responseAlarmItems = as.buildRespOnFendArea(uavRiskLevelScore, in.tbCode)

	return &pb.AlarmCheckResponse{
		UavAlarmRiskLevelScores: responseAlarmItems,
	}, nil
}

// buildRespOnOneFendArea 根据单个告警级别构建 回包
func (as *AlarmStrategy) buildRespOnOneFendArea(uavId string, alarmOne AlarmRiskLevel, tbCode string) *pb.AlarmCheckRspItem {
	var retData *pb.AlarmCheckRspItem
	if uavId == "" {
		return nil
	}

	alarmEventID, expireTm, err := as.getIntrusionAlarmId(getUavUniqueID(tbCode, uavId))
	if err != nil {
		logger.Errorf("produce alarm event id fail, err: %v, tbCode: %v", err, tbCode)
		return nil
	}

	alarmOpID, err := snowflake.GetUniqueID()
	if err != nil {
		logger.Errorf("create unique id fail, e: %v, tb_code: %v", err, tbCode)
		return nil
	}

	retData = &pb.AlarmCheckRspItem{
		Id:             alarmOpID,
		RiskLevel:      int32(alarmOne.RiskLevel),
		ThreatLevel:    int32(alarmOne.RiskScore),
		EventId:        alarmEventID,
		Sn:             alarmOne.Sn,
		ObjId:          alarmOne.ObjId,
		DevName:        alarmOne.DevName,
		C2Sn:           alarmOne.C2Sn,
		AlarmType:      0,
		TbCode:         tbCode,
		DurTime:        time.Now().UnixMilli() - expireTm,
		CreateTime:     time.Now().UnixMilli(),
		UniqueId:       alarmOne.UniqueId,
		AreaId:         alarmOne.AreaId,
		Longitude:      alarmOne.Longitude, // 经度
		Latitude:       alarmOne.Latitude,  // 纬度
		AreaName:       alarmOne.AreaName,
		DevRelations:   alarmOne.DevRelations,
		TrackId:        alarmOne.TrackId,
		InboundAreaIds: alarmOne.InboundAreaId,
	}
	return retData
}

// buildAlarmRiskScoreOnFendAreaResp 构建在有围栏区下 告警等级和分数回包 /*key: sn:objid */
func (as *AlarmStrategy) buildRespOnFendArea(alarmInfo map[string]AlarmRiskLevel, tbCode string) []*pb.AlarmCheckRspItem {
	var retData []*pb.AlarmCheckRspItem

	for uavID, fendAreaRiskScore := range alarmInfo {
		if uavID == "" {
			continue
		}

		retAlarmItem := as.buildRespOnOneFendArea(uavID, fendAreaRiskScore, tbCode)
		if retAlarmItem != nil {
			retData = append(retData, retAlarmItem)
		}
	}

	//// 缓存最新的告警记录, 用于查询最近告警
	//for k, _ := range retData {
	//	NewLatestCacheAlarmRecord().SetItem(tbCode, retData[k])
	//}

	return retData
}

// AlarmRiskLevelScoreOnForeWarning 计算 only 预警区下的无人机告警级别和分数; high 目标进入预警区时
func (as *AlarmStrategy) AlarmRiskLevelScoreOnForeWarning(tbCode string, uav *pb.DevLocationInfo,
	fendArea *bean.FencedAreaConfig, fendAreaLonLat *geo.PolygonUnionList) (*AlarmRiskLevel, error) {

	if uav == nil || fendArea == nil || fendAreaLonLat == nil {
		return nil, fmt.Errorf("uav or fend area is empty, tb_code: %v", tbCode)
	}

	// 判断是是否在围栏区内
	exist, err := geo.GeoCheckPointInPolygons(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonListItems)
	if err != nil {
		logger.Errorf("calc uav in fend area fail, err: %v, uav: %v, fend area: %v",
			err, uav, fendArea)
		return nil, fmt.Errorf("check in polygons fail, e: %v", err)
	}

	var ret = &AlarmRiskLevel{}
	if exist { // 高危险等级: 进入预警区
		diff := geo.GeoDistance(uav.GetLongitude(), uav.GetLatitude(), fendArea.CentroidLatitude, fendArea.CentroidLatitude)
		ret.RiskLevel, ret.RiskScore = CalcHighRiskScoreOnlyForeFendArea(diff)
		return ret, nil
	}

	// 中低等级,画圆是否有交集
	intersection := geo.GeoCalcMiniDistanceToPolygonsByDistance(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonPointListItems, 500)
	//
	ret.RiskLevel, ret.RiskScore = CalcRiskScoreOnlyForeFendArea(0, intersection)
	return ret, nil
}

// AlarmRiskLevelScoreForeInMix 计算 单个飞机在 mix(pre+core)时，单算pre 围栏区下的 等级和分数
func (as *AlarmStrategy) AlarmRiskLevelScoreForeInMix(tbCode string, uav *pb.DevLocationInfo,
	fendArea *bean.FencedAreaConfig, fendAreaLonLat geo.PolygonList, isBound *bool) (*AlarmRiskLevel, error) {
	if uav == nil || fendArea == nil {
		return nil, fmt.Errorf("uav or fend area is empty, tb_code: %v", tbCode)
	}

	// 判断是是否在围栏区内
	exist, err := geo.GeoCheckPointInPolygons(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat)
	if err != nil {
		logger.Errorf("calc uav in fend area fail, err: %v, uav: %v, fend area: %v",
			err, uav, fendArea)
		return nil, fmt.Errorf("check in polygons fail, e: %v", err)
	}
	if exist {
		*isBound = exist
	}

	var ret = &AlarmRiskLevel{}
	if !exist {
		ret.RiskLevel, ret.RiskScore = RiskAlarNo, 0 // 无威胁等级（不触发告警）：目标在侦测范围内，但不在预警区内时
		return ret, nil
	}
	//这个分数没有策略来计算
	ret.RiskLevel, ret.RiskScore = RiskAlarmLow, lowLower
	return ret, nil
}

// AlarmRiskLevelScoreCoreInMix 计算单个飞机在mix(pre+core)时， 单算 core 围栏区下的 等级和分数
func (as *AlarmStrategy) AlarmRiskLevelScoreCoreInMix(tbCode string, uav *pb.DevLocationInfo,
	fendArea *bean.FencedAreaConfig, fendAreaLonLat *geo.PolygonUnionList, inbound *bool) (*AlarmRiskLevel, error) {

	if uav == nil || fendArea == nil {
		return nil, fmt.Errorf("uav or fend area is empty, tb_code: %v", tbCode)
	}

	// 判断是是否在围栏区内
	exist, err := geo.GeoCheckPointInPolygons(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonListItems)
	if err != nil {
		logger.Errorf("calc uav in fend area fail, err: %v, uav: %v, fend area: %v",
			err, uav, fendArea)
		return nil, fmt.Errorf("check in polygons fail, e: %v", err)
	}
	if exist {
		*inbound = exist
	}

	var ret = &AlarmRiskLevel{}
	if exist {
		diff := geo.GeoDistance(uav.GetLongitude(), uav.GetLatitude(), fendArea.CentroidLatitude, fendArea.CentroidLatitude)
		ret.RiskLevel, ret.RiskScore = CalcHighRiskScoreOnlyCoreFendArea(diff)
		return ret, nil
	}
	//
	intersection500 := geo.GeoCalcMiniDistanceToPolygonsByDistance(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonPointListItems, 500)
	intersection2000 := geo.GeoCalcMiniDistanceToPolygonsByDistance(uav.GetLongitude(), uav.GetLatitude(), fendAreaLonLat.PolygonPointListItems, 2000)
	ret.RiskLevel, ret.RiskScore = CalcRiskScoreOnCoreInMix(0, intersection500, intersection2000)
	return ret, nil
}

// ProcessAlarmOnlyPreWarningImpl 仅设置预警区的告警检查
func (as *AlarmStrategy) ProcessAlarmOnlyPreWarningImpl(inParam any) (AlarmCheckResultPtr, error) {
	if inParam == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	in, ok := inParam.(*cfgFendAreaCheckParam)
	if !ok || in == nil {
		return nil, fmt.Errorf("inparam is not *cfgFendAreaCheckParam")
	}

	if len(in.uavItems) == 0 {
		logger.Errorf("uav is empty, tbCode: %v", in.tbCode)
		return nil, nil
	}

	if len(in.fendAreas) == 0 {
		logger.Errorf("pre fend area not be set, tbCode: %v", in.tbCode)
		return nil, fmt.Errorf("pre fend area not set, tbCode: %v", in.tbCode)
	}

	// 开始进入 低危险等级； 计算无人机的告警级别
	var uavRiskLevelScore = make(map[string]AlarmRiskLevel)
	for _, uav := range in.uavItems {
		if uav == nil {
			continue
		}

		var (
			riskLevel = -1
			score     = 1
		)

		var areaId int64 = 0
		var areaName string = ""
		var inboundAreaId []int64

		for index, _ := range in.fendAreas {
			if in.fendAreas[index] == nil {
				continue
			}

			fendAreaLonLatItem, ok := in.preAlarmArea[in.fendAreas[index].ID]
			if !ok || fendAreaLonLatItem == nil {
				logger.Errorf("pre fend area not parse to lon,lat, value: %+v", in.fendAreas[index])
				continue
			}

			// 计算无人机在一个围栏区的告警等级和分数
			tmpRiskScore, err := as.AlarmRiskLevelScoreOnForeWarning(in.tbCode, uav, in.fendAreas[index], fendAreaLonLatItem)
			if err != nil {
				logger.Info("calc risk level score, err: %v", err)
				continue
			}

			// 2. 若用户已设置预警区但未设核心区; 高威胁等级：目标进入预警区时
			if tmpRiskScore.RiskLevel == RiskAlarmHigh {
				inboundAreaId = append(inboundAreaId, in.fendAreas[index].ID)
			}

			// 对每个无人机获取告警级别更高，分数更高的告警
			riskLevel, score = CalcUavRiskScoreOnFendAreas(riskLevel, score, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
			if tmpRiskScore.RiskLevel == riskLevel && tmpRiskScore.RiskScore == score {
				areaId = in.fendAreas[index].ID
				areaName = in.fendAreas[index].AreaName
			}
		}
		// devId := GetDevUnique(uav.GetSn(), uav.GetObjID(), uav.GetDetectDevSn())
		devId := uav.GetUavUniqueId()
		uavRiskLevelScore[devId] = AlarmRiskLevel{
			RiskLevel:     riskLevel,
			RiskScore:     score,
			Sn:            uav.GetSn(),
			ObjId:         uav.GetObjID(),
			DevName:       uav.GetName(),
			C2Sn:          uav.GetC2Sn(),
			UniqueId:      uav.GetUniqueId(),
			AreaId:        areaId,
			Longitude:     uav.GetLongitude(),
			Latitude:      uav.GetLatitude(),
			AreaName:      areaName,
			DevRelations:  uav.GetDevRelations(),
			TrackId:       uav.GetTrackId(),
			InboundAreaId: inboundAreaId,
		}
	}

	var responseAlarmItems = as.buildRespOnFendArea(uavRiskLevelScore, in.tbCode)

	return &pb.AlarmCheckResponse{
		UavAlarmRiskLevelScores: responseAlarmItems,
	}, nil
}

// NotifyDelAlarmStatusOnRisk0 当告警降为0， 则需要通知删除前次最新的告警。
func (as *AlarmStrategy) NotifyDelAlarmStatusOnRisk0(tbCode string, eventId int64) {
	alarmCacheHandle := NewLatestAlarmCache(as.redisFendAreaOps)
	cache, err := alarmCacheHandle.GetLatestAlarmCacheItem(tbCode, eventId)
	if err != nil || cache == nil {
		if e := NewLatestAlarmCache(as.redisFendAreaOps).DelAlarmItem(tbCode, eventId); e != nil {
			logger.Error("del latest alarm item fail, for tbcode: %v, eventId: %v", tbCode, eventId)
			return
		} else {
			//logger.Infof("del tb code: %v, eventId: %v", tbCode, eventId)
		}
		return
	}

	if e := NewLatestAlarmCache(as.redisFendAreaOps).DelAlarmItem(tbCode, eventId); e != nil {
		logger.Error("del latest alarm item fail, for tbcode: %v, eventId: %v", tbCode, eventId)
		return
	}
	logger.Infof("del latest alarm item succ, tbCode: %v, eventId: %v", tbCode, eventId)
	notifyHandle := NewAlarmStatusUpdateNotify()
	//通知 其他端来拉取最新的数据，同步作用
	toNotice := make(map[int64]*pb.AlarmStatusUpdateItem)
	toNotice[cache.GetId()] = &pb.AlarmStatusUpdateItem{
		Id:        fmt.Sprintf("%d", cache.GetId()),
		EventId:   fmt.Sprintf("%d", eventId),
		Status:    4,
		RiskLevel: cache.GetRiskLevel(),
		TbCode:    tbCode,
	}
	notifyHandle.FlagNonAlarmReport(toNotice, false)
	notifyHandle.Notify(toNotice, tbCode)
}

// ProcessPreCoreNotCrossImpl 实现 具有 预警 + 核心，但是不存在交叉的围栏区告警处理
func (as *AlarmStrategy) ProcessPreCoreNotCrossImpl(inParam any) (AlarmCheckResultPtr, error) {
	if inParam == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	in, ok := inParam.(*cfgFendAreaCheckParam)
	if !ok || in == nil {
		return nil, fmt.Errorf("inparam is not *cfgFendAreaCheckParam")
	}

	if len(in.uavItems) == 0 {
		logger.Errorf("uav is empty, tbCode: %v", in.tbCode)
		return nil, nil
	}

	if len(in.fendAreas) == 0 {
		logger.Errorf("pre fend area not be set, tbCode: %v", in.tbCode)
		return nil, fmt.Errorf("pre fend area not set, tbCode: %v", in.tbCode)
	}

	//计算所有预警区的告警
	var uavRiskLevelScore = make(map[string]AlarmRiskLevel)
	for _, uav := range in.uavItems {
		if uav == nil {
			continue
		}

		var (
			preAreaId    int64  = 0
			preAreaName  string = ""
			preRiskLevel        = -1
			preScore            = 1

			//
			coreAreaId    int64  = 0
			coreAreaName  string = ""
			coreRiskLevel        = RiskAlarmLow
			coreScore            = lowLower
		)

		var inboundAreaId []int64

		// 计算预警区下的告警
		calcPreAreaAlarm := func() {
			for index, _ := range in.fendAreas {
				if in.fendAreas[index] == nil {
					continue
				}

				fendAreaLonLatItem, ok := in.preAlarmArea[in.fendAreas[index].ID]
				if !ok || fendAreaLonLatItem == nil {
					continue
				}

				// 计算无人机在一个围栏区的告警等级和分数
				tmpRiskScore, err := as.AlarmRiskLevelScoreOnForeWarning(in.tbCode, uav, in.fendAreas[index], fendAreaLonLatItem)
				if err != nil {
					logger.Info("calc risk level score, err: %v", err)
					continue
				}

				// 2. 若用户已设置预警区但未设核心区; 高威胁等级：目标进入预警区时
				if tmpRiskScore.RiskLevel == RiskAlarmHigh {
					inboundAreaId = append(inboundAreaId, in.fendAreas[index].ID)
				}

				// 对每个无人机获取告警级别更高，分数更高的告警
				preRiskLevel, preScore = CalcUavRiskScoreOnFendAreas(preRiskLevel, preScore, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
				if tmpRiskScore.RiskLevel == preRiskLevel && tmpRiskScore.RiskScore == preScore {
					preAreaId = in.fendAreas[index].ID
					preAreaName = in.fendAreas[index].AreaName
				}
			}
		}

		// 计算核心区下的告警
		calcCoreAreaAlarm := func() {
			for _, fendArea := range in.fendAreas {
				if fendArea == nil {
					continue
				}

				fendAreaLonLatItem, ok := in.coreAlarmArea[fendArea.ID]
				if !ok || fendAreaLonLatItem == nil {
					continue
				}

				// 计算无人机在一个围栏区的告警等级和分数
				tmpRiskScore, err := as.AlarmRiskLevelScoreOnCore(in.tbCode, uav, fendArea, fendAreaLonLatItem)
				if err != nil {
					logger.Info("calc risk level score, err: %v", err)
					continue
				}

				// 3. 若用户已设置核心区但未设预警区 高威胁等级：目标进入核心区时。
				if tmpRiskScore.RiskLevel == RiskAlarmHigh {
					inboundAreaId = append(inboundAreaId, fendArea.ID)
				}

				// 对每个无人机获取告警级别更高，分数更高的无人机
				coreRiskLevel, coreScore = CalcUavRiskScoreOnFendAreas(coreRiskLevel, coreScore, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
				if coreRiskLevel == tmpRiskScore.RiskLevel && coreScore == tmpRiskScore.RiskScore {
					coreAreaId = fendArea.ID
					coreAreaName = fendArea.AreaName
				}
			}
		}

		calcPreAreaAlarm()
		calcCoreAreaAlarm()

		var riskLevel int
		var score int
		var areaId int64
		var areaName string

		if preRiskLevel < coreRiskLevel {
			riskLevel = coreRiskLevel
			score = coreScore
			areaId = coreAreaId
			areaName = coreAreaName

		} else if preRiskLevel == coreRiskLevel {
			if preScore <= coreScore {
				riskLevel = coreRiskLevel
				score = coreScore
				areaId = coreAreaId
				areaName = coreAreaName
			} else {
				riskLevel = preRiskLevel
				score = preScore
				areaId = preAreaId
				areaName = preAreaName
			}

		} else {
			riskLevel = preRiskLevel
			score = preScore
			areaId = preAreaId
			areaName = preAreaName
		}

		// devId := GetDevUnique(uav.GetSn(), uav.GetObjID(), uav.GetDetectDevSn())
		devId := uav.GetUavUniqueId()
		uavRiskLevelScore[devId] = AlarmRiskLevel{
			RiskLevel:     riskLevel,
			RiskScore:     score,
			Sn:            uav.GetSn(),
			ObjId:         uav.GetObjID(),
			DevName:       uav.GetName(),
			C2Sn:          uav.GetC2Sn(),
			UniqueId:      uav.GetUniqueId(),
			AreaId:        areaId,
			Longitude:     uav.GetLongitude(),
			Latitude:      uav.GetLatitude(),
			AreaName:      areaName,
			DevRelations:  uav.GetDevRelations(),
			TrackId:       uav.GetTrackId(),
			InboundAreaId: inboundAreaId,
		}
	}
	var responseAlarmItems = as.buildRespOnFendArea(uavRiskLevelScore, in.tbCode)

	return &pb.AlarmCheckResponse{
		UavAlarmRiskLevelScores: responseAlarmItems,
	}, nil
}

// ProcessForeAndCoreWarningInMixImpl 对设置核心区+预警区的告警检查
func (as *AlarmStrategy) ProcessForeAndCoreWarningInMixImpl(inParam any) (AlarmCheckResultPtr, error) {
	if inParam == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	in, ok := inParam.(*cfgFendAreaCheckParam)
	if !ok || in == nil {
		return nil, fmt.Errorf("input param is nil")
	}

	if len(in.uavItems) == 0 {
		logger.Errorf("uav is empty, tbCode: %v", in.tbCode)
		return nil, nil
	}

	if len(in.fendAreas) <= 0 {
		logger.Errorf("mix pre_core fend area not be set, tbCode: %v", in.tbCode)
		return nil, fmt.Errorf("mix pre_core fend area not set, tbCode: %v", in.tbCode)
	}

	var (
		preFendArea       []*bean.FencedAreaConfig
		preFendAreaLonLat = make(map[int64]*geo.PolygonUnionList) // key 是 围栏区的id

		coreFendArea       []*bean.FencedAreaConfig
		coreFendAreaLonLat = make(map[int64]*geo.PolygonUnionList) //key is 围栏区id
	)

	// 根据已有的围栏区内， 从混合围栏区内 mixAlarmArea 挑选出预警，核心区； 分别算出告警等级，然后根据 mix 模式下做聚合。
	for index, _ := range in.fendAreas {
		if in.fendAreas[index] == nil {
			continue
		}

		if in.fendAreas[index].AreaType == ForeAlarmArea { // 预警区
			preFendArea = append(preFendArea, in.fendAreas[index])
			lonLatFendArea, ok := in.mixAlarmArea[in.fendAreas[index].ID]

			if !ok {
				logger.Errorf("not exist lon lat fend area, fend area id: %v", in.fendAreas[index].ID)
			} else {
				preFendAreaLonLat[in.fendAreas[index].ID] = lonLatFendArea
			}

		} else if in.fendAreas[index].AreaType == CoreAlarmArea { // 核心区
			coreFendArea = append(coreFendArea, in.fendAreas[index])
			lonLatFendArea, ok := in.mixAlarmArea[in.fendAreas[index].ID]

			if !ok {
				logger.Errorf("not exist lon lat fend area, fend area id: %v", in.fendAreas[index].ID)
			} else {
				coreFendAreaLonLat[in.fendAreas[index].ID] = lonLatFendArea
			}
		} else {
		}
	}

	var (
		inPreFendAreaMix = &cfgFendAreaCheckParam{
			tbCode:         in.tbCode,
			uavItems:       in.uavItems,
			fendAreas:      preFendArea,
			fendAreaLonLat: preFendAreaLonLat,
		}

		inCoreFendAreaMix = &cfgFendAreaCheckParam{
			tbCode:         in.tbCode,
			uavItems:       in.uavItems,
			fendAreas:      coreFendArea,
			fendAreaLonLat: coreFendAreaLonLat,
		}
	)

	//4. 若用户已设置预警区和核心区
	//无威胁等级（不触发告警）：目标在侦测范围内，但不在预警区内时。
	//低威胁等级：目标进入预警区时。
	//中威胁等级：目标到核心区的距离介于500m至2000m时。
	//高威胁等级：目标到核心区的最近距离小于等于500m及进入核心区时。

	levelScorePreInMix, preErr := as.calcPreFendAreaWithinMix(inPreFendAreaMix)
	levelScoreCoreInMix, coreErr := as.calcCoreFendAreaWithinMix(inCoreFendAreaMix)

	// 所有设备经历过的围栏区列表
	var inboundAreaId map[string][]int64 = make(map[string][]int64)

	// 将所有设备 经历的 围栏区存储起来
	for dev, info := range levelScorePreInMix {
		items := inboundAreaId[dev]
		items = append(items, info.InboundAreaId...)
		inboundAreaId[dev] = items
	}

	for dev, info := range levelScoreCoreInMix {
		items := inboundAreaId[dev]
		items = append(items, info.InboundAreaId...)
		inboundAreaId[dev] = items
	}

	if preErr != nil && coreErr != nil {
		logger.Errorf("calc pre and core in mix fend area fail, e1: %v, e2: %v", preErr, coreErr)
		return nil, fmt.Errorf("calc fend area fail")
	}

	var responseAlarmItems []*pb.AlarmCheckRspItem
	if preErr == nil && coreErr != nil {
		logger.Errorf("pre alarm area is ok, core alarm area fail")

		for devId, _ := range levelScorePreInMix {
			if levelScorePreInMix[devId].RiskLevel == RiskAlarNo {
				//删除不触发告警的记录
				delete(levelScorePreInMix, devId)

				alarmEventID, _, _ := as.getIntrusionAlarmId(getUavUniqueID(in.tbCode, devId))
				as.NotifyDelAlarmStatusOnRisk0(in.tbCode, alarmEventID)
				continue
			}

			items, _ := inboundAreaId[devId]
			if len(items) > 0 {
				alarmInfo := levelScorePreInMix[devId]
				alarmInfo.InboundAreaId = items
				levelScorePreInMix[devId] = alarmInfo
			}
		}

		responseAlarmItems = as.buildRespOnFendArea(levelScorePreInMix, in.tbCode)

		return &pb.AlarmCheckResponse{
			UavAlarmRiskLevelScores: responseAlarmItems,
		}, nil
	}

	if preErr != nil && coreErr == nil {
		logger.Infof("pre alarm area fail, core alarm area is ok")
		for devId, _ := range levelScoreCoreInMix {
			if levelScoreCoreInMix[devId].RiskLevel == RiskAlarNo {
				//删除不触发告警的记录
				delete(levelScoreCoreInMix, devId)
				continue
			}

			items, _ := inboundAreaId[devId]
			if len(items) > 0 {
				alarmInfo := levelScoreCoreInMix[devId]
				alarmInfo.InboundAreaId = items
				levelScoreCoreInMix[devId] = alarmInfo
			}
		}

		responseAlarmItems = as.buildRespOnFendArea(levelScoreCoreInMix, in.tbCode)

		return &pb.AlarmCheckResponse{
			UavAlarmRiskLevelScores: responseAlarmItems,
		}, nil
	}

	var mixResponseAlarmItems []*pb.AlarmCheckRspItem

	// 先优先处理高危险等级的告警， 同时删除低优先级的记录; (当核心区算出来的是无危险等级，需要和预警区的等级比较。)
	for devId, _ := range levelScoreCoreInMix {
		coreAlarm := levelScoreCoreInMix[devId]

		if coreAlarm.RiskLevel != RiskAlarNo { //已经进入中或高等级威胁，不需要检查预警区的告警
			if _, ok := levelScorePreInMix[devId]; ok {
				delete(levelScorePreInMix, devId)
			}

		} else {

			//核心区的无风险等级，可能进入预警的低危险，需要比对下，取两者风险等级最高的。
			if _, ok := levelScorePreInMix[devId]; ok {
				if levelScorePreInMix[devId].RiskLevel > coreAlarm.RiskLevel {
					//暂时不删除预警区的风险等级; 也不算核心区风险等级
					continue
				} else {
					delete(levelScorePreInMix, devId)
				}
			}
		}

		if coreAlarm.RiskLevel == RiskAlarNo {
			alarmEventID, _, _ := as.getIntrusionAlarmId(getUavUniqueID(in.tbCode, devId))
			as.NotifyDelAlarmStatusOnRisk0(in.tbCode, alarmEventID)

			logger.Infof("not to report risk, core fend area risk level: %v, eventId: %v", coreAlarm.RiskLevel, alarmEventID)
			continue
		}

		items, _ := inboundAreaId[devId]
		if len(items) > 0 {
			coreAlarm.InboundAreaId = items
		}

		item := as.buildRespOnOneFendArea(devId, coreAlarm, in.tbCode)
		if item != nil {
			mixResponseAlarmItems = append(mixResponseAlarmItems, item)
		}
	}

	// 最后处理剩下低优先级的危险告警
	for devId, _ := range levelScorePreInMix {
		preAlarm := levelScorePreInMix[devId]

		items, _ := inboundAreaId[devId]
		if len(items) > 0 {
			preAlarm.InboundAreaId = items
		}

		item := as.buildRespOnOneFendArea(devId, preAlarm, in.tbCode)
		if item != nil {
			mixResponseAlarmItems = append(mixResponseAlarmItems, item)
		}
	}

	if len(mixResponseAlarmItems) > 0 {
		responseAlarmItems = append(responseAlarmItems, mixResponseAlarmItems[:]...)
	}

	return &pb.AlarmCheckResponse{
		UavAlarmRiskLevelScores: responseAlarmItems,
	}, nil
}

// calcCoreFendAreaWithinMix 计算混合模式下核心区的无人机风险等级和分数
func (as *AlarmStrategy) calcCoreFendAreaWithinMix(in *cfgFendAreaCheckParam) (map[string]AlarmRiskLevel, error) {
	if in == nil {
		return nil, fmt.Errorf("input is nil")
	}
	var uavRiskLevelScore = make(map[string]AlarmRiskLevel) //key is dev sn

	for index, _ := range in.uavItems {
		uav := in.uavItems[index]
		if uav == nil {
			continue
		}

		var (
			riskLevel        = RiskAlarNo
			score            = middleLower
			areaId    int64  = 0
			areaName  string = ""
		)

		var inBoundAreaId []int64
		for index2, _ := range in.fendAreas {
			fendArea := in.fendAreas[index2]
			if fendArea == nil {
				continue
			}

			fendAreaLonLatItem, ok := in.fendAreaLonLat[fendArea.ID]
			if !ok {
				logger.Errorf("core in mix fend area not parse to lon,lat, value: %+v", fendArea)
				continue
			}

			var inBound = false
			// 计算无人机在一个围栏区的告警等级和分数 AlarmRiskLevelScoreCoreInMix
			tmpRiskScore, err := as.AlarmRiskLevelScoreCoreInMix(in.tbCode, uav, fendArea, fendAreaLonLatItem, &inBound)
			if err != nil {
				logger.Info("calc risk level score, err: %v", err)
				continue
			}

			if inBound {
				inBoundAreaId = append(inBoundAreaId, fendArea.ID)
			}

			// 对每个无人机获取告警级别更高，分数更高的无人机
			riskLevel, score = CalcUavRiskScoreOnFendAreas(riskLevel, score, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
			if riskLevel == tmpRiskScore.RiskLevel && score == tmpRiskScore.RiskScore {
				areaId = fendArea.ID
				areaName = fendArea.AreaName
			}
		}
		// devId := GetDevUnique(uav.GetSn(), uav.GetObjID(), uav.GetDetectDevSn())
		devId := uav.GetUavUniqueId()
		uavRiskLevelScore[devId] = AlarmRiskLevel{
			RiskLevel:     riskLevel,
			RiskScore:     score,
			Sn:            uav.GetSn(),
			ObjId:         uav.GetObjID(),
			DevName:       uav.GetName(),
			C2Sn:          uav.GetC2Sn(),
			AreaId:        areaId,
			UniqueId:      uav.GetUniqueId(),
			Longitude:     uav.GetLongitude(), // 经度
			Latitude:      uav.GetLatitude(),  // 纬度
			AreaName:      areaName,
			DevRelations:  uav.GetDevRelations(),
			TrackId:       uav.GetTrackId(),
			InboundAreaId: inBoundAreaId,
		}
	}
	return uavRiskLevelScore, nil
}

// calcPreFendAreaWithinMix 获取 无人机列表 在 混合模式下 pre 围栏区的 告警等级和分数
func (as *AlarmStrategy) calcPreFendAreaWithinMix(in *cfgFendAreaCheckParam) (map[string]AlarmRiskLevel, error) {
	if in == nil {
		return nil, fmt.Errorf("input is nil")
	}
	var uavRiskLevelScore = make(map[string]AlarmRiskLevel) //key is dev sn

	for index1, _ := range in.uavItems { //每个无人机
		uav := in.uavItems[index1]
		if uav == nil {
			continue
		}

		var (
			riskLevel = RiskAlarNo
			score     = lowLower
		)

		var areaId int64 = 0
		var areaName string = ""
		var inboundAreaId []int64

		for index2, _ := range in.fendAreas {
			fendArea := in.fendAreas[index2]
			if fendArea == nil {
				continue
			}

			fendAreaLonLatItem, ok := in.fendAreaLonLat[fendArea.ID] //围栏区经纬度
			if !ok || fendAreaLonLatItem == nil {
				logger.Errorf("pre in mix fend area not parse to lon,lat, value: %+v", fendArea)
				continue
			}

			var isInbound bool = false
			// 计算无人机在一个围栏区的告警等级和分数
			tmpRiskScore, err := as.AlarmRiskLevelScoreForeInMix(in.tbCode, uav, fendArea, fendAreaLonLatItem.PolygonListItems, &isInbound)
			if err != nil {
				logger.Info("calc risk level score, err: %v", err)
				continue
			}

			if isInbound {
				inboundAreaId = append(inboundAreaId, fendArea.ID)
			}

			// 对每个无人机获取告警级别更高，分数更高的无人机
			riskLevel, score = CalcUavRiskScoreOnFendAreas(riskLevel, score, tmpRiskScore.RiskLevel, tmpRiskScore.RiskScore)
			if riskLevel == tmpRiskScore.RiskLevel && score == tmpRiskScore.RiskScore {
				areaId = fendArea.ID
				areaName = fendArea.AreaName
			}
		}
		// devId := GetDevUnique(uav.GetSn(), uav.GetObjID(), uav.GetDetectDevSn())
		devId := uav.GetUavUniqueId()
		uavRiskLevelScore[devId] = AlarmRiskLevel{
			RiskLevel:     riskLevel,
			RiskScore:     score,
			Sn:            uav.GetSn(),
			ObjId:         uav.GetObjID(),
			DevName:       uav.GetName(),
			C2Sn:          uav.GetC2Sn(),
			UniqueId:      uav.GetUniqueId(),
			AreaId:        areaId,
			Longitude:     uav.GetLongitude(), // 经度
			Latitude:      uav.GetLatitude(),  // 纬度
			AreaName:      areaName,
			DevRelations:  uav.GetDevRelations(),
			TrackId:       uav.GetTrackId(),
			InboundAreaId: inboundAreaId,
		}
	}
	return uavRiskLevelScore, nil
}

// checkFendAreaAlarm 检查 有围栏区时的无人机告警
func (as *AlarmStrategy) checkFendAreaAlarm(fendAreaType int, tbCode string, in any) (AlarmCheckResultPtr, error) {
	if procHandle, ok := as.fendAreaAlarmProcess[fendAreaType]; ok {
		if procHandle == nil {
			logger.Errorf("fendArea has set, but proc func is nil, fendAreaType: %v, tb_code: %v", fendAreaType, tbCode)
			return nil, fmt.Errorf("not support fendArea type process")
		}

		v, err := procHandle(in)
		if err != nil {
			logger.Errorf("handle fail, %v", err)
			return nil, err
		}
		if v == nil {
			logger.Infof("get alarm result is nil")
			return nil, nil
		}

		// asyncWriteAlarmRecord
		if len(v.UavAlarmRiskLevelScores) > 0 {
			err := as.asyncWriteAlarmRecord(&AlarmRecord{
				TbCode:     tbCode,
				AlarmItems: v.UavAlarmRiskLevelScores,
			})
			if err != nil {
				logger.Errorf("async write alarm item to db fail, err: %v, tbCode: %v", err, tbCode)
			}
		}

		v.UavAlarmRiskLevelScores = as.filterAlarmResponse(v.UavAlarmRiskLevelScores)

		// 另外通知， 除了add, 还有 update.
		if len(v.UavAlarmRiskLevelScores) > 0 {
			//告警事件通知：
			go func() {
				defer func() {
					if e := recover(); e != nil {
						logger.Errorf("checkFendAreaAlarm panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", e)))
					}
				}()

				addItems := []*pb.AlarmCheckAddItem{}
				for index, _ := range v.UavAlarmRiskLevelScores {
					if v.UavAlarmRiskLevelScores[index] == nil {
						continue
					}
					item := v.UavAlarmRiskLevelScores[index]

					addItems = append(addItems, &pb.AlarmCheckAddItem{
						Id: strconv.FormatInt(item.GetId(), 10),
						// 无人机唯一标识
						Sn:    item.GetSn(),
						ObjId: item.GetObjId(),
						// 风险等级： 1: low, 2: middle, 3: high
						RiskLevel: item.GetRiskLevel(),
						// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
						ThreatLevel: item.GetThreatLevel(),
						// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
						EventId: strconv.FormatInt(item.GetEventId(), 10),
						// 租户id
						TbCode: item.GetTbCode(),
						// 设备名字
						DevName: item.GetDevName(),
						// 告警的时间点（毫秒）
						CreateTime: item.GetCreateTime(),
						// 一次 相同eventID的告警持续时间（毫秒）
						DurTime: item.GetDurTime(),
						// 无人机对应的c2 sn
						C2Sn: item.GetC2Sn(),
						// 告警的围栏区id
						AreaId: item.GetAreaId(),
						// 告警触发类型, 0: 围栏区告警 1:只有c2告警; 2: c2+围栏区告警
						AlarmType: item.GetAlarmType(),
						// 标识本次请求id（由调用方来设置，服务方转发）
						UniqueId: item.GetUniqueId(),
						// 设备经纬度
						Longitude: item.GetLongitude(),
						Latitude:  item.GetLatitude(),
						// 围栏区的 name
						AreaName: item.GetAreaName(),
					})
				}
				if e := NewAlarmStatusUpdateNotify().Add(addItems, tbCode); e != nil {
					logger.Errorf("send to add alarm status fail, e: %v", e)
				}
			}()
		}
		return v, err
	}

	logger.Infof("not register fend area alarm process handle, fendAreaType: %v, tb_code: %v", fendAreaType, tbCode)
	return nil, nil
}

// checkAlarm 检查 alarm
func (as *AlarmStrategy) checkAlarm(inParam any) (AlarmCheckResultPtr, error) {
	//检查参数是围栏区存在场景:
	firstIn, okFirst := inParam.(*cfgFendAreaCheckParam)
	if okFirst && firstIn != nil {
		if firstIn.mixAlarmArea != nil && len(firstIn.mixAlarmArea) > 0 {
			logger.Infof("mix fence alarm area and cross")
			return as.checkFendAreaAlarm(FendAreaTypePreCoreCross, firstIn.tbCode, firstIn)
		}

		if firstIn.preAlarmArea != nil && len(firstIn.preAlarmArea) > 0 && (firstIn.coreAlarmArea == nil || len(firstIn.coreAlarmArea) <= 0) {
			logger.Infof("only pre fence alarm area.")
			return as.checkFendAreaAlarm(FendAreaPreAlarmOnly, firstIn.tbCode, firstIn)
		}

		if firstIn.coreAlarmArea != nil && len(firstIn.coreAlarmArea) > 0 && (firstIn.preAlarmArea == nil || len(firstIn.preAlarmArea) <= 0) {
			logger.Infof("only core fence alarm area.")
			return as.checkFendAreaAlarm(FendAreaTypeCoreOnly, firstIn.tbCode, firstIn)
		}

		logger.Infof("exist pre and core fence alarm areas, but not cross within them.")
		return as.checkFendAreaAlarm(FendAreaTypePreCoreNoCross, firstIn.tbCode, firstIn)
	}

	// 检查参数是不存在围栏区场景:
	secondIn, okSecond := inParam.(*noFendAreaCheckParam)
	if okSecond && secondIn != nil {
		logger.Infof("not any fence area alarm process.")
		return as.checkFendAreaAlarm(FendAreaTypeNoSet, secondIn.tbCode, secondIn)
	}

	return nil, fmt.Errorf("not support type: %v", reflect.TypeOf(inParam).Name())
}
