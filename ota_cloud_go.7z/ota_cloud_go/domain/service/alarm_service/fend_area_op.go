package alarm_service

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/redis"
	"fmt"
	"time"
)

const (
	// RedisKeyPrefixFendAreaCollect 围栏区集合的key_前缀
	RedisKeyPrefixFendAreaCollect = "cloud_c2_fend_area_collect"
	RedisKeyPrefixFendAreaDetail  = "cloud_c2_fend_area_item"
)

func BuildFendAreaCollectionRedisKey(tbCode string) string {
	return fmt.Sprintf("%s:%s", RedisKeyPrefixFendAreaCollect, tbCode)
}
func BuildFendAreaDetailRedisKey(tbCode string, id int64) string {
	return fmt.Sprintf("%s:%s:%d", RedisKeyPrefixFendAreaDetail, tbCode, id)
}

type FendAreaOPService struct {
	redisRepo redis.SkyFendRedisOps
	dbRepo    db.DbOpsTplInterface[bean.FencedAreaConfig]
}

// NewFendAreaOpsService 创建围栏区服务对象
func NewFendAreaOpsService(redisOp redis.SkyFendRedisOps, dbOp db.DbOpsTplInterface[bean.FencedAreaConfig]) *FendAreaOPService {
	handle := &FendAreaOPService{
		redisRepo: redisOp,
		dbRepo:    dbOp,
	}
	return handle
}

// GetFendAreaByTbCode 获取 tb code 下围栏区
func (fa *FendAreaOPService) GetFendAreaByTbCode(tbCode string) ([]*bean.FencedAreaConfig, error) {
	if tbCode == "" {
		return nil, fmt.Errorf("tbcode is nil")
	}

	fendAreaCollectKey := BuildFendAreaCollectionRedisKey(tbCode) // tbcode --> [alarm_area id ]
	fendAreaCollectVal, err := fa.redisRepo.SMembers(fendAreaCollectKey)
	if err != nil {
		logger.Errorf("get fend area collect by key: %v, err: %v", fendAreaCollectKey, err)
	}

	if len(fendAreaCollectVal) > 0 {
		var needReload = false
		var ret []*bean.FencedAreaConfig

		for _, fendAreaDetailKey := range fendAreaCollectVal {
			if fendAreaDetailKey == "" {
				continue
			}

			item, e := fa.redisRepo.HGetAll(fendAreaDetailKey)
			if e != nil {
				logger.Errorf("get fend area detail by key: %v, fail: %v", fendAreaDetailKey, e)
				needReload = true
				continue
			}

			if item == nil || len(item) == 0 {
				logger.Infof("get fend area detail by key: %v, is empty", fendAreaDetailKey)
				needReload = true
				continue
			}

			fendAreaConfigItem, e := redis.TransMapToStruct[bean.FencedAreaConfig](item)
			if e != nil {
				logger.Errorf("parse fend area fail, e: %v", e)
				needReload = true
				continue
			}
			if fendAreaConfigItem == nil {
				logger.Errorf("parsed fend area is empty")
				needReload = true
				continue
			}
			ret = append(ret, fendAreaConfigItem)
		}

		if !needReload {
			return ret, nil
		}
		logger.Infof("load cache fail, need reload fend area, tb code: %v", tbCode)
	}

	if err = fa.redisRepo.DeleteKey(fendAreaCollectKey); err != nil {
		logger.Infof("delete fend area item from collection fail, err: %v, key: %v", err, fendAreaCollectKey)
	}

	logger.Infof("not exist any fend area on cache for tb code: %v", tbCode)

	whereCond := "tb_code=?"
	whereValue := []any{tbCode}

	fendAreaDetails, err := fa.dbRepo.QueryItemOnCond(whereCond, whereValue, nil, 0, 0)
	if err != nil {
		logger.Errorf("get fend area from db fail, err: %v, tbCode: %v", err, tbCode)
		return nil, fmt.Errorf("get fend area by deb fail")
	}

	if len(fendAreaDetails) == 0 {
		logger.Infof("get fend area from db is empty, tbCode: %v", tbCode)
		return nil, nil
	}

	for _, detailItem := range fendAreaDetails {
		if nil == detailItem {
			continue
		}

		areaKey := BuildFendAreaDetailRedisKey(tbCode, detailItem.ID)
		err = fa.redisRepo.HSetStruct(areaKey, detailItem)
		if err != nil {
			logger.Errorf("write fend area item to db fail,err: %v, key: %v", err, areaKey)
			continue
		}
		fa.redisRepo.ExpireKey(areaKey, 300*time.Second)

		err = fa.redisRepo.SAdd(fendAreaCollectKey, areaKey)
		if err != nil {
			logger.Errorf("add fend area detail key to collect fail, err: %v, key: %v", err, fendAreaCollectKey)
		}
	}
	fa.redisRepo.ExpireKey(fendAreaCollectKey, 250*time.Second)

	//设置缓存时间戳
	return fendAreaDetails, nil
}

func (fa *FendAreaOPService) DeleteFendArea(tbCode string, areaName string, id int64) error {
	if tbCode == "" {
		return nil
	}

	areaKey := BuildFendAreaDetailRedisKey(tbCode, id)
	if err := fa.redisRepo.DeleteKey(areaKey); err != nil {
		logger.Infof("delete fend area item hash item err: %v, key: %v", err, areaKey)
	}

	fendAreaCollectKey := BuildFendAreaCollectionRedisKey(tbCode)
	if err := fa.redisRepo.SRem(fendAreaCollectKey, areaKey); err != nil {
		logger.Infof("delete fend area item from collection fail, err: %v, key: %v",
			err, areaKey)
	}
	return nil
}

func (fa *FendAreaOPService) DeleteAllFendAreaOnTbCode(tbCode string) error {
	fendAreaCollectKey := BuildFendAreaCollectionRedisKey(tbCode) // tbcode --> [alarm_area id ]
	fendAreaCollectVal, err := fa.redisRepo.SMembers(fendAreaCollectKey)
	if err != nil {
		logger.Errorf("get fend area collect by key: %v, err: %v", fendAreaCollectKey, err)
	}
	if len(fendAreaCollectVal) <= 0 {
		return nil
	}
	for _, keyAlarmItem := range fendAreaCollectVal {
		fa.redisRepo.DeleteKey(keyAlarmItem)
	}
	fa.redisRepo.DeleteKey(fendAreaCollectKey)
	return nil
}

func (fa *FendAreaOPService) GetFenceAreaDetails(tbCode string, areaIds []int64) (error, []*bean.FencedAreaConfig) {
	if fa == nil || fa.dbRepo == nil {
		return fmt.Errorf("fence area op handle is nil"), nil
	}
	if len(areaIds) == 0 || tbCode == "" {
		return fmt.Errorf("tbcode is empty or area id is empty"), nil
	}

	fenceAreaList, err := fa.dbRepo.QueryItems(areaIds)
	if err != nil {
		logger.Errorf("query area id detail fail, err: %v", err)
		return err, nil
	}
	return nil, fenceAreaList
}
