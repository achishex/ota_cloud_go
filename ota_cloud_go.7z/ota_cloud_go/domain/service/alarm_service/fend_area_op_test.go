package alarm_service

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
)

func TestFendAreaOps(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}
	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	ResFendAreaDB = db.NewDBModelTplWrapper[bean.FencedAreaConfig](dbHandler).SetTabName(bean.FencedAreaConfig{}.TableName())

	fenceAreaHandle := NewFendAreaOpsService(nil, ResFendAreaDB)
	err, items := fenceAreaHandle.GetFenceAreaDetails("000001", []int64{1299774794654810112, 1299467674410549260, 1299467674410549260})
	if err != nil {
		t.Logf("query fence area detail fail, err: %v", err)
		return
	}
	if len(items) <= 0 {
		t.Logf("query fence area detail is empty")
		return
	}
	for _, item := range items {
		t.Logf("fence area details: %+v", item)
	}

}
