package alarm_service

import (
	"context"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"sync/atomic"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/Shopify/sarama"
)

// AlarmRecord 用于存在db 的告警记录
type AlarmRecord struct {
	TbCode     string                  `json:"tb_code"`
	AlarmItems []*pb.AlarmCheckRspItem `json:"alarm_items"`
}

type AlarmRecordExt struct {
	Longitude float64
	Latitude  float64
}

// AlarmRecordHandler 消息队列消费消息后的，消息处理实际对象
type AlarmRecordHandler struct {
	alarmDB         db.DbOpsTplInterface[bean.FendAreaAlarm]
	acountWriteNums atomic.Int64
}

// NewAlarmRecordHandler 创建告警记录处理对象
func NewAlarmRecordHandler(alarmDB db.DbOpsTplInterface[bean.FendAreaAlarm]) *AlarmRecordHandler {
	return &AlarmRecordHandler{
		alarmDB: alarmDB,
	}
}

// MarshDevRelation 转化二进制数据
func MarshDevRelation(data []*pb.DevRelation) []byte {
	if len(data) <= 0 {
		return nil
	}
	if len(data) > 0 {
		devRelationsJSON, err := json.Marshal(data)
		if err != nil {
			logger.Errorf("marshal dev relations fail")
			return nil
		}
		return devRelationsJSON
	}
	return nil
}

// UnmarshalDevRelation 转化 设备关系列表
func UnmarshalDevRelation(data json.RawMessage) []*pb.DevRelation {
	if len(data) <= 0 {
		return nil
	}

	var ret []*pb.DevRelation
	if err := json.Unmarshal(data, &ret); err != nil {
		logger.Errorf("unmarshal pb.DevRelation list fail, err: %v", err)
		return nil
	}

	return ret
}

func MarshalDevRelation(src []*pb.DevRelation) json.RawMessage {
	if len(src) > 0 {
		var deviceJson json.RawMessage
		var err error

		deviceJson, err = json.Marshal(src)
		if err != nil {
			logger.Errorf("marshal DevRelation to byte slice fail, %v", err)
		}
		return deviceJson
	}
	return nil
}

// Handle 只记录一条记录
func (ah *AlarmRecordHandler) Handle(ctx context.Context, message any) error {
	//忽略处理逻辑
	return nil
}

// HandleBatch 消费kafka消息处理函数：将多条记录写入数据库
func (ah *AlarmRecordHandler) HandleBatch(ctx context.Context, message []*sarama.ConsumerMessage) error {
	alarmRecordBeginTm := time.Now()
	defer func() {
		if time.Since(alarmRecordBeginTm).Milliseconds() > 100 {
			logger.Infof("handlerBatch cost time: %v ms", time.Since(alarmRecordBeginTm).Milliseconds())
		}
	}()

	if len(message) == 0 {
		return nil
	}
	if ah == nil || ah.alarmDB == nil {
		logger.Error("alarm db not init")
		return fmt.Errorf("alarm db not init")
	}

	var msgItems []*AlarmRecord
	for _, item := range message {
		if item == nil {
			continue
		}

		newItem := &AlarmRecord{}
		err := json.Unmarshal(item.Value, newItem)
		if err != nil {
			logger.Errorf("unmarshal alarm record fail, origin value:%v", item.Value)
			continue
		}
		msgItems = append(msgItems, newItem)
	}

	var toInserts []*bean.FendAreaAlarm
	for _, item := range msgItems {
		if item == nil {
			continue
		}
		if len(item.AlarmItems) == 0 {
			continue
		}

		for _, alarmItem := range item.AlarmItems {
			if alarmItem == nil {
				continue
			}

			var (
				devRelationsJSON []byte
				err              error

				areaList model.ListAnyType[model.CrossAreaId]
				areaJson []byte
			)

			if len(alarmItem.InboundAreaIds) > 0 {
				//logger.Debugf("in bound area id: %v", alarmItem.InboundAreaIds)

				for _, areaId := range alarmItem.InboundAreaIds {
					areaList = append(areaList, &model.CrossAreaId{
						AreaId: areaId,
					})
				}

				areaJson, err = areaList.Marshal()
				if err != nil {
					logger.Errorf("marshal inbound area ids fail, err: %v", err)
				}
			}
			devRelationsJSON = MarshDevRelation(alarmItem.DevRelations)

			//logger.Infof("consumer alarm record: %+v", alarmItem)
			toInserts = append(toInserts, &bean.FendAreaAlarm{
				ID:     alarmItem.GetId(),
				TbCode: alarmItem.GetTbCode(),
				//无人机唯一标识
				DevSn: alarmItem.GetSn(),
				// obj id 是无人机 obj id
				ObjID: alarmItem.GetObjId(),
				// 风险等级： 1: low, 2: middle, 3: high
				RiskLevel: alarmItem.GetRiskLevel(),
				// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
				ThreatLevel: alarmItem.GetThreatLevel(),
				// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
				EventId: alarmItem.GetEventId(),
				// 创建时间
				CreateTime: time.Now().UTC(),
				UpdateTime: time.Now().UTC(),
				C2Sn:       alarmItem.GetC2Sn(),
				AlarmType:  alarmItem.GetAlarmType(),
				// 0: 未处理; 1: 已处理
				Status:         0, //0: 未处理； 1: 手动处理； 2：侦测事件消息处理； 3：告警为0处理
				AreaId:         alarmItem.GetAreaId(),
				DevName:        alarmItem.GetDevName(),
				DurTime:        alarmItem.GetDurTime(),
				Longitude:      alarmItem.GetLongitude(),
				Latitude:       alarmItem.GetLatitude(),
				AreaName:       alarmItem.GetAreaName(),
				Devrelations:   devRelationsJSON,
				TrackId:        alarmItem.GetTrackId(), // inbound_area_ids
				InboundAreaIds: areaJson,
			})
			ah.acountWriteNums.Add(1)
		}
	}
	_, e := ah.alarmDB.Insert(toInserts)
	if e != nil {
		logger.Errorf("write alarm item to db fail, e: %v", e)
	}

	if ah.acountWriteNums.Load()%100 == 0 {
		logger.Infof("write accumulate alarm item nums: %v", ah.acountWriteNums.Load())
	}
	return nil
}
