package countertask

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/redis"
	"errors"
	"fmt"
	"time"
)

type CancelTaskStatusManager struct {
	redisHandle       redis.SkyFendRedisOps
	cancelTaskExpTime time.Duration //默认2second
}

// NewCancelTaskImpl 创建一个取消任务操作的结构
func NewCancelTaskImpl(rds redis.SkyFendRedisOps) *CancelTaskStatusManager {
	if rds == nil {
		return &CancelTaskStatusManager{
			redisHandle:       config.GlobalRedis,
			cancelTaskExpTime: 2 * time.Second,
		}
	}
	return &CancelTaskStatusManager{
		redisHandle:       rds,
		cancelTaskExpTime: 2 * time.Second,
	}
}

// GetCancelTaskStatusKey 获取取消任务状态 key
func GetCancelTaskStatusKey(tbCode string, uavSn string, uavObj string, freq float64) string {
	return fmt.Sprintf("cancel_task_status:%v:%v:%v:%v", tbCode, uavSn, uavObj, freq)
}

// LogCancelOnUav 记录取消无人机反制任务
func (impl *CancelTaskStatusManager) LogCancelOnUav(tbCode string, uavSn string, uavObjId string, freq float64) error {
	if impl == nil || impl.redisHandle == nil {
		logger.Errorf("redis op handle not init, tbCode: %v, uavSn: %v, uavObjId: %v", tbCode, uavSn, uavObjId)
		return errors.New("redis op handle not init")
	}

	redisKey := GetCancelTaskStatusKey(tbCode, uavSn, uavObjId, freq)
	if err := impl.redisHandle.SetEx(redisKey, "11", impl.cancelTaskExpTime); err != nil {
		logger.Errorf("set cancel task status to redis fail, key: %v, err: %v", redisKey, err)
		return err
	}

	return nil
}

// FreshLogCancelOnUav 刷新取消任务状态, 1: 不存在;
func (impl *CancelTaskStatusManager) FreshLogCancelOnUav(tbCode string, uavSn string, uavObjId string, freq float64) (error, int32) {
	if impl == nil || impl.redisHandle == nil {
		logger.Errorf("redis op handle not init, tbCode: %v, uavSn: %v, uavObjId: %v", tbCode, uavSn, uavObjId)
		return errors.New("redis op handle not init"), 0
	}

	redisKey := GetCancelTaskStatusKey(tbCode, uavSn, uavObjId, freq)
	if err := impl.redisHandle.RefreshTTL(redisKey, "11", impl.cancelTaskExpTime); err != nil {
		if errors.Is(err, new(redis.KeyNoExistError)) {
			return nil, 1
		}

		logger.Errorf("refresh key: %v fail, err: %v", redisKey, err)
		return err, 0
	}
	return nil, 0
}
