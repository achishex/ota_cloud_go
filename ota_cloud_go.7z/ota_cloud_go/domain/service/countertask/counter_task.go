package countertask

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/errorcode"
	"cuav-cloud-go-service/domain/common/request"
	"cuav-cloud-go-service/domain/common/response"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"encoding/json"
	"errors"
	"strconv"
	"time"

	"cuav-cloud-go-service/domain/repository/access"
	ec "cuav-cloud-go-service/domain/repository/error_collect"
	"cuav-cloud-go-service/domain/repository/redis"

	ps "cuav-cloud-go-service/infra/protocals"

	"cuav-cloud-go-service/domain/common/utils"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/go-playground/validator/v10"
	"google.golang.org/protobuf/proto"
)

type CounterTaskOps struct {
	dbOps CounterTaskDBType
	rds   redis.SkyFendRedisOps
}

// NewCounterTaskOps 创建反制任务
func NewCounterTaskOps(dbHandle CounterTaskDBType) *CounterTaskOps {
	if dbHandle == nil {
		// 使用默认的全局db
		return &CounterTaskOps{
			dbOps: CounterTaskDBHandle,
			rds:   config.GlobalRedis,
		}
	}
	return &CounterTaskOps{
		dbOps: dbHandle,
		rds:   config.GlobalRedis,
	}
}

func (c *CounterTaskOps) CounterTaskManualStart(ctx context.Context, req *request.CounterTaskManualStartRequest) error {
	if err := validator.New().Struct(req); err != nil {
		logger.Errorf("CounterTaskManualStart param validate error: %s", err.Error())
		return ec.GetError(errorcode.ParameterInvalid)
	}

	var trackId string
	var detectDevLon float64
	var detectDevLat float64
	trackIds := alarm_service.GetTrackIdByDevice(req.TbCode, req.DeviceSn, config.GlobalRedis)
	for _, item := range trackIds {
		if item == nil {
			continue
		}
		if item.TrackId == "" {
			continue
		}
		trackId = item.TrackId

		detectDevLon = item.Longitude
		detectDevLat = item.Latitude
	}
	req.TrackId = trackId
	logger.Infof("track id: %v, device: %v, lon: %v, lat: %v", trackId, req.DeviceSn, detectDevLon, detectDevLat)

	// 查询是否存在
	tasks := []*model.CounterTask{}
	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("tb_code = ? and dev_sn = ? and dev_type = ? and status in ?", req.TbCode,
		req.DeviceSn, req.DeviceType, []int{constant.CounterTaskStatusInProgress}).Find(&tasks).Error; err != nil {
		logger.Errorf("CounterTaskManualStart Find error: %s", err.Error())
		return ec.GetError(errorcode.DBQueryError)
	}
	id, err := snowflake.GetUniqueID()
	if err != nil {
		logger.Errorf("gen task error: %s", err.Error())
		return ec.GetError(errorcode.GetUniqueIDError)
	}
	newTask := &model.CounterTask{
		ID:           id,
		TbCode:       req.TbCode,
		TriggerMode:  constant.TriggerModeManual,
		Status:       constant.CounterTaskStatusInProgress,
		DevSn:        req.DeviceSn,
		DevType:      req.DeviceType,
		DevName:      req.DeviceName,
		ObjName:      req.ObjName,
		ObjType:      req.ObjType,
		ExtraParams:  req.ExtraParams,
		DurTimeS:     req.HitDurTimeSecond,
		BeginTime:    time.Now().UTC(),
		TrackId:      req.TrackId,
		DevLongitude: detectDevLon,
		DevLatitude:  detectDevLat,
	}
	hitMode, err := tranferTaskHitmode(req)
	if err != nil {
		logger.Errorf("tranferTaskHitmode error: %s", err.Error())
		return ec.GetError(errorcode.DBCreateError)
	}
	newTask.Mode = int16(hitMode)
	if len(tasks) > 0 {
		for _, item := range tasks {
			if compareTask(*item, *newTask) {
				logger.Error("CounterTaskManualStart Find error: task exsist")
				return ec.GetError(errorcode.RecordDuplication)
			}
		}
	}
	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Create(newTask).Error; err != nil {
		logger.Errorf("create task error: %s", err.Error())
		return ec.GetError(errorcode.DBCreateError)
	}
	// 写redis
	redisVal, _ := json.Marshal(model.CounterTaskRdValue{ID: newTask.ID, TbCode: newTask.TbCode, BeginTime: newTask.BeginTime})
	if err := c.rds.Client().RPush(context.Background(), constant.RedisKeyCounterTaskInProgress, string(redisVal)).Err(); err != nil {
		logger.Errorf("CounterTaskManualStart RPush error: %s", err.Error())
	}
	// 变更通知
	access.SendKafkaMsg(config.GetConfig().Kafka.EventNoticeTopic, access.NoticeItem{
		Key:  constant.UrlTaskStatusUpdate,
		Data: access.TbCode{TbCode: req.TbCode},
	})
	return nil
}

func compareTask(task model.CounterTask, newTask model.CounterTask) bool {
	if task.TriggerMode == constant.TriggerModeManual && task.DevSn == newTask.DevSn && task.DevType == newTask.DevType &&
		task.DevName == newTask.DevName && task.Mode == newTask.Mode && task.ObjName == newTask.ObjName {
		return true
	}

	return false
}

func tranferTaskHitmode(req *request.CounterTaskManualStartRequest) (int, error) {
	var hitMode int
	if req.DeviceType == constant.DeviceTypeSfl200 {
		if req.ChildDeviceType == "" {
			logger.Error("ChildDeviceType empty")
			return 0, errors.New("ChildDeviceType empty")
		}
		hitMode = constant.DeviceTypeHitModeOutMap[req.DeviceType+req.ChildDeviceType+strconv.Itoa(int(req.HitMode))]
	} else {
		hitMode = constant.DeviceTypeHitModeOutMap[req.DeviceType+strconv.Itoa(int(req.HitMode))]
	}

	return hitMode, nil
}

func (c *CounterTaskOps) CounterStatusFeedBack(ctx context.Context, req *request.CounterStatusFeedBackRequest) error {
	// 校验参数
	if err := validator.New().Struct(req); err != nil {
		logger.Errorf("CounterTaskManualStart valid error: %s", err.Error())
		return ec.GetError(errorcode.ParameterInvalid)
	}
	if req.TbCode == "" {
		token := ps.GetToken(ctx)
		if token == nil {
			logger.Errorf("token in valid for counter measure recommend")
			return ec.GetError(ec.SF_ErrorTokenInvalid)
		}
		req.TbCode = token.Payload.TbCode
	}
	tasks := []*model.CounterTask{}
	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("tb_code = ? and dev_sn = ? and dev_type = ? and status in ?", req.TbCode,
		req.DeviceSn, req.DeviceType, []int{constant.CounterTaskStatusInProgress}).Find(&tasks).Error; err != nil {
		logger.Errorf("CounterStatusFeedBack Find Last error: %s", err.Error())
		return ec.GetError(errorcode.NotFoundError)
	}
	taskIds := []int64{}
	for _, item := range tasks {
		taskIds = append(taskIds, item.ID)
	}
	update := map[string]any{"status": req.Status}
	if req.Status == constant.CounterTaskStatusCancel || req.Status == constant.CounterTaskStatusEnd {
		update["end_time"] = time.Now().UTC()
		for _, item := range tasks {
			redisVal, _ := json.Marshal(model.CounterTaskRdValue{ID: item.ID, TbCode: item.TbCode, BeginTime: item.BeginTime})
			if err := c.rds.Client().LRem(context.Background(), constant.RedisKeyCounterTaskInProgress, 0, string(redisVal)).Err(); err != nil {
				logger.Errorf("CounterTaskManualStart LRem task id: %d error: %s", item.ID, err.Error())
			}
		}
	}
	dbRes := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("id in ?", taskIds).UpdateColumns(update)
	if dbRes.Error != nil {
		logger.Errorf("CounterStatusFeedBack valid error: %s", dbRes.Error.Error())
		return ec.GetError(errorcode.DBUpdateError)
	}
	if dbRes.RowsAffected > 0 {
		// 变更通知
		access.SendKafkaMsg(config.GetConfig().Kafka.EventNoticeTopic, access.NoticeItem{
			Key:  constant.UrlTaskStatusUpdate,
			Data: access.TbCode{TbCode: req.TbCode},
		})
	}

	return nil
}

func (c *CounterTaskOps) CancelTaskOnManual(ctx context.Context, req *request.CounterStatusFeedBackRequest) error {
	// 校验参数
	if err := validator.New().Struct(req); err != nil {
		logger.Errorf("CounterTaskManualStart valid error: %s", err.Error())
		return errors.New("params valid error")
	}
	if req.TbCode == "" {
		token := ps.GetToken(ctx)
		if token == nil {
			logger.Errorf("token in valid for counter measure recommend")
			return ec.GetError(ec.SF_ErrorTokenInvalid)
		}
		req.TbCode = token.Payload.TbCode
	}
	task := &model.CounterTask{}
	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("tb_code = ? and dev_sn = ? and dev_type = ? and status in ? and id = ?", req.TbCode,
		req.DeviceSn, req.DeviceType, []int{constant.CounterTaskStatusInProgress}, req.TaskId).Last(task).Error; err != nil {
		logger.Errorf("CounterStatusFeedBack Find Last error: %s", err.Error())
		return errors.New("DB error")
	}
	update := map[string]any{"status": req.Status}
	if req.Status == constant.CounterTaskStatusCancel || req.Status == constant.CounterTaskStatusEnd {
		update["end_time"] = time.Now().UTC()
	}

	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Model(task).UpdateColumns(update).Error; err != nil {
		logger.Errorf("CounterStatusFeedBack valid error: %s", err.Error())
		return errors.New("update error")
	}

	if task.CounterId > 0 {
		logger.Infof("cancel auto counter task, task auto counter rule id: %v, task id: %v", task.CounterId, task.ID)
		freqAny, ok := task.ExtraParams["freq"]
		if ok {
			freqFloat64, ok := freqAny.(float64)
			if ok {
				NewCancelTaskImpl(nil).LogCancelOnUav(req.TbCode, task.ObjName, task.ObjType, freqFloat64)
				logger.Infof("manual cancel task, write log, tbCode: %v, uavSn: %v, objId: %v, freq: %v", task.ObjName, task.ObjType, freqFloat64)
			}
		}
		redisVal, _ := json.Marshal(model.CounterTaskRdValue{ID: task.ID, TbCode: task.TbCode, BeginTime: task.BeginTime})
		if err := c.rds.Client().LRem(context.Background(), constant.RedisKeyCounterTaskInProgress, 0, string(redisVal)).Err(); err != nil {
			logger.Errorf("CounterTaskManualStart LRem task id: %d error: %s", task.ID, err.Error())
		}
	}

	// 变更通知
	access.SendKafkaMsg(config.GetConfig().Kafka.EventNoticeTopic, access.NoticeItem{
		Key:  constant.UrlTaskStatusUpdate,
		Data: access.TbCode{TbCode: req.TbCode},
	})

	return nil
}

func (c *CounterTaskOps) QueryCounterTask(ctx context.Context, reqBody *request.CounterTaskQueryRequest) (*response.CounterTaskQueryRes, error) {
	token := ps.GetToken(ctx)
	if token == nil {
		logger.Errorf("token in valid for counter measure recommend")
		return nil, ec.GetError(ec.SF_ErrorTokenInvalid)
	}
	query := c.dbOps.GetDBHandle().Table("t_counter_task tct").Select(`tct.*, tacrc.id AS rule_id, tacrc.rule_name AS rule_name, 
		tacrc.counter_area_id, tacrc.fence_area_id, tcac.area_name AS counter_area_name, fac.area_name AS fenced_area_name, 
		fac.area_type AS fenced_area_type, tacrc.forbidden_mode, tacrc.rule_enable, tacrc.create_time, tacrc.update_time, 
		tacrc.whole_day, tacrc.begin_time AS rule_begin_time, tacrc.end_time AS rule_end_time, tacrc.cross_day
	`).Joins(`
		left join t_auto_counter_rule_config tacrc on tacrc.id = tct.counter_rule_id 
		left join t_counter_area_config tcac on tcac.id = tacrc.counter_area_id 
		left join fenced_area_config fac on fac.id = tacrc.fence_area_id`)
	query.Where("tct.tb_code = ? ", token.Payload.TbCode)
	if reqBody.DevSn != "" {
		query.Where("tct.dev_sn like %?% ", reqBody.DevSn)
	}
	modeList := convertHitModeList(reqBody.ModeList)
	if len(modeList) > 0 {
		query.Where("tct.mode in ? ", modeList)
	}
	if len(reqBody.TriggerModeList) > 0 {
		query.Where("tct.trigger_mode in ? ", reqBody.TriggerModeList)
	}
	if len(reqBody.StatusList) > 0 {
		query.Where("tct.status in ? ", reqBody.StatusList)
	}
	if reqBody.SearchName != "" {
		query.Where("tct.dev_name like ? OR tacrc.rule_name like ? ", "%"+reqBody.SearchName+"%", "%"+reqBody.SearchName+"%")
	}
	var total int64
	queryCount := query
	if err := queryCount.Count(&total).Error; err != nil {
		logger.Errorf("QueryCounterTask count error: %s", err.Error())
		return nil, ec.GetError(errorcode.DBQueryError)
	}
	counterTaskAndRules := make([]*model.CounterTaskAndRule, 0, 10)
	if err := query.Order("begin_time desc").Offset(int(reqBody.PageNo-1) * int(reqBody.PageSize)).
		Limit(int(reqBody.PageSize)).Scan(&counterTaskAndRules).Error; err != nil {
		logger.Errorf("QueryCounterTask query error: %s", err.Error())
		return nil, ec.GetError(errorcode.DBQueryError)
	}
	res := new(response.CounterTaskQueryRes)
	res.List = make([]*response.CounterTaskQueryResponse, 0, 10)
	for _, item := range counterTaskAndRules {
		taskRule := &response.CounterTaskQueryResponse{
			Id:          item.ID,
			Name:        item.Name,
			TriggerMode: int32(item.TriggerMode),
			Status:      int32(item.Status),
			DevSn:       item.DevSn,
			DevType:     item.DevType,
			DevName:     item.DevName,
			Mode:        int32(item.Mode),
			ObjName:     item.ObjName,
			ObjType:     item.ObjType,
			DurTimeS:    item.DurTimeS,
			BeginTime:   item.BeginTime.UTC().UnixMilli(),
		}
		if !item.EndTime.IsZero() {
			taskRule.EndTime = item.EndTime.UTC().UnixMilli()
		}

		if item.RuleId != 0 {
			taskRule.RuleItem = &response.AutoCounterRuleSimple{
				RuleId:   item.RuleId,
				RuleName: item.RuleName,
				CounterArea: &response.CounterArea{
					Id:       item.CounterAreaId,
					AreaName: item.CounterAreaName,
				},
				FenceAreaItem: &response.FenceResList{
					Id:       item.FenceAreaId,
					AreaName: item.FencedAreaName,
					AreaType: item.FencedAreaType,
				},
				ForbiddenMode: item.ForbiddenMode,
				RuleEnable:    item.RuleEnable,
				CreateTime:    item.CreateTime,
				UpdateTime:    item.UpdateTime,
				BeginTime:     item.RuleBeginTime,
				EndTime:       item.RuleEndTime,
				WholeDay:      item.WholeDay,
				CrossDay:      item.CrossDay,
			}
			sH, sM, sS := utils.GetTimeByDB(item.RuleBeginTime)
			taskRule.RuleItem.StartHour, taskRule.RuleItem.StartMinute, taskRule.RuleItem.StartSecond = proto.Int32(sH),
				proto.Int32(sM), proto.Int32(sS)
			eH, eM, eS := utils.GetTimeByDB(item.RuleEndTime)
			taskRule.RuleItem.EndHour, taskRule.RuleItem.EndMinute, taskRule.RuleItem.EndSecond = proto.Int32(eH),
				proto.Int32(eM), proto.Int32(eS)
		}
		res.List = append(res.List, taskRule)
	}

	res.PageNo = reqBody.PageNo
	res.PageSize = reqBody.PageSize
	res.Total = int32(total)
	return res, nil
}

func convertHitModeList(modeList []int) []int {
	var res []int
	for _, item := range modeList {
		if list, ok := constant.TaskModeMap[item]; ok {
			res = append(res, list...)
		}
	}
	return res
}

func (c *CounterTaskOps) CounterAutoTaskStart(ctx context.Context, req *request.CounterTaskAutoStartRequest, taskId int64) error {
	// 查询是否存在
	tasks := []*model.CounterTask{}
	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("tb_code = ? and dev_sn = ? and dev_type = ? and trigger_mode=? and status in ?",
		req.TbCode, req.DeviceSn, req.DeviceType, constant.TriggerModeAuto, []int{constant.CounterTaskStatusInProgress}).Find(&tasks).Error; err != nil {
		logger.Errorf("Find error: %s", err.Error())
		return errors.New("DB error")
	}
	if len(tasks) > 0 {
		logger.Error("auto counter task Find as exist")
		return errors.New("task exist")
	}

	var trackId string
	trackIds := alarm_service.GetTrackIdByDevice(req.TbCode, req.DeviceSn, config.GlobalRedis)
	for _, item := range trackIds {
		if item == nil {
			continue
		}
		logger.Infof("track id: %v, device: %v", item.TrackId, req.DeviceSn)
		if item.TrackId == "" {
			continue
		}
		trackId = item.TrackId
	}
	req.TrackId = trackId

	newTask := &model.CounterTask{
		ID:          taskId,
		TbCode:      req.TbCode,
		TriggerMode: constant.TriggerModeAuto,
		Status:      constant.CounterTaskStatusInProgress,
		DevSn:       req.DeviceSn,
		DevType:     req.DeviceType,
		DevName:     req.DeviceName,
		Mode:        int16(req.HitMode),
		ObjName:     req.ObjName,
		ObjType:     req.ObjType,
		ExtraParams: req.ExtraParams,
		DurTimeS:    req.HitDurTimeSecond,
		BeginTime:   time.Now().UTC(),
		TrackId:     req.TrackId,
	}

	if req.RuleId > 0 {
		newTask.CounterId = req.RuleId
	}

	if err := c.dbOps.GetDBHandle().Model(&model.CounterTask{}).Create(newTask).Error; err != nil {
		logger.Errorf("create task error: %s", err.Error())
		return errors.New("create task error")
	}
	// 写redis
	redisVal, _ := json.Marshal(model.CounterTaskRdValue{ID: newTask.ID, TbCode: newTask.TbCode, BeginTime: newTask.BeginTime})
	if err := c.rds.Client().RPush(context.Background(), constant.RedisKeyCounterTaskInProgress, string(redisVal)).Err(); err != nil {
		logger.Errorf("CounterTaskManualStart RPush error: %s", err.Error())
	}
	// 变更通知
	access.SendKafkaMsg(config.GetConfig().Kafka.EventNoticeTopic, access.NoticeItem{
		Key:  constant.UrlTaskStatusUpdate,
		Data: access.TbCode{TbCode: req.TbCode},
	})
	return nil
}

func (c *CounterTaskOps) QueryTaskListByTrackId(trackId string, tbCode string) (error, []*model.CounterTask) {
	if c == nil || c.dbOps == nil {
		logger.Errorf("task on db handle not init")
		return errors.New("db handle is nil"), nil
	}

	whereCond := "track_id = ? and tb_code = ?"
	whereValue := []any{trackId, tbCode}

	taskList, err := c.dbOps.QueryItemOnCond(whereCond, whereValue, map[string]bool{
		"begin_time": true,
	}, 0, 0)

	if err != nil {
		logger.Errorf("query tasks fail, err: %v, trackId: %v, tbCode: %v", err, trackId, tbCode)
		return err, nil
	}
	return nil, taskList
}

// QueryTaskDetailList 查询任务详情
func (c *CounterTaskOps) QueryTaskDetailList(taskIds []int64) (error, []*model.CounterTask) {
	if c == nil || c.dbOps == nil {
		logger.Errorf("task on db handle not init")
		return errors.New("db handle is nil"), nil
	}
	if len(taskIds) == 0 {
		return nil, nil
	}
	ret, err := c.dbOps.QueryItems(taskIds)
	if err != nil {
		logger.Errorf("query task detail by task id fail, err: %v", err)
		return err, nil
	}
	return err, ret
}

// QueryCounterTaskCount
func (c *CounterTaskOps) CounterTaskProgressCount(ctx context.Context, req *request.TaskProgressCountRequest) (*response.TaskProgressCount, error) {
	if c == nil || c.dbOps == nil {
		logger.Errorf("task on db handle not init")
		return nil, errors.New("db handle is nil")
	}
	now := time.Now().UTC()
	total, err := c.dbOps.CountItems("begin_time > ? and begin_time < ? and tb_code = ? and status = ?",
		[]any{now.Add(-2 * time.Hour), now.Add(1 * time.Hour), req.TbCode, constant.CounterTaskStatusInProgress})
	if err != nil {
		return nil, err
	}
	return &response.TaskProgressCount{
		Count: total,
	}, nil
}
