package countertask

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"gorm.io/gorm"
)

func InitRes(ctx context.Context) {
	InitCounterTask()
}

type CounterTaskDBType = db.DbOpsTplInterface[model.CounterTask]

var CounterTaskDBHandle CounterTaskDBType = nil

// InitCounterTask 在主流程中注册该函数
func InitCounterTask() CounterTaskDBType {
	CounterTaskDBHandle = db.NewDBModelTplWrapper[model.CounterTask](config.GetDB()).SetTabName(model.CounterTask{}.TableName())
	return CounterTaskDBHandle
}

// MockCounterTaskDBType 仅用于测试 mock task db
func MockCounterTaskDBType(dbHandle *gorm.DB) CounterTaskDBType {
	CounterTaskDBHandle = db.NewDBModelTplWrapper[model.CounterTask](dbHandle).SetTabName(model.CounterTask{}.TableName())
	return CounterTaskDBHandle
}
