package uav_record

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/apimap"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/repository/geo"
	"cuav-cloud-go-service/domain/service/alarm_service"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	DetectUavEventKeyPrefix = "Detect.Uav.Event.Key@"
	taskUniqueKey           = "UavRecordStrategyRunV2"
	AlarmCheckDistance      = 500
	CacheKeySplitSize       = 6
	EventStart              = 0
	EventEnd                = 1
	inarea                  = 0
	outarea                 = 1
	timeoutCheck            = 200000
	workTaskSize            = 10
	queueSize               = 2000
	updateWorkTaskSize      = 5
	updateQueueSize         = 2000
)

var (
	uavFlyMessageCh       chan uavFlyMessage
	uavEventUpdateCh      chan uavEventUpdateItem
	onceDo                sync.Once
	gUavRecordStrategyMap map[string]bean.FencedUavRecord = make(map[string]bean.FencedUavRecord)
	gKeyIdMap             map[string]int64                = make(map[string]int64)
	gEventTimeMap         map[string]time.Time            = make(map[string]time.Time)
)

type VideoTime struct {
	StartTime string `json:"startTime"`
	EndTime   string `json:"endTime"`
}
type uavFlyMessage struct {
	TbCode   string
	UavData  *pb.AlarmCheckReqItem
	AreaData []*bean.FencedAreaConfig
}

type uavEventUpdateItem struct {
	Id        int64
	SiteStart uavTude
	SiteEnd   uavTude
	EndTime   time.Time
	Status    int
}

type uavTude struct {
	Longitude float64 // 经度
	Latitude  float64 // 纬度
}

// SendUavFlyMessage
func SendUavFlyMessage(tbcode string, uavdata *pb.AlarmCheckReqItem, areaData []*bean.FencedAreaConfig) {
	uavFlyMessageCh <- uavFlyMessage{
		TbCode:   tbcode,
		UavData:  uavdata,
		AreaData: areaData,
	}
}

// 异步处理慢流程
func sendUavEventUpdateItem(msg uavEventUpdateItem) {
	uavEventUpdateCh <- msg
}

func InitUavFlyHandler() {
	onceDo.Do(func() {
		uavFlyMessageCh = make(chan uavFlyMessage, queueSize)
		uavEventUpdateCh = make(chan uavEventUpdateItem, updateQueueSize)
		for number := 0; number < workTaskSize; number++ {
			go func(taskNo int) {
				defer func() {
					if err := recover(); err != nil {
						logger.Errorf("task no {%d} panic error: %s", taskNo, utils.ErrTrace(fmt.Sprintf("%+v", err)))
					}
				}()

				// 处理
				for msg := range uavFlyMessageCh {
					uavStart := time.Now().UnixMicro()
					UavRecordStoreV2(msg.TbCode, msg.UavData, msg.AreaData)
					if time.Now().UnixMicro()-uavStart > timeoutCheck {
						logger.Infof("task no {%d} UavRecordStoreV2 cost: %d", taskNo, time.Now().UnixMicro()-uavStart)
					}
				}
			}(number)
		}

		for number := 0; number < updateWorkTaskSize; number++ {
			go func(taskNo int) {
				defer func() {
					if err := recover(); err != nil {
						logger.Errorf("task no {%d} panic error: %s", taskNo, utils.ErrTrace(fmt.Sprintf("%+v", err)))
					}
				}()

				// 处理
				for msg := range uavEventUpdateCh {
					uavStart := time.Now().UnixMicro()
					if err := handleUavEventUpdate(msg); err != nil {
						logger.Errorf("task no {%d} update uav event error: %s", taskNo, err.Error())
					}
					if time.Now().UnixMicro()-uavStart > 5000000 {
						logger.Infof("task no {%d} handleUavEventUpdate cost: %d", taskNo, time.Now().UnixMicro()-uavStart)
					}
				}
			}(number)
		}
	})
}

func handleUavEventUpdate(msg uavEventUpdateItem) error {
	endSite := apimap.GetSite(msg.SiteEnd.Longitude, msg.SiteEnd.Latitude)
	startSite := apimap.GetSite(msg.SiteStart.Longitude, msg.SiteStart.Latitude)
	updateMsg := map[string]any{
		"start_site": startSite,
		"end_site":   endSite,
		"end_time":   msg.EndTime,
		"status":     msg.Status,
	}
	if err := config.GetDB().Model(&bean.FencedUavRecord{}).Where("id = ?", msg.Id).UpdateColumns(updateMsg).Error; err != nil {
		return err
	}
	return nil
}

func removeOutDateEventTime() {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("removeOutDateEventTime panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	for {
		time.Sleep(10 * time.Minute)
		for k, v := range gEventTimeMap {
			if time.Now().UTC().Sub(v)/10e8 > 10*60 {
				delete(gEventTimeMap, k)
			}
		}
	}
}

// 弃用
func UavRecordStrategyRun() {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("UavRecordStrategyRun panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	go removeOutDateEventTime()
	alarm_db := alarm_service.ResAlarmDB.GetDBHandle()

	for {
		time.Sleep(5 * time.Second)
		uavTimeout := NewRefreshUavTimeoutConfig().getUavTimeout()
		for key, v := range gUavRecordStrategyMap {

			id := gKeyIdMap[key]
			if time.Now().UnixMilli()-v.EndTime.UnixMilli() > int64(uavTimeout) {
				// 查不到就是无告警
				var maxRiskLevel int32
				if err := alarm_db.Model(&bean.FendAreaAlarm{}).
					Select("COALESCE(MAX(risk_level), 0)").
					Where("track_id = ? AND create_time BETWEEN ? AND ? ", v.TrackId, v.StartTime.UTC(), v.EndTime.UTC()).
					Scan(&maxRiskLevel).Error; err != nil {
					logger.Errorf("UavRecordStrategyRun query uav alarm level error: %s", err.Error())
				}

				endSite := apimap.GetSite(v.Longitude, v.Latitude)
				startSite := apimap.GetSite(v.StartLongitude, v.StartLatitude)
				var err error
				timeList := make([]VideoTime, 0)
				var timeMsg []byte
				if len(v.Eventid) != 0 {
					startTimeTemp := v.StartTime
					endTimeTemp := v.EndTime.Add(1 * time.Second)
					if val, ok := gEventTimeMap[v.Eventid]; ok {
						if v.StartTime.Sub(val) > 0 {
							startTimeTemp = val
						} else {
							logger.Error("C2 event startTime larger than drone event startTime")
						}
					}

					times := VideoTime{
						StartTime: startTimeTemp.Format(time.RFC3339Nano),
						EndTime:   endTimeTemp.Format(time.RFC3339Nano),
					}
					timeList = append(timeList, times)
					timeMsg, err = json.Marshal(timeList)
					if err != nil {
						logger.Error("errj = ", err)
					}

					_, err = alarm_service.ResUavRecordmDB.Updates("id", []any{id}, bean.FencedUavRecord{
						ID:             id, //注意：这里的id是唯一的，不能重复
						SerialNum:      v.SerialNum,
						ObjID:          v.ObjID,
						DroneName:      v.DroneName,
						StartTime:      v.StartTime,
						EndTime:        v.EndTime,
						Duration:       int64(endTimeTemp.Sub(startTimeTemp)) / 10e8, //second
						AreaID:         v.AreaID,
						PilotLongitude: v.PilotLongitude,
						PilotLatitude:  v.PilotLatitude,
						HomeLongitude:  v.HomeLongitude,
						HomeLatitude:   v.HomeLatitude,
						SN:             v.SN,
						TbCode:         v.TbCode,
						Status:         1,
						C2SN:           v.C2SN,
						Type:           v.Type,
						Longitude:      v.Longitude,
						Latitude:       v.Latitude,
						Freq:           v.Freq,
						AreaName:       v.AreaName,
						Videotime:      timeMsg,
						Devrelations:   v.Devrelations,
						StartSite:      startSite,
						EndSite:        endSite,
						RiskLevel:      maxRiskLevel,
						Eventid:        v.Eventid,
						TrackId:        v.TrackId,
					})
				} else {
					logger.Error("event id is nil")
					_, err = alarm_service.ResUavRecordmDB.Updates("id", []any{id}, bean.FencedUavRecord{
						ID:             id, //注意：这里的id是唯一的，不能重复
						SerialNum:      v.SerialNum,
						ObjID:          v.ObjID,
						DroneName:      v.DroneName,
						StartTime:      v.StartTime,
						EndTime:        v.EndTime,
						Duration:       int64(time.Since(v.StartTime)) / 10e8, //second
						AreaID:         v.AreaID,
						PilotLongitude: v.PilotLongitude,
						PilotLatitude:  v.PilotLatitude,
						HomeLongitude:  v.HomeLongitude,
						HomeLatitude:   v.HomeLatitude,
						SN:             v.SN,
						TbCode:         v.TbCode,
						Status:         1,
						C2SN:           v.C2SN,
						Type:           v.Type,
						Longitude:      v.Longitude,
						Latitude:       v.Latitude,
						Freq:           v.Freq,
						AreaName:       v.AreaName,
						Videotime:      timeMsg,
						Devrelations:   v.Devrelations,
						StartSite:      startSite,
						EndSite:        endSite,
						RiskLevel:      maxRiskLevel,
						TrackId:        v.TrackId,
					})
				}

				if err != nil {
					logger.Error("update ResUavRecordmDB fail, err: %v", err)
				}
				delete(gUavRecordStrategyMap, key)
				delete(gKeyIdMap, key)
			} else {
				logger.Debugf("uav still keep fly, uav = %+v", v)
			}
		}

	}
}

func getScanEventsFromCache() ([]any, error) {
	var (
		keys   []string
		cursor uint64
		err    error
	)
	for {
		redisRes := config.GlobalRedis.Client().Scan(context.Background(), cursor, DetectUavEventKeyPrefix+"*", 100)
		if redisRes.Err() != nil {
			logger.Errorf("UavRecordStrategyRunV2 scan redis key error: %s", redisRes.Err())
			break
		}
		var ks []string
		ks, cursor, err = redisRes.Result()
		if err != nil {
			logger.Errorf("UavRecordStrategyRunV2 scan redis key error: %s", err.Error())
			break
		}
		keys = append(keys, ks...)
		if cursor == 0 {
			break
		}
	}
	if len(keys) == 0 {
		return nil, nil
	}
	var resultSet []any
	batchSize := 50
	for i := 0; i < len(keys); i += batchSize {
		end := i + batchSize
		if end > len(keys) {
			end = len(keys)
		}
		values, err := config.GlobalRedis.Client().MGet(context.Background(), keys[i:end]...).Result()
		if err != nil {
			logger.Errorf("UavRecordStrategyRunV2 mget redis error: %s", err.Error())
			continue
		}
		resultSet = append(resultSet, values...)
	}

	return resultSet, nil
}

func getEvent(val any) (*bean.FencedUavRecord, error) {
	event := new(bean.FencedUavRecord)
	var body []byte
	if v, ok := val.(string); ok {
		body = []byte(v)
	} else {
		vv, err := json.Marshal(val)
		if err != nil {
			return nil, err
		}
		body = vv
	}
	if err := json.Unmarshal([]byte(body), event); err != nil {
		return nil, err
	}
	return event, nil
}

func UavRecordStrategyRunV2() {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("UavRecordStrategyRunV2 panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	alarm_db := alarm_service.ResAlarmDB.GetDBHandle()

	for {
		time.Sleep(5 * time.Second)
		setNXRes := config.GlobalRedis.Client().SetNX(context.Background(), taskUniqueKey, time.Now().UnixNano(), 5*time.Minute)
		if setNXRes.Err() != nil {
			logger.Infof("UavRecordStrategyRunV2 SetNX error: %s", setNXRes.Err())
			time.Sleep(time.Second)
			continue
		}
		setResult, err := setNXRes.Result()
		if err != nil {
			logger.Infof("UavRecordStrategyRunV2 SetNX get result error: %s", err.Error())
			time.Sleep(time.Second)
			continue
		}
		if !setResult {
			logger.Infof("UavRecordStrategyRunV2 SetNX fail")
			time.Sleep(time.Second)
			continue
		}
		uavTimeout := NewRefreshUavTimeoutConfig().getUavTimeout()
		// scan cache
		valSet, err := getScanEventsFromCache()
		if err != nil {
			return
		}
		for _, val := range valSet {
			v, err := getEvent(val)
			if err != nil {
				logger.Errorf("UavRecordStrategyRunV2 Marshal event error: %s", err.Error())
				continue
			}
			if time.Now().UnixMilli()-v.EndTime.UnixMilli() > int64(uavTimeout) {
				// 事件结束
				// 查不到就是无告警
				var maxRiskLevel int32
				if err := alarm_db.Model(&bean.FendAreaAlarm{}).
					Select("COALESCE(MAX(risk_level), 0)").
					Where("track_id = ? AND create_time BETWEEN ? AND ? ", v.TrackId, v.StartTime.UTC(), v.EndTime.UTC()).
					Scan(&maxRiskLevel).Error; err != nil {
					logger.Errorf("UavRecordStrategyRun query uav alarm level error: %s", err.Error())
				}
				v.RiskLevel = maxRiskLevel
				updateItem := uavEventUpdateItem{
					Id:        v.ID,
					SiteStart: uavTude{Longitude: v.StartLongitude, Latitude: v.StartLatitude},
					SiteEnd:   uavTude{Longitude: v.Longitude, Latitude: v.Latitude},
					EndTime:   v.EndTime.Add(time.Second),
					Status:    EventEnd,
				}
				sendUavEventUpdateItem(updateItem)
				if len(v.Eventid) != 0 {
					timeList := []VideoTime{{
						StartTime: v.StartTime.Format(time.RFC3339Nano),
						EndTime:   v.EndTime.Format(time.RFC3339Nano),
					}}
					if timeMsg, err := json.Marshal(timeList); err != nil {
						logger.Error("errj = ", err)
					} else {
						v.Videotime = timeMsg
					}
				}
				if _, err := alarm_service.ResUavRecordmDB.Updates("id", []any{v.ID}, v); err != nil {
					logger.Errorf("UavRecordStrategyRunV2 Updates event error: %s", err.Error())
					continue
				}
				key := DetectUavEventKeyPrefix + fmt.Sprintf("%s@%s", v.TbCode, v.TrackId)
				if err := config.GlobalRedis.Client().Del(context.Background(), key).Err(); err != nil {
					logger.Errorf("UavRecordStrategyRunV2 delete event error: %s", err.Error())
					continue
				}
			}
		}
		if err := config.GlobalRedis.Client().Del(context.Background(), taskUniqueKey).Err(); err != nil {
			logger.Errorf("UavRecordStrategyRunV2 Updates event error: %s", err.Error())
		}
	}
}

// UavRecordStoreV2
func UavRecordStoreV2(tbcode string, uavdata *pb.AlarmCheckReqItem, areaData []*bean.FencedAreaConfig) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("UavRecordStoreV2 panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	uavTimeout := NewRefreshUavTimeoutConfig().getUavTimeout()
	var newEvents []*bean.FencedUavRecord
	for _, v := range uavdata.UavItems {
		devRelationsJSON, err := json.Marshal(v.DevRelations)
		if err != nil {
			logger.Error(err)
		}
		// c2 SN， 设备SN，无人机SN，无人机ObjID
		key := DetectUavEventKeyPrefix + fmt.Sprintf("%s@%s", tbcode, v.TrackId)
		eventVal, err := config.GlobalRedis.Get(key)
		if err != nil && err.Error() != "redis: nil" {
			logger.Errorf("get key %s from cache error: %s", key, err.Error())
			continue
		}
		var cacheItem *bean.FencedUavRecord
		if eventVal != nil {
			cacheItem, err = parseUavRecordCacheItem(eventVal)
			if err != nil {
				logger.Errorf("parseUavRecordCacheItem cache error: %s", err.Error())
				continue
			}
			if time.Now().Before(cacheItem.EndTime.Add(time.Second)) {
				// 丢弃
				logger.Errorf("discard event ID {%d}", cacheItem.ID)
				continue
			}
		}
		//按C2
		if len(areaData) == 0 {
			for _, c2Local := range uavdata.C2Location {
				if geo.GeoDistance(c2Local.Longitude, c2Local.Latitude, v.GetLongitude(), v.GetLatitude()) < AlarmCheckDistance {
					if cacheItem != nil {
						if v.GetEventId() != cacheItem.Eventid || (time.Now().UnixMilli()-cacheItem.EndTime.UnixMilli() > int64(uavTimeout)) {
							logger.Infof("UavRecordStoreV2 event end event: %+v", cacheItem)
							// 侦测事件结束
							// 1、更新事件信息
							var maxRiskLevel int32
							if err := alarm_service.ResAlarmDB.GetDBHandle().Model(&bean.FendAreaAlarm{}).
								Select("COALESCE(MAX(risk_level), 0)").
								Where("track_id = ? AND create_time BETWEEN ? AND ? ", cacheItem.TrackId,
									cacheItem.StartTime.UTC(), cacheItem.EndTime.UTC()).
								Scan(&maxRiskLevel).Error; err != nil {
								logger.Errorf("UavRecordStrategyRun query uav alarm level error: %s", err.Error())
							}
							cacheItem.RiskLevel = maxRiskLevel
							updateItem := uavEventUpdateItem{
								Id:        cacheItem.ID,
								SiteStart: uavTude{Longitude: cacheItem.StartLongitude, Latitude: cacheItem.StartLatitude},
								SiteEnd:   uavTude{Longitude: cacheItem.Longitude, Latitude: cacheItem.Latitude},
								EndTime:   cacheItem.EndTime,
								Status:    EventEnd,
							}
							sendUavEventUpdateItem(updateItem)
							if cacheItem.Eventid != "" {
								timeList := []VideoTime{{
									StartTime: cacheItem.StartTime.Format(time.RFC3339Nano),
									EndTime:   cacheItem.EndTime.Add(time.Second).Format(time.RFC3339Nano),
								}}
								if timeMsg, err := json.Marshal(timeList); err != nil {
									logger.Error("errj = ", err)
								} else {
									cacheItem.Videotime = timeMsg
								}
							}
							cacheItem.Duration = int64(cacheItem.EndTime.Sub(cacheItem.StartTime)) / 10e8 //second
							if _, err := alarm_service.ResUavRecordmDB.Updates("id", []any{cacheItem.ID}, cacheItem); err != nil {
								logger.Errorf("UavRecordStoreV2 event end update event error: %s", err.Error())
								continue
							}

							// 2、删除redis缓存
							if err := config.GlobalRedis.Client().Del(context.Background(), key).Err(); err != nil {
								logger.Errorf("del cache error: %s", err.Error())
								continue
							}

							// 3、创建新的事件
							newEvent, err := genEvent(tbcode, v, nil, devRelationsJSON)
							if err != nil {
								logger.Errorf("gen new event error: %s", err.Error())
								continue
							}
							newEvents = append(newEvents, newEvent)
							break
						}

						cacheItem.EndTime = time.Now().UTC()
						cacheItem.Duration = int64(cacheItem.EndTime.Sub(cacheItem.StartTime)) / 10e8 //second
						cacheItem.Devrelations = devRelationsJSON
						refreshFencedUavRecord(cacheItem, v)
						if err = config.GlobalRedis.SetEx(key, cacheItem, time.Hour); err != nil {
							logger.Errorf("SetEx key %s from cache error: %s", key, err.Error())
						}
					} else {
						// 创建新事件
						newEvent, err := genEvent(tbcode, v, nil, devRelationsJSON)
						if err != nil {
							logger.Errorf("gen new event error: %s", err.Error())
							continue
						}
						newEvents = append(newEvents, newEvent)
					}
					// 只算经过一个c2
					break
				}
			}
		} else {
			for _, fendArea := range areaData {
				fendAreaLonLat, _ := geo.UnmarshalToPoint(fendArea.Geometry)
				intersection := geo.GeoCalcMiniDistanceToPolygonsByDistance(v.GetLongitude(), v.GetLatitude(), fendAreaLonLat, AlarmCheckDistance)
				if intersection {
					if cacheItem != nil {
						if v.GetEventId() != cacheItem.Eventid || (time.Now().UnixMilli()-cacheItem.EndTime.UnixMilli() > int64(uavTimeout)) {
							logger.Errorf("UavRecordStoreV2--- end cache event: %+v", cacheItem)
							logger.Errorf("UavRecordStoreV2--- end event: %+v", v)
							// 侦测事件结束
							// 1、更新事件信息
							var maxRiskLevel int32
							if err := alarm_service.ResAlarmDB.GetDBHandle().Model(&bean.FendAreaAlarm{}).
								Select("COALESCE(MAX(risk_level), 0)").
								Where("track_id = ? AND create_time BETWEEN ? AND ? ", cacheItem.TrackId,
									cacheItem.StartTime.UTC(), cacheItem.EndTime.UTC()).
								Scan(&maxRiskLevel).Error; err != nil {
								logger.Errorf("UavRecordStrategyRun query uav alarm level error: %s", err.Error())
							}
							cacheItem.RiskLevel = maxRiskLevel
							// 处理慢请求
							updateItem := uavEventUpdateItem{
								Id:        cacheItem.ID,
								SiteStart: uavTude{Longitude: cacheItem.StartLongitude, Latitude: cacheItem.StartLatitude},
								SiteEnd:   uavTude{Longitude: cacheItem.Longitude, Latitude: cacheItem.Latitude},
								EndTime:   cacheItem.EndTime,
								Status:    EventEnd,
							}
							sendUavEventUpdateItem(updateItem)
							if cacheItem.Eventid != "" {
								timeList := []VideoTime{{
									StartTime: cacheItem.StartTime.Format(time.RFC3339Nano),
									EndTime:   cacheItem.EndTime.Add(time.Second).Format(time.RFC3339Nano),
								}}
								if timeMsg, err := json.Marshal(timeList); err != nil {
									logger.Error("errj = ", err)
								} else {
									cacheItem.Videotime = timeMsg
								}
							}
							cacheItem.Duration = int64(cacheItem.EndTime.Sub(cacheItem.StartTime)) / 10e8 //second
							if _, err := alarm_service.ResUavRecordmDB.Updates("id", []any{cacheItem.ID}, cacheItem); err != nil {
								logger.Error("UavRecordStoreV2 event end update event error: %s", err.Error())
								continue
							}

							// 2、删除redis缓存
							if err := config.GlobalRedis.Client().Del(context.Background(), key).Err(); err != nil {
								logger.Errorf("del cache error: %s", err.Error())
								continue
							}

							// 3、创建新的事件
							// 创建新事件
							newEvent, err := genEvent(tbcode, v, nil, devRelationsJSON)
							if err != nil {
								logger.Errorf("gen new event error: %s", err.Error())
								continue
							}
							newEvents = append(newEvents, newEvent)
							// 只算经过一个围栏区
							break
						}
						cacheItem.EndTime = time.Now().UTC()
						cacheItem.Duration = int64(cacheItem.EndTime.Sub(cacheItem.StartTime)) / 10e8 //second
						cacheItem.Devrelations = devRelationsJSON
						cacheItem.AreaID = fendArea.ID
						cacheItem.AreaName = fendArea.AreaName
						refreshFencedUavRecord(cacheItem, v)
						if err = config.GlobalRedis.SetEx(key, cacheItem, time.Hour); err != nil {
							logger.Errorf("SetEx key %s from cache error: %s", key, err.Error())
						}
					} else {
						//之前不存在，则新建，并存库记录
						// 创建新事件
						newEvent, err := genEvent(tbcode, v, fendArea, devRelationsJSON)
						if err != nil {
							logger.Errorf("gen new event error: %s", err.Error())
							continue
						}
						newEvents = append(newEvents, newEvent)
					}
					// 只算经过一个围栏区
					break
				}
			}
		}
	}
	if len(newEvents) > 0 {
		if err := saveEvents(newEvents); err != nil {
			logger.Errorf("saveEvents error: %s", err.Error())
		}
	}
}

func saveEvents(events []*bean.FencedUavRecord) error {
	// 缓存
	for _, event := range events {
		cacheKey := DetectUavEventKeyPrefix + fmt.Sprintf("%s@%s", event.TbCode, event.TrackId)
		if err := config.GlobalRedis.SetEx(cacheKey, event, time.Hour); err != nil {
			continue
		}
	}
	if _, err := alarm_service.ResUavRecordmDB.Insert(events); err != nil {
		return err
	}

	return nil
}

func genEvent(tbCode string, v *pb.DevLocationInfo, fendArea *bean.FencedAreaConfig, devRelationsJSON json.RawMessage) (*bean.FencedUavRecord, error) {
	id, err := snowflake.GetUniqueID()
	if err != nil {
		return nil, err
	}
	item := buildEvent(id, tbCode, fendArea, devRelationsJSON)
	refreshFencedUavRecord(item, v)

	return item, err
}

func buildEvent(id int64, tbCode string, fendArea *bean.FencedAreaConfig, devRelationsJSON json.RawMessage) *bean.FencedUavRecord {
	item := &bean.FencedUavRecord{
		ID:           id,
		StartTime:    time.Now().UTC(),
		EndTime:      time.Now().UTC(),
		Duration:     0,
		AreaID:       -1,
		TbCode:       tbCode,
		Status:       EventStart,
		Type:         outarea,
		Devrelations: devRelationsJSON,
		AreaName:     "-1",
	}
	if fendArea != nil {
		if fendArea.ID != 0 {
			item.AreaID = fendArea.ID
		}
		if fendArea.AreaName != "" {
			item.AreaName = fendArea.AreaName
		}
		item.Type = inarea
	}
	return item
}

func parseUavRecordCacheItem(eventVal any) (*bean.FencedUavRecord, error) {
	cacheItem := &bean.FencedUavRecord{}
	if eventVal != nil {
		if redisVal, ok := eventVal.(string); ok {
			if err := json.Unmarshal([]byte(redisVal), cacheItem); err != nil {
				logger.Errorf("cache value error: %s", err.Error())
				return cacheItem, err
			}
		} else {
			valBytes, err := json.Marshal(eventVal)
			if err != nil {
				logger.Errorf("cache value Marshal error: %s", err.Error())
				return cacheItem, err
			}
			if err := json.Unmarshal(valBytes, cacheItem); err != nil {
				logger.Errorf("cache value Unmarshal error: %s", err.Error())
				return cacheItem, err
			}
		}
	}

	return cacheItem, nil
}

func refreshFencedUavRecord(record *bean.FencedUavRecord, v *pb.DevLocationInfo) {
	record.SerialNum = v.Sn
	record.ObjID = v.ObjID
	record.DroneName = v.Name
	record.PilotLongitude = v.PilotLongitude
	record.PilotLatitude = v.PilotLongitude
	record.HomeLongitude = v.HomeLongitude
	record.HomeLatitude = v.HomeLatitude
	record.SN = v.DetectDevSn
	record.C2SN = v.C2Sn
	record.Longitude = v.Longitude
	record.Latitude = v.Latitude
	record.Freq = v.Freq
	record.StartLongitude = v.Longitude
	record.StartLatitude = v.Latitude
	record.Eventid = v.EventId
	record.TrackId = v.GetTrackId()
}

// 弃用
func UavRecordStore(tbcode string, uavdata *pb.AlarmCheckReqItem, areaData []*bean.FencedAreaConfig) {
	for _, v := range uavdata.UavItems {
		if len(v.EventId) != 0 {
			if _, ok := gEventTimeMap[v.EventId]; !ok {
				gEventTimeMap[v.EventId] = time.Now().UTC()
			}
		}

		devRelationsJSON, err := json.Marshal(v.DevRelations)
		if err != nil {
			logger.Error(err)
		}
		//按C2
		if len(areaData) == 0 {
			for _, c2Local := range uavdata.C2Location {
				if geo.GeoDistance(c2Local.Longitude, c2Local.Latitude, v.GetLongitude(), v.GetLatitude()) < 500 {
					// c2 SN， 设备SN，无人机名字，无人机SN，无人机ObjID
					key := fmt.Sprintf("%s_%s_%s_%s_%s", v.C2Sn, v.DetectDevSn, v.Name, v.Sn, v.ObjID)
					if val, ok := gUavRecordStrategyMap[key]; ok {
						eventidTmp := val.Eventid
						if len(v.EventId) != 0 {
							eventidTmp = v.EventId
						} else {
							logger.Error("rcv eventid is nil")
						}
						gUavRecordStrategyMap[key] = bean.FencedUavRecord{
							ID:             gKeyIdMap[key], //注意：这里的id是唯一的，不能重复
							SerialNum:      v.Sn,
							ObjID:          v.ObjID,
							DroneName:      v.Name,
							StartTime:      val.StartTime,
							EndTime:        time.Now().UTC(),
							Duration:       int64(time.Since(val.StartTime)) / 10e8, //second
							AreaID:         -1,
							PilotLongitude: v.PilotLatitude,
							PilotLatitude:  v.PilotLatitude,
							HomeLongitude:  v.HomeLongitude,
							HomeLatitude:   v.HomeLatitude,
							SN:             v.DetectDevSn,
							TbCode:         tbcode,
							Status:         0,
							C2SN:           v.C2Sn,
							Type:           outarea,
							Longitude:      v.Longitude,
							Latitude:       v.Latitude,
							Freq:           v.Freq,
							Eventid:        eventidTmp,
							Devrelations:   devRelationsJSON,
							StartLongitude: val.StartLongitude,
							StartLatitude:  val.StartLatitude,
							AreaName:       "-1",
							TrackId:        v.GetTrackId(),
						}
					} else {
						//之前不存在，则新建，并存库记录
						id, err := snowflake.GetUniqueID()
						if err != nil {
							logger.Errorf("err = %s", err.Error())
							continue
						}
						gKeyIdMap[key] = id
						item := bean.FencedUavRecord{
							ID:             id, //注意：这里的id是唯一的，不能重复
							SerialNum:      v.Sn,
							ObjID:          v.ObjID,
							DroneName:      v.Name,
							StartTime:      time.Now().UTC(),
							EndTime:        time.Now().UTC(),
							Duration:       0,
							AreaID:         -1,
							PilotLongitude: v.PilotLongitude,
							PilotLatitude:  v.PilotLatitude,
							HomeLongitude:  v.HomeLongitude,
							HomeLatitude:   v.HomeLatitude,
							SN:             v.DetectDevSn,
							TbCode:         tbcode,
							Status:         0,
							C2SN:           v.C2Sn,
							Type:           outarea,
							Longitude:      v.Longitude,
							Latitude:       v.Latitude,
							Freq:           v.Freq,
							StartLongitude: v.Longitude,
							StartLatitude:  v.Latitude,
							Eventid:        v.EventId,
							Devrelations:   devRelationsJSON,
							AreaName:       "-1",
							TrackId:        v.GetTrackId(),
						}
						items := make([]*bean.FencedUavRecord, 0)

						gUavRecordStrategyMap[key] = item
						items = append(items, &item)
						_, err = alarm_service.ResUavRecordmDB.Insert(items)
						if err != nil {
							logger.Errorf("insert alarm record fail, err: %v", err)
						}
					}
				}
			}
		} else {
			// for _, c2Local := range uavdata.C2Location {
			for _, fendArea := range areaData {
				fendAreaLonLat, _ := geo.UnmarshalToPoint(fendArea.Geometry)
				intersection := geo.GeoCalcMiniDistanceToPolygonsByDistance(v.GetLongitude(), v.GetLatitude(), fendAreaLonLat, 500)
				if intersection {
					// c2 SN， 设备SN，无人机名字，无人机SN，无人机ObjID
					key := fmt.Sprintf("%s_%s_%s_%s_%s", v.C2Sn, v.DetectDevSn, v.Name, v.Sn, v.ObjID)

					if val, ok := gUavRecordStrategyMap[key]; ok {
						eventidTmp := val.Eventid
						if len(v.EventId) != 0 {
							eventidTmp = v.EventId
						} else {
							logger.Error("rcv eventid is nil")
						}
						gUavRecordStrategyMap[key] = bean.FencedUavRecord{
							ID:             gKeyIdMap[key], //注意：这里的id是唯一的，不能重复
							SerialNum:      v.Sn,
							ObjID:          v.ObjID,
							DroneName:      v.Name,
							StartTime:      val.StartTime,
							EndTime:        time.Now().UTC(),
							Duration:       int64(time.Since(val.StartTime)) / 10e8, //second
							AreaID:         fendArea.ID,
							PilotLongitude: v.PilotLongitude,
							PilotLatitude:  v.PilotLatitude,
							HomeLongitude:  v.HomeLongitude,
							HomeLatitude:   v.HomeLatitude,
							SN:             v.DetectDevSn,
							TbCode:         tbcode,
							Status:         0,
							C2SN:           v.C2Sn,
							Type:           inarea,
							Longitude:      v.Longitude,
							Latitude:       v.Latitude,
							AreaName:       fendArea.AreaName,
							Freq:           v.Freq,
							Eventid:        eventidTmp,
							Devrelations:   devRelationsJSON,
							StartLongitude: val.StartLongitude,
							StartLatitude:  val.StartLatitude,
							TrackId:        v.GetTrackId(),
						}
					} else {
						//之前不存在，则新建，并存库记录
						id, err := snowflake.GetUniqueID()
						if err != nil {
							logger.Debug("err = ", err)
						}
						gKeyIdMap[key] = id
						item := bean.FencedUavRecord{
							ID:             id, //注意：这里的id是唯一的，不能重复
							SerialNum:      v.Sn,
							ObjID:          v.ObjID,
							DroneName:      v.Name,
							StartTime:      time.Now().UTC(),
							EndTime:        time.Now().UTC(),
							Duration:       0,
							AreaID:         fendArea.ID,
							PilotLongitude: v.PilotLongitude,
							PilotLatitude:  v.PilotLongitude,
							HomeLongitude:  v.HomeLongitude,
							HomeLatitude:   v.HomeLatitude,
							SN:             v.DetectDevSn,
							TbCode:         tbcode,
							Status:         0,
							C2SN:           v.C2Sn,
							Type:           inarea,
							Longitude:      v.Longitude,
							Latitude:       v.Latitude,
							Freq:           v.Freq,
							AreaName:       fendArea.AreaName,
							StartLongitude: v.Longitude,
							StartLatitude:  v.Latitude,
							Eventid:        v.EventId,
							Devrelations:   devRelationsJSON,
							TrackId:        v.GetTrackId(),
						}
						items := make([]*bean.FencedUavRecord, 0)
						gUavRecordStrategyMap[key] = item
						items = append(items, &item)
						_, err = alarm_service.ResUavRecordmDB.Insert(items)
						if err != nil {
							logger.Debug("insert alarm record fail, err: %v", err)
						}
					}
				}
			}
		}

	}

}

// QueryFenceUavRecordByTrackId 通过 track id 查询 uavitems
func QueryFenceUavRecordByTrackId(tbCode string, trackId string) (error, []*bean.FencedUavRecord) {
	if tbCode == "" || trackId == "" {
		logger.Errorf("tb code: %v empty or track id: %v empty", tbCode, trackId)
		return fmt.Errorf("param is empty"), nil
	}
	whereCond := "track_id=? and tb_code = ?"
	whereValue := []any{trackId, tbCode}

	items, err := alarm_service.ResUavRecordmDB.QueryItemOnCond(whereCond, whereValue, map[string]bool{
		"start_time": true,
	}, 0, 0)

	if err != nil {
		logger.Errorf("query uav record fail, err: %v, tbCode: %v, trackId: %v", err, tbCode, trackId)
		return err, nil
	}
	return nil, items
}
