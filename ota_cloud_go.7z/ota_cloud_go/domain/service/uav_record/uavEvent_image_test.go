package uav_record

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"testing"
)

func TestGetEventImageDownloadURL(t *testing.T) {
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.35"
		config.ServiceCfg.Db.Port = 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "cuav_cloud_business"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)
	alarm_service.MockUavEventImageDb(dbHandler)

	eventId := "1825779604334768128@1724134752037"
	GetEventImageDownloadURL(eventId)
}
