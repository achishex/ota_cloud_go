package uav_record

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/repository/mock"
	"testing"
)

func Test_refreshUavTimeoutConfig_getUavTimeout(t *testing.T) {
	mock.LoggerMock()
	config.InitConfig("./application-dev.yml")
	config.InitRedis()

	tests := []struct {
		name string
		c    *refreshUavTimeoutConfig
		want int
	}{
		{name: "xxx", c: NewRefreshUavTimeoutConfig(), want: 15000},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.c.getUavTimeout(); got != tt.want {
				t.Errorf("refreshUavTimeoutConfig.getUavTimeout() = %v, want %v", got, tt.want)
			}
		})
	}
}
