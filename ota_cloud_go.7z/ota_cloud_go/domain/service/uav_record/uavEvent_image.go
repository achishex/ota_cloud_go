package uav_record

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/repository/cmqtt"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"encoding/json"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
)

const (
	pingTopic = "mqtt/event/images"
	v1        = 1
	v2        = 2
	SuccMsg   = "OK"
)

func eventImage(m cmqtt.Message) ([]byte, int32) {

	data := m.Payload()
	var msg bean.EventCaptureT
	err := json.Unmarshal(data, &msg)
	if err != nil {
		logger.Error("err = ", err)
	}
	logger.Debugf("msg = %+v", msg)
	msgSlice, err := json.Marshal(&msg.S3Msg)
	if err != nil {
		logger.Error("err = ", err)
	}
	var info []*bean.EventImageData
	id, _ := snowflake.GetUniqueID()
	infoItem := bean.EventImageData{
		ID:      id,
		C2Sn:    msg.C2sn,
		Sn:      msg.Sn,
		MsgID:   msg.MsgID,
		EventID: msg.EventID,
		S3Msg:   msgSlice,
	}
	info = append(info, &infoItem)
	_, err = alarm_service.UavEventImageDBHandler.Insert(info)
	if err != nil {
		logger.Error("err = ", err)
	}

	return []byte(SuccMsg), v1
}

var consumes = []cmqtt.DoRoute{
	{
		Topic:   pingTopic,
		Handler: eventImage,
	},
}

func initAdaptorWithAuth() *cmqtt.Adaptor {
	usename := config.GetConfig().Mqtt.Username
	password := config.GetConfig().Mqtt.Password
	url := config.GetConfig().Mqtt.Url
	clientid := config.GetConfig().Mqtt.ClientId
	return cmqtt.NewAdaptorWithAuth(url, clientid, usename, password)
}
func DoRcvMqttMsg() {
	s := initAdaptorWithAuth()
	s.SetAutoReconnect(true)
	s.SetCleanSession(false)
	s.RegisterSubHandlers(consumes)
	if err := s.Connect(); err != nil {
		logger.Errorf("connect mqtt fail, err: %v", err)
	}
}

type ImageUrlInfo struct {
	Url        string
	TimeCreate time.Time
}

// GetEventImageDownloadURL
func GetEventImageDownloadURL(event_id string) []ImageUrlInfo {

	URLs := make([]ImageUrlInfo, 0)
	logger.Infof("query event image, event_id: %v", event_id)

	val, err := alarm_service.UavEventImageDBHandler.QueryItems(event_id)
	if err != nil {
		logger.Error("err = ", err)
		return nil
	} else {
		logger.Infof("images list len: %v, event_id: %v", len(val), event_id)
	}

	for _, v := range val {
		if v == nil {
			continue
		}
		logger.Debugf("s3 msg: %+v", string(v.S3Msg))

		var s3Msg []bean.EventS3UrlT
		err := json.Unmarshal(v.S3Msg, &s3Msg)
		if err != nil {
			logger.Error("err = ", err)
			continue
		}

		for _, v := range s3Msg {
			logger.Debugf("s3 msg item: %+v", v)
			path := v.S3Path
			url, err := GenDownloadUrl(path)
			if err != nil {
				logger.Errorf("err = %v, event_id: %v", err, event_id)
				continue
			}

			URLs = append(URLs, ImageUrlInfo{
				Url:        url,
				TimeCreate: time.UnixMilli(v.CreateTime).UTC(),
			})
		}
	}
	logger.Debugf("urls = %+v", URLs)
	return URLs
}

func GenDownloadUrl(path string) (string, error) {
	defer func() {
		if r := recover(); r != nil {
			logger.Errorf("GenDownloadUrl panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", r)))
		}
	}()

	Ak := config.GetConfig().EvidenceReportS3.Ak
	Sk := config.GetConfig().EvidenceReportS3.Sk
	Region := config.GetConfig().EvidenceReportS3.Region
	Bucket := "c2-eventvideo"

	sess := session.Must(session.NewSession())

	svc := s3.New(sess, &aws.Config{
		Region:      aws.String(Region),
		Credentials: credentials.NewStaticCredentials(Ak, Sk, ""),
	})

	// 生成预签名URL的请求
	req, _ := svc.GetObjectRequest(&s3.GetObjectInput{
		Bucket: &Bucket, // 替换为你的S3桶名称
		Key:    &path,   // 替换为你想要下载的对象的键
	})

	urlStr, err := req.Presign(7 * 24 * time.Hour)
	if err != nil {
		logger.Errorf("Failed to sign request: %v", err)
		return "", err
	}
	logger.Infof("The pre-signed URL is: %s", urlStr)
	return urlStr, nil

}
