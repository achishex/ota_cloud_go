package uav_record

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	"cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/repository/redis"
	"encoding/json"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	RefreshUavTimeoutConfig = "RefreshUavTimeoutConfig"
	cachePrefix             = "system.config.cache.v5."
	timeoutConfigKey        = "check_timeout_config"
)

var (
	once       sync.Once
	uavTimeout = 10000
)

type refreshUavTimeoutConfig struct {
	rdsOps redis.SkyFendRedisOps
}

// NewRefreshUavTimeoutConfig 创建任务
func NewRefreshUavTimeoutConfig() *refreshUavTimeoutConfig {
	return &refreshUavTimeoutConfig{
		rdsOps: config.GlobalRedis,
	}
}

func (c *refreshUavTimeoutConfig) getUavTimeout() int {
	value, err := c.rdsOps.Get(cachePrefix + timeoutConfigKey)
	if err != nil && err.Error() != "redis: nil" {
		logger.Errorf("getUavTimeout cache error: %s", err.Error())
		return uavTimeout
	}
	if value == nil {
		res, err := thirdpartapi.NewCloudAccountService().GetSystemConfig(&model.GetSystemConfigQuery{Ids: []string{timeoutConfigKey}})
		if err != nil {
			logger.Errorf("getUavTimeout init error: %s", err.Error())
			return uavTimeout
		}
		if len(res) == 0 {
			logger.Errorf("getUavTimeout init query config error")
			return uavTimeout
		}
		configItem := res[0]
		conf := &uavTimeoutConfig{}
		if err := json.Unmarshal([]byte(configItem.Json), conf); err != nil {
			logger.Errorf("getUavTimeout init Unmarshal config error", err.Error())
			return uavTimeout
		}
		if conf.UavTimeout == 0 {
			return uavTimeout
		}
		if err := c.rdsOps.SetEx(cachePrefix+timeoutConfigKey, configItem, 10*time.Minute); err != nil {
			logger.Errorf("getUavTimeout config set cache error", err.Error())
		}
		return conf.UavTimeout
	}
	conf := parseUavTimeoutConfig(value)
	if conf != nil && conf.UavTimeout != 0 {
		return conf.UavTimeout
	}

	return uavTimeout
}

type uavTimeoutConfig struct {
	UavTimeout int `json:"uavTimeout"`
}

func parseUavTimeoutConfig(config any) *uavTimeoutConfig {
	systemConfig := &model.SystemConfig{}
	res := &uavTimeoutConfig{}
	if v, ok := config.(string); ok {
		if err := json.Unmarshal([]byte(v), systemConfig); err != nil {
			return nil
		}
	} else {
		body, err := json.Marshal(config)
		if err != nil {
			return nil
		}
		if err := json.Unmarshal(body, systemConfig); err != nil {
			return nil
		}
	}
	if len(systemConfig.Json) == 0 {
		return nil
	}
	if err := json.Unmarshal([]byte(systemConfig.Json), res); err != nil {
		return nil
	}

	return res
}
