package uavwhitelist

import (
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/model"
	"testing"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func initResource() {
	if err := logger.Init("./application-dev.yml",
		"/logs/ms_log/cuav-cloud-go-service"); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return
	}
	config.InitConfig("./application-dev.yml")
	// 初始化数据库
	_, err := config.InitDB()
	if err != nil {
		// logger.Fatalf("InitSqlite err %v", err)
		return
	}
	config.InitRedis()
}

func TestUavWhitelistService_GetUavWhitelist(t *testing.T) {
	initResource()
	tbCode := "000001"
	srv := NewUavWhitelistService()
	uws := make([]*model.TUavWhite, 0)
	if err := srv.acc.Find(nil, &uws, "tb_code = ?", tbCode); err != nil {
		logger.Errorf("error: %s", err.Error())
		return
	}
	m := make(map[string]any)
	for _, item := range uws {
		m[item.SerialNum] = item
	}
	if err := srv.rds.HSet(constant.UavWhitelistCachePrefix+tbCode, m); err != nil {
		logger.Errorf("error: %s", err.Error())
	}
}

func TestUavWhitelistService_DelCache(t *testing.T) {
	initResource()
	tbCode := "000001"
	srv := NewUavWhitelistService()
	if err := srv.rds.DeleteKey(constant.UavWhitelistCachePrefix + tbCode); err != nil {
		logger.Errorf("error: %s", err.Error())
	}

}

func TestUavWhitelistService_GetCache(t *testing.T) {
	initResource()
	tbCode := "000001"
	srv := NewUavWhitelistService()
	result, err := srv.rds.HGetAll(constant.UavWhitelistCachePrefix + tbCode)
	if err != nil {
		logger.Errorf("error: %s", err.Error())
		return
	}
	logger.Infof("33311122result: %+v", result)
}

func TestUavWhitelistService_UavWhitelist(t *testing.T) {
	initResource()
	srv := NewUavWhitelistService()
	list, err := srv.UavWhitelist("000001", false)
	if err != nil {
		logger.Errorf("error: %s", err.Error())
		return
	}

	logger.Infof("211000data: %+v", list)
}
