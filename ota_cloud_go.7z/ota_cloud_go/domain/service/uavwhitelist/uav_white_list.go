package uavwhitelist

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/thirdpartapi"
	tmodel "cuav-cloud-go-service/domain/common/thirdpartapi/model"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/redis"
	pb "cuav-cloud-go-service/proto"
	"encoding/json"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type UavWhitelistService struct {
	acc db.BaseAccess
	rds redis.SkyFendRedisOps
}

func NewUavWhitelistService() *UavWhitelistService {
	return &UavWhitelistService{
		acc: db.NewBaseAccessImpl(config.GetDB()),
		rds: config.GlobalRedis,
	}
}

// 获取数据
func (u *UavWhitelistService) UavWhitelist(tbCode string, filterDel bool) ([]*model.TUavWhite, error) {
	result := u.rds.Client().LRange(context.Background(), constant.UavWhitelistCachePrefix+tbCode, 0, -1)
	if result.Err() != nil {
		logger.Warnf("LRange error: %v", result.Err())
	}
	rdsRes, err := result.Result()
	if err != nil {
		logger.Warnf("UavWhitelist error: %+v", err)
	}
	list := make([]*model.TUavWhite, 0)
	for _, item := range rdsRes {
		uw := &model.TUavWhite{}
		if err := json.Unmarshal([]byte(item), uw); err != nil {
			logger.Errorf("Unmarshal error: %s", err.Error())
			continue
		}
		list = append(list, uw)
	}
	if len(list) == 0 {
		logger.Info("UavWhitelist from db")
		if err := u.acc.Find(nil, &list, "tb_code = ?", tbCode); err != nil {
			logger.Errorf("Find error: %v", err.Error())
			return nil, err
		}
		// 或者过滤被删除超过15天的数据
		afterFilterList := make([]*model.TUavWhite, 0)
		for _, item := range list {
			if item.Status == constant.DeleteStatus && item.UpdateTime.UTC().UnixMilli() < time.Now().Add(-15*24*time.Hour).UTC().UnixMilli() {
				continue
			}
			afterFilterList = append(afterFilterList, item)
		}
		pl := u.rds.Client().Pipeline()
		for _, item := range afterFilterList {
			pl.LPush(context.Background(), constant.UavWhitelistCachePrefix+tbCode, item)
		}
		if _, err := pl.Exec(context.Background()); err != nil {
			logger.Errorf("LPush error: %v", err.Error())
		}
		if err := u.rds.ExpireKey(constant.UavWhitelistCachePrefix+tbCode, 12*time.Hour); err != nil {
			logger.Errorf("ExpireKey error: %v", err.Error())
		}
		list = afterFilterList
	}

	lastList := make([]*model.TUavWhite, 0)
	if filterDel {
		for _, item := range list {
			if item.Status != constant.DeleteStatus {
				lastList = append(lastList, item)
			}
		}
		list = lastList
	}

	return list, nil
}

func (u *UavWhitelistService) UavWhitelistSync(req *pb.UavWhitelistSyncRequest) error {
	// 1、查缓存全量
	list, err := u.UavWhitelist(req.TbCode, false)
	if err != nil {
		logger.Errorf("UavWhitelist error: %v", err.Error())
		return err
	}
	rdsRes := make(map[string]*model.TUavWhite)
	for _, v := range list {
		// 以 v.SerialNum为key
		key := v.SerialNum
		if val, ok := rdsRes[key]; ok {
			// 以最新为主
			if val.UpdateTime.UTC().UnixMilli() < v.UpdateTime.UTC().UnixMilli() {
				rdsRes[key] = v
			}
		} else {
			rdsRes[key] = v
		}
	}
	// 2、比对数据, 分类出 1、新增 2、更新 3、删除
	addList, updateList, delList, err := u.groupWhitelist(rdsRes, req)
	if err != nil {
		logger.Errorf("UavWhitelistSync error: %s", err.Error())
		return err
	}
	// 3、更新数据库
	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + req.TbCode); err != nil {
		logger.Errorf("UavWhitelistSync DeleteKey error: %s", err.Error())
	}
	// 3.1 更新pg
	tx := u.acc.DB().Begin()
	if len(addList) > 0 {
		if _, err := u.acc.InsertBatch(tx, &addList, len(addList)); err != nil {
			tx.Rollback()
			logger.Errorf("UavWhitelistSync create error: %s", err.Error())
			return err
		}
	}
	if len(updateList) > 0 {
		logger.Debugf("Expect update rows: %d", len(updateList))
		var rows int
		for _, item := range updateList {
			_, err := u.acc.Updates(tx, item)
			if err != nil {
				tx.Rollback()
				logger.Errorf("UavWhitelistSync update error: %s", err.Error())
				return err
			}
			rows++
		}
		logger.Debugf("update rows: %d", rows)
	}
	if len(delList) > 0 {
		var delIds []int64
		for _, item := range delList {
			delIds = append(delIds, item.Id)
		}
		if _, err := u.acc.Update(tx, &model.TUavWhite{}, map[string]any{
			"status":    constant.DeleteStatus,
			"update_at": time.Now().UTC(),
		}, "id in ?", delIds); err != nil {
			tx.Rollback()
			logger.Errorf("UavWhitelistSync delete error: %s", err.Error())
			return err
		}
	}
	tx.Commit()
	// 删除缓存
	if err := u.rds.DeleteKey(constant.UavWhitelistCachePrefix + req.TbCode); err != nil {
		logger.Errorf("UavWhitelistSync DeleteKey error: %s", err.Error())
	}

	// 批量添加变更记录
	addUwOperationLogBatch(addList, updateList, delList, rdsRes, req.C2Sn)

	return nil
}

// 对同步的数据进行更改
func (u *UavWhitelistService) groupWhitelist(olds map[string]*model.TUavWhite, req *pb.UavWhitelistSyncRequest) (addList, updateList, delList []*model.TUavWhite, err error) {

	originMap := make(map[string]*pb.UavInfo)
	for _, item := range req.UavBlackWhiteRuleList {
		if item.SerialNum == "" || item.Status != constant.EffectStatus && item.Status != constant.DeleteStatus {
			continue
		}
		key := item.SerialNum
		if val, ok := originMap[key]; ok {
			// 以最新为主，主要针对删除
			if val.UpdateTime < item.UpdateTime {
				originMap[key] = item
			}
		} else {
			originMap[key] = item
		}
		uwKey := model.GetUavWhitelistKey(model.TUavWhite{TbCode: req.TbCode, SerialNum: item.SerialNum, Role: int(item.Role), Status: int(item.Status)})
		if val, ok := olds[key]; !ok || item.Status != int32(val.Status) && item.Status == constant.EffectStatus {
			if ok && val.UpdateTime.UTC().UnixMilli() > item.UpdateTime {
				logger.Errorf("Uav white %s has been delete", val.SerialNum)
				continue
			}
			id, err := snowflake.GetUniqueID()
			if err != nil {
				logger.Errorf("Failed to get snowflake id: %v", err)
				return nil, nil, nil, err
			}
			// 查找redis
			uwVal, err := u.rds.Get(uwKey)
			if err != nil && err.Error() != "redis: nil" {
				logger.Errorf("Failed to get redis key %s : %s", uwKey, err.Error())
				continue
			}
			if uwVal != nil {
				logger.Warnf("Key %s exsist", uwKey)
				continue
			}
			newUw := &model.TUavWhite{
				Id:         id,
				TbCode:     req.TbCode,
				SerialNum:  item.SerialNum,
				Vendor:     item.Vendor,
				Model:      item.Model,
				Usage:      int(item.Usage),
				UsageDesc:  item.UsageDesc,
				Remark:     item.Remark,
				Status:     int(item.Status),
				Role:       int(item.Role),
				CreateTime: time.UnixMilli(item.CreateTime).UTC(),
				UpdateTime: time.UnixMilli(item.CreateTime).UTC(),
			}
			addList = append(addList, newUw)
			if err := u.rds.SetEx(uwKey, item.SerialNum, time.Hour*24); err != nil {
				logger.Errorf("Failed to SetEx redis key %s : %s", uwKey, err.Error())
			}
		} else {
			valTmp := *val
			// 判断是否删除
			if item.UpdateTime < valTmp.UpdateTime.UTC().UnixMilli() {
				continue
			}
			if item.Status != int32(valTmp.Status) && item.Status == constant.DeleteStatus {
				// 删除
				delUwKey := model.GetUavWhitelistKey(model.TUavWhite{TbCode: req.TbCode, SerialNum: valTmp.SerialNum, Role: int(valTmp.Role), Status: int(valTmp.Status)})
				delList = append(delList, &valTmp)
				if err := u.rds.DeleteKey(delUwKey); err != nil {
					logger.Errorf("Failed to get redis key %s : %v", delUwKey, err)
					continue
				}
			} else if !compareSwap(item, &valTmp) {
				// 存在判断是否需要更新
				// 更新
				updateList = append(updateList, &valTmp)
			}
		}
	}
	return
}

func compareSwap(a *pb.UavInfo, b *model.TUavWhite) bool {
	flag := true
	if a.UpdateTime < b.UpdateTime.UTC().UnixMilli() {
		// 判断更新时间，以最新为主
		return flag
	}
	if a.Model != b.Model {
		b.Model = a.Model
		flag = false
	}
	if int(a.Usage) != b.Usage {
		b.Usage = int(a.Usage)
		flag = false
	}
	if a.UsageDesc != b.UsageDesc {
		b.UsageDesc = a.UsageDesc
		flag = false
	}
	if a.Vendor != b.Vendor {
		b.Vendor = a.Vendor
		flag = false
	}
	if a.Remark != b.Remark {
		b.Remark = a.Remark
		flag = false
	}
	if a.Role != int32(b.Role) {
		b.Role = int(a.Role)
		flag = false
	}
	if b.CreateTime.UTC().UnixMilli() != a.CreateTime {
		b.CreateTime = time.UnixMilli(a.CreateTime)
		flag = false
	}
	if !flag {
		b.UpdateTime = time.UnixMilli(a.UpdateTime)
	}

	return flag
}

func addUwOperationLogBatch(addList, updateList, delList []*model.TUavWhite, olds map[string]*model.TUavWhite, c2Sn string) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("addUwOperationLogBatch panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
		}
	}()
	operatorName := c2Sn
	for _, item := range addList {
		if item.Status != constant.EffectStatus {
			continue
		}
		addUwOperationLog(item, constant.OperationLogOperationTypeAdd, constant.OperationLogBusinessTypeWhitelistAdd, nil, item.TbCode, operatorName)
	}
	for _, item := range delList {
		addUwOperationLog(item, constant.OperationLogOperationTypeDelete, constant.OperationLogBusinessTypeWhitelistDelete, nil, item.TbCode, operatorName)
	}
	for _, item := range updateList {
		if val, ok := olds[item.SerialNum]; ok {
			updateMap := make(map[string]any)
			if !compareAndGetDiff(item, val, updateMap) {
				addUwOperationLog(item, constant.OperationLogOperationTypeUpdate, constant.OperationLogBusinessTypeWhitelistUpdate, updateMap, item.TbCode, operatorName)
			}
		}
	}
}

func compareAndGetDiff(a *model.TUavWhite, b *model.TUavWhite, update map[string]any) bool {
	flag := true
	if a.Usage != 0 && a.Usage != b.Usage {
		flag = false
		update["usage"] = a.Usage
	}
	if a.Vendor != b.Vendor {
		flag = false
		update["vendor"] = a.Vendor
	}

	return flag
}

func addUwOperationLog(uw *model.TUavWhite, optType, optObject int, updateMap map[string]any, tbCode, operatorName string) {
	optUavWhiteName := uw.SerialNum
	if uw.Model != "" {
		optUavWhiteName = uw.Model + "-" + uw.SerialNum
	}
	content := map[string]any{constant.OptlogWhitelistI18NPrefix + constant.ContentFieldNameUavWhiteName: optUavWhiteName}
	if optObject == constant.OperationLogBusinessTypeWhitelistUpdate {
		fields := tmodel.GetUpdateFields(optObject, updateMap)
		if len(fields) == 0 {
			return
		}
		content[constant.OptlogWhitelistI18NPrefix+constant.ContentFieldNameUpdateFields] = fields
	}
	optLog := &tmodel.OperationLogAddIn{
		LogType:         constant.OperationLogTypeUser,
		BusinessType:    constant.OperationLogBusinessTypeWhitelist,
		OperationType:   optType,
		OperationObject: optObject,
		TbCode:          tbCode,
		OperatorName:    operatorName,
		Content:         content,
		Status:          constant.OperationLogStatusSuccess,
		Source:          constant.OperationLogSourcePad,
		ToInfoWindow:    constant.OperationLogToInfoWindow,
	}
	if err := thirdpartapi.NewCloudDataService().OperationLogAdd(optLog); err != nil {
		logger.Errorf("OperationLogAdd error: %s", err.Error())
	}
}

func (u *UavWhitelistService) GetUavWhitelist(req *pb.UavWhitelistListReq, filterDel bool) (*pb.UavWhitelistRes, error) {
	list, err := u.UavWhitelist(req.TbCode, filterDel)
	if err != nil {
		logger.Errorf("GetUavWhitelist error: %v", err.Error())
		return nil, err
	}
	res := new(pb.UavWhitelistRes)
	for _, uw := range list {
		uavWhitelistItem := &pb.UavWhitelistItem{
			Id:         uw.Id,
			TbCode:     uw.TbCode,
			SerialNum:  uw.SerialNum,
			Model:      uw.Model,
			Vendor:     uw.Vendor,
			Role:       int32(uw.Role),
			Usage:      int32(uw.Usage),
			UsageDesc:  uw.UsageDesc,
			Remark:     uw.Remark,
			Status:     int32(uw.Status),
			UpdateTime: uw.UpdateTime.UTC().UnixMilli(),
			CreateTime: uw.CreateTime.UTC().UnixMilli(),
		}
		res.List = append(res.List, uavWhitelistItem)
	}
	res.PageSize = 20
	res.Total = int64(len(res.List))
	return res, nil
}
