package cron_tasks

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/snowflake"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/domain/service/alarm_service"
	pb "cuav-cloud-go-service/proto"
	"errors"
	"fmt"
	"sync/atomic"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/bsm/redislock"
)

const (
	AlarmEventTimeOut = 2000
)

type InvalidAlarmCheck struct {
	latestAlarmCache *alarm_service.LatestAlarmCache
	rdsOps           redis.SkyFendRedisOps
	ttl              time.Duration
}

func NewInvalidAlarmCheck(latestAlarmCache *alarm_service.LatestAlarmCache, rdsOp redis.SkyFendRedisOps) *InvalidAlarmCheck {
	return &InvalidAlarmCheck{
		latestAlarmCache: latestAlarmCache,
		rdsOps:           rdsOp,
		ttl:              10 * time.Second,
	}
}

func (c *InvalidAlarmCheck) GetKey() string {
	return fmt.Sprintf("dis_task_id:2024:6:5")
}

// Process 清除历史告警记录
func (c *InvalidAlarmCheck) Process(ctx context.Context) {
	data, err := c.latestAlarmCache.GetLatestAlarmList()
	if err != nil {
		logger.Errorf("get all latest alarm fail, err: %v", err)
		return
	}
	if len(data) <= 0 {
		return
	}

	for tbCode, _ := range data {
		if tbCode == "" {
			continue
		}

		var latestAlarmOnAllEventIds map[int64]*pb.AlarmCheckRspItem = data[tbCode]
		if latestAlarmOnAllEventIds == nil || len(latestAlarmOnAllEventIds) <= 0 {
			continue
		}

		for eventId, _ := range latestAlarmOnAllEventIds {
			if latestAlarmOnAllEventIds[eventId] == nil {
				c.latestAlarmCache.DelAlarmItem(tbCode, eventId)

			} else {
				if time.Now().UnixMilli()-latestAlarmOnAllEventIds[eventId].GetCreateTime() < AlarmEventTimeOut {
					continue
				}

				// 最新告警记录是 2 second 之前，需要删除和通知前端
				logger.Infof("latest event alarm is time out, alarm: %+v", latestAlarmOnAllEventIds[eventId])
				toDelEventId := eventId

				if e := c.latestAlarmCache.DelAlarmItem(tbCode, toDelEventId); e != nil {
					logger.Infof("del alarm item from cache, tbCode: %v, eventId: %v, err: %v", tbCode, toDelEventId, err)
				}
			}

			notifyHandle := alarm_service.NewAlarmStatusUpdateNotify()
			//通知 其他端来拉取最新的数据，同步作用
			toNotice := make(map[int64]*pb.AlarmStatusUpdateItem)
			alarmId := ""
			RiskLevel := int32(0)

			if latestAlarmOnAllEventIds[eventId] != nil {
				alarmId = fmt.Sprintf("%d", latestAlarmOnAllEventIds[eventId].GetId())
				RiskLevel = latestAlarmOnAllEventIds[eventId].GetRiskLevel()

				logger.Infof("alarm has expire time: %v ms, alarm id: %v, eventId: %v, alarmType: %v",
					time.Now().UnixMilli()-latestAlarmOnAllEventIds[eventId].GetCreateTime(),
					latestAlarmOnAllEventIds[eventId].GetId(), eventId, latestAlarmOnAllEventIds[eventId].GetAlarmType())
			} else {
				logger.Infof("alarm is nil, but event id exist, need to close event id: %v, tbCode: %v", eventId, tbCode)
			}

			if latestAlarmOnAllEventIds[eventId] == nil {
				toNotice[0] = &pb.AlarmStatusUpdateItem{
					Id:        alarmId,
					EventId:   fmt.Sprintf("%d", eventId),
					Status:    3,
					RiskLevel: RiskLevel,
					TbCode:    tbCode,
				}
			} else {
				toNotice[latestAlarmOnAllEventIds[eventId].GetId()] = &pb.AlarmStatusUpdateItem{
					Id:        alarmId,
					EventId:   fmt.Sprintf("%d", eventId),
					Status:    3,
					RiskLevel: RiskLevel,
					TbCode:    tbCode,
				}
			}

			//通知 其他端来拉取最新的数据，同步作用
			notifyHandle.FlagNonAlarmReport(toNotice, false)

			if e := notifyHandle.Notify(toNotice, tbCode); e != nil {
				logger.Errorf("send to notify alarm status disappear fail, e: %v", e)
			}
		}
	}
}

func (c *InvalidAlarmCheck) TaskRun(ctx context.Context) {
	if c == nil {
		return
	}
	var checkAlarmFlag atomic.Bool
	globalId := fmt.Sprintf("%d", config.GetConfig().ConnectPort.GrpcPort)

	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("panic lock fail, e: %v", e)
			}
		}()

		for {
			select {
			case <-ctx.Done():
				logger.Infof("receive stop signal")
				return
			default:
			}

			e := c.rdsOps.Lock(c.GetKey(), c.ttl, globalId)
			if e != nil {
				// logger.Errorf("not get lock, id: %d", config.GetConfig().ConnectPort.GrpcPort)
				checkAlarmFlag.Store(false)
				time.Sleep(2 * time.Second)
				continue

			} else {
				if !checkAlarmFlag.Load() {
					logger.Infof("lock succ, key: %v, id: %v, tm: %v", c.GetKey(), globalId, c.ttl)
				}
				//
				checkAlarmFlag.Store(true)
				for {
					select {
					case <-ctx.Done():
						logger.Infof("receive stop signal.")
						return
					default:
					}

					if er := c.rdsOps.RefreshTTL(c.GetKey(), globalId, c.ttl); er != nil {
						checkAlarmFlag.Store(false)
						logger.Infof("refresh ttl fail, e: %v, key: %v, id: %v", er, c.GetKey(), globalId)
						break
					}

					checkAlarmFlag.Store(true)
					time.Sleep(c.ttl / 2)
				}
			}
		}
	}()

	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("panic, task run, e: %v", e)
			}
		}()

		for {
			select {
			case <-ctx.Done():
				logger.Infof("receive stop signal.")
				return
			default:
			}

			if !checkAlarmFlag.Load() {
				time.Sleep(1 * time.Second)
				continue
			}

			c.Process(ctx)
			time.Sleep(2 * time.Second)
		}
	}()
}

func (c *InvalidAlarmCheck) TaskRunOnThird(ctx context.Context, flag int64) {
	if c == nil {
		return
	}
	var checkAlarmFlag atomic.Bool

	locker := redislock.New(c.rdsOps.GetRedisRow())
	var lockHandle *redislock.Lock = nil
	var e error

	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("panic lock fail, e: %v", e)
			}
		}()

		for {
			select {
			case <-ctx.Done():
				logger.Infof("lock, receive stop signal, flag: %v.", flag)
				checkAlarmFlag.Store(false)
				return
			default:
			}

			lockHandle, e = locker.Obtain(ctx, c.GetKey(), c.ttl, nil)
			if e != nil {
				if !errors.Is(e, redislock.ErrNotObtained) {
					logger.Errorf("get lock fail, err: %v", e)
				}
				checkAlarmFlag.Store(false)
				time.Sleep(2 * time.Second)
				continue
			} else {
				if !checkAlarmFlag.Load() {
					logger.Infof("lock succ, key: %v, id: %v, tm: %v, flag: %v, now: %v", c.GetKey(), "", c.ttl, flag, time.Now().UnixMilli())
				}
				checkAlarmFlag.Store(true)

				for {
					select {
					case <-ctx.Done():
						checkAlarmFlag.Store(false)
						lockHandle.Release(ctx)
						logger.Infof("refresh 2, receive stop signal, flag: %v, now: %v", flag, time.Now().UnixMilli())
						return
					default:
					}

					//
					if er := lockHandle.Refresh(ctx, c.ttl, nil); er != nil {
						checkAlarmFlag.Store(false)
						lockHandle.Release(ctx)
						logger.Infof("refresh ttl fail, e: %v, key: %v, id: %v, flag: %v", er, c.GetKey(), "", flag)
						break
					}

					checkAlarmFlag.Store(true)
					time.Sleep(c.ttl / 2)
				}
			}
		}
	}()

	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf("panic, task run, e: %v", e)
			}
		}()

		for {
			select {
			case <-ctx.Done():
				logger.Infof("receive stop signal. proc flag: %v.", flag)
				return
			default:
			}

			if !checkAlarmFlag.Load() {
				time.Sleep(1 * time.Second)
				continue
			}

			procBeginTime := time.Now()
			tmOutCtx, _ := context.WithTimeout(ctx, 1*time.Second)
			c.Process(tmOutCtx)

			sleepTm := 1 * time.Second
			time.Sleep(sleepTm)
			elapseTime := time.Since(procBeginTime)
			if elapseTime > sleepTm+200*time.Millisecond {
				logger.Infof("process history alarm item cost time: %v", elapseTime)
			}
		}
	}()
}

// InitInvalidAlarmCache 创建cache检查
func InitInvalidAlarmCache(ctx context.Context) {
	item := NewInvalidAlarmCheck(alarm_service.NewLatestAlarmCache(alarm_service.ResAlarmRecordRedis), alarm_service.ResAlarmRecordRedis)
	if item == nil {
		return
	}
	go func() {
		flag, _ := snowflake.GetUniqueID()
		item.TaskRunOnThird(ctx, flag)
	}()
}
