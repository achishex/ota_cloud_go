package cron_tasks

import (
	"testing"
)

func TestRedisDisLock(t *testing.T) {
	//mock.LoggerMock()
	//c := redis.NewSkyFendRedisClient(redis.WithRedisAddrOpt("10.240.34.36:30356"),
	//	redis.WithRedisPasswd("ZAQ!2wsx"), redis.WithRedisDB(15))
	//a := NewInvalidAlarmCheck(nil, c)
	//go func() {
	//	time.Sleep(1 * time.Second)
	//	a.TaskRunOnThird(context.Background(), 1)
	//}()
	//go func() {
	//	ctx, cf := context.WithCancel(context.Background())
	//	go func() {
	//		a.TaskRunOnThird(ctx, 2)
	//	}()
	//	time.Sleep(15 * time.Second)
	//	cf()
	//}()
	//select {}
}
