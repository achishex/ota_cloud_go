package cron_tasks

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/bean"
	"cuav-cloud-go-service/domain/repository/db"
	"cuav-cloud-go-service/domain/repository/mock"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"testing"
	"time"
)

func TestAlarmEliminate(t *testing.T) {
	tm1 := time.Now()
	tm := tm1.UTC()
	t.Logf("tm millisecond: %v, now tm: %v", tm.UnixMilli(), tm1.UnixMilli())
	
	mock.LoggerMock()

	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.Db.Host = "10.240.34.36" // "10.240.34.35"
		config.ServiceCfg.Db.Port = 31762          // 5432
		config.ServiceCfg.Db.Pwd = "ZAQ!2wsx"
		config.ServiceCfg.Db.User = "postgres"
		config.ServiceCfg.Db.Dbname = "postgres" //"cuav_cloud_business"
	}

	dbHandler, _ := config.InitDB()
	defer config.CloseDB(dbHandler)
	t.Logf("create db: %v", dbHandler)

	alarm_service.ResAlarmDB = db.NewDBModelTplWrapper[bean.FendAreaAlarm](dbHandler).SetTabName(bean.FendAreaAlarm{}.TableName())

	ctx, cancelFn := context.WithTimeout(context.Background(), 39238*time.Second)
	{
		//CreateAlarmTaskDeleteOnSecond(ctx)
	}

	{
		CreateAlarmTaskDeleteOnTimePoint(ctx, 16, 11, 50, 1)
	}

	defer cancelFn()
	select {}
}
