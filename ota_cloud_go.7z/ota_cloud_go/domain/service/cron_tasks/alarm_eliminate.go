package cron_tasks

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"fmt"
	"github.com/robfig/cron/v3"
)

// FenceAlarmHistoryEliminate 告警历史数据清除
type FenceAlarmHistoryEliminate struct {
	expireTmSecond int64 // 默认使用 30 天
	// db
	alarmService *alarm_service.AlarmOps
}

func NewFenceAreaHistoryEliminate(expSecond int64) *FenceAlarmHistoryEliminate {
	if expSecond <= 0 {
		expSecond = 31 * 24 * 3600
	}
	return &FenceAlarmHistoryEliminate{
		expireTmSecond: expSecond, // uint is day: 30 *24 * 3600
		alarmService:   alarm_service.NewAlarmOps(alarm_service.ResAlarmDB),
	}
}
func (f *FenceAlarmHistoryEliminate) Run() {
	if f.alarmService == nil {
		logger.Errorf("alarm service handle is nil")
		return
	}

	f.alarmService.DeleteExpireHistory(f.expireTmSecond)
}

// CreateAlarmTaskDeleteOnSecond 创建告警删除定时任务; 在固定时间间隔运行定时任务.
func CreateAlarmTaskDeleteOnSecond(ctx context.Context) {
	cronHandle := cron.New()
	cronHandle.AddJob("@every 1h", NewFenceAreaHistoryEliminate(1))
	cronHandle.Start()
	defer cronHandle.Stop()
	//
	select {
	case <-ctx.Done():
		logger.Infof("stop delete alarm history record task.")
	}
}

// CreateAlarmTaskDeleteOnTimePoint 指定时间上运行定时器; 在指定时间点上运行job.
func CreateAlarmTaskDeleteOnTimePoint(ctx context.Context, hour, minute, second int64, logicExpireSecond int64) {
	cronHandle := cron.New(cron.WithSeconds())
	spec := fmt.Sprintf("%d %d %d * * *", second, minute, hour)
	cronHandle.AddJob(spec, NewFenceAreaHistoryEliminate(logicExpireSecond))
	cronHandle.Start()
	defer cronHandle.Stop()
	//
	select {
	case <-ctx.Done():
		logger.Infof("stop delete alarm history record task.")
	}
}
