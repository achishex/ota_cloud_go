package cron_tasks

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/common/constant"
	"cuav-cloud-go-service/domain/common/utils"
	"cuav-cloud-go-service/domain/model"
	"cuav-cloud-go-service/domain/repository/access"
	"cuav-cloud-go-service/domain/repository/redis"
	"cuav-cloud-go-service/domain/service/countertask"
	"encoding/json"
	"fmt"
	"math/rand"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/robfig/cron/v3"
)

const (
	TaskLockCounterTaskInProgress = "TaskLockCounterTaskInProgress"
)

type counterTaskOps struct {
	dbOps countertask.CounterTaskDBType
	rds   redis.SkyFendRedisOps
}

// NewCounterTaskOps 创建反制任务
func NewCounterTaskOps(dbHandle countertask.CounterTaskDBType) *counterTaskOps {
	if dbHandle == nil {
		// 使用默认的全局db
		return &counterTaskOps{
			dbOps: countertask.CounterTaskDBHandle,
			rds:   config.GlobalRedis,
		}
	}
	return &counterTaskOps{
		dbOps: dbHandle,
		rds:   config.GlobalRedis,
	}
}

func (ops *counterTaskOps) Run() {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("Cron cancel task panic error: %s", utils.ErrTrace(fmt.Sprintf("%+v", err)))
			return
		}
	}()
	nxCmd := ops.rds.Client().SetNX(context.Background(), TaskLockCounterTaskInProgress, "", 30*time.Second)
	if nxCmd.Err() != nil {
		logger.Errorf("Cron cancel task SetNX redis error: %s", nxCmd.Err().Error())
		return
	}
	flag, err := nxCmd.Result()
	if err != nil || !flag {
		logger.Errorf("Cron cancel task exisit")
		return
	}
	defer func() {
		cmd := ops.rds.Client().Del(context.Background(), TaskLockCounterTaskInProgress)
		if cmd.Err() != nil {
			logger.Errorf("Cron cancel task delete lock key error: %s", cmd.Err())
		}
	}()

	// 扫描
	cmd := ops.rds.Client().LRange(context.Background(), constant.RedisKeyCounterTaskInProgress, 0, -1)
	if cmd.Err() != nil {
		logger.Errorf("Cron cancel task redis error: %s", cmd.Err().Error())
		return
	}
	list, err := cmd.Result()
	if err != nil {
		logger.Errorf("Cron cancel task get redis error: %s", cmd.Err().Error())
		return
	}
	var updateTaskIDs []int64
	tbCodes := make(map[string]struct{})
	for _, item := range list {
		val := &model.CounterTaskRdValue{}
		if err := json.Unmarshal([]byte(item), val); err != nil {
			logger.Errorf("Cron cancel task Unmarshal redis value error: %s", cmd.Err().Error())
			continue
		}
		holdTime := int64(rand.Intn(90)+90) * int64(time.Second/1e6)
		if time.Now().UTC().UnixMilli()-val.BeginTime.UTC().UnixMilli() > holdTime {
			tbCodes[val.TbCode] = struct{}{}
			updateTaskIDs = append(updateTaskIDs, val.ID)
			if err := ops.rds.Client().LRem(context.Background(), constant.RedisKeyCounterTaskInProgress, 0, item).Err(); err != nil {
				logger.Errorf("Cron cancel task redis LRem value: %s error: %s", item, cmd.Err().Error())
			}
		}
	}

	// 处理超时
	var effectCount int
	if len(updateTaskIDs) > 0 {
		update := map[string]any{"status": constant.CounterTaskStatusEnd, "end_time": time.Now().UTC()}
		stat := ops.dbOps.GetDBHandle().Model(&model.CounterTask{}).Where("id in ? and status = ?",
			updateTaskIDs, constant.CounterTaskStatusInProgress).UpdateColumns(update)
		if stat.Error != nil {
			logger.Errorf("Cron cancel task db update error: %s", err.Error())
		}
		effectCount = int(stat.RowsAffected)
	}
	if effectCount > 0 {
		for tbCode, _ := range tbCodes {
			access.SendKafkaMsg(config.GetConfig().Kafka.EventNoticeTopic, access.NoticeItem{
				Key:  constant.UrlTaskStatusUpdate,
				Data: access.TbCode{TbCode: tbCode},
			})
		}
	}
}

// TaskTimeOutCancalOnTimePoint 任务超时取消
func TaskTimeOutCancalOnTimePoint(ctx context.Context, hour, minute, second int64) {
	cronHandle := cron.New(cron.WithSeconds())
	spec := fmt.Sprintf("*/%d * * * * *", second)
	if _, err := cronHandle.AddJob(spec, NewCounterTaskOps(nil)); err != nil {
		logger.Fatalf("TaskTimeOutCancalOnTimePoint add task error: %s", err.Error())
	}
	cronHandle.Start()
	defer cronHandle.Stop()
	select {
	case <-ctx.Done():
		logger.Infof("stop cancel timeout task cron task.")
	}
}
