package model

import (
	"database/sql/driver"
	"encoding/json"
	"time"
)

// CounterTask 反制任务表
type CounterTask struct {
	ID           int64     `json:"id" redis:"id" gorm:"column:id"`                                        //任务id
	TbCode       string    `json:"tb_code" redis:"tb_code" gorm:"column:tb_code"`                         // 企业编号
	Name         string    `json:"name" redis:"name" gorm:"column:name"`                                  //任务名
	TriggerMode  int16     `json:"trigger_mode" redis:"trigger_mode" gorm:"column:trigger_mode"`          //任务触发方式：1： 自动； 2： 手动
	Status       int16     `json:"status" redis:"status" gorm:"column:status"`                            //任务状态： 1: 进行中; 2: 已取消; 3: 已结束
	DevSn        string    `json:"dev_sn" redis:"dev_sn" gorm:"column:dev_sn"`                            //反制设备sn
	DevName      string    `json:"dev_name" redis:"dev_name" gorm:"column:dev_name"`                      //反制设备名称
	DevType      string    `json:"dev_type" redis:"dev_type" gorm:"column:dev_type"`                      //反制设备类型
	Mode         int16     `json:"mode" redis:"mode" gorm:"column:mode"`                                  //反制模式
	ObjName      string    `json:"obj_name" redis:"obj_name" gorm:"column:obj_name"`                      //目标名称
	ObjType      string    `json:"obj_type" redis:"obj_type" gorm:"column:obj_type"`                      //目标机型
	DurTimeS     int32     `json:"dur_time_second" redis:"dur_time_second" gorm:"column:dur_time_second"` //打击时长
	CounterId    int64     `json:"counter_rule_id" redis:"counter_rule_id" gorm:"column:counter_rule_id"` //反制规则id
	BeginTime    time.Time `json:"begin_time" redis:"begin_time" gorm:"column:begin_time"`                //开始时间
	EndTime      time.Time `json:"end_time" redis:"end_time" gorm:"column:end_time"`                      //结束时间
	ExtraParams  PgJson    `json:"extra_params" redis:"extra_params" gorm:"column:extra_params"`          //参数
	TrackId      string    `json:"track_id" redis:"track_id" gorm:"column:track_id"`                      //目标事件id
	DevLongitude float64   `json:"dev_longitude" redis:"dev_longitude" gorm:"column:dev_longitude"`       //侦测设备经度
	DevLatitude  float64   `json:"dev_latitude" redis:"dev_latitude" gorm:"column:dev_latitude" `         //侦测设备纬度
}

// TableName  反制任务存储表名
func (CounterTask) TableName() string {
	return "t_counter_task"
}

type PgJson map[string]any

func (p *PgJson) Scan(value interface{}) error {
	return json.Unmarshal(value.([]byte), p)
}

func (p PgJson) Value() (driver.Value, error) {
	return json.Marshal(p)
}

type CounterTaskAndRule struct {
	ID              int64     `json:"id" redis:"id" gorm:"column:id"`                                              //任务id
	TbCode          string    `json:"tb_code" redis:"tb_code" gorm:"column:tb_code"`                               // 企业编号
	Name            string    `json:"name" redis:"name" gorm:"column:name"`                                        //任务名
	TriggerMode     int16     `json:"trigger_mode" redis:"trigger_mode" gorm:"column:trigger_mode"`                //任务触发方式：1： 自动； 2： 手动
	Status          int16     `json:"status" redis:"status" gorm:"column:status"`                                  //任务状态： 1: 进行中; 2: 已取消; 3: 已结束
	DevSn           string    `json:"dev_sn" redis:"dev_sn" gorm:"column:dev_sn"`                                  //反制设备sn
	DevName         string    `json:"dev_name" redis:"dev_name" gorm:"column:dev_name"`                            //反制设备名称
	DevType         string    `json:"dev_type" redis:"dev_type" gorm:"column:dev_type"`                            //反制设备类型
	Mode            int16     `json:"mode" redis:"mode" gorm:"column:mode"`                                        //反制模式
	ObjName         string    `json:"obj_name" redis:"obj_name" gorm:"column:obj_name"`                            //目标名称
	ObjType         string    `json:"obj_type" redis:"obj_type" gorm:"column:obj_type"`                            //目标机型
	DurTimeS        int32     `json:"dur_time_second" redis:"dur_time_second" gorm:"column:dur_time_second"`       //打击时长
	BeginTime       time.Time `json:"begin_time" redis:"begin_time" gorm:"column:begin_time"`                      //开始时间
	EndTime         time.Time `json:"end_time" redis:"end_time" gorm:"column:end_time"`                            //结束时间
	RuleId          int64     `json:"rule_id" redis:"rule_id" gorm:"column:rule_id"`                               //反制规则id
	RuleName        string    `json:"rule_name" redis:"rule_name" gorm:"column:rule_name"`                         //规则名称
	CounterAreaId   int64     `json:"counter_area_id" redis:"counter_area_id"  gorm:"column:counter_area_id"`      //反制区id, 大于0有效
	FenceAreaId     int64     `json:"fence_area_id" redis:"fence_area_id"  gorm:"column:fence_area_id"`            //围栏区id, 大于0有效
	CounterAreaName string    `json:"counter_area_name" redis:"counter_area_name" gorm:"column:counter_area_name"` //反制区名称
	FencedAreaName  string    `json:"fenced_area_name" redis:"fenced_area_name" gorm:"column:fenced_area_name"`    //围栏区名称
	FencedAreaType  int       `json:"fenced_area_type" redis:"fenced_area_type" gorm:"column:fenced_area_type"`    //围栏区类型
	ForbiddenMode   int32     `json:"forbidden_mode" redis:"forbidden_mode" gorm:"column:forbidden_mode"`          //0 不禁用任何模式, 1: 禁用无线电打击(0x01), 16: 禁用诱骗(0x10), 256: 禁用诱打联动(0x100); 0x11 ：禁止无线电打击+诱骗; 0x101: 禁止无线电打击+诱导联动; 0x110: 矜持诱骗+诱打联动； 0x111:禁止无线电打击+诱骗+诱打联动
	RuleEnable      int32     `json:"rule_enable" redis:"rule_enable" gorm:"column:rule_enable"`                   //1 标识开启; 2 关闭该规则
	CreateTime      time.Time `json:"create_time" redis:"create_time" gorm:"column:create_time"`                   //UTC时间
	UpdateTime      time.Time `json:"update_time" redis:"update_time" gorm:"column:update_time"`                   //UTC时间
	WholeDay        int32     `json:"whole_day" redis:"whole_day" gorm:"column:whole_day"`                         // 0: 不是全天， 1：全天
	RuleBeginTime   int32     `json:"rule_begin_time" redis:"rule_begin_time" gorm:"column:rule_begin_time"`       // 规则有效开始时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	RuleEndTime     int32     `json:"rule_end_time" redis:"rule_end_time" gorm:"column:rule_end_time"`             // 规则有效结束时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	CrossDay        int32     `json:"cross_day" redis:"cross_day" gorm:"column:cross_day"`                         // 0: 不跨天， 1： 跨1天， 2： 跨2天， n:跨n天
}

type CounterTaskRdValue struct {
	ID        int64     `json:"id"`         //任务id
	TbCode    string    `json:"tbCode"`     // 企业编号
	BeginTime time.Time `json:"begin_time"` //开始时间
}
