package model

import "time"

// AutoCounterRuleConfig 表model
type AutoCounterRuleConfig struct {
	ID            int64      `json:"id" redis:"id" gorm:"column:id"` //规则id
	TbCode        string     `json:"tb_code" redis:"tb_code" gorm:"column:tb_code"`
	RuleName      string     `json:"rule_name" redis:"rule_name" gorm:"column:rule_name"`                    //规则名
	CounterAreaId int64      `json:"counter_area_id" redis:"counter_area_id"  gorm:"column:counter_area_id"` //反制区id, 大于0有效
	FenceAreaId   int64      `json:"fence_area_id" redis:"fence_area_id"  gorm:"column:fence_area_id"`       //围栏区id, 大于0有效
	ForbiddenMode int32      `json:"forbidden_mode" redis:"forbidden_mode" gorm:"column:forbidden_mode"`     //0 不禁用任何模式, 1: 禁用无线电打击(0x01), 16: 禁用诱骗(0x10), 256: 禁用诱打联动(0x100); 0x11 ：禁止无线电打击+诱骗; 0x101: 禁止无线电打击+诱导联动; 0x110: 矜持诱骗+诱打联动； 0x111:禁止无线电打击+诱骗+诱打联动
	RuleEnable    int32      `json:"rule_enable" redis:"rule_enable" gorm:"column:rule_enable"`              //1 标识开启; 2 关闭该规则
	CreateTime    *time.Time `json:"create_time" redis:"create_time" gorm:"column:create_time"`              //UTC时间
	UpdateTime    *time.Time `json:"update_time" redis:"update_time" gorm:"column:update_time"`              //UTC时间
	DeleteTime    *time.Time `json:"delete_time" redis:"delete_time" gorm:"column:delete_time"`              //UTC时间
	IsDelete      int32      `json:"is_delete" redis:"is_delete" gorm:"column:is_delete"`                    // 0: 未删除， 1： 已删除
	WholeDay      int32      `json:"whole_day" redis:"whole_day" gorm:"column:whole_day"`                    // 0: 不是全天， 1：全天
	BeginTime     int32      `json:"begin_time" redis:"begin_time" gorm:"column:begin_time"`                 // 规则有效开始时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	EndTime       int32      `json:"end_time" redis:"end_time" gorm:"column:end_time"`                       // 规则有效结束时间点： 小时 + 分钟 + 秒; 00,00,00 分别占十分位两位
	CrossDay      int32      `json:"cross_day" redis:"cross_day" gorm:"column:cross_day"`                    // 0: 不跨天， 1： 跨1天， 2： 跨2天， n:跨n天
	RuleDurTime   int32      `json:"rule_dur_time" redis:"cross_day" gorm:"column:rule_dur_time"`            // 规则有效持续时间，单位为秒
}

// TableName  获取自动反制存储表名
func (AutoCounterRuleConfig) TableName() string {
	return "t_auto_counter_rule_config"
}
