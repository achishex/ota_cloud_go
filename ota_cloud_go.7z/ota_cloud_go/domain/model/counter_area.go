package model

import "time"

// CounterAreaConfig 表model
type CounterAreaConfig struct {
	ID                int64      `json:"id" redis:"id" gorm:"column:id"`
	TbCode            string     `json:"tb_code" redis:"tb_code" gorm:"column:tb_code"`
	AreaName          string     `json:"area_name" redis:"area_name" gorm:"column:area_name"`
	AreaPerimeter     float64    `json:"area_perimeter" redis:"area_perimeter"  gorm:"column:area_perimeter"`
	AreaSquare        float64    `json:"area_square" redis:"area_square"  gorm:"column:area_square"`
	CentroidLongitude float64    `json:"centroid_longitude" redis:"centroid_longitude"  gorm:"column:centroid_longitude"`
	CentroidLatitude  float64    `json:"centroid_latitude" redis:"centroid_latitude"  gorm:"column:centroid_latitude"`
	Geometry          string     `json:"geometry" redis:"geometry"  gorm:"column:geometry"`
	CreateTime        *time.Time `json:"create_time" redis:"create_time"  gorm:"column:create_time"`
	UpdateTime        *time.Time `json:"update_time" redis:"update_time"  gorm:"column:update_time"` //utc
	DeleteTime        *time.Time `json:"delete_time" redis:"delete_time"  gorm:"column:delete_time"` //utc
	FenceAreaId       int64      `json:"fence_area_id" redis:"fence_area_id" gorm:"column:fence_area_id"`
}

// TableName  获取反制区存储表名
func (CounterAreaConfig) TableName() string {
	return "t_counter_area_config"
}
