package model

type NoticeItem struct {
	Key  string `json:"key"`
	Data any    `json:"data"`
}
