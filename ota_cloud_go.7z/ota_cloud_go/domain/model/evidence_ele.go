package model

import (
	"bytes"
	"encoding/json"
)

// ListAnyType 定义 泛型切片 类型
type ListAnyType[T any] []*T

// ToList 返回切片
func (s *ListAnyType[T]) ToList() []*T {
	if s == nil {
		return nil
	}
	return *s
}

// Marshal 泛型切片序列化
func (s *ListAnyType[T]) Marshal() ([]byte, error) {
	return json.Marshal(s)
}

// MarshalSpecial 禁止特别符号的转化，比如 & to \u00026 (特化json 序列化)
func (s *ListAnyType[T]) MarshalSpecial() ([]byte, error) {
	var response bytes.Buffer
	encoder := json.NewEncoder(&response)
	encoder.SetEscapeHTML(false) // 禁用 HTML 转义
	err := encoder.Encode(s)
	return response.Bytes(), err
}

// Unmarshal 泛型切片反序列化
func (s *ListAnyType[T]) Unmarshal(data []byte) error {
	return json.Unmarshal(data, s)
}

// CrossAreaId 轨迹经历过的围栏区
type CrossAreaId struct {
	AreaId int64 `json:"area_id"`
}

// CrossPhotoUrl 侦测经历的 ptz 拍照url
type CrossPhotoUrl struct {
	PhotoPath    string `json:"photo_path"`
	PhotoUrl     string `json:"photo_url"`
	PhotoCreated int64  `json:"created_at"`
}

// CrossTimelineId 经历时间线
type CrossTimelineId struct {
	TimelineId int64 `json:"timeline_id" gorm:"timeline_id"`
}

// CrossTaskId 侦测经历过得任务id
type CrossTaskId struct {
	TaskId int64 `json:"task_id" gorm:"task_id"`
}

// CrossAlarmId 经历不同告警的告警id
type CrossAlarmId struct {
	AlarmId int64 `json:"alarm_id" gorm:"alarm_id"`
}
