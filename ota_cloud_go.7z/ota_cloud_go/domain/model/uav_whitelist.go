package model

import (
	"encoding/json"
	"fmt"
	"time"
)

type TUavWhite struct {
	Id         int64     `json:"id" gorm:"column:id" redis:"id"`
	TbCode     string    `json:"tbCode" gorm:"column:tb_code" redis:"tbCode"`
	SerialNum  string    `json:"serialNum" gorm:"column:serial_num" redis:"serialNum"`
	Vendor     string    `json:"vendor" gorm:"column:vendor" redis:"vendor"`
	Role       int       `json:"role" gorm:"column:role" redis:"role"`
	Model      string    `json:"model" gorm:"column:model" redis:"model"`
	Usage      int       `json:"usage" gorm:"column:usage" redis:"usage"`
	UsageDesc  string    `json:"usageDesc" gorm:"column:usage_desc" redis:"usageDesc"`
	Remark     string    `json:"remark" gorm:"column:remark" redis:"remark"`
	Status     int       `json:"status" gorm:"column:status" redis:"status"`
	CreateTime time.Time `json:"createTime" gorm:"column:create_at;type:timestamp NOT NULL" redis:"createTime"`
	UpdateTime time.Time `json:"updateTime" gorm:"column:update_at;type:timestamp NOT NULL" redis:"updateTime"`
}

func (TUavWhite) TableName() string {
	return "t_uav_white"
}

func (t TUavWhite) MarshalBinary() (data []byte, err error) {
	return json.Marshal(t)
}

func (t *TUavWhite) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, t)
}

type TUavWhiteSlice []*TUavWhite

func (t TUavWhiteSlice) MarshalBinary() (data []byte, err error) {
	return json.Marshal(t)
}

func (t *TUavWhiteSlice) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, t)
}

func GetUavWhitelistKey(uw TUavWhite) string {
	return fmt.Sprintf("UavWhitelist:%s:%s:%d:%d", uw.TbCode, uw.SerialNum, uw.Role, uw.Status)
}
