package model

import (
	"testing"
)

func TestMarshalJonMessage(t *testing.T) {
	var srcAreaIds = new(ListAnyType[CrossAreaId])
	//
	var areaIds []*CrossAreaId
	for i := 0; i < 5; i++ {
		item := &CrossAreaId{
			AreaId: int64(i),
		}
		areaIds = append(areaIds, item)
	}
	*srcAreaIds = areaIds
	//
	dstBytes, err := srcAreaIds.Marshal()
	if err != nil {
		t.Logf("marshal to bytes fail, err: %v", err)
	} else {
		t.Logf("marshal to bytes: %s", dstBytes)
	}

	//
	var dstAreaIds = new(ListAnyType[CrossAreaId])
	if err := dstAreaIds.Unmarshal(dstBytes); err != nil {
		t.Logf("unmarshal to bytes fail, err: %v", err)
		return
	}

	for _, item := range dstAreaIds.ToList() {
		if item == nil {
			continue
		}
		t.Logf("item: %+v", item)
	}
}
