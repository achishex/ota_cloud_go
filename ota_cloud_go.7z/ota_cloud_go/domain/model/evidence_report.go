package model

import (
	"database/sql/driver"
	"encoding/json"
	"strings"
	"time"
)

// ProtocolUavDetect 协议解析-侦测无人机信息表结构
type ProtocolUavDetect struct {
	CreateTime int64 `json:"createTime" gorm:"time_stamp"`
	// 无人机高度
	DroneAltitude float64 `json:"droneAltitude" gorm:"drone_height"`
	// 无人机速度
	DroneSpeed float64 `json:"droneSpeed" gorm:"drone_speed"`
	// 无人机垂直速度
	VerticalSpeed float64 `json:"verticalSpeed" gorm:"vertical_speed"`
	// 无人机经度
	DroneLongitude float64 `json:"droneLongitude" gorm:"drone_longitude"`
	// 无人机纬度
	DroneLatitude float64 `json:"droneLatitude" gorm:"drone_latitude"`
}

// TableName 获取协议解析侦测无人机信息 表名
func (ProtocolUavDetect) TableName() string {
	return "t_protocol_uav"
}

// UavTargetEventModel 目标事件模型
type UavTargetEventModel struct {
	Id                 int64           `json:"id" gorm:"column:id"`                                     //主键
	TrackId            string          `json:"track_id" gorm:"column:track_id"`                         //目标轨迹id, 唯一索引
	EventBeginTime     *time.Time      `json:"event_begin_time" gorm:"column:event_begin_time"`         //事件开始时间点 utc
	EventEndTime       *time.Time      `json:"event_end_time" gorm:"column:event_end_time"`             // 事件结束时间点 utc
	DroneModel         string          `json:"drone_model" gorm:"column:drone_model"`                   //无人机品牌
	SerialNum          string          `json:"serial_num" gorm:"column:serial_num"`                     //无人机序列号，sn
	ObjId              string          `json:"obj_id" gorm:"column:obj_id"`                             //无人机目标id, 雷达监测结果
	UavName            string          `json:"uav_name" gorm:"column:uav_name"`                         //无人机名字
	CreateAt           *time.Time      `json:"create_at" gorm:"column:create_at"`                       //记录创建时间点 utc
	AreaIds            json.RawMessage `json:"area_ids" gorm:"column:area_ids"`                         //经历的围栏区id 列表
	PhotoUrls          json.RawMessage `json:"photo_url_list" gorm:"column:photo_url_list"`             //拍照照片url列表
	TaskIds            json.RawMessage `json:"task_ids" gorm:"column:task_ids"`                         //创建任务id 列表
	AlarmIds           json.RawMessage `json:"alarm_ids" gorm:"column:alarm_ids"`                       //经历不同告警的告警id列表
	DetectDevicesBegin json.RawMessage `json:"detect_devices_begin" gorm:"column:detect_devices_begin"` // 开始侦测设备列表; proto.DevRelation
	DetectDevicesEnd   json.RawMessage `json:"detect_devices_end" gorm:"column:detect_devices_end"`     // 结束侦测设备列表; proto.DevRelation
	DetectDevicesTotal json.RawMessage `json:"detect_devices_total" gorm:"column:detect_devices_total"` // 全部侦测设备列表; proto.DevRelation
	TbCode             string          `json:"tb_code" gorm:"column:tb_code"`                           //租户编码
	EvidenceReportUrl  string          `json:"evidence_report_url" gorm:"column:evidence_report_url"`   //取证报告文件下载地址; 包括 没有https 和 https
	TrajectoryZipPath  string          `json:"trajectory_zip_path" gorm:"column:trajectory_zip_path"`   // 轨迹文件压缩包存储路径
	Freq               float64         `json:"freq" gorm:"column:freq"`                                 // 无人机频率
	PilotLong          float64         `json:"pilot_long" gorm:"column:pilot_long"`                     // 飞手经度
	PilotLat           float64         `json:"pilot_lat" gorm:"column:pilot_lat"`                       // 飞手纬度
	HomeLong           float64         `json:"home_long" gorm:"column:home_long"`                       // 返航点经度
	HomeLat            float64         `json:"home_lat" gorm:"column:home_lat"`                         // 返航点纬度
	BeginLong          float64         `json:"begin_long" gorm:"column:begin_long"`                     // 飞机起飞点经度
	BeginLat           float64         `json:"begin_lat" gorm:"column:begin_lat"`                       // 飞机起飞点纬度
	EndLong            float64         `json:"end_long" gorm:"column:end_long"`                         // 飞机结束经度
	EndLat             float64         `json:"end_lat" gorm:"column:end_lat"`                           // 飞机结束纬度
	ReportName         string          `json:"report_name" gorm:"column:report_name"`                   //  报告自定义名称
}

// TableName 目标事件模型表名
func (UavTargetEventModel) TableName() string {
	return "t_uav_target_event"
}

type CaptureFlyingInfo struct {
	Id           int64        `json:"id" gorm:"column:id"` //主键
	TbCode       string       `json:"tbCode" gorm:"column:tb_code"`
	TrackId      string       `json:"trackId" gorm:"column:track_id"`           //目标轨迹id, 唯一索引
	DocumentInfo DocumentInfo `json:"documentInfo" gorm:"column:document_info"` //  抓飞手信息
	CreatedAt    time.Time    `json:"createdAt" gorm:"column:created_at;type:timestamp NOT NULL"`
}

// TableName 目标事件模型表名
func (CaptureFlyingInfo) TableName() string {
	return "t_capture_flying"
}

type DocumentInfo struct {
	VideoDocuments      []DocumentItem `json:"video_documents" gorm:"video_documents:name"`
	ScreenshotDocuments []DocumentItem `json:"screenshot_documents" gorm:"screenshot_documents"`
	CompressFlag        bool           `json:"compress_flag" gorm:"compress_flag"`
}

func (c *DocumentInfo) Scan(value interface{}) error {
	return json.Unmarshal(value.([]byte), c)
}

func (c DocumentInfo) Value() (driver.Value, error) {
	val, err := json.Marshal(c)
	if err != nil {
		return "", err
	}
	content := strings.ReplaceAll(string(val), "\\u003c", "<")
	content = strings.ReplaceAll(content, "\\u003e", ">")
	content = strings.ReplaceAll(content, "\\u0026", "&")
	return content, nil
}

type DocumentItem struct {
	S3Path         string    `json:"s3_path" gorm:"column:s3_path"`
	Url            string    `json:"url" gorm:"column:url"`
	Name           string    `json:"name" gorm:"column:name"`
	Type           string    `json:"type" gorm:"column:type"`
	ExpireAt       time.Time `json:"expire_at" gorm:"column:expire_at"`
	PilotLatitude  float64   `json:"pilot_latitude" gorm:"column:pilot_latitude"`
	PilotLongitude float64   `json:"pilot_longitude" gorm:"column:pilot_longitude"`
	ShootingAt     string    `json:"shooting_at" gorm:"column:shooting_at"`
}

func (c *DocumentItem) Scan(value interface{}) error {
	return json.Unmarshal(value.([]byte), c)
}

func (c DocumentItem) Value() (driver.Value, error) {
	val, err := json.Marshal(c)
	if err != nil {
		return "", err
	}
	content := strings.ReplaceAll(string(val), "\\u003c", "<")
	content = strings.ReplaceAll(content, "\\u003e", ">")
	content = strings.ReplaceAll(content, "\\u0026", "&")
	return content, nil
}
