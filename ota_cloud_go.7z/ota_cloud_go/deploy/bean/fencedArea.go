package bean

type FencedAreaConfig struct {
	ID                int64   `json:"id" redis:"id"`
	TbCode            string  `json:"tb_code" redis:"tb_code"`
	AreaName          string  `json:"area_name" redis:"area_name"`
	AreaType          int     `json:"area_type" redis:"area_type"`
	AreaPerimeter     float64 `json:"area_perimeter" redis:"area_perimeter"`
	AreaSquare        float64 `json:"area_square" redis:"area_square"`
	CentroidLongitude float64 `json:"centroid_longitude" redis:"centroid_longitude"`
	CentroidLatitude  float64 `json:"centroid_latitude" redis:"centroid_latitude"`
	Geometry          string  `json:"geometry" redis:"geometry"`
	CreateTime        int64   `json:"create_time" redis:"create_time"`
	UpdateTime        int64   `json:"update_time" redis:"update_time"`
	DeleteTime        int64   `json:"delete_time" redis:"delete_time"`
}

func (FencedAreaConfig) TableName() string {
	return "fenced_area_config"
}
