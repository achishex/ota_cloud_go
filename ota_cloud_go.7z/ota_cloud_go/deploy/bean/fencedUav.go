package bean

import (
	"encoding/json"
	"time"
)

type FencedUavRecord struct {
	ID             int64           `json:"id" `             // 编号
	SerialNum      string          `json:"serial_num"`      // 无人机SN
	ObjID          string          `json:"obj_id"`          // 对象ID
	DroneName      string          `json:"drone_name"`      // 无人机名称
	StartTime      time.Time       `json:"start_time"`      // 开始时间
	EndTime        time.Time       `json:"end_time"`        // 结束时间
	Duration       int64           `json:"duration"`        // 持续时间
	AreaID         int64           `json:"area_id"`         // 区域ID
	PilotLongitude float64         `json:"pilot_longitude"` // 飞行员经度
	PilotLatitude  float64         `json:"pilot_latitude"`  // 飞行员纬度
	HomeLongitude  float64         `json:"home_longitude"`  // 起飞点经度
	HomeLatitude   float64         `json:"home_latitude"`   // 起飞点纬度
	SN             string          `json:"sn"`              // 设备 SN
	TbCode         string          `json:"tb_code"`         // TB代码
	Status         int64           `json:"status"`          // 状态
	C2SN           string          `json:"c2_sn"`           // C2序列号
	Type           int64           `json:"type"`            // 类型
	Longitude      float64         `json:"longitude"`       // 经度
	Latitude       float64         `json:"latitude"`        // 纬度
	AreaName       string          `json:"area_name"`       //围栏区名称
	Freq           float64         `json:"freq"`            //无人机频率
	Devrelations   json.RawMessage `json:"devrelations"`    // 使用 json.RawMessage 以便于存储和读取 JSON 数据
	Videotime      json.RawMessage `json:"videotime"`       // 使用 json.RawMessage 以便于存储和读取 JSON 数据
	Eventid        string          `json:"eventid"`         //事件ID
	StartLongitude float64         `json:"start_longitude"` // 飞机开始经度
	StartLatitude  float64         `json:"start_latitude"`  // 飞机开始纬度
	StartSite      string          `json:"start_site"`      //开始位置
	EndSite        string          `json:"end_site"`        //结束位置
	// 风险等级： 1: low, 2: middle, 3: high
	RiskLevel int32  `json:"risk_level"`
	TrackId   string `json:"track_id" gorm:"column:track_id"` // 目标事件
}

func (FencedUavRecord) TableName() string {
	return "t_fenced_uav_record"
}

func (t FencedUavRecord) MarshalBinary() (data []byte, err error) {
	return json.Marshal(t)
}

func (t *FencedUavRecord) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, t)
}
