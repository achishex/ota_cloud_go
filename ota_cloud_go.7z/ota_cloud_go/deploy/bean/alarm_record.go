package bean

import (
	"encoding/json"
	"time"
)

type FendAreaAlarm struct {
	ID     int64  `json:"id"`
	TbCode string `json:"tb_code"`
	//无人机唯一标识
	DevSn string `json:"dev_sn"`
	// obj id 是无人机 obj id
	ObjID string `json:"obj_id"`
	// 风险等级： 1: low, 2: middle, 3: high
	RiskLevel int32 `json:"risk_level"`
	// 危险等级： high(80~100 score), middle(50~79 score), low(1~49 score), none(0 score)
	ThreatLevel int32 `json:"threat_level"`
	// 告警时间ID (每次入侵id), 一次告警事件id会关联多次告警id(比如，低、中、高)
	EventId int64 `json:"event_id"`
	// 创建时间
	CreateTime time.Time `json:"create_time" gorm:"type:timestamp"`
	// 更新记录时间
	UpdateTime time.Time `json:"update_time" gorm:"type:timestamp"`
	// 0: 未处理; 1: 手动处理， 2: 侦测结束事件处理 3: 告警级别降为0
	Status int32 `json:"status"` //0: 未处理； 1: 手动处理； 2：侦测事件消息处理； 3：告警为0处理
	// 设备无人机名称
	DevName string `json:"dev_name"`
	// 告警持续时间（毫秒）
	DurTime int64 `json:"dur_time"`

	// 围栏区id
	AreaId int64 `json:"area_id"`
	//无人机对应的c2sn
	C2Sn string `json:"c2_sn"`
	//告警触发的类型： 0-按围栏，1-按c2, 3-按围栏与C2
	AlarmType int32 `json:"alarm_type"`
	//
	Longitude float64 `json:"longitude"` //无人机经纬度
	Latitude  float64 `json:"latitude"`
	AreaName  string  `json:"area_name"` //围栏区名称
	//db type: jsonb  default: '[]'::jsonb
	Devrelations   json.RawMessage `json:"devrelations" gorm:"column:devrelations"`         // 一个无人机告警时对应的融合数据：多个c2sn; 多个侦测设备， 站点. 使用 json.RawMessage 以便于存储和读取 JSON 数据
	TrackId        string          `json:"track_id" gorm:"column:track_id"`                 // 目标事件id
	InboundAreaIds json.RawMessage `json:"inbound_area_ids" gorm:"column:inbound_area_ids"` // 经过的围栏区id 列表
}

func (FendAreaAlarm) TableName() string {
	return "t_fenced_area_alarm"
}

//type DBItemRecordAbs interface {
//	TableName() string
//}
