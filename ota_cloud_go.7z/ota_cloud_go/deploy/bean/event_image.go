package bean

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"
)

type EventImageData struct {
	ID        int64           `json:"id"`
	C2Sn      string          `json:"c2_sn"`
	Sn        string          `json:"sn"`
	MsgID     uuid.UUID       `json:"msg_id"`
	EventID   string          `json:"event_id"`
	S3Msg     json.RawMessage `json:"s3msg" gorm:"column:s3msg"`
	CreatedAt time.Time       `json:"created_at"`
}
type EventS3UrlT struct {
	S3Path     string `json:"s3_path"`
	Index      int32  `json:"index"`
	CreateTime int64  `json:"create_time"`
}

type EventCaptureT struct {
	C2sn    string        `json:"c2sn"`
	Sn      string        `json:"sn"`
	MsgID   uuid.UUID     `json:"msgid"`
	EventID string        `json:"eventid"`
	S3Msg   []EventS3UrlT `json:"s3msg"`
}

func (EventImageData) TableName() string {
	return "t_event_image"
}
