package snowflake

import (
	"sync"
	"testing"
	"time"
)

type fliterMap struct {
	lk     sync.Mutex
	filter map[int64]bool
}

func (f *fliterMap) check(id int64) bool {
	f.lk.Lock()
	defer f.lk.Unlock()
	//
	_, ok := f.filter[id]
	if ok {
		return false
	}
	f.filter[id] = true
	return true
}
func TestSnowFlake(t *testing.T) {
	ff := &fliterMap{
		filter: make(map[int64]bool),
	}
	//
	for i := 0; i < 100; i++ {
		for {
			id, _ := GetUniqueID()
			if !(ff.check(id)) {
				t.Logf(".....repeated: %v", id)
			} else {
				t.Logf("unique id: %v", id)
			}
			time.Sleep(5 * time.Millisecond)
		}

	}
	select {}
}

func TestParseTimeStampBySnowflakeId(t *testing.T) {
	alarmIds := []int64{1287961607355891713} // 1284944027721793536   12842476160332595212024-06-22 18:56:39  1287961607355891716 2024-07-02 19:08:50 1287961607355891713  2024-07-02 19:08:50
	//eventId := []int64{1284238824206106670}
	for _, alarmId := range alarmIds {
		t.Logf("time shift: %v, center shift: %v", timestampLeftShift, datacenterIdShift)
		tm := alarmId >> timestampLeftShift
		t.Logf("time: %v, strTm: %v", tm+twepoch, time.Unix(tm+twepoch, 0))

	}

}
