package snowflake

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	workerIdBits       = int64(5)
	datacenterIdBits   = int64(5)
	serviceIdBits      = int64(5)
	maxWorkerId        = int64(-1) ^ (int64(-1) << workerIdBits)
	maxDatacenterId    = int64(-1) ^ (int64(-1) << datacenterIdBits)
	maxServiceId       = int64(-1) ^ (int64(-1) << serviceIdBits)
	sequenceBits       = int64(17)
	workerIdShift      = sequenceBits + serviceIdBits
	datacenterIdShift  = sequenceBits + serviceIdBits + workerIdBits
	timestampLeftShift = sequenceBits + serviceIdBits + workerIdBits + datacenterIdBits
	sequenceMask       = ^(int64(-1) << sequenceBits)
	twepoch            = int64(1420041600)
	serviceIdShift     = sequenceBits
	LEN                = 32

	DEFAULT_MILLISECONDS_OFFSET = 60 * 1000
	TICK_SLEEP                  = 200
)

var GlobalSnowFlakeInstance *Snowflake = nil

func init() {
	defaultConfig, err := defaultIdWorkConfig()
	if err != nil {
		logger.Error("GetUniqueID defaultIdWorkConfig error: ", err)
		return
	}
	GlobalSnowFlakeInstance, _ = NewSnowflake(defaultConfig.workerId, 1, defaultConfig.serviceId)
}

type Snowflake struct {
	mu            sync.Mutex
	lastTimestamp int64
	workerId      int64
	datacenterId  int64
	serviceId     int64
	sequence      int64
}
type IdWorkConfig struct {
	datacenterId int64
	workerId     int64
	serviceId    int64
}

func GetUniqueID() (int64, error) {
	return GlobalSnowFlakeInstance.NextID()
}

func defaultIdWorkConfig() (*IdWorkConfig, error) {
	hostAddress, err := getLocalIP()
	if err != nil {
		return nil, err
	}
	workerId := createWorkerId(hostAddress)
	serviceId := createServiceId(hostAddress)
	return &IdWorkConfig{1, workerId, serviceId}, nil
}

func getLocalIP() (string, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "", err
	}
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String(), nil
			}
		}
	}
	return "", errors.New("Could not determine local IP address")
}

func createWorkerId(hostIp string) int64 {
	codes := []rune(hostIp)
	sum := 0
	for _, code := range codes {
		sum += int(code)
	}
	return int64(sum % LEN)
}

func createServiceId(hostIp string) int64 {
	arr := strings.Split(hostIp, ".")
	addr := arr[len(arr)-1]
	serviceId, _ := strconv.Atoi(addr)
	return int64(serviceId % LEN)
}
func NewSnowflake(workerId, datacenterId, serviceId int64) (*Snowflake, error) {
	if workerId < 0 || workerId > maxWorkerId {
		return nil, errors.New("worker ID out of range")
	}
	if datacenterId < 0 || datacenterId > maxDatacenterId {
		return nil, errors.New("datacenter ID out of range")
	}
	if serviceId < 0 || serviceId > maxServiceId {
		return nil, errors.New("service ID out of range")
	}
	return &Snowflake{
		lastTimestamp: 0,
		workerId:      workerId,
		datacenterId:  datacenterId,
		serviceId:     serviceId,
		sequence:      0,
	}, nil
}

func (s *Snowflake) NextID() (int64, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	timestamp := timeGen()

	if timestamp < s.lastTimestamp {
		if s.lastTimestamp-timestamp >= DEFAULT_MILLISECONDS_OFFSET {
			panic(fmt.Sprintf("clock moving backwards, could not generate id for: %d ms", s.lastTimestamp-timestamp))
		}
		timestamp = s.lastTimestamp
	}

	if s.lastTimestamp == timestamp {
		tmpSeq := (s.sequence + 1) & sequenceMask
		if tmpSeq == 0 {
			timestamp = s.tilNextSecond(s.lastTimestamp)
		}
		s.sequence = tmpSeq
	} else {
		s.sequence = 0
	}

	s.lastTimestamp = timestamp

	x0 := timestamp - twepoch
	x1 := (x0) << timestampLeftShift
	x2 := s.datacenterId << datacenterIdShift
	x3 := s.workerId << workerIdShift
	x4 := s.serviceId << serviceIdShift
	x5 := s.sequence

	x := x1 | x2 | x3 | x4 | x5
	return x, nil
}

func (s *Snowflake) tilNextSecond(lastTimestamp int64) int64 {
	timestamp := timeGen()
	for timestamp <= lastTimestamp {
		timestamp = timeGen()
		if timestamp == lastTimestamp {
			time.Sleep(TICK_SLEEP * time.Millisecond)
		}
	}
	return timestamp
}

func timeGen() int64 {
	return time.Now().Unix()
}
