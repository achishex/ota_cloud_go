package i18nlib

import (
	"cuav-cloud-go-service/config"
	"testing"
)

func TestInitI18n(t *testing.T) {
	tests := []struct {
		name string
	}{
		{name: "xxx"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			InitI18n()
		})
	}
}

func TestGetValue(t *testing.T) {
	if config.ServiceCfg == nil {
		config.ServiceCfg = &config.ServiceConfig{}
		config.ServiceCfg.I18nPath = "./jsonfiles/"
	}

	InitI18n()
	type args struct {
		key  string
		lang string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{name: "xxx", args: args{key: "10000", lang: "zh-CN"}, want: "参数错误", wantErr: false},
		{name: "xxx", args: args{key: "10000", lang: "zh"}, want: "", wantErr: true},
		{name: "xxx", args: args{key: "10000", lang: "en"}, want: "Params error", wantErr: false},
		{name: "xxx", args: args{key: "10000", lang: "en-US"}, want: "", wantErr: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetValue(tt.args.key, tt.args.lang)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetValue() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("GetValue() = %v, want %v", got, tt.want)
			}
		})
	}
}
