package i18nlib

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/domain/common/constant"
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"github.com/nicksnyder/go-i18n/v2/i18n"
	"golang.org/x/text/language"
)

var (
	Bundle       *i18n.Bundle
	localizerMap = make(map[string]*i18n.Localizer)
)

func InitI18n() {

	path := config.GetConfig().I18nPath
	Bundle = i18n.NewBundle(language.English)
	Bundle.RegisterUnmarshalFunc("json", json.Unmarshal)
	files, err := os.ReadDir(path)
	if err != nil {
		logger.Fatalf("ReadDir error: %s", err)
	}
	for _, file := range files {
		if file.IsDir() {
			continue
		}
		filePath := path + file.Name()
		content, err := os.ReadFile(filePath)
		if err != nil {
			logger.Fatalf("ReadFile error: %s", err)
		}
		message, err := Bundle.ParseMessageFileBytes(content, file.Name())
		if err != nil {
			logger.Fatalf("LoadMessageFile error: %s", err)
		}
		thisLocalizer := i18n.NewLocalizer(Bundle, message.Tag.String())
		localizerMap[message.Tag.String()] = thisLocalizer
	}
}

func GetValue(key, lang string) (string, error) {
	localizer := localizerMap[lang]
	if localizer == nil {
		return "", fmt.Errorf("get i18n localizer error, lang: %v not exist", lang)
	}

	return localizer.LocalizeMessage(&i18n.Message{ID: key})
}

func GetLangStrInCtx(ctx context.Context) string {
	lang := ctx.Value(constant.XLanguageHeaderKey)
	langStr, _ := lang.(string)
	if langStr == "" {
		logger.Errorf("not get any language set in http header, key: %v", constant.XLanguageHeaderKey)
		langStr = "zh-CN"
	}
	return langStr
}
func SetLangStrToCtx(ctx context.Context, r *http.Request) context.Context {
	ctx = context.WithValue(ctx, constant.XLanguageHeaderKey, r.Header.Get(constant.XLanguageHeaderKey))
	return ctx
}
