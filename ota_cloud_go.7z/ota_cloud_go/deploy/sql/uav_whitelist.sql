CREATE TABLE public.t_uav_white (
	id serial4 NOT NULL,
	tb_code varchar(8) NOT NULL,
	serial_num varchar(32) NOT NULL,
	vendor varchar(32) NOT NULL,
	"role" int4 NOT NULL,
	model varchar(32) NOT NULL,
	usage int4 NOT NULL, -- 用途类型
    usage_desc VARCHAR(32), -- 用途描述
	remark varchar(256) NULL,
	status int4 NOT NULL,
	create_at timestamp NOT NULL,
	update_at timestamp NOT NULL,
	CONSTRAINT t_uav_white_pk PRIMARY KEY (id),
	CONSTRAINT t_uav_white_tb_code_serial_num_key UNIQUE (tb_code, serial_num)
);

ALTER TABLE public.t_uav_white add column status int4 NULL;
update t_uav_white set status = 1;
ALTER TABLE t_uav_white DROP CONSTRAINT t_uav_white_tb_code_serial_num_key;
CREATE INDEX t_uav_white_tb_code_serial_num_key on t_uav_white(tb_code, serial_num);