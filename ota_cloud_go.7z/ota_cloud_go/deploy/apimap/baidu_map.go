package apimap

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type BaiduGeocodingResponse struct {
	Status int `json:"status"`
	Result struct {
		Location struct {
			Lng float64 `json:"lng"`
			Lat float64 `json:"lat"`
		} `json:"location"`
		FormattedAddress    string           `json:"formatted_address"`
		Edz                 Edz              `json:"edz"`
		Business            string           `json:"business"`
		AddressComponent    AddressComponent `json:"addressComponent"`
		Pois                []interface{}    `json:"pois"`
		Roads               []interface{}    `json:"roads"`
		PoiRegions          []interface{}    `json:"poiRegions"`
		SematicDescription  string           `json:"sematic_description"`
		FormattedAddressPoi string           `json:"formatted_address_poi"`
		CityCode            int              `json:"cityCode"`
	} `json:"result"`
}

type Edz struct {
	Name string `json:"name"`
}

type AddressComponent struct {
	Country         string `json:"country"`
	CountryCode     int    `json:"country_code"`
	CountryCodeISO  string `json:"country_code_iso"`
	CountryCodeISO2 string `json:"country_code_iso2"`
	Province        string `json:"province"`
	City            string `json:"city"`
	CityLevel       int    `json:"city_level"`
	District        string `json:"district"`
	Town            string `json:"town"`
	TownCode        string `json:"town_code"`
	Distance        string `json:"distance"`
	Direction       string `json:"direction"`
	Adcode          string `json:"adcode"`
	Street          string `json:"street"`
	StreetNumber    string `json:"street_number"`
}

type LocationInfo struct {
	Address string
	City    string //深圳市
	State   string //广东省
	Country string
	// PostalCode string
	District string //南山区
	Town     string //桃源街道
	Street   string //学苑大道
}

func getLocationInfo(apiKey string, lat, lng float64) (*LocationInfo, error) {
	url := fmt.Sprintf("http://api.map.baidu.com/reverse_geocoding/v3/?ak=%s&output=json&coordtype=wgs84ll&location=%s,%s",
		apiKey, strconv.FormatFloat(lat, 'f', 6, 64), strconv.FormatFloat(lng, 'f', 6, 64))
	// fmt.Println("url = ", url)
	resp, err := http.Get(url)
	if err != nil {
		return nil, fmt.Errorf("failed to make request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("bad status: %s", resp.Status)
	}

	var baiduResp BaiduGeocodingResponse
	if err := json.NewDecoder(resp.Body).Decode(&baiduResp); err != nil {
		return nil, fmt.Errorf("failed to decode response: %v", err)
	}

	if baiduResp.Status != 0 {
		return nil, fmt.Errorf("error from API: %d", baiduResp.Status)
	}

	fmt.Printf("baiduResp = %+v\n", baiduResp)
	fmt.Printf("stress---------------- = %+v\n", baiduResp.Result.AddressComponent.Street)

	locationInfo := &LocationInfo{
		Address:  baiduResp.Result.FormattedAddress,
		City:     baiduResp.Result.AddressComponent.City,
		State:    baiduResp.Result.AddressComponent.Province,
		Country:  baiduResp.Result.AddressComponent.Country,
		District: baiduResp.Result.AddressComponent.District,
		Town:     baiduResp.Result.AddressComponent.Town,
		Street:   baiduResp.Result.AddressComponent.Street,
	}

	return locationInfo, nil
}
func GetSite(longitude, latitude float64) string {

	// apiKey := "dEiQMJ0OEypEf8zPqfVOUKd3RK8TAvVO"
	// latitude := 22.5969
	// longitude := 113.9981

	// locationInfo, err := getLocationInfo(apiKey, latitude, longitude)
	// if err != nil {
	// 	logger.Debug("failed to get location info: %v", err)
	// }
	// fmt.Printf("locationInfo = %+v", locationInfo)
	// msg := fmt.Sprintf("%s%s%s%s", locationInfo.City, locationInfo.District, locationInfo.Town, locationInfo.Street)
	// logger.Debug("msg = ", msg)

	locationInfo, err := getLocationInfoFree(longitude, latitude)
	if err != nil {
		logger.Debug("failed to get location info: %v", err)
	}
	return locationInfo
}

type SpatialReference struct {
	Wkid       int `json:"wkid"`
	LatestWkid int `json:"latestWkid"`
}

type Location struct {
	X                float64          `json:"x"`
	Y                float64          `json:"y"`
	SpatialReference SpatialReference `json:"spatialReference"`
}

type Address struct {
	LongLabel   string `json:"LongLabel"`
	AddrType    string `json:"Addr_type"`
	CountryCode string `json:"CountryCode"`
}

type ArcgisResponse struct {
	Address  Address  `json:"address"`
	Location Location `json:"location"`
}

func getLocationInfoFree(lng, lat float64) (string, error) {

	url := fmt.Sprintf("https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/reverseGeocode?f=json&langCode=zh-CN&location=%f,%f&outFields=LongLabel,Addr_type,CountryCode&featureTypes=",
		lng, lat)
	resp, err := http.Get(url)
	if err != nil {
		return "", fmt.Errorf("failed to make request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("bad status: %s", resp.Status)
	}
	var baiduResp ArcgisResponse
	if err := json.NewDecoder(resp.Body).Decode(&baiduResp); err != nil {
		return "", fmt.Errorf("failed to decode response: %v", err)
	}
	return baiduResp.Address.LongLabel, nil
}
