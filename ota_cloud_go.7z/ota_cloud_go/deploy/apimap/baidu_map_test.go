package apimap

import (
	"testing"
)

func Test(t *testing.T) {
	startlon := 113.9980
	startla := 22.5970

	endlon := 113.9981
	endla := 22.5969

	startsite := GetSite(startlon, startla)
	endSite := GetSite(endlon, endla)
	t.Log("startsite = ", startsite)
	t.Log("endsite = ", endSite)
}
