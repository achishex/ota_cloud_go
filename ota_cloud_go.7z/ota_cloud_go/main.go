package main

import (
	"context"
	"cuav-cloud-go-service/config"
	"cuav-cloud-go-service/deploy/i18nlib"
	"cuav-cloud-go-service/domain/service/alarm_service"
	"cuav-cloud-go-service/domain/service/auto_counter_service"
	"cuav-cloud-go-service/domain/service/countertask"
	"cuav-cloud-go-service/domain/service/cron_tasks"
	"cuav-cloud-go-service/domain/service/evidence_report"
	"cuav-cloud-go-service/domain/service/uav_record"
	"cuav-cloud-go-service/handler/requestHttp"
	"cuav-cloud-go-service/handler/requestRpc"
	pb "cuav-cloud-go-service/proto"
	"net"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	grpcc "github.com/go-micro/plugins/v4/client/grpc"
	_ "github.com/go-micro/plugins/v4/registry/kubernetes"
	grpcs "github.com/go-micro/plugins/v4/server/grpc"
	"github.com/nacos-group/nacos-sdk-go/v2/clients"
	"github.com/nacos-group/nacos-sdk-go/v2/clients/config_client"
	"github.com/nacos-group/nacos-sdk-go/v2/clients/naming_client"
	"github.com/nacos-group/nacos-sdk-go/v2/common/constant"
	"github.com/nacos-group/nacos-sdk-go/v2/vo"
	"go-micro.dev/v4"
)

var (
	name    = "cuav-cloud-go-service"
	version = "1.0.0"
)
var NamingClient naming_client.INamingClient
var ConfigClient config_client.IConfigClient

// main godoc
// @title CuavCloudGoService API
// @version 1.0
// @description This is a server CuavCloudGoService server.
// @contact.name API Support
// @contact.url http://www.swagger.io/support
// @contact.email A23542@autel.com
// @host localhost:8902
// @BasePath /
func main() {
	config.InitLog()

	// 读取配置
	config.InitConfig("/opt/cloud/service/cuav-cloud-go-service/config/application-dev.yml")
	i18nlib.InitI18n()

	//服务注册到nacos
	NacosSetup()

	logger.Info("config.GetConfig().Nacos.ServerAddr", config.GetConfig().Nacos.ServerAddr)

	// 初始化资源
	initResource()
	uav_record.InitUavFlyHandler()

	defer config.CloseDB(config.GetDB())

	//Create service
	srv := micro.NewService(
		micro.Server(grpcs.NewServer()),
		micro.Client(grpcc.NewClient()),
		micro.WrapHandler(requestRpc.NewGrpcAccessWrapper()),
	)
	opts := []micro.Option{
		micro.Name(name),
		micro.Version(version),
		micro.Address(config.Address()),
	}

	srv.Init(opts...)

	// Register handler
	if err := pb.RegisterCuavCloudGoServiceHandler(srv.Server(), requestRpc.NewCuavCloudGoService()); err != nil {
		logger.Fatal(err)
	}
	requestRpc.InitGrpcRouter()

	go uav_record.UavRecordStrategyRunV2()
	go uav_record.DoRcvMqttMsg()

	ctx, cancelFn := context.WithCancel(context.Background())
	alarm_service.InitRes(ctx)
	auto_counter_service.InitRes(ctx)
	countertask.InitRes(ctx)
	evidence_report.InitRes(ctx)

	go func() {
		cron_tasks.CreateAlarmTaskDeleteOnTimePoint(ctx, 01, 0, 0, -1)
	}()
	go cron_tasks.TaskTimeOutCancalOnTimePoint(ctx, 0, 0, 10)
	defer cancelFn()

	go requestHttp.InitRoute()

	cron_tasks.InitInvalidAlarmCache(ctx)

	// Run service
	if err := srv.Run(); err != nil {
		logger.Fatal(err)
	}

}

// ============= nacos初始化 ============

func NacosSetup() {
	sc := []constant.ServerConfig{
		// *constant.NewServerConfig("cuav-base-nacos-cs", uint64(config.GetConfig().Nacos.Port), constant.WithContextPath("/nacos")),
		*constant.NewServerConfig(config.GetConfig().Nacos.ServerAddr, uint64(config.GetConfig().Nacos.Port), constant.WithContextPath("/nacos")),
	}

	cc := *constant.NewClientConfig(
		constant.WithNamespaceId("public"),
		constant.WithTimeoutMs(5000),
		constant.WithNotLoadCacheAtStart(true),
	)

	client, _ := clients.NewNamingClient(
		vo.NacosClientParam{
			ClientConfig:  &cc,
			ServerConfigs: sc,
		},
	)
	configClient, _ := clients.NewConfigClient(
		vo.NacosClientParam{
			ClientConfig:  &cc,
			ServerConfigs: sc,
		},
	)
	ConfigClient = configClient
	NamingClient = client
	// 注册服务
	registerServiceInstance(client, vo.RegisterInstanceParam{
		Ip:          getHostIp(),
		Port:        uint64(config.GetConfig().ConnectPort.NacosPort),
		ServiceName: name,
		Weight:      10,
		Enable:      true,
		Healthy:     true,
		Ephemeral:   true,
	})
}

// 获取本机ip地址
func getHostIp() string {
	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		logger.Error("get current host ip err: ", err)
		return ""
	}
	addr := conn.LocalAddr().(*net.UDPAddr)
	ip := strings.Split(addr.String(), ":")[0]
	return ip
}

// 注册服务
func registerServiceInstance(nacosClient naming_client.INamingClient, param vo.RegisterInstanceParam) {
	success, err := nacosClient.RegisterInstance(param)
	if !success || err != nil {
		panic("register Service Instance failed!")
	}
}

func initResource() {
	// 初始化数据库
	_, err := config.InitDB()
	if err != nil {
		logger.Fatalf("InitSqlite err %v", err)
		return
	}
	config.InitRedis()
}
