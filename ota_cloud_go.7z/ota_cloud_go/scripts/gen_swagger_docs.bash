#! /usr/bin/env bash
go install github.com/swaggo/swag/cmd/swag@latest
swag init -g main.go